# ASRP-Saltstack
Salt States for ASRP application and tools

echo -E "[hubblestack]
name=CST Hubble repo
enabled=1
baseurl=http://repo.loc.adobe.net/yum/centos/6.8/techops/prod/x86_64/
gpgcheck=0" >> /etc/yum.repos.d/hubblestack.repo
yum install -y hubblestack-2.4.1 ; service hubble stop
echo "

hubblestack:
  returner:
    splunk:
      - token: 9128549A-C6E0-4A4F-80E5-14C45879B619
        indexer: splunk-hec-ext.adobe.net
        index: soco_hubble
        sourcetype_nova: hubble_audit
        sourcetype_nebula: hubble_osquery
        sourcetype_pulsar: hubble_fim
" > /etc/hubble/hubble.d/soco.conf

service hubble start