#!/usr/bin/bash
wget http://mirrors.fibergrid.in/apache/zookeeper/zookeeper-3.4.10/zookeeper-3.4.10.tar.gz
tar -xzf zookeeper-3.4.10.tar.gz
mkdir /usr/local/zookeeper
chown solr:solr /usr/local/zookeeper