mkdir -p asrp/conf
cp -rf sample_techproducts_configs/conf/* asrp/conf/
