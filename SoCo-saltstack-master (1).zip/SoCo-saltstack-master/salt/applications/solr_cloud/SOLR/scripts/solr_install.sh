#!/usr/bin/bash
wget https://archive.apache.org/dist/lucene/solr/7.0.0/solr-7.0.0.tgz
tar xzf solr-7.0.0.tgz solr-7.0.0/bin/install_solr_service.sh --strip-components=2
sudo bash ./install_solr_service.sh solr-7.0.0.tgz -n
chown -R solr:solr /opt/solr-7.0.0
exit 0