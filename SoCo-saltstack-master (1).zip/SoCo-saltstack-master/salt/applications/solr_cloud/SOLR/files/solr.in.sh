
ZK_HOST="10.90.244.246:2181,10.90.245.27:2181"

SOLR_HOST="{{grains['fqdn_ip4']}}"

SOLR_PID_DIR="/usr/local/solr"
SOLR_HOME="/usr/local/solr/data"
LOG4J_PROPS="/usr/local/solr/log4j.properties"
SOLR_LOGS_DIR="/usr/local/solr/logs"
SOLR_PORT="8983"

