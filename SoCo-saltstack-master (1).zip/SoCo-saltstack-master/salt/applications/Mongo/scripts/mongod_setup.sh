#!/usr/bin/bash
mkdir -p mongo/data
mkdir -p mongo/logs
chmod -R 755 mongo/
chown -R mongod:mongod mongo/
service mongod start
chkconfig mongod on
