#!/usr/bin/bash
chown -R apache:apache ../soco_social_api
chmod -R 755 ../soco_social_api
php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
php composer-setup.php --install-dir=bin --filename=composer
exit 0