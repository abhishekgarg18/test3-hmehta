#!/usr/bin/bash
php bin/composer require mongodb/mongodb
mkdir -p logs/soco
chown -R apache:apache ../soco_social_api
chmod -R 755 ../soco_social_api