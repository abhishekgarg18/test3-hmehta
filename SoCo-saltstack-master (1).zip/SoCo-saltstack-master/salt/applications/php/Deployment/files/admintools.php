<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/
$APP_DIR = realpath(__DIR__ . '/../bin/Soco/');
require_once $APP_DIR . '/Config/Service.php';
Soco\Config\Service::bootstrap(false);
require '../vendor/autoload.php';
require_once $APP_DIR . '/Lib/Validator/iValidator.php';
require_once $APP_DIR . '/Lib/Validator/Validator.php';
require_once $APP_DIR . '/Lib/Validator/ReportSuiteValidator.php';
require_once $APP_DIR . '/Lib/Validator/EnvelopeValidator.php';
require_once $APP_DIR . '/Lib/Validator/BatchEnvelopeValidator.php';
require_once $APP_DIR . '/Lib/Validator/AttachmentValidator.php';
require_once $APP_DIR . '/Model/Loggable.php';
require_once $APP_DIR . '/Model/iCache.php';
require_once $APP_DIR . '/Model/Memcache.php';
require_once $APP_DIR . '/Model/Company.php';
require_once $APP_DIR . '/Model/DocumentStore.php';
require_once $APP_DIR . '/Model/SolrClient.php';
require_once $APP_DIR . '/RouteHandler/AdminTools.php';
require_once $APP_DIR . '/Lib/OAuth.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/LogWriter.php';
require_once $APP_DIR . '/Lib/LogWriter.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/MethodOverride.php';
require_once $APP_DIR . '/Lib/Middleware/TokenValidationMiddleware.php';
require_once $APP_DIR . '/Lib/SocoException.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Environment.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Helper/Set.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Response.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/Flash.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/PrettyExceptions.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Route.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Router.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Headers.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Request.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Cookies.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Util.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Log.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/View.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Exception/Stop.php';

use Soco\Model\Memcache;
use Soco\Lib\LogWriter;
use \Slim\Log;
$config = Soco\Config\Service::config();

$log_fh = fopen($config['log']['filename'], 'a');
$log_writer = new LogWriter($log_fh);

$app = new Slim\Slim(array(
    'log.writer'  => $log_writer,
    'log.enabled' => $config['log']['enabled'],
    'log.level'   => $config['log']['level'],
    'debug'       => false,
    'templates.path' => '../bin/Soco/Template/',
    'environment' => $config
));

// convert all the command line arguments into a URL
$argv = $GLOBALS['argv'];
array_shift($GLOBALS['argv']);
$pathInfo = '/' . implode('/', $argv);

// Set up the environment so that Slim can route
$app->environment = Slim\Environment::mock([
    'PATH_INFO'   => $pathInfo
]);

$app->container->singleton('memcache', function() use ($config, $app) {
    $memcache = new Memcache($config['memcache']);
    $memcache->setLogger($app->getLog());
    return $memcache;
});

$app->error(function (\Exception $e) use ($app) {
    $error_code = $e->getCode() != 0 ? $e->getCode() : 500;
    $app->response()->status($error_code);

    $response = new \stdClass();
    $response->result = false;
    $response->error_message = $e->getMessage();
    $app->response()->body(sprintf('%s', json_encode($response)));
    $app->getLog()->fatal(sprintf('Exception="%s" Message="%s" Code="%s" StackTrace="%s"',get_class($e), $e->getMessage(), $e->getCode(), $e->getTraceAsString()));
});

$app->group('/v1', function() use ($app) {

            $app->get('/:report_suite/restoreSolr',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\AdminTools", "RepopulateSolr")
            )
                ->name("Repopulate Solr");
/*              This is the function to use if we have to completely rebuild solr from content in mongo
                To invoke, call from the command line like:

                php admintools.php v1 REPORTSUITE restoreSolr

                (replace REPORTSUITE with the report suite being re-indexed in solr)
*/
});
/**
 * The following section must be filled out manually before this function can be executed.
 */
$company['company'] = ''; // Name of the company as provisioned via ASRP provisioning
$company['solr_endpoint'] = 'http://example.com:8983/solr/'; // URL of Solr endpoint
$company['solr_collection'] = ''; // Solr Collection name which would receive all updated indexes
$company['report_suites'] = array(''); // list of report suites which are allowed to be processed by this script. This list would be used for validation only.
$company['startDate']="2014-01-01"; // startDate - data starting from which date should be reindexed ; format = yyyy-mm-dd; default date is set = 2014-01-01
$company['endDate']="2017-12-31"; // endDate - data till what date should be reindexed ; format = yyyy-mm-dd; default date is set = 2017-12-31
$company['timezone']="America/Los_Angeles"; //timeZone String for the DC where this script would be used; default set to US pacific time zone.
$company['solrBatchSize']=50;
// Oregon (Pacific Time) - America/Los_Angeles
//  Dallas (Central Time) - America/Chicago
//London (Europe)- Europe/London
// Singapore (APAC) - Asia/Singapore
// refer - http://php.net/manual/en/timezones.php

$app->company = $company;

/**
 * Un-comment $app->run(); when ready to execute and confirm all the data set properly in $company object
 */
// $app->run();
