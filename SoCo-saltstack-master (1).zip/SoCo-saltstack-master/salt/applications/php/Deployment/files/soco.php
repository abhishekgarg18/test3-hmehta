<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
/*
 * Cory Aitchison
 * caitchis@adobe.com
 *
 * Description is a function I added to the \Slim\Route object.  If we ever upgrade SLIM this will need to be re-added
 */
$APP_DIR = realpath(__DIR__ . '/../bin/Soco/');
require_once $APP_DIR . '/Config/Service.php';
Soco\Config\Service::bootstrap(false);
require '../vendor/autoload.php';
require_once $APP_DIR . '/Lib/Validator/iValidator.php';
require_once $APP_DIR . '/Lib/Validator/Validator.php';
require_once $APP_DIR . '/Lib/Validator/ReportSuiteValidator.php';
require_once $APP_DIR . '/Lib/Validator/EnvelopeValidator.php';
require_once $APP_DIR . '/Lib/Validator/BatchEnvelopeValidator.php';
require_once $APP_DIR . '/Lib/Validator/AttachmentValidator.php';
require_once $APP_DIR . '/Model/Loggable.php';
require_once $APP_DIR . '/Model/iCache.php';
require_once $APP_DIR . '/Model/Memcache.php';
require_once $APP_DIR . '/Model/Company.php';
require_once $APP_DIR . '/Model/DocumentStore.php';
require_once $APP_DIR . '/Model/SolrClient.php';
require_once $APP_DIR . '/RouteHandler/Document.php';
require_once $APP_DIR . '/RouteHandler/Children.php';
require_once $APP_DIR . '/RouteHandler/Attachment.php';
require_once $APP_DIR . '/RouteHandler/Attachments.php';
require_once $APP_DIR . '/RouteHandler/Heartbeat.php';
require_once $APP_DIR . '/RouteHandler/Search.php';
require_once $APP_DIR . '/Lib/OAuth.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/LogWriter.php';
require_once $APP_DIR . '/Lib/LogWriter.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/MethodOverride.php';
require_once $APP_DIR . '/Lib/Middleware/TokenValidationMiddleware.php';
require_once $APP_DIR . '/Lib/SocoException.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Environment.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Helper/Set.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Response.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/Flash.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Middleware/PrettyExceptions.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Route.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Router.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Headers.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Request.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Cookies.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Http/Util.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Log.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/View.php';
require_once $APP_DIR . '/Lib/vendor/slim/Slim/Exception/Stop.php';

use Soco\Model\Memcache;
use Soco\Lib\LogWriter;
$start = microtime(true);
$config = Soco\Config\Service::config();

$log_fh = fopen($config['log']['filename'], 'a');
$log_writer = new LogWriter($log_fh);

$app = new Slim\Slim(array(
	'log.writer'  => $log_writer,
	'log.enabled' => $config['log']['enabled'],
	'log.level'   => $config['log']['level'],
	'debug'       => false,
	'templates.path' => '../bin/Soco/Template/',
	'environment' => $config
));

$app->container->singleton('memcache', function() use ($config, $app) {
	$memcache = new Memcache($config['memcache']);
	$memcache->setLogger($app->getLog());
	return $memcache;
});

$app->error(function (\Exception $e) use ($app) {
	$error_code = $e->getCode() != 0 ? $e->getCode() : 500;
	$app->response()->status($error_code);

	$response = new \stdClass();
	$response->result = false;
	$response->error_message = $e->getMessage();
	$app->response()->body(sprintf('%s', json_encode($response)));
    $app->getLog()->fatal(sprintf('Exception="%s" Message="%s" Code="%s" Path="%s" StackTrace="%s"',get_class($e),
        $e->getMessage(), $e->getCode(), $_SERVER['REQUEST_URI'], $e->getTraceAsString()));
});

$app->add(new \Soco\Lib\Middleware\TokenValidationMiddleware());

// ============== Help Routes =================
$app->get('/', function() {
	$app = \Slim\Slim::getInstance();

	$app->render(
		'api_help.php',
		array('app' => $app)
	);
});

$app->group('/v1', function() use ($app) {

    switch($_SERVER['REQUEST_METHOD']) {
        case "GET":
            // ================ Heartbeat Routes ================
            $app->get('/heartbeat',
                array("\\Soco\\RouteHandler\\Heartbeat", "checkHeartbeat")
            )
                ->name("Heartbeat: Check basic API functionality")
                ->description("Verify the API is available");

            // ================ Children Routes =================

            $app->get('/:report_suite/count/children/:parent_provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Children", "CountChildren")
            )
                ->name("Children:Get Number of Children")
                ->description("Get number of children of a post");

            $app->get(
                '/:report_suite/children/:parent_provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Children", "GetChildren")
            )
                ->name("Children:Get Children")
                ->description("Get children of a post");

            // ============== Document Routes =================

            $app->get('/:report_suite/document/:provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "GetDocument")
            )
                ->name("Document:Get Document")
                ->description("Get a document");

            $app->get('/:report_suite/documentIndex',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "GetDocumentIndex")
            )
                ->name("Document:Get Document index")
                ->description("Get a document index");

            // ============== Attachment Routes =================
            // attachment
            $app->get('/:report_suite/attachment/download/:provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachment", "DownloadAttachment")
            )
                ->name("Attachment: Download")
                ->description("Get the actual attachment data");

            $app->get('/:report_suite/attachment/:provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachment", "GetAttachment")
            )
                ->name("Attachment: Get Attachment")
                ->description("Get an attachment's metadata");
            $app->get('/:report_suite/attachments/:name+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachments", "ListAttachments")
            )
                ->name("Attachment: List")
                ->description("Get a list of all available attachments");

            // ============== Search Routes =================

            $app->get('/search/',
                array("\\Soco\\RouteHandler\\Search", "DoSearch")
            )
                ->name("Search:Search")
                ->description("Lucene search");

            $app->get('/mlt/',
                array("\\Soco\\RouteHandler\\Search", "DoMLTSearch")
            )
                ->name("Search:MLTSearch")
                ->description("Lucene MLT search");
            break;
        case "POST":

            // ============== Document Routes =================
            $app->post('/:report_suite/documentBatch/',
                array("\\Soco\\Lib\\Validator\\BatchEnvelopeValidator", "ValidateApp"),
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "CreateDocuments")
            )
                ->name("Document:Create Batched Documents")
                ->description("Add batched documents. See https://git.corp.adobe.com/AdobeSocial/soco_social_api/wiki/Schema for the document schema.");

            $app->post('/:report_suite/document/',
                array("\\Soco\\Lib\\Validator\\EnvelopeValidator", "ValidateApp"),
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "CreateDocument")
            )
                ->name("Document:Create Document")
                ->description("Add a new document. See https://git.corp.adobe.com/AdobeSocial/soco_social_api/wiki/Schema for the document schema.");

            $app->post('/:report_suite/documentBatch/GET',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "GetDocuments")
            )
                ->name("Document:Get Batched Documents")
                ->description("Get batched documents");

            $app->post('/:report_suite/documentBatch/DELETE',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "DeleteDocuments")
            )
                ->name("Document:Delete Batched Documents")
                ->description("Delete batched documents");

            $app->post('/documentBatch/COMMIT',
                array("\\Soco\\Lib\\Validator\\BatchEnvelopeValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "BatchCommit")
            )
                ->name("Document:Perform a set of batch operations")
                ->description("Add batched documents. See https://git.corp.adobe.com/AdobeSocial/soco_social_api/wiki/Schema for the document schema.");

            // ============== Attachment Routes =================

            $app->post('/:report_suite/attachment/:name+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\Lib\\Validator\\AttachmentValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachment", "CreateAttachment")
            )
                ->name("Attachment: Create Attachment")
                ->description("Adds attachments to a document");

            // ================ Children Routes =================

            $app->post('/:report_suite/count/children',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Children", "BatchCountChildren")
            )
                ->name("Children:Get Number of Children for Multiple Parents")
                ->description("Get number of children of multiple posts");
            break;

        case "PUT":

            // ============== Document Routes =================
            $app->put('/:report_suite/documentBatch/',
                array("\\Soco\\Lib\\Validator\\BatchEnvelopeValidator", "ValidateApp"),
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "UpdateDocuments")
            )
                ->name("Document:Update Batched Documents")
                ->description("Update batched documents");

            $app->put('/:report_suite/document/:provider_id+',
                array("\\Soco\\Lib\\Validator\\EnvelopeValidator", "ValidateApp"),
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "UpdateDocument")
            )
                ->name("Document:Update Document")
                ->description("Update a document");

            break;

        case "DELETE":

            // ============== Document Routes =================
            $app->delete('/:report_suite/document/:provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Document", "DeleteDocument")
            )
                ->name("Document:Delete Document")
                ->description("Delete a document");

            $app->delete('/:report_suite/attachment/:provider_id+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachment", "DeleteAttachment")
            )
                ->name("Attachment: Delete Attachment")
                ->description("Delete an attachment associated with a document");

            $app->delete(
                '/:report_suite/attachments/:name+',
                array("\\Soco\\Lib\\Validator\\ReportSuiteValidator", "ValidateApp"),
                array("\\Soco\\RouteHandler\\Attachments", "DeleteAttachments")
            )
                ->name("Attachment: Delete Attachments for a Document")
                ->description("Delete an attachment associated with a document");
            break;
    }
});
$app->run();
if ($config['log']['level'] >= LOG_DEBUG) {
    $total = microtime(true) - $start;
    if ($total > 10) {
        $app->getLog()->critical("Total Processing Time = " . $total . ", request was: " . $_SERVER['REQUEST_URI'],
            array());
    } else if ($total > 1) {
        $app->getLog()->error("Total Processing Time = "  . $total . ", request was: " . $_SERVER['REQUEST_URI'],
            array());
    } else if ($total > 0.2) {
        $app->getLog()->warn("Total Processing Time = " . $total, array());
    }
    $app->getLog()->notice("Total Processing Time = " . $total, array());
}
