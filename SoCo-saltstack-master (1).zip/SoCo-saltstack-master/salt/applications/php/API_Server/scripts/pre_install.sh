#!/usr/bin/bash
mount -o remount,exec /var/tmp/
yum -y install http://rpms.remirepo.net/enterprise/remi-release-7.rpm
yum-config-manager --enable remi-php72
yum -y --enablerepo=extras install centos-release-scl
yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
yum --enablerepo=remi,remi-php72 -y install php php-pear  php-devel