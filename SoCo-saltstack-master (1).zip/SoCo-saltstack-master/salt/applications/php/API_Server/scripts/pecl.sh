#!/usr/bin/bash
scl enable httpd24 bash
pecl channel-update pecl.php.net
pecl uninstall mongodb
pecl install mongodb