#!/bin/bash

sed -i '/^idm_installed_date/d' /etc/salt/grains

idm_mod_date=`date +'%m-%d-%y' -r /etc/sssd/sssd.conf`
echo "idm_installed_date: "$idm_mod_date >> /etc/salt/grains
