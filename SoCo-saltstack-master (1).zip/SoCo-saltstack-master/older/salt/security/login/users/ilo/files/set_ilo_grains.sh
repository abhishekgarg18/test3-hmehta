#!/bin/bash


ilo_type=`hponcfg | grep Firmware | cut -d ' ' -f8,9 `
ilo_version=`hponcfg | grep Firmware | cut -d ' ' -f4`

echo "ilo_type: " $ilo_type >> /etc/salt/grains
echo "ilo_version: " $ilo_version >> /etc/salt/grains

