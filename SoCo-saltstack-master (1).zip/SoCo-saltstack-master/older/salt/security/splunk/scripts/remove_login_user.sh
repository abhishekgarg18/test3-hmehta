#!/bin/bash
passwd -l splunk
usermod --expiredate 1 splunk
usermod -s /sbin/nologin splunk

