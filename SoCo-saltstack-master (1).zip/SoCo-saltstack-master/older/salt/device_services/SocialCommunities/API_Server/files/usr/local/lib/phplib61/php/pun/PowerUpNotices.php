<?php
require_once "application.inc";
require_once "pun/services/LatencyService.php";
require_once "pun/services/IdentityService.php";
require_once "pun/services/LatencyNoticeService.php";
require_once "pun/services/LatencyNoticeDefinitionService.php";
require_once "pun/services/LatencyEventService.php";
require_once "pun/services/LatencyEventDefinitionService.php";
require_once "pun/services/NotificationService.php";
require_once "pun/services/ConfigService.php";
require_once "pun/services/IdentityService.php";
require_once "pun/model/LatencyNotice.php";
require_once "pun/model/LatencyNoticeDefinition.php";
require_once "pun/model/LatencyEvent.php";
require_once "pun/model/LatencyEventDefinition.php";
require_once "pun/model/LatencyEventDefinitionSelector.php";
require_once "pun/model/Login.php";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

$powerUpNotices = new PowerUpNotices();
$powerUpNotices->setParamsFromDatabase();
$powerUpNotices->parseCommandlineArguments($argv);  // commandline will override what is in the config database 
$powerUpNotices->checkLatency();

/**
 * This is the main application for PowerUp Notices. This is intended to run at a certian time interval. It will check latency
 * for all configured report suites and send the appropriate notification.
 *
 */
class PowerUpNotices
{

	private $log;
	private $identityService;
	private $latencyNoticeDefinitionService;
	private $latencyNoticeService;
	private $latencyEventService;
	private $latencyEventDefinitionService;
	private $latencyService;
	private $notificationService;
	private $configService;
	private $preNotificationLatencyTime = 30; // 1/2 hour
	private $allClearTime = 120; 	// two hours in minutes
	private $sendExternalEmails = FALSE;
	private $enforceEligibility = FALSE;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
		$this->identityService = new IdentityService();
		$this->latencyNoticeDefinitionService = new LatencyNoticeDefinitionService();
		$this->latencyNoticeService = new LatencyNoticeService();
		$this->latencyEventService = new LatencyEventService();
		$this->latencyEventDefinitionService = new LatencyEventDefinitionService();
		$this->latencyService = new LatencyService();
		$this->notificationService = new NotificationService();
		$this->configService = new ConfigService();
	}
	
	/**
	 * This is the main function for scheduled checks of latency. First this method will check for any short circuits to skip the 
	 * current rsid (rsid not configured, in a Hold state, not enough time since the last notification email ect...)
	 * 
	 * It will check for pre-latency for internal notification
	 * 
	 * It will check for latency and determine if it should send a notification and why kind of notification it should send.
	 * 
	 */
	public function checkLatency()
	{
		if(!$this->configService->isLatencyMonitoringEnabled())
		{
			$this->log->info("Latency monitoring is not enabled. Check database setting.");
			return;
		}
		
		$startTime = time();
		$noticeDefs = $this->latencyNoticeDefinitionService->getLatencyNoticeDefinitions(new LatencyNoticeDefinitionSelector(),false);
		$preLatentEvents = array();
		
		$eligibleUserids = $this->configService->getEligibleUserids();
		
		$this->log->info("Start checking latency for ".sizeof($noticeDefs)." login companies.\r\n\r\n");
		
		foreach($noticeDefs as $noticeDef)
		{
			$companyName = $noticeDef->getLoginCompanyName(); 
			$companyId = $noticeDef->getLoginCompanyId();
			$this->log->info("***********************************************************************************************************");
			$this->log->info("Checking latency for configured usernames in login company $companyName");
			if($noticeDef->getNotifyState() == 'Hold')
			{
				$this->log->info("Login Company ".$companyName." is not configured to send notifications. Skipping\r\n\r\n");
				continue;
			}
			
			$lastLatencyNotice = $this->latencyNoticeService->getLastLatencyNotice($companyId);
			$okayToEmail = (is_null($lastLatencyNotice)) ? true : $this->isOkayToEmail($lastLatencyNotice,$noticeDef->getEmailFrequency(),$companyName);

			$selector = new LatencyEventDefinitionSelector();
			$selector->setNoticeDefId($noticeDef->getID());
			$eventDefs = $this->latencyEventDefinitionService->getLatencyEventDefinitions($selector);
			$this->log->info("Start checking latency for ".sizeof($eventDefs)." report suites for login company ".$companyName);
			
			$allEvents = $this->getLatencyEventsForSuites($eventDefs, $okayToEmail, $lastLatencyNotice, $noticeDef, $eligibleUserids);
			
			$events = $allEvents["events"];
			$preLatentEvents = array_merge($preLatentEvents,$allEvents["preLatentEvents"]);
			$this->log->debug(sizeof($events)." latency events created for $companyName");			
			$this->log->debug(sizeof($preLatentEvents)." pre latency events created for $companyName");			
			
			if(sizeof($events) > 0)
			{
				$this->log->debug("Creating notice for login company ".$companyName." with ".sizeof($events)." latency events");
				$this->createNotice($noticeDef, $events, 1);
			}
				
			$this->log->info("Done checking latency for configured usernames in login company $companyName\r\n\r\n");
		}
		if(sizeof($preLatentEvents) > 0)
		{
			$scVersions = array();
			if($this->latencyEventService->hasLatencyEventsForSiteCatalystVersion($preLatentEvents,14))
			{
				$scVersions[] = 14;
			}
			if($this->latencyEventService->hasLatencyEventsForSiteCatalystVersion($preLatentEvents,15))
			{
				$scVersions[] = 15;
			}
			$haDef = $this->getInternalNoticeDef($scVersions);
			$this->log->debug("Creating pre latency notice for ".$haDef->getLoginCompanyName()." with ".sizeof($events)." latency events");
			$this->createNotice($haDef, $preLatentEvents, 1,4);
		}
		
		$totalTime = round((time() - $startTime) /60,2);
		$this->log->info("Done checking latency for ".sizeof($noticeDefs)." login companies in $totalTime minutes.");
	}
	
	/**
	 * Loops through all of the configured event defs (report suites) for a login company. Gathers all latency events, including
	 * pre latent events and returns them in an array of arrays.
	 *  
	 * @param array $eventDefs
	 * @param boolean $okayToEmail
	 * @param LatencyNotice $lastLatencyNotice
	 * @param LatencyNoticeDefinition $noticeDef
	 */
	public function getLatencyEventsForSuites($eventDefs, $okayToEmail, $lastLatencyNotice, $noticeDef, $eligibleUserids)
	{
		$retVal = array();
		$retVal["events"] = array();
		$retVal["preLatentEvents"] = array();
		
		foreach($eventDefs as $eventDef)
		{
			$userid = $eventDef->getUserid();
			$username =$eventDef->getUsername();
			$this->log->info("**********************************");
			$this->log->info("Checking latency for $username");
			if($this->enforceEligibility && !in_array($userid,$eligibleUserids))
			{
				$this->log->info("$username is not eligible for latency monitoring.");
			}
			
			$isV15Rsid = $this->identityService->isV15Rsid($username);
			$scVersion = $isV15Rsid ? 15 : 14;
			$this->log->debug("Report suite $username is configured for SiteCatalyst version $scVersion");
			
			$threshold =  $noticeDef->getLatencyThreshold();
			$latencyThreshold =  $threshold * 60; // convert hours to minutes. 
			$this->log->debug("Latentcy threshold for $username is $latencyThreshold minutes.");
			
			$minutesLatent = $this->latencyService->getLatency($userid,$isV15Rsid);  
			$this->log->debug("Report suite $username is $minutesLatent minutes latent");
			
			$inLatentState = $this->latencyNoticeService->isUserCurrentlyLatent($username);
			$str = $inLatentState ?"True" : "False";
			$this->log->debug("Current latent state for suite $username is $str");
			
			if($this->inPrenotificationWindow($minutesLatent, $latencyThreshold) && !$inLatentState)
			{
				if($this->isOkayToPreNotify($username))
				{
					$retVal["preLatentEvents"][] = $this->createLatencyEvent($eventDef,$minutesLatent,4,$scVersion);
					$this->log->info("Pre-Latency event created for $username. $minutesLatent minutes latent.\r\n\r\n");
					$this->log->info("Done checking latency for suite $username");
				}
				continue;
			}

			// Short circuit
			if(! $okayToEmail)
			{
				$this->log->debug("Not okay to email.");
				$this->log->info("Done checking latency for suite $username");
				continue;
			}
			
			$minutesSinceLastEmail = $this->getMinutesSinceLastNotice($lastLatencyNotice);				
			if($minutesLatent >= $latencyThreshold)
			{
				$this->log->info("Suite $username is over the configured latency threshold of $latencyThreshold minutes. It is $minutesLatent minutes latent.");
				$eventType = ($inLatentState) ? 2 : 1;  // type 1 == new latency, type 2 == continuing latency
				$retVal["events"][] = $this->createLatencyEvent($eventDef,$minutesLatent,$eventType,$scVersion);
				$this->log->info("Latency event created for $username.");
			}
			else if($inLatentState && ($minutesSinceLastEmail > ($this->allClearTime)))
			{
				// If they are not currently latent, but still in a latent state, create a 'no longer latent' event if enough time has passed.
				$retVal["events"][] = $this->createLatencyEvent($eventDef,0,3,$scVersion);
				$this->log->info("Suite $username is no longer latent. End of latency incident event created.");
			}
			
			$this->log->info("Done checking latency for suite $username");
		}
		return $retVal;		
	}
	
	/**
	 * Creates a new LatencyNotification record in the database and sends out the emails for the notification.
	 * 
	 * @param LatencyNotificationdefinition $noticeDef
	 * @param latencyNoticeDefinition $noticedef
	 * @param array $events
	 * @param int $emailVersion
	 * @param int $emailType
	 */
	public function createNotice(LatencyNoticeDefinition $noticeDef, array $events, $emailVersion, $noticeType = 0)
	{
		$latencyNotice = new LatencyNotice();
		$latencyNotice->setDefId($noticeDef->getID()); 
		$latencyNotice->setEmailVersion($this->configService->getCurrentTemplateVersion($emailVersion));
		$latencyNotice->setCc($noticeDef->getAdobeEmail());
		$latencyNotice->setBcc($noticeDef->getHaEmail());
		$latencyNotice->setLatencyEvents($events);
		$latencyNotice->setLoginCompany($noticeDef->getLoginCompanyName());
		$latencyNotice->setLoginCompanyId($noticeDef->getLoginCompanyId());
		
		// type for is an internal only pre latency notice type
		if($noticeType == 4)
		{
			$logins = array();
			$login = new Login();
			if($this->latencyEventService->hasLatencyEventsForSiteCatalystVersion($latencyNotice->getLatencyEvents(),14))
			{
				$login->setEmail($this->configService->getV14PagerContacts());
			}	
			else if($this->latencyEventService->hasLatencyEventsForSiteCatalystVersion($latencyNotice->getLatencyEvents(),15))
			{
				$login->setEmail($this->configService->getV15OperationsContacts());
			}
			$logins[] = $login;
		}
		else
		{
			$logins = $this->identityService->getLoginsFromIDs($noticeDef->getCustomerLogins(),$noticeDef->getLoginCompanyId(),$noticeDef->getLoginCompanyName());
		}
		$customerEmails = array();
		foreach($logins as $login)
		{
			$customerEmails[] = $login->getEmail();
		}
		$customerEmails = implode(",",$customerEmails);
		$latencyNotice->setTo($customerEmails);
		$this->latencyNoticeService->saveLatencyNotice($latencyNotice);
		
		$this->notificationService->mailLatencyNotice($latencyNotice,$noticeDef->getEmailFrequency(),$logins);
	}
	
	public function createLatencyEvent(LatencyEventDefinition $eventDef, $minutesLatent, $eventType, $siteCatalystVersion)
	{
		$event = new LatencyEvent();
		$event->setDefId($eventDef->getEventDefId());
		$event->setUsername($eventDef->getUsername());
		$event->setUserId($eventDef->getUserid());
		$event->setLatency($minutesLatent);
		$event->setEventType($eventType);
		$event->setSiteCatalystVersion($siteCatalystVersion);
		
		return $event;
	}
	
	private function getLastNotificationTime(LatencyNotice $lastLatencyNotice)
	{
		return (! is_null($lastLatencyNotice)) ? $lastLatencyNotice->getSentTime() : NULL;
	}
	
	private function inPrenotificationWindow($minutesLatent, $latencyThreshold)
	{
		$retVal = ($minutesLatent < $latencyThreshold && ($minutesLatent >= ($latencyThreshold - ($this->preNotificationLatencyTime + 2))));  // Adds a two minute fudge factor for some timing issues.
		$v = $retVal ? "true" : "false";
		$this->log->debug("inPrenotificationWindow is returning $v.  minutes latent: $minutesLatent latency threshold: $latencyThreshold diff: ". ($latencyThreshold - $minutesLatent));
		return $retVal;
	}
	
	private function isOkayToPreNotify($username)
	{
		$retVal = true;
		$lastEvent = $this->latencyEventService->getMostRecentEvent($username);
		if(!is_null($lastEvent))
		{
			$interval = ( time() - strtotime($lastEvent->getEventTime()) ) / 60;  // If a notice of any kind was sent for the given username less than 2 hours ago, don't send a pre notice
			$this->log->debug("Interval since last event for $username is ". round($interval,0) ." minutes");
			$retVal = $interval >= $this->configService->getPreLatencyNoticeInterval(); 
		}
		$v = $retVal ? "true" : "false";
		$this->log->debug("isOkayToPreNotify is returning $v");
		return $retVal;
	}
	
	private function isOkayToEmail(LatencyNotice $lastNotice, $emailFrequency, $companyName)
	{
		$retVal = true;
		if(!is_null($lastNotice))
		{
			$lnt = $lastNotice->getSentTime();
			$lastNotificationTime = strtotime($lnt);
			$this->log->debug("Last notification time for company $companyName was $lnt");
			
			$emailInterval = $emailFrequency * 60;  // Convert to minutes
			$this->log->debug("Email interval for login company  is $emailInterval minutes");
			
			$currentTime = time();
			$minutesSinceLastEmail = round((($currentTime - $lastNotificationTime)/60),0)+5; // add a 5 minute fudge factor so timing issues are avoided 
			$this->log->debug("Minutes since last email notification: $minutesSinceLastEmail");
			
			if($minutesSinceLastEmail <= $emailInterval)
			{
				$this->log->info("Email interval has not expired for suite ".$companyName." Skipping.\r\n\r\n");
				$retVal = false;
			}
		}
		return $retVal;
	}
	
	private function getMinutesSinceLastNotice($lastNotice)
	{
		$retVal = NULL;
		if(! is_null($lastNotice))
		{
			$lastNotificationTime = strtotime($this->getLastNotificationTime($lastNotice));
			$retVal = time() - $lastNotificationTime +60; // add 60 second fudge factor 
		}
		return $retVal;
	}
	
	private function getInternalNoticeDef($scVersions)
	{
		global $localConfig;
		$currentDataCenter = $localConfig['data_center'];
		$noticeDef = new LatencyNoticeDefinition();
		$noticeDef->setLoginCompanyName($currentDataCenter);
		$noticeDef->setID(0);
		$adobeEmails = array();
		if(in_array(14,$scVersions))
		{
			$adobeEmails = array_merge($adobeEmails,explode(",",$this->configService->getV14OperationsContacts()));
			$this->log->debug("Adding version 14 internal contacts to pre latent notice");
		}
		if(in_array(15,$scVersions))
		{
			$adobeEmails = array_merge($adobeEmails,explode(",",$this->configService->getV15OperationsContacts()));
			$this->log->debug("Adding version 15 internal contacts to pre latent notice");
		}
		$noticeDef->setAdobeEmail(implode(",",$adobeEmails)); 
		return $noticeDef;
	}
	
	public function parseCommandlineArguments($argv)
	{
		$this->log->debug("Parsing command line arguments.");
		if ( count($argv) > 0 ) {
		
		    // If asking for help, ignore any errors in options they might have
		    if ( in_array( '-h', $argv ) || in_array( '--help', $argv ) ) 
		    {
		    	$this->display_usage();
				$this->log->info("Displayed help. Exiting");
		    	exit(0);
		    }
		
		    while ( count( $argv ) ) 
		    {
		        array_shift($argv);
		        $arg = $argv[ 0 ];
		        $optarg = $argv[ 1 ];
		        
		        switch( $arg ) 
		        {
		
		            case '-e':
		            case '--enforce_eligibility':
		            	$this->enforceEligibility = TRUE;
		            	$this->log->debug("Command line arg enforce_eligibility set to TRUE");
		                continue 2;
		
		            case '-s':
		            case '--send_external_emails':
		                $this->sendExternalEmails = TRUE;
		            	$this->log->debug("Command line arg send_external_emails set to TRUE");
		                continue 2;
		
		            case '-p':
		            case '--pre_notification_time':
		            	if(is_numeric($optarg))
		            	{
		            		$this->preNotificationLatencyTime = $optarg;
		            		$this->log->debug("Command line arg pre_notification_time set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for pre_notification_time");
		            		exit(1);
		            	}
		                array_shift( $argv );
		                continue 2;
		
		            case '-a':
		            case '--all_clear_time':
		            	if(is_numeric($optarg))
		            	{
		            		$this->allClearTime = $optarg;
		            		$this->log->debug("Command line arg all_clear_time set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for all_clear_time");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		            default:
		            	if(isset($arg))
		            	{
		            		$this->log->error("Unknown command line parameter $arg");
		            	}
		            	continue 2;
		            		
		        }
		    }
		}
	}
	
	public function setParamsFromDatabase()
	{
		$this->preNotificationLatencyTime = $this->configService->getPreNotificationlatencyTime();
		$this->allClearTime = $this->configService->getAllClearTime();
		$this->sendExternalEmails = $this->configService->useExtenalEmails();
		$this->enforceEligibility = $this->configService->enforceEligibility();
		$seeVal = ($this->sendExternalEmails)?'TRUE':'FALSE';
		$eeVal = $this->enforceEligibility?'TRUE':'FALSE';
		$this->log->debug("Parameters retrieved from config database: prelatency time: [$this->preNotificationLatencyTime] all celar time: [$this->allClearTime] send external emails: [$seeVal] enforce eligibility: [$eeVal]");
	}
	
	private function display_usage()
	{
		echo("-h --help \t\t\tPrints this help and exits.\r\n\r\n");
		echo("-e --enforce_eligibility \tInstructs the application to only check latency for report suites in the eligibility list in the database. \r\n\t\t\t\tDefault: FALSE \r\n\r\n");
		echo("-s --send_external_emails \tInstructs the application to send notice emails to external (non adobe.com) email addresses. \r\n\t\t\t\tDefault: FALSE \r\n\r\n");
		echo("-p --pre_notification_time \tThe amount of time before the configured latency threshold where the internal operations team is contacted with a pre latency event. \r\n\t\t\t\t(in minutes) Default: $this->preNotificationLatencyTime \r\n\r\n");
		echo("-a --all_clear_time \t\tThe amount of time that must pass with a report suite under the configured latency threshold before the no longer latent notice is sent. \r\n\t\t\t\t(in minutes) Default: $this->allClearTime \r\n\r\n");
		echo("\r\n\tNote: These command line parameters will override the corresponding values in the config_misc database\r\n");
	}
}
