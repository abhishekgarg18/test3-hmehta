<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade IMS_secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
/**
 * 
 * @author mgould
 *
 */
require_once 'Config.class.php';

class BertApiClient {
	private $config;
	private $ims; // IMS CURL Handle
	private $IMS_endpoint;
	private $ch; // Curl Handler
	private $endpoint;
	private $authToken;
	
	private $verbose;
	
	function __construct($verbose = false) {
		$this->verbose = $verbose;
		$this->config = new BertConfig('BertAPI');
		
		if ('' == ($this->IMS_endpoint = $this->config->IMS_endpoint))
			$this->IMS_endpoint = $this->config->IMS_endpoint = 'https://ims-na1-qa2.adobelogin.com/ims/token/v1';
				
		if ('' == ($this->server = $this->config->server))
			$this->server = $this->config->server = 'http://vm9443.ut1.omniture.com:18000';

		$this->ims = curl_init();
		
		$this->ch = curl_init();
		curl_setopt ($this->ch , CURLOPT_RETURNTRANSFER , 1 );
	}
	
	private function get_auth_header() {
		static $header = '';
		
		static $IMS_token_expire = 0;
		if (!$IMS_token_expire) $IMS_token_expire = $this->config->IMS_token_expire;
		
		static $IMS_token = '';
		if (!$IMS_token) $IMS_token = $this->config->IMS_token;
		
		static $IMS_client_id = '';
		if (!$IMS_client_id && !($IMS_client_id = $this->config->IMS_client_id))
			$IMS_client_id = $this->config->IMS_client_id = 'fragApi_devqa';
		
		static $IMS_secret = '';
		if (!$IMS_secret && !($IMS_secret = $this->config->IMS_secret))
			$IMS_secret = $this->config->IMS_secret = '842919c1-9f4a-4299-aa2d-1b94805aae16';
		
			
		
		
		
		if (!$IMS_token || (time() > $IMS_token_expire && !$this->config->IMS_refresh_token)) {
			if ($this->verbose) echo "No token available.\n";
			if ('' == ($IMS_code = $this->config->IMS_code))
				$IMS_code = $this->config->IMS_code = 'eyJhbGciOiJSUzI1NiJ9.eyJpZCI6ImZyYWdBcGlfZGV2cWEiLCJzY29wZSI6Im9wZW5pZCxBZG9iZUlELHNhby5jcmVhdGl2ZV9jbG91ZCxmb3JjZV9wcm9qZWN0Iiwic3RhdGUiOm51bGwsImFzIjpudWxsLCJjcmVhdGVkX2F0IjoiMTQxNjkwMzAyNzg2MSIsImV4cGlyZXNfaW4iOiIyNTkyMDAwMDAwMDAiLCJ1c2VyX2lkIjoiZnJhZ0FwaV9kZXZxYUBBZG9iZUlEIiwiY2xpZW50X2lkIjoiZnJhZ0FwaV9kZXZxYSIsInR5cGUiOiJhdXRob3JpemF0aW9uX2NvZGUifQ.N6Dgw9ZEljZcn2nJ2mOqNsObWjty4TbzTVQDNQF2WFEmzG8hJ6Lps9-iPJYMVRMom236whRwt4sEJESBKfRn5NNcUOzVwWPngLxPuixKlo-X76Zt3mwDCg365RUddHx9Sh13Qmkffj9SeOSS3bPZ64tmz7ouuwtSwnsllAWKcr-q3olgeRBslGZGUSJ-esDRvGyLZE1WINQ4KzPqHX3CDkoNPLnme9oKl1flwYcrHPNcN2LqjtLYB0yaO23zbYthqbxv-BxrgX7pmLxBEQAQAGvGw5qXDxM_PCtO9i3mK1hc2qEIGpYcjBQ9YNoIsPDo1FQ68B3L9SiD3vkmQM5lsA';
			
			$postData = sprintf("grant_type=%s&client_id=%s&client_secret=%s&code=%s",
					'authorization_code',
					$IMS_client_id,
					$IMS_secret,
					$IMS_code
			);
			
			curl_setopt_array($this->ims, array(
					CURLOPT_URL => $this->IMS_endpoint,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POST => true,
					CURLOPT_POSTFIELDS => $postData,
			));
			$response = json_decode(curl_exec($this->ims));
			$response_code = curl_getinfo($this->ims, CURLINFO_HTTP_CODE);
			$err_message = curl_error($this->ims);
			if ($err_message) {
				throw new Exception(sprintf("\"Message\":\"Error making http request\" \"Endpoint\":\"%s\" \"Response\":\"%s\"", $this->IMS_endpoint, $err_message));
			}
			if ($response_code != 200) {
				throw new Exception(sprintf("\"Message\":\"Unexpected return code\" \"Endpoint\":\"%s\" \"Response Code\":\"%s\" \"Response\":\"%s\"", $this->IMS_endpoint, $response_code, print_r($response,true)));
			}
			if (!$response) {
				throw new Exception(sprintf("\"Message\":\"Empty response\" \"Endpoint\":\"%s\" \"Response Code\":\"%s\"", $this->IMS_endpoint, $response_code));
			}
			$this->config->IMS_token = $IMS_token = $response->access_token;
			$this->config->IMS_refresh_token = $response->refresh_token;
			$this->config->IMS_token_expire = $IMS_token_expire = round(time() + $response->expires_in/1000 - 10);
			
			$header = sprintf("Authorization: Bearer %s", $response->access_token);
			
		} elseif (time() > $IMS_token_expire) {
			if ($this->verbose) echo "Refreshing expired token\n";
			$postData = sprintf("grant_type=%s&client_id=%s&client_secret=%s&refresh_token=%s",
					'refresh_token',
					$IMS_client_id,
					$IMS_secret,
					$this->config->IMS_refresh_token
			);
							
			curl_setopt_array($this->ims, array(
			CURLOPT_URL => $this->IMS_endpoint,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $postData,
			));

			$response = json_decode(curl_exec($this->ims));
			$response_code = curl_getinfo($this->ims, CURLINFO_HTTP_CODE);
			$err_message = curl_error($this->ims);
			if ($err_message) {
				throw new Exception(sprintf("\"Message\":\"Error making http request\" \"Endpoint\":\"%s\" \"Response\":\"%s\"", $this->IMS_endpoint, $err_message));
			}
			if ($response_code != 200) {
				throw new Exception(sprintf("\"Message\":\"Unexpected return code\" \"Endpoint\":\"%s\" \"Response Code\":\"%s\" \"Response\":\"%s\"", $this->IMS_endpoint, $response_code, print_r($response,true)));
			}
			if (!$response) {
				throw new Exception(sprintf("\"Message\":\"Empty response\" \"Endpoint\":\"%s\" \"Response Code\":\"%s\"", $this->IMS_endpoint, $response_code));
			}
			$this->config->IMS_token = $IMS_token = $response->access_token;
			$this->config->IMS_refresh_token = $response->refresh_token;
			$this->config->IMS_token_expire = $IMS_token_expire = round(time() + $response->expires_in/1000 - 10);
				
			$header = sprintf("Authorization: Bearer %s", $response->access_token);
				
		} elseif (!$header) {
			$header = sprintf("Authorization: Bearer %s", $IMS_token);
			if ($this->verbose) echo "Hit cached token\n";
		} else {
			if ($this->verbose) echo "Already had a header.\n";
		}
		return $header;
		
	}
	
	function makeRequest($url, $method = 'GET') {
		
		
		$endpoint = $this->server.'/'.ltrim($url,'/');
		curl_setopt($this->ch, CURLOPT_URL, $endpoint);
		
		curl_setopt($this->ch, CURLOPT_CUSTOMREQUEST, $method);
		
		$response = curl_exec($this->ch);
		$response_code = curl_getinfo($this->ch, CURLINFO_HTTP_CODE);
		$err_message = curl_error($this->ch);
		if ($err_message) {
			throw new Exception(sprintf("\"Message\":\"Error making http request\" \"Endpoint\":\"%s\" \"Response\":\"%s\"", $endpoint, $err_message));
		}
		if ($response_code != 200) {
			throw new Exception(sprintf("\"Message\":\"Unexpected return code\" \"Endpoint\":\"%s\" \"Response Code\":\"%s\" \"Response\":\"%s\"", $endpoint, $response_code, $response));
		}
		return json_decode($response);
		
	}
	
	function doPost($url) {
	 	return $this->makeRequest($url, 'POST');
	}

	function doDelete($url) {
		return $this->makeRequest($url, 'DELETE');
	}
	
	function doGet($url) {
		return $this->makeRequest($url, 'GET');
	}
}

/**
 * SELFTEST
 * Usage: php cli_tools.inc <optional arguments>
 */
if (count(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
		(version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
				debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1))) == 0) {
	
	require_once 'cli_tools.inc';
	try {
		$bac = new BertApiClient(true);
		
		echo get_ansi_color('black', 'yellow') . "This should work\n" . ANSI_COLOR_CODE_RESET;
		$list_data = $bac->makeRequest('/v1/report_suite_list/list');
		if (!is_array($list_data)) die("No report suite lists found\n");
		echo "Found ". count($list_data) . " lists\n";
		
		echo get_ansi_color('black', 'yellow') . "This should work\n" . ANSI_COLOR_CODE_RESET;
		print_r($bac->makeRequest('v1/report_suite_list/list/'.end($list_data)->id));
		
		echo get_ansi_color('black', 'yellow') . "This should fail\n" . ANSI_COLOR_CODE_RESET;
		print_r($bac->makeRequest('/v1/nothing to see here'));
		
	} catch (Exception $e) {
	    echo 'Caught exception: ',  $e->getMessage(), "\n";
	}
	

}