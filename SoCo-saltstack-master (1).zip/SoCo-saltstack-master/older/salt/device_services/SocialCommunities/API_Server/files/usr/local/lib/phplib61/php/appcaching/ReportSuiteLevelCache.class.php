<?php
/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2010-2011 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require_once 'appcaching/MemCachedCache.class.php';
/**
 * Wraps caching implementations
 *
 * Currently wraps Memcache and DummyCache.
 *
 * Handles which products have caching turned on
 */
class ReportSuiteLevelCache{
	/**
	 * A cache object.
	 */
	private static $instance = null;
	private $product_id = PRODUCT_ID_SITECATALYST;
	private static $enabled = false;
	const CACHE_KEY = 'SC_RS_MEMCACHE_KEYS';
	private $values = array();
	private $session = null;
	private $companyid = 0;
	
	//populates the cache and sets up internal data structures
	private function __construct($sess, $companyid) {
		$this->session = $sess;
		$this->companyid = $companyid;
		$this->values = $this->session->get(self::CACHE_KEY); 
		if (!is_array($this->values)) {
			$this->values = array();
		}
	}
	/**
	 * Grabs the singleton cache object.
	 *
	 * Creates it if needed
	 */
	public function getInstance($sess=null, $companyid=0, $force_new_instance = false) {
		//try to pull the session out of global scope
		if ($sess == null) {
			$sess = $GLOBALS['sess']; 
		}

		//try and get a session for the persistance container
		if (ReportSuiteLevelCache::$enabled == false 
				|| $sess == null
				|| ($companyid === 0 || !is_integer($companyid))) {
			self::$instance = new DummyReportSuiteLevelCache($sess);
		}else if(is_null(self::$instance) || (self::$instance->getCompanyId() !== $companyid) ||  $force_new_instance){
			self::$instance = new ReportSuiteLevelCache($sess, $companyid);
		}
		return self::$instance;
	}

	public function getCompanyId(){
		return $this->companyid;
	}

	public static function setEnabled($enabled) {
		if($enabled === true){
			ReportSuiteLevelCache::$enabled = true;
		}else{
			ReportSuiteLevelCache::$enabled = false;
		}
	}

	public static function isEnabled(){
		return ReportSuiteLevelCache::$enabled;
	}

	/**
	 * Retrieves a value based on a key
	 *
	 * @param $key          (string) A cache key
	 *
	 * @return anything
	 */
	public function get($key_string, $rsid) {
		if (ReportSuiteLevelCache::$enabled ==false || $GLOBALS['loki']['reportsuitelevelcacheoff']) {
			return null;
		}
		$key = $this->getKey($key_string,$rsid);
		$cached_keys = $this->session->get(self::CACHE_KEY);
		if(isset($cached_keys[$key])) {
			$memcache = MemCachedCache::getInstance($this->product_id);
			return $memcache->get($key);
		}
		return null;
	}

	/**
	 * Sets a value to a key in the cache
	 *
	 * @param $key         (string) A cache key
	 * @param $data        (anything) A value to be set, will be serialized
	 */
	public function set($key_string, $rsid,  $data) {
		$memcache = MemCachedCache::getInstance($this->product_id);
		$key = $this->getKey($key_string,$rsid);
		if($memcache->set($key, $data)) {
			$this->values[$key] = 1;
			$this->session->set(self::CACHE_KEY, $this->values);
		}
	}
	
	private function getKey($key, $rsid) {
		return $key .'_'. $rsid .'_'. $this->companyid;
	}
	
	public function getProductId() {
		return $this->product_id;
	}

	//this shouldn't be needed since we are storing the data in the session
	//and it will expire when the user logs out
	public function invalidateCache() {
		$memcache = MemCachedCache::getInstance($this->product_id);
		foreach($this->values as $key=>$val){
			$memcache->set($key, null);
		}
		$this->values   = array();
		$this->session->set(self::CACHE_KEY, $this->values);
	}

}

/**
 * Ignore all calls by using the magic __call method
 * to capture all calls
 */
class DummyReportSuiteLevelCache {
	public function __call($name, $arguments) {
	}
}
