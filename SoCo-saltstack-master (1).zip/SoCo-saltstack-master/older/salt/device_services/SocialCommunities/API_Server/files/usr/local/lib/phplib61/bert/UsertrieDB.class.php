<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2008 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
/**
 * A class that mimic the regular MySQL_DB class allowing queries over all usertries at once.
 * Moved to bertlib by Matt Gould
 *
 * @author Kalon Mills
 */

class UsertrieDB {
	
	var $_recordset;
	var $_dbhost;
	var $_max_field_lengths;
	var $_field_list;
	var $Record;
	var $Row;

	function UsertrieDB()
	{
		global $localConfig;
		$td = trie_load($localConfig['usertrie_enterprise']);
		$this->_dbhost = trie_get_all_unique($td);
		$this->_recordset = Array();
		$this->_max_field_lengths = Array();
		$this->_field_list = Array();
		$this->Record = Array();
		$this->Row = -1;
	}

	//Given a database record this will travers it and return an array of field names 
	function _getFieldNames($query_result_resource){
		$name_list = array();
	
		for($ndx = 0; $ndx < $query_result_resource->num_fields(); ++$ndx) {
			$name_list[$ndx] = $query_result_resource->field_name($ndx);
		}
	
		return $name_list;
	}

	function query($usql, $once = false)
	{
		$udb = new masterdb;
  		$udb->connect_failure_force_reset = true;
		$udb->halt_on_error = false;
		
		$this->_field_list = Array();
		$this->_recordset = Array();
		$this->_max_field_lengths = NULL;
		$this->Row = 0;
	
		reset($this->_dbhost);
		while (list($k, $v) = each($this->_dbhost)) {
		    $udb->set($v['host'], $v['db']);
	
			$first_record = true;
			$tries = 0;
		    $udb->query($usql);
		    while ($udb->next_record()) {
		        if (count($this->_field_list) == 0) { //do this until actually get field names
		            $this->_field_list = $this->_getFieldNames($udb);
		        }

				$num_fields = $udb->num_fields();
				if ($num_fields > 0) {
					$record = Array();
	
					for ($field_ndx = 0; $field_ndx < $num_fields; ++$field_ndx) {
						$field_value = $udb->f($field_ndx);
						$record[$field_ndx] = $field_value;
						$record[$this->_field_list[$field_ndx]] = $field_value;
						//get the max field lengths
						if (strlen($field_value) > $this->_max_field_lengths[$field_ndx]) $this->_max_field_lengths[$field_ndx] = strlen($field_value);
					}
					
					$this->_recordset[] = $record;
				}
		    }
		    $udb->free();
			if ($once) break;  //If once is set then we don't need to do this for every host, db.
		}
	
		return $this->_recordset;
	}

	function next_record()
	{
		$this->Record = $this->_recordset[$this->Row];
		$this->Row++;

		return is_array($this->Record);		
	} 

	function free()
	{
		$this->_recordset = Array();
		$this->_max_field_lengths = Array();
		$this->_field_list = Array();
		$this->Record = Array();
		$this->Row = -1;
	}

	function num_fields()
	{
		return count($this->_recordset);
	}

	function f($name)
	{
		return $this->Record[$name];
	}

	function getMaxFieldLength($field_ndx) 
	{
		return $this->_max_field_lengths[$field_ndx];
	}

	function getMaxFieldLengths()
	{
		return $this->_max_field_lengths;
	}
	
	function getFieldNames()
	{
		return $this->_field_list;
	}
}
