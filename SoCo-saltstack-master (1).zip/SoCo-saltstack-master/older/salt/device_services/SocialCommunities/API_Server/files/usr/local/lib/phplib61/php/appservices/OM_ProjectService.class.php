<?
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2014 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property laws, 
* including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require_once("appservices/OM_AppServiceBase.class.php");

class OM_ProjectService extends OM_AppServiceBase
{
	//Include Types
	const INCLUDETYPE_ALL = 'all';
	const INCLUDETYPE_SHARED = 'shared';

	public function getSimpleProjectList($token,$expansion=array(),$includeType=null,$ownerId = 0,$includeBasicInfo=false)
	{
		$path = "/projects?";
		if (!is_null($includeType)) {
			$path .= "&includeType=".$includeType;
		}
		//Filter the list by a specific owner if necessary
		if($ownerId){
			$path .= "&ownerId=".$ownerId;
		}
		//add the expansion params
		if (is_array($expansion) && count($expansion) > 0) {
			$path .= "&expansion=".implode(',', $expansion);
		}
		$response_obj = $this->makeAnalyticsEndpointRequest($path,$token);
		if($response_obj && !$response_obj->hasErrors()){
			$response = $response_obj->getResponse();
			$response = json_decode($response);
			$result = array();
			foreach ($response as $item) {
				$seg = array();
				$seg['id'] = $item->id;
				$seg['name'] = $item->name;
				if ($includeBasicInfo) {
					$seg['rsid'] = $item->rsid;
					$seg['description'] = $item->description;
					$seg['owner'] = $item->owner;
				}
				if (is_array($expansion) && count($expansion) > 0) {
					foreach ($expansion as $expand) {
						$seg[$expand] = $item->$expand;
					}
				}
				$result[] = $seg;
			}
			usort($result,array("OM_ProjectService","sortProjectsByName"));
			return $result;
		} else {
			var_export($response_obj);
			return false;
		}
	}

	private static function sortProjectsByName($project_a, $project_b){
		return strcasecmp($project_a['name'],$project_b['name']);
	}

	public function changeOwner($project_id,$new_owner_loginid,$token){
		if($project_id && $new_owner_loginid){
			$path = "/projects/$project_id";
			$request_body = json_encode(array("owner" => array("id" => $new_owner_loginid)));
			$this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::PUT_REQUEST,$request_body);
		}
	}

	public function deleteProject($project_id,$token){
		if($project_id){
			$path = "/projects/$project_id";
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::DELETE_REQUEST);
			if($response_obj && !$response_obj->hasErrors()){
				return $response_obj->getResponse();
			}
		}
		return false;
	}
}

