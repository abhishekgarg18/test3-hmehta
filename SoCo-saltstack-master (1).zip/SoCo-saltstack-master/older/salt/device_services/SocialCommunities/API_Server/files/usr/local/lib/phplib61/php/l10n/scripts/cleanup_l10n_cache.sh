#! /bin/bash

RECIPIENTS="jsahleen@adobe.com"
TEMP_DIR=/tmp

# Copy corrupt file to temp for archiving
copy_file_to_temp()
{
	if [ -d $TEMP_DIR ]; then
		STAMP=`date +%s`
		NEW_FILE="${TEMP_DIR}/L10n_${STAMP}_${FILE_NAME}"
		cp $1 $NEW_FILE
	fi
	return
}

# Send notification email 
send_mail()
{
	FILE=$1
	HOST=`hostname`
	SUBJECT="Corrupt l10n cache file on ${HOST}"
	MESSAGE="The following l10n cache file was corrupt and has been deleted.\n\nHost: ${HOST}\nFile Name: ${FILE}\n\nAn archived version can be found on the affected server here:\n${NEW_FILE}\n"
	echo -e "${MESSAGE}" | mail -s "${SUBJECT}" $RECIPIENTS
	return
}

# Delete the corrupted file
delete_corrupt_file()
{
	FILE=$1
	if [ -f $FILE ]; then
		rm $FILE
	fi
	return
}

# Main script starts here
if [[ ! -f $1 && ! -d $1 ]]; then
	exit
fi

if [ -d $1 ]; then
	FILES=`find $1/ -type f -iname \*.inc`
	for i in $FILES
	do
		$0 $i
	done
	exit
fi

if [ -f $1 ]; then
	FILE_DIR=`dirname $1`
	FULL_DIR=$(cd $FILE_DIR/; pwd)/
	FILE_NAME=`basename $1`
	FILE_PATH=$FULL_DIR$FILE_NAME
	
	php -l $FILE_PATH 1>/dev/null 2>&1

	if [ $? -ne 0 ]; then
		copy_file_to_temp $FILE_PATH
		send_mail $FILE_PATH
		delete_corrupt_file $FILE_PATH
	fi
fi