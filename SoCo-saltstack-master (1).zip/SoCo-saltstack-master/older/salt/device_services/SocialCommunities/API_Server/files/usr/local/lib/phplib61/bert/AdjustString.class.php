<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * simple string representation for adjustments as follows:
 * usage:±dc:count:atype or usage:±server or usage:±count or usage:±dc:count:atype,usage:±server
 * some parts are optional, mainly to avoid repetition
 * ? can be used as a placeholder for dc or atype
 *
 * @author  Jack Thomasson <thomasso@adobe.com>
 *
 * @version $Id: $
 */
require_once 'CacheServerUsage.class';
require_once 'FragServerUsage.class';
require_once 'CacheAllocationTypes.class';
require_once 'FragAllocationTypes.class';
require_once 'common_functions.inc';

/**
 * @file
 * exceptions thrown for certain error associated with AdjustString methods
 */
class AdjustStringException extends Exception {}
class AdjustStringParseException extends AdjustStringException {}
class AdjustStringMissingUsageException extends AdjustStringException {}
class AdjustStringWrongDatacenter extends AdjustStringException {}

/**
 * @class AdjustString - concise representation of adjustments to setup
 */
class AdjustString implements Iterator {
	/// offsets for matches returned by Iterator
	const MATCH_MODE = 'MODE';
	const MATCH_USAGE = 'USAGE';
	const MATCH_ALLOCATION = 'ALLOC';
	const MATCH_DC = 'DC';
	const MATCH_COUNT = 'COUNT';
	const MATCH_ATYPE = 'ATYPE';

	const RANDOM = '?';
	const DOMAIN = 'DOMAIN';
	const COUNTONLY = 'COUNTONLY';

	const CACHE = 'Cache';
	const FRAG = 'Frag';

	private static $preg; ///< regular expression used by Iterator
	protected static $tracker = [
		self::CACHE => [
			'usage' => [
				'L:' => CacheServerUsage::LOBBY,
				'E:' => CacheServerUsage::ELEVATOR,
				'H:' => CacheServerUsage::HOTEL,
				],
			],
		self::FRAG => [
			'usage' => [
				'F:' => FragServerUsage::FRAG,
				'U:' => FragServerUsage::USER_UNIQUE,
				'C:' => FragServerUsage::COMBO,
				],
			],
		];
	protected static $mapper = []; ///< map abbreviation to expressive word
	protected static $abbrev = []; ///< map expressive word to abbreviation
	protected static $order = [];  ///< sort order of usages, including abbreviations

	protected $setup; ///< string representation of self
	protected $parse; ///< key representation for Iterator
	protected $matches; ///< value representation for Iterator

	static private function promote($x) {
		return $x[0];
	}

	/**
	 * @return array of usages, @see CacheServerUsage and FragServerUsage
	 */
	public static function USAGES() {
		return array_flip(self::ABBREVS());
	}

	/**
	 * @return array of usage abbreviations, without trailing :
	 */
	public static function ABBREVS() {
		return array_map('AdjustString::promote', self::$abbrev);
	}

	/**
	 * @return string of allocation types, including RANDOM (?)
	 */
	public static function ATYPES() {
		return array_unique(array_merge(self::$tracker[self::CACHE]['atypes'], self::$tracker[self::FRAG]['atypes'], [self::RANDOM]));
	}

	/**
	 * filter 'actual' host, i.e., in Analytics environment has a . in hostname
	 * @note . as leading character violates STD0013
	 * @param[in] $host or allocation string
	 * @return bool
	 */
	public static function actual($host) {
		return (bool)strpos($host, '.');
	}
	/**
	 * filter 'allocated' host, i.e., not 'actual'
	 * @note allocation could be just a number
	 * @param[in] $host or allocation string
	 * @return bool
	 */
	public static function allocated($host) {
		return !self::actual($host);
	}

	/**
	 * construct an AdjustString
	 * note this function is protected so not for external consumption, instead use the public static with* forms
	 */
	protected function __construct() {}

	/**
	 * initialize static members
	 */
	public static function __init() {
		$usages = [];
		$atypes = [self::RANDOM];
		$order = 0;
		foreach (self::$tracker as $group => &$info) {
			$group .= 'AllocationTypes';
			$group = new $group;
			$info['atypes'] = $group->get_valid_config_codes();
			$atypes = array_merge($atypes, $info['atypes']);
			foreach ($info['usage'] as $k => $v) {
				$l = strtolower($k);
				self::$mapper[$l] = self::$mapper[$k] = $v;
				self::$abbrev[$v] = $k;
				$usages[] = $k[0];
				self::$order[$v] = self::$order[$k] = self::$order[$k[0]] = self::$order[$l] = self::$order[$l[0]] = $order++;
			}
		}
		global $localConfig;
		$MODE = self::MATCH_MODE;
		$USAGE = self::MATCH_USAGE;
		$ALLOCATION = self::MATCH_ALLOCATION;
		$DC = self::MATCH_DC;
		$COUNT = self::MATCH_COUNT;
		$ATYPE = self::MATCH_ATYPE;
		$DOMAIN = self::DOMAIN;
		$COUNTONLY = self::COUNTONLY;
		self::$preg = "/^(?:(?:,)?(?<$USAGE>[".join('', $usages)."]:)?(?<$MODE>[-+])(?<$ALLOCATION>(?<$DC>".join('|',array_merge(array_flatten($localConfig['data_center_hostname_suffix_list']),['\?']))."):(?<$COUNT>\d+):(?<$ATYPE>[".join('', array_unique($atypes))."])|[[:alpha:]][-[:alnum:].]*\.(?<$DOMAIN>".join('|',$localConfig['data_center_hostname_suffixes']).")|(?<$COUNTONLY>\d+[^,+]*)))/i";
	}

	/**
	 * construct a AdjustString from a string representation
	 * @param[in]	string setup
	 * @return AdjustString
	 * @throws AdjustStringParseException
	 */
	public static function withString($setup) {
		$class = get_called_class();
		$thing = new $class();
		if (!preg_match($thing->preg(), $setup))
			throw new AdjustStringParseException('could not parse');
		$thing->parse = $thing->setup = $setup;
		return $thing;
	}

	/**
	 * check for AdjustString properties and separate into some component parts,
	 * return array holding base and adjustment if it looks like an AdjustString, empty array otherwise
	 * @param[in]	string setup
	 * @return array
	 */
	public static function split($setup) {
		// AdjustString form requires prepended BRS
		if (preg_match('/(.+?):(.:[-+].+)/', $setup, $match)) {
			try {
				AdjustString::withString($match[2]);
				return array_splice($match, 1);
			}
			catch(Exception $e) {
			}
		}
		return [];
	}

	/**
	 * construct a string representation of a self
	 */
	public function asString() {
		return $this->setup;
	}

	/**
	 * determine sort order by usage
	 */
	public static function by_usage($a, $b) {
		return self::$order[$a] - self::$order[$b];
	}

	/**
	 * the regular expression used for parsing
	 */
	protected function preg() {
		return self::$preg;
	}

	/**
	 * Iterator functions returning $matches a la preg_match
	 */
	public function rewind() {
		$this->parse = $this->setup;
		$this->matches = [];
	}
	public function current() {
		return $this->matches;
	}
	public function key() {
		return $this->parse;
	}
	public function next() {
		$this->parse = substr($this->parse, strlen($this->matches[0]));
	}
	public function valid() {
		$last = $this->matches;
		if (!($this->parse and preg_match($this->preg(), $this->parse, $this->matches)))
			return FALSE;
		if ($this->extra_validation($last))
			return TRUE;
		$this->matches[self::MATCH_USAGE] = $this->matches[self::MATCH_USAGE] ? self::$mapper[$this->matches[self::MATCH_USAGE]] : $last[self::MATCH_USAGE];
		if (strlen($this->matches[self::COUNTONLY])) {
			if (!is_intval($this->matches[self::COUNTONLY]))
				throw new AdjustStringWrongDatacenter('missing datacenter');
			$this->matches[self::MATCH_DC] = $this->matches[self::MATCH_ATYPE] = self::RANDOM;
			$this->matches[self::MATCH_COUNT] = $this->matches[self::COUNTONLY];
		} else if (self::actual($this->matches[self::MATCH_ALLOCATION])) {
			$this->matches[self::MATCH_DC] = $this->matches[self::DOMAIN];
			$this->matches[self::MATCH_COUNT] = 1;
			foreach (self::$tracker as $group => &$info)
				if (in_array($this->matches[self::MATCH_USAGE], $info['usage'])) {
					$group .= 'AllocationTypes';
					$group = new $group;
					if (!($this->matches[self::MATCH_ATYPE] = $group->get_allocation_type($this->matches[self::MATCH_ALLOCATION])))
						throw new AdjustStringException("{$this->matches[self::MATCH_ALLOCATION]}: could not determine atype");
					$this->matches[self::MATCH_ATYPE] = strtolower($this->matches[self::MATCH_ATYPE][0]);
					break;
				}
		} else if (self::RANDOM != $this->matches[self::MATCH_ATYPE]) {
			$this->matches[self::MATCH_ATYPE] = strtolower($this->matches[self::MATCH_ATYPE]);
			foreach (self::$tracker as $group => &$info)
				if (in_array($this->matches[self::MATCH_USAGE], $info['usage']) and !in_array($this->matches[self::MATCH_ATYPE], $info['atypes']))
					throw new AdjustStringException("invalid atype={$this->matches[self::MATCH_ATYPE]} for group=$group");
		}
		global $localConfig;
		if ($this->matches[self::MATCH_DC] != self::RANDOM and !in_array($this->matches[self::MATCH_DC], $localConfig['data_center_hostname_suffixes']))
			throw new AdjustStringWrongDatacenter('wrong datacenter');
		if (!$this->matches[self::MATCH_USAGE])
			throw new AdjustStringMissingUsageException('missing usage');
		return TRUE;
	}

	/**
	 * extra validation for child classes
	 */
	protected function extra_validation(array $last) {}

	/**
	 * produce abbreviation for expressive usage
	 */
	public static function abbreviate($usage) {
		if (!($ret = self::$abbrev[$usage]))
			throw new AdjustStringException("$usage: invalid usage");
		return $ret;
	}
}
AdjustString::__init();


/**
 * SELFTEST
 * Usage: php AdjustString.class.php
 */
if (!(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
      (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
       debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)))) {
	if (function_exists('xdebug_break')) xdebug_break();

	echo var_export(AdjustString::ABBREVS(), TRUE), "\n";
	echo var_export(AdjustString::USAGES(), TRUE), "\n";

	if (1 < count($argv))
		array_splice($argv, 0, 1);
	else
		$argv = split("\n", <<<SAMPLES
L:+ut1:5:g
L:+ut1:1:s+ut1:1:l,E:+ut1:1:h+ut1:1:g,H:+ut1:1:e+ut1:1:v,F:+ut1:1:l+ut1:1:c,C:+ut1:1:b+ut1:1:d,U:+ut1:1:e
L:+ut1:5:g,E:-ut1:5:?
L:-ut1:5:g,E:-ut1:5:g
L:-ut1:5:g,E:+?:5:g
L:+c107.ut1,E:-c108.ut1
L:+5,E:-6
SAMPLES
			);
	foreach ($argv as $s) {
		echo "\nprocess $s\n";
		$a = AdjustString::withString($s);
		foreach ($a as $matches)
			echo<<<EOF
MODE ={$matches[AdjustString::MATCH_MODE]}
USAGE={$matches[AdjustString::MATCH_USAGE]}
ALLOC={$matches[AdjustString::MATCH_ALLOCATION]}
DC   ={$matches[AdjustString::MATCH_DC]}
COUNT={$matches[AdjustString::MATCH_COUNT]}
ATYPE={$matches[AdjustString::MATCH_ATYPE]}


EOF;
	}
	$exit = 0;
	foreach (['invalid-atype:L:ut1:1:b' => 'could not parse',
	          'ut1:1:b' => 'could not parse',
	          '+sbx1:1:b' => 'wrong datacenter',
	          '+ut1:1:b' => 'missing usage',
	          '+1:b' => 'missing datacenter',
	         ] as $s => $m) {
		echo "\nprocess $s\n";
		try {
			$a = AdjustString::withString($s);
			foreach ($a as $matches)
				var_export($matches);
			fwrite(STDERR, "Missed Exception for '$m'!\n");
			$exit = 1;
		} catch (Exception $e) {
			$e = $e->getMessage();
			if ($m == $e)
				echo "Good! caught '$e'\n";
			else {
				fwrite(STDERR, "Bad! expected '$m', caught '$e'\n");
				$exit = 1;
			}
		}
	}
	if ($exit) exit($exit);
	echo var_export(AdjustString::split('base-then-adjustment:L:-1'), TRUE), "\n";
	if (AdjustString::split('L:-1')) {
		fwrite(STDERR, "AdjustString::split() failed on simple adjustment\n");
		exit(1);
	}
}
