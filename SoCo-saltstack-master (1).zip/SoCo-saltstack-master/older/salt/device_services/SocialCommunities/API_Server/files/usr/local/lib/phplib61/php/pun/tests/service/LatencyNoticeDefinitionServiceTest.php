<?php
include ("application.inc");
require_once("pun/services/LatencyNoticeDefinitionService.php");
require_once("pun/model/LatencyNoticeDefinition.php");
require_once("pun/model/LatencyEventDefinition.php");

class LatencyNoticeDefinitionServiceTest  extends PHPUnit_Framework_TestCase
{
	private $service;
	
	public function __construct()
	{
		$this->service = new LatencyNoticeDefinitionService();	
	}
	
	public function testCreateDef()
	{
		$def = new LatencyNoticeDefinition();
		$def->setLoginCompanyName("Bee");
		$def->setLoginCompanyId(100);
		$def->setBillingCustomerName("Test1");
		$def->setBillingCustomerId(1000);
		$def->setAdobeEmail("gpaulsen@adobe.com");
		$def->setHaEmail("stan@xmission.com");
		$def->setEmailFrequency(2);
		$def->setLatencyThreshold(4);
		$def->setNotifyState("Active");
		
		$eventDef = new LatencyEventDefinition();
		$eventDef->setLatencyThreshold(4);
		$eventDef->setUsername("sctestscript1");
		$def->addEventDefinition($eventDef);
		
		$newDef = $this->service->saveLatencyNoticeDefinition($def);
		
		$this->service->deleteLatencyNoticeDefinition($newDef->getID());
	}
	
	public function testValidateDef()
	{
		$def = new LatencyNoticeDefinition();
		$def->setLoginCompanyName("funkcorp");
		$def->setBillingCustomerName("Test1");
		$def->setBillingCustomerId(1000);
		$def->setAdobeEmail("gpaulsen@adobe.com");
		$def->setHaEmail("stan@xmission.com");
		$def->setEmailFrequency(2);
		$def->setLatencyThreshold(4);
		$def->setNotifyState("Active");
		
		$eventDef = new LatencyEventDefinition();
		$eventDef->setLatencyThreshold(4);
		$eventDef->setUsername("bugzilla.www14");
		$def->addEventDefinition($eventDef);
		
		$this->service->validateDefinition($def);
		
		$eventDef = new LatencyEventDefinition();
		$eventDef->setLatencyThreshold(4);
		$eventDef->setUsername("blahblah");
		$def->addEventDefinition($eventDef);

		try
		{
			$this->service->validateDefinition($def);
			$this->assertTrue(FALSE);
		}
		catch(InvalidParameterException $ex)
		{
			echo($ex->getMessage());
		}
	}
	
	public function testSaveVsUpdate()
	{
		$def = new LatencyNoticeDefinition();
		$def->setLoginCompanyName("stancorp");
		$def->setLoginCompanyId(345);
		$def->setBillingCustomerName("Test1");
		$def->setBillingCustomerId(1000);
		$def->setAdobeEmail("gpaulsen@adobe.com");
		$def->setHaEmail("stan@xmission.com");
		$def->setEmailFrequency(2);
		$def->setLatencyThreshold(4);
		$def->setNotifyState("Active");
		
		$newDef = $this->service->saveLatencyNoticeDefinition($def);
		
		try 
		{
			$this->service->saveLatencyNoticeDefinition($def);
			$this->fail();// save should have failed!			
		}
		catch(InvalidParameterException $ex)
		{
			
		}
		$def->setAdobeEmail("blah1@blah.com");
		$def->setHaEmail("blah2@blah.com");
		$def->setEmailFrequency(6);
		$def->setLatencyThreshold(6);
		$def->setNotifyState("Hold");
		$updatedDef = $this->service->updateLatencyNoticeDefinition($def);

		$this->assertEquals($updatedDef->getEmailFrequency(),6);
		$this->assertEquals($updatedDef->getlatencyThreshold(),6);
		$this->assertEquals($updatedDef->getNotifyState(),"Hold");
		$this->assertEquals($updatedDef->getAdobeEmail(),"blah1@blah.com");
		$this->assertEquals($updatedDef->getHaEmail(),"blah2@blah.com");
		
		$this->service->deleteLatencyNoticeDefinition($updatedDef->getID());
	}
}