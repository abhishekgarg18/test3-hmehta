<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2014 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
require_once 'appcaching/AppcachingAutoloader.php';

class IMSAutoloader
{
	public static function autoloadIMS($name)
	{
		static $classes;

		if (!$classes) {
			$classes = array(
				'IMSClient' => 'ims/IMSClient.class',
				'IMSRequest' => 'ims/IMSRequest.class',
				'IMSAuthenticationException' => 'ims/IMSAuthenticationException.class',
			);
		}

		if (isset($classes[$name])) {
			require_once $classes[$name];
		}
	}
}

spl_autoload_register(array('IMSAutoloader', 'autoloadIMS'));