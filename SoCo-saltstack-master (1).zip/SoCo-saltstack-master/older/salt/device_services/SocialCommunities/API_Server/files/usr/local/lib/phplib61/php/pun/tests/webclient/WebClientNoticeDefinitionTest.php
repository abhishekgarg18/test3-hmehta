<?php

include 'application.inc';
require_once 'pun/webclient/LatencyNoticeWebClient.php';
require_once 'pun/tests/dao/LatencyNoticeDefinitionDaoTest.php';
require_once 'pun/dao/LatencyNoticeDefinitionDao.php';

class WebClientNoticeDefinitionTest extends PHPUnit_Framework_TestCase
{
    private $webapi;
    private $defDao;

    public function __construct()
    {   
        $this->webapi = new LatencyNoticeWebClient();
        $this->defDao = new LatencyNoticeDefinitionDao(); 
    }   

	public function test_getNoticeDefinitionByID()
	{
		$def = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("c1",1);
		$def = $this->defDao->saveLatencyNoticeDefinition($def);
		$definition = $this->webapi->getNoticeDefinition($def->getID());
		$this->assertType('object', $definition);
		$this->assertTrue(get_class($definition) == 'LatencyNoticeDefinition');
		$this->defDao->deleteLatencyNoticeDefinition($def->getID());
	}

	public function test_getNoticeDefinitionWithSelector()
	{
		$def = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("c1",1);
		$def = $this->defDao->saveLatencyNoticeDefinition($def);
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->setLoginCompanyName("c1");
		$definitions = $this->webapi->getNoticeDefinitions($selector);

		$this->assertType('array', $definitions);
		$this->assertTrue((count($definitions) == 1));
		$this->assertType('object', $definitions[0]);
		$this->assertTrue(get_class($definitions[0]) == 'LatencyNoticeDefinition');
		$this->assertTrue($definitions[0]->getLoginCompanyId() == 1);
		
		$this->defDao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function test_getNoticeDefinitionWithSelectorLimit()
	{
		$def = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("c1",1);
		$def = $this->defDao->saveLatencyNoticeDefinition($def);
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->limitResult(1);
		$definitions = $this->webapi->getNoticeDefinitions($selector);

		$this->assertType('array', $definitions);
		$this->assertTrue((count($definitions) == 1));
		$this->assertType('object', $definitions[0]);
		$this->assertTrue(get_class($definitions[0]) == 'LatencyNoticeDefinition');
		//$this->assertTrue($definitions[0]->getLoginCompanyName() == "wholyoak");
		
		$this->defDao->deleteLatencyNoticeDefinition($def->getID());
	}

	public function test_getNoticeDefinitionExists()
	{
		//$rsid = 'bugzilla.www14';
		$rsid = 'sistr2';
		$this->assertTrue($this->webapi->noticeDefinitionExistsForReportSuite($rsid));
	}

	public function test_definitionExistsForCompany()
	{
		$company = 42;
		$this->assertTrue($this->webapi->noticeDefinitionExistsForCompany($company));
	}
}

