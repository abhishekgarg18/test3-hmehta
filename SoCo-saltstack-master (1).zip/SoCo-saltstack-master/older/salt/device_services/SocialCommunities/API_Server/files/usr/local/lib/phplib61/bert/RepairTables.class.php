<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * @file
 * RepairTables.class.php Check and repair MySQL tables using a variety of methods
 * 
 * @author  Matt Gould <mgould@adobe.com>
 *
 */
require_once 'application.inc';
require_once 'cli_tools.inc';
require_once 'common_functions.inc';
require_once 'frag_table_creator.class';
require_once 'SqlTableFinder.class.php';
require_once 'fragmentFunctions.inc';
require_once 'ServerInventory.class';
require_once 'hostname.inc';
require_once 'reverse_userid_lookup.inc';
require_once 'stdio.inc';

require_once OMNITURE_ROOT . '/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/Retriever.php';
require_once OMNITURE_ROOT . '/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/SecretRetriever.php';
require_once OMNITURE_ROOT . '/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/RetrieverFactory.php';

class RepairTablesException extends Exception {}
class RepairTablesNoTableException extends RepairTablesException {}
class RepairTablesLargeTableException extends RepairTablesException {}

/**
 * Class to repair MySQL tables using all known methods
 * @internal Whenever the word "key" is used it means a string representation of a table in the form "host:database:table"
 * @author mgould
 *
 */
class RepairTables
{
	const ftp_token = 'mysql_ftp';
	
	private $db;
	private $ftc;
	
	private $compatible_table_location;
	private $compatible_table_name;
	
	private $cur_host;
	private $cur_database;
	private $ftp_username;
	private $ftp_password;
	private $log_level;
	
	private $tables_to_repair;
	private $extended_select;
	private $force_repair;
	private $check_definition;
	private $optimize;
	private $skip_ftp_repair;
	private $create_myd_from_bak;
	private $recreate_when_only_bak_exists;
	private $required_tables;
	
	private $max_table_size;
	private $max_repairs;
	private $repair_check_interval;
	private $max_waits;
	
	private $sqlComment;
	
	private $repair_errors;
	private $repair_results;
	private $repair_actions;
	
	private $skipped_due_to_size;
	private $recent_bak_available;
	private $missing_myd;
	private $bad_def_tables;
	
	private $key;
	private $max_key_len;
	private $total_tables;
	private $cur_repair;
	
	const FTP_BASE_DIR = '/usr/local/mysql/var/';
	
	const RESULT_FAILED = 'Corrupt';
	const RESULT_OK = 'OK';
	const RESULT_REPAIRED = 'Repaired';
	const RESULT_MISSING = 'No Such Table';
	const RESULT_LARGE = 'Table is too large to repair';
	
	private $sep;
	
	/**
	 * @param int $output_level Use syslog constants
	 * @see http://php.net/manual/en/function.syslog.php
	 */
	public function __construct($output_level = LOG_EMERG)
	{
		$this->sqlComment = sprintf(' /* MODULE: bertlib FILE: %s */ ', __FILE__);
		$this->db = new Db_Sql('masterdb');
		$this->db->halt_on_error = false;
		
		$this->ftc = new frag_table_creator();
		$this->compatible_table_location = [];
		$this->compatible_table_name = preg_replace('/\\./', '_', sprintf('tmp_ftp_repair_%s_%d', get_hostname(), posix_getpid())); 
		
		$this->required_tables = SqlTableFinder::get_all_required_tables();
		
		$this->log_level = $output_level;
		
		$config = new BertConfig(__CLASS__);
		
		$this->max_table_size = $config->filter('max_table_data_gb', 32, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => PHP_INT_MAX / (1024*1024*1024)]])*1024*1024*1024;
		$this->max_repairs = $config->filter('max_concurrent_repairs', 3, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 50]]);
		$this->repair_check_interval = $config->filter('repair_check_interval', 30, FILTER_VALIDATE_INT, ['options' => ['min_range' => 5, 'max_range' => 600]]);
		$this->max_waits = $config->filter('repair_max_checks', 10, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 20]]);
		
		$this->sep = ' -> ';
		
		$retriever = Dms_Shared_SecretRetrieval_RetrieverFactory::getCurrentRetriever();
		$secrets = $retriever->getSecrets(array(self::ftp_token));
		$this->ftp_username = $secrets[self::ftp_token]->username;
		$this->ftp_password = $secrets[self::ftp_token]->password;
		
		$this->reset();
		
	}
	
	/**
	 * Reset the class to initial state
	 */
	public function reset() {
		$this->force_repair = false;
		$this->extended_select = true;
		$this->check_definition = false;
		$this->optimize = false;
		$this->skip_ftp_repair = false;
		$this->restore_myd_from_bak = false;
		$this->recreate_when_only_bak_exists = false;
		$this->tables_to_repair = [];
		$this->max_key_len = 0;
		$this->reset_results();
	}
	
	/**
	 * Set the option that controls whether we should also SELECT the last row of a table before deciding it is OK.
	 * @param bool $extended
	 */
	public function do_extended_select($extended = true) {
		$this->extended_select = $extended;
	}
	
	/**
	 * Set the option that controls whether a successful SELECT should mean that the table is OK.
	 * @param bool $force
	 */
	public function force_repair($force = true) {
		$this->force_repair = $force;
	}
	
	/**
	 * Set the option to force an OPTIMIZE TABLE
	 * @param bool $optimize
	 */
	public function do_optimize($optimize = true) {
		$this->optimize = $optimize;
	}
	
	/**
	 * Set the option to see if the table matches the expected table definition.
	 * @param bool $check
	 */
	public function check_definition($check = true) {
		$this->check_definition = $check;
	}
	
	/**
	 * Set the option to skip repairing the table by replacing files via ftp even if the REPAIR TABLE fails
	 * @param bool $skip
	 */
	public function skip_ftp_repair($skip = true) {
		$this->skip_ftp_repair = $skip;
	}

	/**
	 * Set the option to recreate the MYD file for the table if it is missing and there is a recent BAK file available
	 * @param bool $restore
	 */
	public function restore_myd_from_bak($restore = true) {
		$this->restore_myd_from_bak = $restore;
	}
	
	/**
	 * Set the option to recreate the entire table even if only a BAK file exists
	 * @param bool $recreate
	 */
	public function recreate_when_only_bak_exists($recreate = true) {
		$this->recreate_when_only_bak_exists = $recreate;
	}
	
	/**
	 * Change the string that is used to separate the repair steps when logging
	 * @param string $sep
	 */
	public function set_step_separator($sep) {
		$this->sep = (string)$sep;
	}
	
	/**
	 * Override the default table MYD size limit
	 * @param int $gb The maximum table MYD size to allow a REPAIR TABLE to run against
	 */
	public function set_max_table_gb($gb) {
		$this->max_table_size = $gb*1024*1024*1024;
	}
	
	/**
	 * Gets the errors that occured when repairing tables
	 * @param (optional) string $key  ("Host:Database:Table")
	 * @return If no $key is specified: an array of arrays in the form [key => [step => error string, ...], ...] -Or-
	 *   If $key is specified: just the inner array for the specified key.
	 */
	public function get_errors($key = '') {
		return $key?$this->repair_errors[$key]:$this->repair_errors;
	}
	
	/**
	 * Gets the repair results. Each result will be one of the RESULT_* class constants
	 * @param (optional) string $key ("Host:Database:Table")
	 * @return If no $key is specified: an array in the form [key => result, ...] -Or-
	 *   If $key is specified: just the result for the specified key.
	 */
	public function get_results($key = '') {
		return $key?$this->repair_result[$key]:$this->repair_result;
	}
	
	/**
	 * Gets the actions taken when repairing the table(s)
	 * @param (optional) string $key ("Host:Database:Table")
	 * @return If no $key is specified: an array in the form [key => [action, ...] -Or-
	 *   If $key is specified: just the inner array for the specified key.
	 */
	public function get_actions($key = '') {
		return $key?$this->repair_actions[$key]:$this->repair_actions;
	}
	
	/**
	 * Get a list of the recent BAK files that are available with how old they are in seconds
	 * @return array in the form [key => age_of_bak, ...]
	 */
	public function get_available_bak_files() {
		return $this->recent_bak_available;
	}
	
	/**
	 * Get a list of the tables which were attempted to be repaired but had no MYD file and whether or not a recent BAK file is available.
	 * @return array in the form [key => bak_exists, ...]
	 */
	public function get_missing_myd_tables() {
		return $this->missing_myd;
	}
	
	/**
	 * Get a list of the tables that had incorrect table definitions when checked
	 * @return array in the form [key => row_count, ...]
	 */
	public function get_bad_def_tables() {
		return $this->bad_def_tables;
	}
	
	/**
	 * Gets the max string length of keys for tables we are working with
	 * @return int The string length of the longest key
	 */
	public function get_max_key_length() {
		return $this->max_key_len;
	}
	
	/**
	 * Gets the list of the tables which we did not attempt to repair due to the size of the MYD along with the MYD size
	 * @return array in the form [key => size, ...]
	 */
	public function get_skipped_due_to_size() {
		return $this->skipped_due_to_size;
	}
	
	/**
	 * Queues a table to be repaired when the do_repairs function is called
	 * @param string $host
	 * @param string $database
	 * @param string $table
	 */
	public function queue_table($host, $database, $table) {
		$key = "$host:$database:$table";
		if (strlen($key) > $this->max_key_len) $this->max_key_len = strlen($key);
		$this->tables_to_repair[$key] = 
			[
				'host' => $host,
				'database' => $database,
				'table' => $this->db->escape_string($table),
			];
	}
	
	/**
	 * Repair the queued tables
	 * @return bool True if no tables failed to repair.
	 */
	public function do_repairs() {
		$this->reset_results();
		$ret = true;
		
		$this->total_tables = count($this->tables_to_repair);
		$this->cur_repair = 0;
		$this->log("\nAttempting to repair {$this->total_tables} table(s):\n");
		ksort($this->tables_to_repair, SORT_NATURAL);
		foreach ($this->tables_to_repair as $table_info) {
			$ret = ((self::RESULT_FAILED != $this->attempt_repair($table_info['host'], $table_info['database'], $table_info['table'])) && $ret);
		}
		return $ret;
		
	}
	
	/**
	 * Repair a singe table
	 * @param string $host
	 * @param string $database
	 * @param string $table
	 * 
	 * @return True if the repair did not fail
	 */
	public function repair_single_table($host, $database, $table, $preserve_results = false) {
		if (!$preserve_results) {
			$this->reset_results();
		}
		$this->total_tables = 1;
		$this->cur_repair = 0;
		
		$this->max_key_len = strlen("$host:$database:$table");
		return (self::RESULT_FAILED != $this->attempt_repair($host, $database, $this->db->escape_string($table)));
	}
	
	
	private function reset_results() {
		$this->skipped_due_to_size = [];
		$this->recent_bak_available = [];
		$this->missing_myd = [];
		$this->bad_def_tables = [];
		$this->repair_errors = [];
		$this->repair_results = [];
		$this->repair_actions = [];
	}
	
	/**
	 * Make sure the internal database object is pointing to the correct host and database and has a valid connection.
	 * 
	 * @param string $host
	 * @param string $database
	 */
	private function ensure_db($host, $database)
	{
		if ($host != $this->cur_host || $database != $this->cur_database) {
			$this->db->set($host, $database);
			if ($this->db->connect(true)) {
				$this->cur_host = $host;
				$this->cur_database = $database;
			} else {
				unset($this->cur_host);
				unset($this->cur_database);
				throw new Exception("Could not connect to $host:$database");
			}
		}
		return true;
	}
	
	private function attempt_repair($host, $database, $table)
	{
		$this->key = "$host:$database:$table";
		$result = self::RESULT_OK;
		
		if (1 == $this->total_tables) {
			$this->log(sprintf("\nRepairing %-{$this->max_key_len}s ", $this->key));
		} else {
			$this->log(sprintf("\n%5d of %-5d Repairing %-{$this->max_key_len}s ", ++$this->cur_repair, $this->total_tables, $this->key));
		}
		try {
			try {
				// Try selecting from the table, repair the table if the select fails or we are forcing a repair
				$this->flush_table($host, $database, $table);
				if ($this->force_repair || !$this->attempt_select($host, $database, $table)) {
					$result = self::RESULT_REPAIRED;
					if ('table_defs' == $table && ('lobby' == $database || 'elevator' == $database)) {
						try {
							$this->replace_table($host, $database, $table);
						} catch (Exception $e) {
							$this->repair_errors[$this->key]['REPLACE_TABLE_DEFS'] = $err;
						}
					} elseif ('frag' != $this->get_db_type($database) || !$this->drop_known_bad_table($host, $database, $table)) {
						// Make sure there aren't too many repairs running
						$waits = 0;
						try {
							$this->ensure_db($host, $database);
						} catch (Exception $e) {
							$this->repair_errors[$this->key]['TOO_MANY_MYSQL_REPAIRS'] = $e->getMessage();
							throw $e;
						}
						while ($this->get_num_mysql_repairs() > $this->max_repairs) {
							if ($waits++ >= $this->max_waits) {
								$waits--;
								$this->repair_errors[$this->key]['TOO_MANY_MYSQL_REPAIRS'] = "More than {$this->max_repairs} check/repair table queries running for too long on $host";
								throw new Exception();
							} else {
								$this->log("\nToo many repairs... sleeping {$this->repair_check_interval} seconds ($waits)");
								sleep($this->repair_check_interval);
							}
						}
						
						// Try repairing the table using MySQL, if that fails drop it if it is a div table, or if not try using ftp to get files from a compatible table
						if (!$this->repair_using_mysql($host, $database, $table)
								&& !$this->drop_and_mirror_div_table($host, $database, $table)
								&& ($this->skip_ftp_repair || !$this->repair_using_ftp($host, $database, $table))) {
							throw new Exception();
						}
					}
				}
			} catch (RepairTablesNoTableException $e) {
				if (!$this->create_table($host, $database, $table)) {
					throw $e;
				}
				$result = self::RESULT_REPAIRED;
			}
			
			if ($this->check_definition && !$this->check_table_definition($host, $database, $table)) {
				throw new Exception();
			}
			
			if ($this->optimize && !$this->optimize_table($host, $database, $table)) {
				throw new Exception();
			}
			
			$this->log($this->sep . ((self::RESULT_OK == $result)?ANSI_COLOR_CODE_SUCCESS:ANSI_COLOR_CODE_INFO) . $result . ANSI_COLOR_CODE_RESET);
			$this->repair_result[$this->key] = $result;
				
		} catch (RepairTablesNoTableException $e) {
			$this->log($this->sep . ANSI_COLOR_CODE_INFO . self::RESULT_MISSING . ANSI_COLOR_CODE_RESET);
			$this->repair_result[$this->key] = self::RESULT_MISSING;
		} catch (RepairTablesLargeTableException $e) {
			$this->log($this->sep . ANSI_COLOR_CODE_INFO . self::RESULT_LARGE . ANSI_COLOR_CODE_RESET);
			$this->repair_result[$this->key] = self::RESULT_LARGE;
		} catch (Exception $e) {
			$this->log($this->sep . ANSI_COLOR_CODE_ERROR . self::RESULT_FAILED . ANSI_COLOR_CODE_RESET);
			$this->repair_result[$this->key] = self::RESULT_FAILED;
		}
		if ($this->repair_errors[$this->key]) {
			switch ($this->repair_result[$this->key]) {
				case self::RESULT_REPAIRED:
				case self::RESULT_LARGE:
					$log_level = LOG_NOTICE;
					$this->log("\nIntermediate Errors:", $log_level);
					break;
				case self::RESULT_FAILED:
					$log_level = LOG_ERR;
					$this->log("\nErrors:", $log_level);
					break;
			}
			foreach ($this->repair_errors[$this->key] as $step => $err) {
				$this->log("\n  $step - $err", $log_level);
			}
		}
		return $this->repair_result[$this->key]; 
		
	}
	
	private function flush_table($host, $database, $table) {
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		try {
			$this->ensure_db($host, $database);
		} catch (Exception $e) {
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $e->getMessage();
			throw $e;
		}
		if (!$this->db->query("FLUSH TABLE {$this->sqlComment} `$table`")) {
			if (1146 == $this->db->Errno) {
				$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = 'Table does not exist';
				throw new RepairTablesNoTableException();
			}
			$err = "FLUSH ERROR: ({$this->db->Errno}) {$this->db->Error}";
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
			throw new Exception($err);
		}
	}
	
	private function attempt_select($host, $database, $table) {
		
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			$this->ensure_db($host, $database);
			if (!$this->db->query("SELECT {$this->sqlComment} * FROM `$table` LIMIT 1")) {
				if (1146 == $this->db->Errno) {
					$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = 'Table does not exist';
					throw new RepairTablesNoTableException();
				} 
				throw new Exception("SELECT FIRST ROW ERROR: ({$this->db->Errno}) {$this->db->Error}");
			}
			if ($this->extended_select) {
				if (!$this->db->squery("SELECT {$this->sqlComment} COUNT(*) - 1 FROM `$table`")) {
					throw new Exception("SELECT COUNT ERROR: ({$this->db->Errno}) {$this->db->Error}");
				}
				$last_row = $this->db->f(0);
				if ($last_row > 0 && !$this->db->query("SELECT {$this->sqlComment} * FROM `$table` LIMIT $last_row, 1")) {
					throw new Exception("SELECT LAST ROW ERROR: ({$this->db->Errno}) {$this->db->Error}");
				}
			}
		} catch (Exception $e) {
			if (0 === strpos(get_class($e), 'RepairTables')) {
				throw $e;
			}
			$err = $e->getMessage();
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
			return false;
		}
		return true;
	}

	private function optimize_table($host, $database, $table) {
	
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			$this->ensure_db($host, $database);
			if (!$this->db->query("OPTIMIZE TABLE {$this->sqlComment} `$table`")) {
				throw new Exception("OPTIMIZE ERROR: ({$this->db->Errno}) {$this->db->Error}");
			}
		} catch (Exception $e) {
			$err = $e->getMessage();
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
			return false;
		}
		return true;
	}
	
	private function drop_known_bad_table($host, $database, $table) {
		if (!self::is_known_bad_tablename($table)) { 
			return false;
		}
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		$this->missing_myd[$this->key] = false;
		$this->drop_bad_table($host, $database, $table, true);
		
		return true;
	}
	
	private function drop_and_mirror_div_table($host, $database, $table) {
		static $mirrored = array();
		if (!preg_match('/^([0-9]+)_div[0-9]*_/', $table, $matches)) {
			return false;
		}
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		$this->missing_myd[$this->key] = false;
		$this->drop_bad_table($host, $database, $table, true);
		if (!array_key_exists($matches[1], $mirrored)) {
			$mirrored[$matches[1]] = true;
			$username = reverse_userid_lookup($matches[1]);
			mirror_divs($username);
		}
		return true;
	}
	
	/**
	 * Drops a table if the table has a bad definition or there is no data file available.
	 * 
	 * @param string host - The host on which the table is located
	 * @param string database - The database in which the table is located
	 * @param string table - The name of the table
	 * @param bool ignore_recent_bak - Optionally ignore the existance of a recent BAK file
	 * @return bool Returns true on success or false on failure. 
	 */
	public function drop_bad_table($host, $database, $table, $ignore_recent_bak = false) {
		$this->key = "$host:$database:$table";
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			if (array_key_exists($this->key, $this->bad_def_tables) || (array_key_exists($this->key, $this->missing_myd) && ($ignore_recent_bak || !array_key_exists($this->key, $this->recent_bak_available)))) {
				$this->ensure_db($host, $database);
				if (!$this->db->query("DROP TABLE {$this->sqlComment} `$table`")) {
					$conn_id = $this->ftp_create_connection($host, $database);
					if (!$this->ftp_remove_table($conn_id, $tablename)) {
						throw new Exception("DROP ERROR: ({$this->db->Errno}) {$this->db->Error}");
					}
					$this->flush_table($host, $database, $table);
				}
			} else {
				throw new Exception("DROP ERROR: Table is not confirmed bad");
			}
		} catch (Exception $e) {
			$err = $e->getMessage();
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
			if ($conn_id) ftp_close($conn_id);
			return false;
		}
		return true;
	}
	
	/**
	 * Creates a table that was determined to be missing
	 * 
	 * @param string host - The host on which to create the table
	 * @param string database - The database in which to create the table
	 * @param string table - The name of the table
	 * 
	 * @return bool True if the table was created. False if the table isn't a required table.
	 * 
	 * @throws RepairTablesNoTableException if unable to create the table.
	 */
	private function create_table($host, $database, $table)
	{
		if (!$this->required_tables[$database] || !array_search($table, $this->required_tables[$database])) {
			return false;
		} else {
			$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
				
			$extra = ('export' == $this->get_db_type($database))?$this->get_compatible_export_table_extra():'';
			$definition = $this->get_compatible_table_def($host, $database, $table);
			
			if (!$definition) {
				$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = "No definition found to create table $table in $database database";
				throw new RepairTablesNoTableException();
			}
			
			$this->ensure_db($host, $database);
			if (!$this->db->query("CREATE TABLE {$this->sqlComment} `$table` ($definition)$extra")) {
				$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = "Unable to create table $table in $database database: ({$this->db->Errno}) {$this->db->Error}";
				throw new RepairTablesNoTableException();
			}
		}
		return true;
	}
	
	private function repair_using_mysql($host, $database, $table)
	{
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			//Check table size before repair
			$conn_id = $this->ftp_create_connection($host, $database);
			$file_info = new MySQLFileInfo();
			$file_info->load($conn_id, $table);
			$this->log("\n$file_info\n", LOG_DEBUG);
			if ($file_info->myd_size > $this->max_table_size) {
				$this->skipped_due_to_size[$this->key] = $file_info->myd_size;
				throw new RepairTablesLargeTableException();
			}
			
			$this->ensure_db($host, $database);
			if (!$this->db->query("REPAIR TABLE {$this->sqlComment} `$table`")) {
				if (1146 == $this->db->Errno) {
					$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = 'Table does not exist';
					throw new RepairTablesNoTableException();
				}
				throw new Exception("Query Error: ({$this->db->Errno}) {$this->db->Error}");
			}
			while ($this->db->next_record()) {
				if (0 == strcasecmp('error', $this->db->f('Msg_type')))
				{
					throw new Exception('MySQL Error: ' . $this->db->f('Msg_text'));
				}
			}
					
		} catch (Exception $e) {
			if ($conn_id) {
				ftp_close($conn_id);
			}
			$this->db->free();
			if (0 === strpos(get_class($e), 'RepairTables')) {
				throw $e;
			}
			$err = $e->getMessage();
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
				
			return false;
		}
		
		return true;
		
	}
	
	private function get_num_mysql_repairs() {
		$num = 0;
		if (!$this->db->query("SHOW PROCESSLIST {$this->sqlComment}")) {
			throw new Exception("Unable to determine number of running checks/repairs.");
		}
		while ($this->db->next_record()) {
			switch ($this->db->f('Command')) {
				case 'Repair':
				case 'Check':
					$num++;
					break;
			}
		}
		$this->db->free();
		return $num;
	}
	
	private function repair_using_ftp($host, $database, $table)
	{
		$ret = true;
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			$conn_id = $this->ftp_create_connection($host, $database);
			
			$file_info = new MySQLFileInfo();
			$file_info->load($conn_id, $table);
			$this->log("\n$file_info\n", LOG_DEBUG);
			
			if ($file_info->data_exists()) {
				$this->replace_missing_or_corrupt_files($conn_id, $host, $database, $table, $file_info);
			} else {
				$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = "Data files do not exist for $table";
				$this->missing_myd[$this->key] = false;
				$ret = false;
			}
			
		} catch (Exception $e) {
			$err = $e->getMessage();
			$ret = false;
			$this->repair_errors[$this->key]['REPLACE_MISSING_OR_CORRUPT_FILES'] = $err;
		}
				
		$this->remove_compatible_table();

		if ($conn_id) {
			ftp_close($conn_id);
		}
		return $ret;
	}
	
	private function replace_missing_or_corrupt_files($conn_id, $host, $database, $table, MySQLFileInfo $file_info) {
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		$err = '';
		try {
			// create a compatible table
			$this->create_compatible_table($host, $database, $table);
			
			// get information about the compatible table;
			$compatible_file_info = new MySQLFileInfo();
			$compatible_file_info->load($conn_id, $this->compatible_table_name);
			$this->log("\n$compatible_file_info\n", LOG_DEBUG);
				
			
			// Rename .BAK to .MYD if requested and .BAK is new enough, double check that we want to if that is the only file for the table
			if (!$file_info->myd_exists) {
				if ($file_info->bak_exists && $file_info->bak_file_age < (2 * 24 * 60 * 60)) {
					$this->recent_bak_available[$this->key] = $file_info->bak_file_age;
					if ($this->restore_myd_from_bak) {
						if ($this->recreate_when_only_bak_exists || $file_info->frm_exists || $file_info->myi_exists) {
							$this->log($this->sep.($this->repair_actions[$this->key][] = 'CREATE_MYD_FROM_BAK'));
								
							$this->ftp_file_copy($conn_id, $file_info->bak_file_name, $table . '.MYD');
							$file_info->myd_exists = true;
						} else {
							$err = "No other files exist for $table, and we weren't asked to create from .BAK only.";
						}
					} else {
						$err = "Not renaming {$file_info->bak_file_name} to $table.MYD because we weren't asked to.";
					}
				} else {
					$err = ".MYD is missing for $table and no recent .BAK file exists.";
				}
			}
			
			// Only fix up the other files if we have an MYD
			if ($file_info->myd_exists) {
				// Create .MYI by copying from compatible table
				$this->log($this->sep.($this->repair_actions[$this->key][] = 'CREATE_MYI_AND_FRM'));
				$this->ftp_file_copy($conn_id, $this->compatible_table_name . '.MYI', $table . '.MYI');
				
				// Create .frm by copying from compatible table
				$this->ftp_file_copy($conn_id, $this->compatible_table_name . '.frm', $table . '.frm');
			} else {
				$this->missing_myd[$this->key] = array_key_exists($this->key, $this->recent_bak_available);
			}
		} catch (Exception $e) {
			$err = $e->getMessage();
		}
		
		$this->remove_compatible_table();
		if ($err) {
				
			throw new Exception($err);
		} else {
			$this->repair_using_mysql($host, $database, $table);
		}
		
	}
	
	private function ftp_create_connection($host, $database) {
		try {
			if (! ($conn_id = ftp_connect($host))) {
				throw new Exception("FTP Connection Error:  Unable to connect to $host");
			}
			if (! @ftp_login($conn_id, $this->ftp_username, $this->ftp_password)) {
				throw new Exception('FTP Authentication Error');
			}
			if (! @ftp_chdir($conn_id, self::FTP_BASE_DIR . $database)) {
				throw new Exception('FTP: Unable to change directory to ' . self::FTP_BASE_DIR . $database);
			}
		} catch (Exception $e) {
			if ($conn_id) ftp_close($conn_id);
			throw $e;
		}
			
		return $conn_id;
	}

	private function ftp_remove_table($conn_id, $table) {
		$fileinfo = new MySQLFileInfo();
		$fileinfo->load($conn_id, $table);
		if ($fileinfo->frm_exists || $fileinfo->myi_exists || $fileinfo->myd_exists)
			return @ftp_delete($conn_id, $table . '.*');
		else {
			return true;
		}
	}
	
	private function ftp_file_copy($conn_id, $source, $dest)
	{
		$local_file = tempnam('/tmp', 'repair_table_');
		if (!ftp_get($conn_id, $local_file, $source, FTP_BINARY))
		{
			unlink($local_file);
			throw new Exception("Unable to get $source when copying $source to $dest.");
		}
		
		ftp_delete($conn_id, $dest);
	
		if (!ftp_put($conn_id, $dest, $local_file, FTP_BINARY))
		{
			unlink($local_file);
			throw new Exception("Unable to put $dest when copying $source to $dest.");
		}
		unlink($local_file);
	}
	
	
	private function get_compatible_table_def($host, $database, $table) {
		$definition = '';
		
		switch ($this->get_db_type($database)) {
			case 'frag':
				$definition = $this->get_compatible_frag_table_def($table);
				break;
			case 'export':
				$definition = $this->get_compatible_export_table_def();
				break;
			case 'lobby':
			case 'elevator':
			case 'suite':
			case 'visits':
			case 'metrics':
			case 'config':
			case 'cache_commands':
				$definition = $this->get_compatible_cache_table_def($host, $database, $table);
				break;
			default:
				throw new Exception("Unknown Database type $database");
		}
		
		return $definition;
	}
	
	private function create_compatible_table($host, $database, $table) {
		$this->remove_compatible_table();
		$extra = ('export' == $this->get_db_type($database))?$this->get_compatible_export_table_extra():'';
		$definition = $this->get_compatible_table_def($host, $database, $table);
		
		if (!$definition) {
			throw new Exception("No definition found to create compatible table for $table in $database database");
		}

		$this->ensure_db($host, $database);
		if (!$this->db->query("CREATE TABLE {$this->sqlComment} `{$this->compatible_table_name}` ($definition) $extra")) {
			throw new Exception("Unable to create compatible table for $table in $database database: ({$this->db->Errno}) {$this->db->Error}");
		}
		$this->compatible_table_location = ['host' => $host, 'database' => $database];
		
	}
	
	private function remove_compatible_table() {
		if ($this->compatible_table_location) {
			$this->ensure_db($this->compatible_table_location['host'], $this->compatible_table_location['database']);
			$this->db->query("DROP TABLE {$this->sqlComment} `{$this->compatible_table_name}`");
			$this->compatible_table_location = [];
		}
	}
	
	private function get_db_type($database) {
		static $replacements = [
			'/^ss[0-9]{4,5}(_(ru|ar))?$/' => 'frag',
			'/^export[0-9]{4}$/' => 'export'
		];
		return preg_replace(array_keys($replacements), array_values($replacements), $database);
	}
	
	private function get_compatible_frag_table_def($table) {
		$table = preg_replace('/^([0-9]+_.+_)now[0-9]+(_[0-9]+)$/', '$1now$2', $table);
		return $this->ftc->get_datadef($table);
	}
	
	private function get_compatible_cache_table_def($host, $database, $table) {
		if (('lobby' == $database && preg_match('/^(lobby|tmp_lobbyd[0-9]+$)/', $table)) || ('elevator' == $database && preg_match('/^elev(99)?_/', $table))) {
			$type99 = ('elev99_' == substr($table, 0, 7) || 'lobby99' == $table);
			// Create the definiton from the table_defs table
			// If the table_defs table is corrupt or does not exist then recreate it by calling this function for table_defs and try again
			try {
				$def = $this->get_def_from_table_defs($host, $database, $type99);
			} catch (Exception $e) {
				$this->replace_table($host, $database, $table);
				$def = $this->get_def_from_table_defs($host, $database, $type99);
			}
			return $def;
		} else {
			// Get the table def from the same table on another lobby server
			$source_host = $this->get_random_cache_recovery_server($host);
			try {
				$def = $this->get_def_from_create_table($source_host, $database, $table);
			} catch (Exception $e) {
				throw new Exception("'$table' is in a cache server database, but does not exist on $source_host:$database");
			}
			return $def;
		}
	}
	
	private function get_compatible_export_table_def() {
		static $def = null;
		if (null == $def) {
			$fields = $indexes = [];
			$mdb = new masterdb();
			$sql = <<<SQL
				SELECT {$this->sqlComment}
					`row_type`,
					`field`
				FROM 
					`export_table_defs`
				WHERE 
					`table_type` = 'export'
					AND
					`row_type` IN ('field', 'index')
				ORDER BY
					`field_order`
SQL;
			if ($mdb->query($sql)) {
				while ($mdb->next_record()) {
					switch ($mdb->f('row_type')) {
						case 'field':
							$fields[] = $mdb->f('field');
							break;
						case 'index':
							$indexes[] = $mdb->f('field');
							break;
					}
				}
				$mdb->free();
				
			} else {
				throw new Exception('Unable to load export table definition.');
			}
			
			if (!$fields) {
				throw new Exception('No fields found in export table definition.');
			}
			
			$def = implode(',', $fields) . ($indexes?(',' . implode(',', $indexes)):'');
		}
		
		return $def;
	}

	private function get_compatible_export_table_extra() {
		static $extra = null;
		if (null === $extra) {
			$rows = [];
			$mdb = new masterdb();
			$sql = <<<SQL
				SELECT {$this->sqlComment}
					`field`
				FROM
					`export_table_defs`
				WHERE
					`table_type` = 'export'
					AND
					`row_type` = 'extra'
				ORDER BY
					`field_order`
SQL;
			if ($mdb->query($sql)) {
				while ($mdb->next_record()) {
					$rows[] = $mdb->f('field');
				}
				$mdb->free();
	
			} else {
				throw new Exception('Unable to load export table definition.');
			}
				
			$extra = implode(' ', $rows);
		}
	
		return $extra;
	}
	
	private function get_random_cache_recovery_server($not_host = '') {
		static $server = null;
		if (null === $server || $not_host == $server) {
			global $localConfig;
			$si = new ServerInventory();
			$groups = implode('-cache-recovery|', $localConfig['data_center_hostname_suffixes']) . '-cache-recovery';
			$servers = $si->get_servers($si->create_servers_spec("sisgroups:$groups"))[2];
			$servers = array_diff($servers, [$not_host]);
			if (!$servers) {
				throw new Exception('No valid cache recovery server found');
			}
			$server = array_rand($servers);
		}
		
		return $server;
	}
	
	private function get_def_from_create_table($host, $database, $table) {
		$this->ensure_db($host, $database);
		if ($this->db->squery("SHOW CREATE TABLE {$this->sqlComment} `$table`")) {
			return implode("\n", array_slice(explode("\n", $this->db->f('Create Table')), 1,-1));
			
		} else {
			throw new Exception("Unable to SHOW CREATE TABLE $table on $host:$database");
		}
		
	}
	
	private function get_def_from_table_defs($host, $database, $type_99) {
		if ('lobby' != $database && 'elevator' != $database) {
			throw new Exception("Cannot get definition from table_defs for tables in $database database");
		}
		$this->ensure_db($host, $database);
		if ($this->db->squery("SELECT {$this->sqlComment} `definition` FROM `table_defs` WHERE `row_type` = 'FIELD'")) { 
			$fields = $this->db->f('definition');
		} else {
			throw new Exception("No FIELD row found in table_defs");
		}
		
		$indexrow = 'INDEX' . ($type_99?'99':'');
		if ($this->db->squery("SELECT {$this->sqlComment} `definition` FROM `table_defs` WHERE `row_type` = '$indexrow'")) {
			$index = $this->db->f('definition');
		} else {
			throw new Exception("No $indexrow row found in table_defs");
		}
		
		return $fields . ($index?", $index":'');
	}
	
	private function log($str, $level = LOG_INFO) {
			if ($level > $this->log_level) {
				return;
			}
			$show_color = true;
			$color = '';
			switch ($level) {
				case LOG_DEBUG:
				case LOG_INFO:
					$show_color = false;
					break;
				case LOG_NOTICE:
					$color = ANSI_COLOR_CODE_INFO;
					break;
					
				case LOG_WARNING:
					$color = ANSI_COLOR_CODE_WARN;
					break;
					
				case LOG_ERR:
				case LOG_CRIT:
				case LOG_ALERT:
				case LOG_EMERG:
					$color = ANSI_COLOR_CODE_ERROR;
					break;
					
			}
			echo_string($str, $color, $show_color);
	}
	
	private function check_table_definition($host, $database, $table) {
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper(__FUNCTION__)));
		
		try {
			$this->create_compatible_table($host, $database, $table);
			$comp_def = $this->get_def_from_create_table($host, $database, $this->compatible_table_name);
			$this->remove_compatible_table();
			if ($comp_def != $this->get_def_from_create_table($host, $database, $table)) {
				$this->bad_def_tables[$this->key] = $this->get_row_count($host, $database, $table);
				throw new Exception("Does not match.");
			}
		} catch (Exception $e) {
			$err = $e->getMessage();
			$this->repair_errors[$this->key][strtoupper(__FUNCTION__)] = $err;
			return false;
		}
		
		return true;
		
	}
	
	private function get_row_count($host, $datables, $table) {
		$this->ensure_db($host, $database);
		if (!$this->db->squery("SELECT COUNT(*) AS c FROM $table")) {
			throw new Exception("FLUSH ERROR: ({$this->db->Errno}) {$this->db->Error}");
		}
		$count = $this->db->f('c');
		$this->db->free();
		return $count;
		
	}

	private function replace_table($host, $database, $table) {
		$this->log($this->sep.($this->repair_actions[$this->key][] = strtoupper('replace_'.$table)));
		
		$source_host = $this->get_random_cache_recovery_server($host);
		
		// Recreate the table instead of just getting the definition
		// Copy the table from another lobby server (a cache recovery server seems like a good option)
		ob_start();
		$ret = copy_tables('', "exact:$table", $source_host, $database, $host, $database);
		ob_end_clean();
		if ('ok' != $ret) {
			throw new Exception("Unable to copy $table from $source_host: $ret");
		}
		
	}
	
	/**
	 * Determines if a tablename is a known bad table.
	 * 
	 * @param string $tablename
	 * 
	 * @return bool True if the table is known to be bad. False otherwise.
	 */
	public static function is_known_bad_tablename($tablename, $userid = null, $force_reload = false) {
		static $patterns = null;
		static $timeout = 0;
		if (null == $patterns || $force_reload || $timeout < time()) {
			$timeout = time() + 86400; // 1 day cache
			$patterns = self::get_known_bad_table_patterns();
		}
		$prefix = '/^' . ((null == $userid)?'[[:digit:]]+':$userid) . '_';
		foreach ($patterns as $pattern) {
			if (preg_match($prefix . $pattern, $tablename)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gets an array of patterns that designate a known bad table
	 * Patterns are defined in the frag_bad_tablename table in the cache_maintenance database and MUST end with a '/'
	 * 
	 * @throws Exception
	 * @return Array of tablename patterns that are known to be bad.
	 */
	public static function get_known_bad_table_patterns() {
		// get patterns from frag_bad_tablename_pattern table
		$patterns = array();
		$db = new DB_Sql('cache_maintenance');
		$db->halt_on_error = false;
		if (!$db->query("SELECT pattern FROM frag_bad_tablename_pattern WHERE pattern LIKE '%/'")) {
			throw new Exception($db->Error, $db->Errno);
		}
		while($db->next_record()){
			$patterns[] = $db->f('pattern');
		}
		return $patterns;
	
	}
	
}

class MySQLFileInfo
{
	private $table_name;
	
	public $bak_exists;
	public $myd_exists;
	public $myi_exists;
	public $frm_exists;
	
	public $bak_size;
	public $myd_size;
	public $myi_size;
	public $frm_size;
	
	public $bak_file_name;
	public $bak_file_age;

	public function __construct()
	{
		$this->bak_exists = $this->myd_exists = $this->myi_exists = $this->frm_exists = false;
		$this->bak_size = $this->myd_size = $this->myi_size = $this->frm_size = 0;
		$this->bak_file_age = PHP_INT_MAX;
		$this->bak_file_name = '';
	}
	
	public function data_exists() {
		return $this->myd_exists || $this->bak_exists;
	}
	
	public function __toString() {
		$str = [];
		if ($this->table_name) {
			$str[] = "Table: {$this->table_name}";
			if ($this->frm_exists) {
				$str[] = '  frm Size: ' . get_human_readable_size($this->frm_size, 2);
			} else {
				$str[] = '  frm: MISSING';
			}
			if ($this->myi_exists) {
				$str[] = '  MYI Size: ' . get_human_readable_size($this->myi_size, 2);
			} else {
				$str[] = '  MYI: MISSING';
			}
			if ($this->myd_exists) {
				$str[] = '  MYD Size: ' . get_human_readable_size($this->myd_size, 2);
			} else {
				$str[] = '  MYD: MISSING';
			}
			if ($this->bak_exists) {
				$str[] = sprintf('  BAK Size: %s Name: %s Age: %s', get_human_readable_size($this->bak_size, 2), $this->bak_file_name, secondsToPeriod($this->bak_file_age));
			}
		} else {
			$str[] = 'No table loaded';
		}
		return implode("\n", $str) . "\n";
	}

	public function load($conn_id, $table_name)
	{
		$this->table_name = $table_name;
		if (false === ($mysql_files = ftp_nlist($conn_id, "-l $table_name.*"))) {
			throw new Exception("ftp_nlist failed for '-l $table_name.*'");
		}
		if (false === ($bak_files = ftp_nlist($conn_id, "-l $table_name-*.BAK"))) {
			throw new Exception("ftp_nlist failed for '-l $table_name-*.BAK'");
		}

		foreach (array_merge($mysql_files, $bak_files) as $line) {
			$file_details = preg_split('/ +/', $line);
			if (count($file_details) < 9) {
				throw new Exception("Invalid information returned when looking for files: $line");
			}
			$size = intval($file_details[4]);
			$file_name = $file_details[8];
			list ($base_name, $ext) = explode('.', $file_name);
			
			if (strtolower($ext) == 'bak') {
				list ($base_name, ) = explode('-', $file_name);
				$modified = ftp_mdtm($conn_id, $file_name);
				if ($modified >= 0) {
					$age = time() - $modified;
					if ($age < $this->bak_file_age) {
						$this->bak_file_age = $age;
						$this->bak_file_name = $file_name;
					}
				}
			}
			
			if ($table_name != $base_name) {
				throw new Exception("Invalid file. $file_name is not for table $table_name");
			}
			
			if (strtolower($ext) == 'bak') {
				$this->bak_exists = true;
				$this->bak_size = $size;
			} elseif (strtolower($ext) == 'myd') {
				$this->myd_exists = true;
				$this->myd_size = $size;
			} elseif (strtolower($ext) == 'myi') {
				$this->myi_exists = true;
				$this->myi_size = $size;
			} elseif (strtolower($ext) == 'frm') {
				$this->frm_exists = true;
				$this->frm_size = $size;
			}
		}
	}
}


/**
 * SELFTEST
 * Usage: php RepairTables.class.php
 */
if (count(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
	(version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
		debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1))) == 0) {
	if (function_exists('xdebug_break')) xdebug_break();
	if (4 != $argc) {
		echo "Usage: php RepairTables.class.php <host> <database> <table>\n";
		exit(1);
	}
	try {
		$r = new RepairTables(LOG_DEBUG);
		$r->check_definition();
		$r->queue_table($argv[1], $argv[2], $argv[3]);
		$r->queue_table($argv[1], $argv[2], 'zfoo');
		
		echo "\n\n" . ($r->do_repairs()?ANSI_COLOR_CODE_SUCCESS . 'No':ANSI_COLOR_CODE_ERROR_SUBTLE . 'Some') . " Repairs Failed\n" . ANSI_COLOR_CODE_RESET;
		
		$actions = $r->get_actions();
		$errors = $r->get_errors();
		echo "\nResults:\n";
		foreach ($r->get_results() as $table => $result) {
			switch ($result) {
				case RepairTables::RESULT_FAILED:
					$color = ANSI_COLOR_CODE_ERROR_SUBTLE;
					break;
				
				case RepairTables::RESULT_LARGE:
					$color = ANSI_COLOR_CODE_WARN_SUBTLE;
					break;
				
				case RepairTables::RESULT_MISSING:
				case RepairTables::RESULT_REPAIRED:
					$color = ANSI_COLOR_CODE_INFO;
					break;
					
				case RepairTables::RESULT_OK:
					$color = ANSI_COLOR_CODE_SUCCESS;
			}
			printf("   %s : %s%s\n" . ANSI_COLOR_CODE_RESET, $table, $color, $result);
			printf("     Steps: %s\n", implode(' -> ', $actions[$table]));
			if (RepairTables::RESULT_FAILED == $result) {
				echo "     Errors:\n";
				foreach ($errors[$table] as $step => $error) {
					printf("       %s : %s\n", $step, $error);
				}
			}
			echo "\n";
		}
	} catch (Exception $e) {
		fprintf(STDERR, "caught %s%s%s\n", get_class($e),
			$e->getCode() ? sprintf(', code=%d', $e->getCode()) : '',
			$e->getMessage() ? sprintf(', message="%s"', $e->getMessage()) : '');
		exit(1);
	}
}
