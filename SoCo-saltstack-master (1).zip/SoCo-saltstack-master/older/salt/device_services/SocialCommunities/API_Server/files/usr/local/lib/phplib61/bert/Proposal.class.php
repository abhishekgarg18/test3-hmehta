<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * a Proposal indicates a desired future setup for cache and/or frag and optional preceding current setup with semicolon separator.
 * it accepts a few string forms but internally converts to canonical form, listed first below.
 * accordingly, asString() may not return the value accepted by withString().
 * SetupString;SetupString
 * SetupString;SetupString (BRS omitted on second for brevity)
 * SetupString;AdjustString
 * SetupString
 * BRS:AdjustString
 *
 * @author  Jack Thomasson <thomasso@adobe.com>
 *
 * @version $Id: $
 */
require_once 'AdjustString.class.php';
require_once 'SetupString.class.php';
require_once 'ProposedSetup.class.php';

/**
 * @class Proposal
 */
class Proposal {
	private $current;
	private $proposed;

	/**
	 * construct a Proposal
	 * note this function is private so not for external consumption, instead use the public static with* forms
	 */
	private function __construct() {
	}

	/**
	 * construct a Proposal from a string representation
	 * @param string $proposal
	 * @return Proposal
	 * @throws Exception
	 */
	public static function withString($proposal) {
		$that = new Proposal;
		$setups = split(';', $proposal);
		switch (count($setups)) {
		case 1:
			// construct current using setup with proposed as guide
			if (($matches = AdjustString::split($setups[0]))) {
				$BRS = $matches[0];
				$adjust = AdjustString::withString($matches[1]);
			} else {
				$that->proposed = SetupString::withString($setups[0]);
				$BRS = $that->proposed->base();
			}
			// determine current setup
			$host_specified = AdjustString::actual($setups[0]);
			$currentSetup = new ProposedSetup($BRS);
			$that->current = $currentSetup->asSetupString($BRS);
			if ($adjust) {
				$currentSetup->adjust($adjust);
				$that->proposed = $currentSetup->asSetupString($BRS);
			}
			break;
		case 2:
			// construct current from given
			$that->current = SetupString::withString($setups[0]);
			$BRS = $that->current->base();
			if (preg_match('/:[-+]/', $setups[1])) {
				if (0 === strpos($setups[1], $BRS))
					$setups[1] = substr($setups[1], 1+strlen($BRS)); // strip BRS, if provided
				$that->proposed = ProposedSetup::withSetupString($that->current);
				$that->proposed->adjust(AdjustString::withString($setups[1]));
				$that->proposed = $that->proposed->asSetupString($BRS);
				break;
			}

			// run proposed fully through its paces
			try {
				$that->proposed = SetupString::withString($setups[1]);
			}
			catch (AdjustStringParseException $e) {
				// prepend BRS from current
				$that->proposed = SetupString::withString($that->current->base().':'.$setups[1]);
			}
			try {
				if ($that->current->base() !== $that->proposed->base())
					throw new Exception("current BRS ({$that->current->base()}) and proposed BRS ({$that->proposed->base()}) must match");
			}
			catch (SetupStringMissingBRSException $e) {
				// prepend BRS from current
				$that->proposed = SetupString::withString($that->current->base().':'.$setups[1]);
				if ($that->current->base() !== $that->proposed->base())
					throw new Exception("current BRS ({$that->current->base()}) and proposed BRS ({$that->proposed->base()}) must match");
			}
			break;
		default:
			throw new Exception('Proposal formatted incorrectly');
		}
		return $that;
	}

	/**
	 * construct a Proposal from two SetupStrings
	 * @param SetupString $current
	 * @param SetupString $proposed
	 * @return Proposal
	 */
	public static function withSetupString(SetupString $current, SetupString $proposed) {
		$that = new Proposal;
		$that->current = $current;
		$that->proposed = $proposed;
		return $that;
	}

	/**
	 * return the "current" portion of a Proposal
	 * @return SetupString
	 */
	public function current() {
		return $this->current;
	}

	/**
	 * return the "proposed" portion of a Proposal
	 * @return SetupString
	 */
	public function proposed() {
		return $this->proposed;
	}

	/**
	 * construct a string representation of a Proposal
	 * @return string
	 */
	public function asString() {
		return $this->current->asString().';'.$this->proposed->asString();
	}

	/**
	 * provide descriptive help and samples
	 * @return array [0] => help, [1+] => samples
	 */
	public static function HELP() {
		static $HELP;
		if (!$HELP) {
			$help = SetupString::HELP();
			$HELP = array(
				"one or two setup strings separated by a semicolon representing optional current setup and proposed setup.  a setup string is ".$help[0],
				$help[2].',C:oak1:4:e;'.$help[3],
				$help[1].','.$help[2].';'.$help[4],
				);
		}
		return $HELP;
	}
}


/**
 * SELFTEST
 * Usage: php Proposal.class
 */
if (!(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
      (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
       debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)))) {
	if (function_exists('xdebug_break')) xdebug_break();
	define('DEBUG_MESSAGES', 1);

	echo join("\n", Proposal::HELP()), "\n";
	if (1 < count($argv))
		array_splice($argv, 0, 1);
	else
		$argv = split("\n", <<<SAMPLE
ha-testing-jkt-clean:H:ut1:1:e,C:ut1:1:e;ha-testing-jkt-clean:L:1,H:scvm112.dev.ut1,C:db129.ut1,U:1
ha-testing-jkt-clean:H:ut1:1:e,C:ut1:1:e;L:1,H:scvm112.dev.ut1,C:db129.ut1,U:1
ha-testing-jkt-clean:U:ut1:2:d,F:ut1:1:c;ha-testing-jkt-clean:C:ut1:1:?
ha-testing-jkt-clean:L:1,H:scvm112.dev.ut1,C:db129.ut1,U:1
ha-testing-jkt-clean:L:1,H:scvm112.dev.ut1
ha-testing-jkt-clean:C:db129.ut1,U:1
ha-testing-jkt-clean:C:+1
ha-testing-jkt-clean:H:ut1:2:e,C:ut1:1:e;H:-1
ha-testing-jkt-clean:H:ut1:1:e,C:ut1:1:e;H:+ut1:1:e
ha-testing-jkt-clean:H:+scvm102.dev.ut1
ha-testing-jkt-clean:H:-scvm112.dev.ut1
SAMPLE
		             );
	foreach ($argv as $s) {
		echo "processing '$s'\n";
		$proposal = Proposal::withString($s);
		echo var_export(($setup = ProposedSetup::withSetupString($proposal->proposed())), TRUE), "\n";
		echo $proposal->asString(), "\n";
	}

	exit(0);
}
?>
