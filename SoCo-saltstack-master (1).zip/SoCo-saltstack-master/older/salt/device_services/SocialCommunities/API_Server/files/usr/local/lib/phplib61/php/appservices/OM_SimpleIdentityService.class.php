<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once 'appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php';
require_once 'appservices/OM_AppServiceBase.class.php';
class OM_SimpleIdentityService extends OM_AppServiceBase {

	const METRIC_IDENTITY_PREFIX = "metrics/";
	const DIMENSION_IDENTITY_PREFIX = "variables/";

	/**
	 * @var OM_Dimension[]
	 */
	private $dimensions;

	private $hidden_dimensions;

	/**
	 * @var OM_Metric[]
	 */
	private $metrics;

	private $hidden_metrics;

	private function __construct($report_suite, $logger){
		$this->metrics = array();
		$this->hidden_metrics = array();
		$this->dimensions = array();
		$this->hidden_dimensions = array();

		$token = OM_AnalyticsServicesAccessTokenGenerator::getIMSServiceToken();
		if($token){
			if($report_suite){
				$this->populateFromIdentityService($report_suite,$token, $logger);
			}else{
				if ($logger != null) {
					$error_id = $logger->generateUniqueErrorID();
					$full_error_message = "errorId=". $error_id .": Attempted to call identity service without a report suite";
					$logger->warn($full_error_message);
				}
			}
		}
		else{
			if ($logger != null) {
				$error_id = $logger->generateUniqueErrorID();
				$full_error_message = "errorId=". $error_id .": Failed to generate valid appservice access token";
				$logger->warn($full_error_message);

				$e = new Exception();
				$error_string = $e->getTraceAsString();
				$logger->warn($error_string);
			}
		}
	}

	/**
	 * @return OM_Metric[]
	 */
	public function getMetrics(){
		return $this->metrics;
	}

	public function getHiddenMetrics() {
		return $this->hidden_metrics;
	}

	/**
	 * @return OM_Dimension[]
	 */
	public function getDimensions(){
		return $this->dimensions;
	}

	public function getHiddenDimensions() {
		return $this->hidden_dimensions;
	}

	public static function getInstance($report_suite, $logger){
		static $cached_report_suite;
		static $cached_instance;
		//Cache the OM_IdentityService instance to minimize the number of calls to the appservice on each page load
		if(!$cached_instance || $cached_report_suite != $report_suite){
			$cached_report_suite = $report_suite;
			$cached_instance = new OM_SimpleIdentityService($report_suite, $logger);
		}
		return $cached_instance;
	}

	private function populateFromIdentityService($report_suite,$token, $logger){
		$query_string = "?includeHidden=true&expansion=description,fragRelId,oid&locale=" . $GLOBALS['locale'];
		$path = "/identity/$report_suite" . $query_string;
		$response = $this->makePlatformEndpointRequest($path,$token,self::GET_REQUEST);
		if($response->hasErrors()){
			if ($logger != null) {
				$error_id = $response->getErrorId();
				$error_code = $response->getErrorCode();
				$error_message = $response->getErrorMessage();
				$full_error_message = "Error when retrieving metrics and dimensions for report suite $report_suite from the identity service. errorId=". $error_id ." errorCode=$error_code errorMessage=$error_message";
				$logger->warn($full_error_message);
			}
			return false;
		}

		$response_obj = json_decode($response->getResponse());
		if(!$this->parseMetrics($response_obj)){
			if ($logger != null) {
				$logger->warn("appservice failed to return valid metrics from the identity service");
			}
		}

		if(!$this->parseDimensions($response_obj)){
			if ($logger != null) {
				$logger->warn("appservice failed to return valid dimensions from the identity service");
			}
		}
	}

	private function parseMetrics($response_obj){
		$return_value = true;
		if($response_obj && isset($response_obj->metrics)){
			$metrics_array = (array) $response_obj->metrics;
			if(count($metrics_array)){
				foreach($metrics_array as $metric_id => $metric_details){
					$frag_relid = isset($metric_details->fragRelId) ? $metric_details->fragRelId : 0;
					$storage_id = isset($metric_details->storage_id) ? $metric_details->storage_id : false;
					$description = isset($metric_details->description) ? $metric_details->description : "";
					$support = isset($metric_details->support) ? $metric_details->support : array();
					$new_object = array(
							'id' =>self::METRIC_IDENTITY_PREFIX . $metric_id,
							'name' =>$metric_details->name,
							'category' =>$metric_details->category,
							'type' =>$metric_details->type,
							'data_group' =>$metric_details->data_group,
							'frag_relid' =>$frag_relid,
							'description' =>$description,
							'storage_id' =>$storage_id,
							'polarity' =>$metric_details->polarity,
							'support' =>$support,
							'oid' => $metric_details->oid);
					$hidden = $metric_details->hidden;
					if ($hidden) {
						$this->hidden_metrics[self::METRIC_IDENTITY_PREFIX . $metric_id] = $new_object;
					} else {
						$this->metrics[self::METRIC_IDENTITY_PREFIX . $metric_id] = $new_object;
					}
				}
			}
			else{
				$return_value = false;
			}
		}
		else{
			$return_value = false;
		}
		return $return_value;
	}

	private function parseDimensions($response_obj){
		$return_value = true;
		if($response_obj && isset($response_obj->variables)){
			$dimensions_array = (array) $response_obj->variables;
			if(count($dimensions_array)){
				foreach($dimensions_array as $dimension_id => $dimension_details) {
					$frag_relid = isset($dimension_details->fragRelId) ? $dimension_details->fragRelId : 0;
					$storage_id = isset($dimension_details->storage_id) ? $dimension_details->storage_id : false;
					$description = isset($dimension_details->description) ? $dimension_details->description : "";
					$support = isset($dimension_details->support) ? $dimension_details->support : array();
					$hidden = $dimension_details->hidden;
					$new_object = array(
						'id' =>self::DIMENSION_IDENTITY_PREFIX . $dimension_id,
						'name' =>$dimension_details->name,
						'category' =>$dimension_details->category,
						'type' =>$dimension_details->type,
						'data_group' =>$dimension_details->data_group,
						'frag_relid' =>$frag_relid,
						'description' =>$description,
						'storage_id' =>$storage_id,
						'support' =>$support,
						'oid' => $dimension_details->oid);
					if ($hidden) {
						$this->hidden_dimensions[self::DIMENSION_IDENTITY_PREFIX . $dimension_id] = $new_object;
					} else {
						$this->dimensions[self::DIMENSION_IDENTITY_PREFIX . $dimension_id] = $new_object;
					}
				}
			}
			else{
				$return_value = false;
			}
		}
		else{
			$return_value = false;
		}
		return $return_value;
	}
	private function getIdNumFromIdentity($typeString,$identity) {
		$regex = '/.*\/'.$typeString.'([0-9]+)/';
		$matches = array();
		preg_match($regex,$identity,$matches);
		if (count($matches) >1) {
			return $matches[1];
		}
	}
}
