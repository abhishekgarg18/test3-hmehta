<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * The DependencyFinder.class.php file contains the DependencyFinder class.
 *  
 * @author Matt Gould <mgould@adobe.com>
 *  
 */


/**
 * Required files
 */
require_once 'application.inc';
require_once 'lobby_distribution.class';
require_once 'LobbyTrie.class.php';
require_once 'common_functions.inc';
require_once 'cli_tools.inc';


/**
 * Class to determine what bases copy data to others and map the dependency tree.
 *
 * @author mgould
 *
 */
class DependencyFinder {

    public $show_latency;
    public $show_details;
    public $latency_crit;
    public $latency_warn;

    private $lt;
    private $checked_dependency_bases;
    private $checked_dependent_bases;
    private $dependency_color;
    private $shared_host_color;
    private $warn_color;
    private $crit_color;
    private $reset_color;
    
    const LATENCY_CRIT_DEFAULT = 240;
    const LATENCY_WARN_DEFAULT = 240;
    
    const SHAREDHOST = 'SharedHost';
    
    function __construct() {
        $this->lt = new LobbyTrie();
        $this->ldb = new DB_Sql('latencydb');
        $this->ldb->halt_on_error = false;

        $this->checked_dependency_bases = array();
        $this->checked_dependent_bases = array();

        $this->show_latency = false;
        $this->show_details = false;

        $this->latency_crit = self::LATENCY_CRIT_DEFAULT;
        $this->latency_warn = self::LATENCY_WARN_DEFAULT;

        $this->dependency_color = '';
        $this->shared_host_color = '';
        $this->warn_color = '';
        $this->crit_color = '';

        $this->reset_color = '';
    }

    /**
     * Find the bases that users on the base of the current user/base receive hits from.
     * @param string $user The user/base that you want to check dependencies for.
     * @param int $level Used internally to determine the depth of the recursion.
     *
     * @return array - The tree of dependencies that were found.
     */
    function find_dependencies($user, $level = 1) {

        $dependencies = array();
        //get base for user
        $base = $this->lt->getBaseForUser($user);
        if ($level == 1 ) {
            $this->checked_dependency_bases = array($base);
        } else {
            if (in_array($base, $this->checked_dependency_bases)) {
                return array("Previously checked");
            } else {
                $this->checked_dependency_bases[] = $base;
            }
        }

        //get sub-bases
        $sub_bases = $this->lt->getChildBases($base);


        //find everything that copies to this base from duplicated_usernames
        $sql = "SELECT from_username, to_username FROM duplicated_usernames WHERE to_username LIKE '{$base}%'";
        foreach ($sub_bases as $sub) {
            $sql .= " AND to_username NOT LIKE '{$sub}%'";
        }
        $this->ldb->query($sql);
        while ($this->ldb->next_record()) {
            $dependency_user = $this->ldb->f(0);
            $base_user = $this->ldb->f(1);
            $dependency_base = $this->lt->getBaseForUser($dependency_user);
            if ($dependency_base != $base) {
                $dependencies[$dependency_base][$base_user][] = $dependency_user;
            }
        }
        $this->ldb->free();

        // Now go through any bases on the same server and add them to the dependencies
        $base_servers = $this->lt->getServersForBase($base);
        $shared_server_bases = array();
        foreach ($base_servers as $server)
            $shared_server_bases = array_merge($shared_server_bases, $this->lt->getBasesForServer($server));
        $shared_server_bases = array_unique($shared_server_bases);
        foreach ($shared_server_bases as $dependency_base) {
            $base_user = $base;
            $dependency_user = self::SHAREDHOST;
            if ($dependency_base != $base) {
                $dependencies[$dependency_base][$base_user][] = $dependency_user;
            }
        }

        foreach ($dependencies as $dependency_base => $foo) {
            $dependencies[$dependency_base]['dependencies'] = $this->find_dependencies($dependency_base, ++$level);
        }


        return $dependencies;

    }

    /**
     * Find the bases that users on the base of the current user/base duplicate hits to.
     * @param string $user The user/base that you want to check dependencies for.
     * @param int $level Used internally to determine the depth of the recursion.
     *
     * @return array - The tree of dependenceis that were found.
     */
    function find_dependents($user, $level = 1) {
        $dependents = array();
        //get base for user
        $base = $this->lt->getBaseForUser($user);
        if ($level == 1) {
            $this->checked_dependent_bases = array($base);
        } else {
            if (in_array($base, $this->checked_dependent_bases)) {
                return array("Previously checked");
            } else {
                $this->checked_dependent_bases[] = $base;
            }
        }

        //get sub-bases
        $sub_bases = $this->lt->getChildBases($base);

        //find everything that this base copies to from duplicated_usernames
        $sql = "SELECT to_username, from_username FROM duplicated_usernames WHERE to_username <> '' AND from_username LIKE '{$base}%'";
        foreach ($sub_bases as $sub) {
            $sql .= " AND from_username NOT LIKE '{$sub}%'";
        }
        $this->ldb->query($sql);
        while ($this->ldb->next_record()) {
            $dependent_user = $this->ldb->f(0);
            $base_user = $this->ldb->f(1);
            $dependent_base = $this->lt->getBaseForUser($dependent_user);
            if ($dependent_base != $base) {
                $dependents[$dependent_base][$base_user][] = $dependent_user;
            }
        }
        $this->ldb->free();

        // Now go through any bases on the same server and add them to the dependents
        $base_servers = $this->lt->getServersForBase($base);
        $shared_server_bases = array();
        foreach ($base_servers as $server)
            $shared_server_bases = array_merge($shared_server_bases, $this->lt->getBasesForServer($server));
        $shared_server_bases = array_unique($shared_server_bases);
        foreach ($shared_server_bases as $dependent_base) {
            $base_user = self::SHAREDHOST;
            $dependent_user = $base;
            if ($dependent_base != $base) {
                $dependents[$dependent_base][$base_user][] = $dependent_user;
            }
        }


        foreach ($dependents as $dependent_base => $foo) {
            $dependents[$dependent_base]['dependents'] = $this->find_dependents($dependent_base, ++$level);
        }


        return $dependents;

    }

    /**
     * Create a formatted string of the dependencies for a given dependency tree.
     * @param array $dependencies The tree of dependencies generated by find_dependencies
     * @param string $old_prefix used internally to draw the correct tree
     *
     * @return string - A formatted tree of the dependencies.
     */
    function get_dependency_tree($dependencies, $old_prefix = '') {
        $output = '';
        $arrow =  '\__ ';
        $pipe =   '|   ';
        $indent = '    ';
        $num_dependencies = count($dependencies);
        if ($num_dependencies > 0) {
            $num = 0;
            foreach ($dependencies as $base => $subs) {
                if ($subs == "Previously checked") {
                    $output .= $old_prefix . $arrow . "<Previously checked>" . "\n";
                    continue;
                }
                $num++;
                if ($num == $num_dependencies) {
                    $prefix = $old_prefix . $indent;
                } else {
                    $prefix = $old_prefix . $pipe;
                }
                if ($this->show_details) {
                    $details = " (";
                    foreach ($subs as $to => $froms) {
                        if ($to != 'dependencies') {
                            foreach ($froms as $from_user) {
                                $details .= (self::SHAREDHOST == $from_user)?"{$this->shared_host_color}$from_user":"{$this->dependency_color}$from_user=>$to";
                                $details .= "{$this->reset_color}, ";
                            }
                        }
                    }
                    $details = rtrim($details, ', ');
                    $details .= ")";
                } else {
                    $details = '';
                }
                if ($this->show_latency) {
                    $latency = $this->getLatencyForBase($base);
                    if ($latency > $this->latency_crit) $latency = " {$this->crit_color}[$latency]{$this->reset_color}";
                    elseif ($latency > $this->latency_warn) $latency = " {$this->warn_color}[$latency]{$this->reset_color}";
                    else $latency = " [$latency]";
                } else {
                    $latency = '';
                }
                $output .= $old_prefix . $arrow . $base . $latency . $details . "\n";
                $sub_dependency = $subs['dependencies'];
                $output .= $this->get_dependency_tree($sub_dependency, $prefix);
            }
        }
        return $output;
    }


    /**
     * Create a formatted string of the dependents for a given dependent tree.
     * @param array $dependencies The tree of dependents generated by find_dependents
     * @param string $dependents used internally to draw the correct tree
     *
     * @return string - A formatted tree of the dependents.
     */
    function get_dependent_tree($dependents, $old_prefix = '') {
        $output = '';
        $arrow =  '\__ ';
        $pipe =   '|   ';
        $indent = '    ';
        $num_dependents = count($dependents);
        if ($num_dependents > 0) {
            $num = 0;
            foreach ($dependents as $base => $subs) {
                if ($subs == "Previously checked") {
                    $output .= $old_prefix . $arrow . "<Previously checked>" . "\n";
                    continue;
                }
                $num++;
                if ($num == $num_dependents) {
                    $prefix = $old_prefix . $indent;
                } else {
                    $prefix = $old_prefix . $pipe;
                }
                if ($this->show_details) {
                    $details = " (";
                    foreach ($subs as $from => $tos) {
                        if ($from != 'dependents') {
                            foreach ($tos as $to_user) {
                                $details .= (self::SHAREDHOST == $from)?"{$this->shared_host_color}$from":"{$this->dependency_color}$from=>$to_user";
                                $details .= "{$this->reset_color}, ";
                            }
                        }
                    }
                    $details = rtrim($details, ', ');
                    $details .= ")";
                } else {
                    $details = '';
                }
                if ($this->show_latency) {
                    $latency = $this->getLatencyForBase($base);
                    if ($latency > $this->latency_crit) $latency = " {$this->crit_color}[$latency]{$this->reset_color}";
                    elseif ($latency > $this->latency_warn)  $latency = " {$this->warn_color}[$latency]{$this->reset_color}";
                    else $latency = " [$latency]";
                } else {
                    $latency = '';
                }
                $output .= $old_prefix . $arrow . $base . $latency . $details . "\n";
                $sub_dependent = $subs['dependents'];
                $output .= $this->get_dependent_tree($sub_dependent, $prefix);
            }
        }
        return $output;

    }

    /**
     * Find the current lobby latency for the given base
     * @param string $base The base you wnat the latency for.
     *
     * @return int - The lobby latency of the base in minutes.
     */
    function getLatencyForBase($base) {

        $servers = $this->lt->getServersForBase($base);
        if (is_array($servers) && count($servers > 0)) {
            $servers = $this->getDependentLobbies($servers);
            $sql = "SELECT MAX(ROUND((UNIX_TIMESTAMP(NOW()) - IF(lobby_oldest_hit_time>0,lobby_oldest_hit_time,UNIX_TIMESTAMP(NOW())))/60,2)) FROM cache_latency WHERE server IN ('". implode("','", $servers) . "')";
            $this->ldb->query($sql);
            if ($this->ldb->next_record()) {
                $ret = $this->ldb->f(0);
            } else {
                $ret = 'N/A';
            }
            $this->ldb->free();
        } else {
            $ret = 'N/A';
        }
        return $ret;
    }

    /**
     * Find all of the stage2_latency_dependencies for a list of servers.
     * @param array $hosts
     *
     * @return array - The list of all servers found
     */
    function getDependentLobbies($hosts){
        $hosts = (array)$hosts;

        $dependent_hosts = array();

        $server_in = "'0','" . implode("','",$hosts) . "'";

        $sql = "SELECT DISTINCT depends_on from stage2_latency_dependencies where server in ($server_in)";
        $this->ldb->query($sql);
        while ($this->ldb->next_record()) {
            $dependent_hosts[] = $this->ldb->f('depends_on');
        }
        $dependent_hosts = array_unique(array_merge($hosts,$dependent_hosts));
        $new_hosts = array_diff($dependent_hosts,$hosts);
        if(count($new_hosts)) {
            $dependent_hosts = $this->getDependentLobbies($dependent_hosts);
        }

        return $dependent_hosts;
    }

    function show_colors(){
        
        $this->dependency_color = get_ansi_color('green');
        $this->shared_host_color = get_ansi_color('cyan');
        $this->warn_color = get_ansi_color('black', 'yellow');
        $this->crit_color = get_ansi_color('white', 'red');

        $this->reset_color = get_ansi_color();

    }

    function get_dependency_list() {
        sort($this->checked_dependency_bases);
        return $this->checked_dependency_bases;
    }

    function get_dependent_list() {
        sort($this->checked_dependent_bases);
        return $this->checked_dependent_bases;
    }

}


