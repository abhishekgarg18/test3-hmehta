<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * VCookieTransfer.class.php Schedule and manage the dump_truck process for MySQL -> VCCluster Transfer
 *
 * @author  Matt Gould <mgould@adobe.com>
 *
 */
require_once 'application.inc';
require_once 'Config.class.php';
require_once 'ReportSuiteConfig.class';
require_once 'vcookiesMysqlToHbaseFunctions.inc';
require_once 'CacheControl.class';
require_once 'DataMigration.class';

class VCookieTransferException extends Exception {}

class VCookieTransfer {
	private $cc = null;
	private $cmdb;
	
	private $min_hours_enabled; 
	private $sql_comment;
	
	public static $dump_truck_state_names = array(
		0 => 'Scheduled',
		2 => 'Finding Tables',
		4 => 'Transfer In Progress',
		6 => 'Transfers Complete',
		8 => 'Disabling MySQL',
		10 => 'MySQL Disabled',
		12 => 'Deleting Tables',
		14 => 'Complete',
	);
	
	const STATUS_COMPLETE = 14;
	const STATUS_WAITING = 10;
	const STATUS_DELETING = 12;
	const STATUS_UNKNOWN = -1;

	// One HBase handler and one MySQL handler
	const VALID_SHORT_HANDLER = 'HM';
	
	const NO_DATA = '--';
	
	function __construct()
	{
	
		$this->sql_comment = sprintf(" /* MODULE: bertlib FILE: %s CLASS: %s */ ", basename(__FILE__), __CLASS__);
		
		$this->cmdb = new DB_Sql('cache_maintenance');
		$this->cmdb->halt_on_error = false;
		
		$config = new BertConfig(get_class($this));
		$this->min_hours_enabled = $config->filter('min_hours_enabled', 4, FILTER_VALIDATE_INT, array('options' => array('min_range' => 2, 'max_range' => 24)));
			
	}
	
	/**
	 * Start the vcookie transfer process for the given report suite
	 * @param string $rsid The report suite to start
	 * @param bool $execute Do it or just explain what would be done
	 * @param bool $skip_restart Do not restart the elevator daemons even if the report suite may have been recently enabled
	 * @param bool $ignore_data_migration Start the transfer even if the report suite is marked as migrating
	 * @throws VCookieTransferException
	 */
	public function startDumpTruck($rsid, $execute, $skip_restart, $ignore_data_migration = false) {
		$ret = array();

		$rsConfig = new ReportSuiteConfig($rsid);
		
		if (!$ignore_data_migration) {
			$dm = new DataMigration();
			if ($dm->isMigrating($rsid)) {
				throw new VCookieTransferException("$rsid is currently migrating.");
			}
		}
		if (!$rsConfig->get_vcookie_handler_info_flag()) {
			throw new VCookieTransferException("$rsid is not set up to use vCookie handlers.");
		}
		if (static::VALID_SHORT_HANDLER != $rsConfig->get_short_vcookie_handler_info()) {
			throw new VCookieTransferException("$rsid does not have the correct vCookie handlers to start the vCookie Transfer process.");
		}
		$vh_info = $rsConfig->get_vcookie_handler_information();
		if (strtotime($vh_info[0]['start_date'] . ' 23:59:59') > time() - ($this->min_hours_enabled*60*60) && !$skip_restart) {
			// Log that we will restart ignore elevators for this report suite.
			$ret[] = "Start date ({$vh_info[0]['start_date']}) for $rsid may be within the past {$this->min_hours_enabled} hours. Restarting elevator daemons to be safe.";
			$elevs = $rsConfig->get_elevator_servers();

			if ($execute) {
				// Restart ignore elevators for this report suite.
				if (null == $this->cc) {
					$cc = new CacheControl(3);
					$cc->create_command(reset($elevs));
				}
				$cc->restart_ignore_elevatorctl($elevs);
			}
		}
		if ($execute) {
			$errMsg = '';
			StartVcookieMigrationForUsername($rsid, $errMsg, 0);
			if ($errMsg) {
				throw new VCookieTransferException($errMsg);
			}
		}
		$ret[] = "Scheduled $rsid for vCookie Transfer.";
		
		return $ret;
	}
	
	/**
	 * See where the report suite is in the vcookie transfer process
	 * @param string $rsid The report suite
	 * 
	 * @return array labeled for use as a table row
	 */
	public function getDumpTruckStatus($rsid) {
	
		$status = $this->getDumpTruckProcessStatus($rsid);
		if (4 <= $status['status']) {
			list($done, $total, $in_progress) = $this->getDumpTruckTableTransferProgress($rsid);
			if ($in_progress || $done) {
				$transfer_progress = "$done of $total";
			} else {
				$transfer_progress = "$total Not Started";
			}
		} else {
			$transfer_progress = static::NO_DATA;
		}

		return array(
			'RSID' => $rsid,
			'State' => $status['state'],
			'Tables Transfered' => $transfer_progress,
			'Scheduled' => $status['added'],
			'Tables Found' => $status['tables found'],
			'Transfers Complete' => $status['xfer complete'],
			'MySQL Disabled' => $status['mysql disabled'],
			'Tables Deleted' => $status['tables deleted'],

		);
	}

	/**
	 * Get the number of report suites in each vcookie transfer state
	 * 
	 * @return array of rows suitable for use in displaying a table of the counts
	 * @throws VCookieTransferException
	 */
	public function getDumpTruckStateSummary() {
		$summary = [];
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				status,
				COUNT(*) as c
			FROM
				vcookie_migration
			GROUP BY
				status
			ORDER BY
				status
SQL;
		if (!$this->cmdb->query($sql)) {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: \nSQL: $sql \nERRNO: {$this->cmdb->Errno} \nERROR: {$this->cmdb->Error}");
		}
		while ($this->cmdb->next_record(MYSQL_ASSOC)) {
			$summary[] = ['State' => static::getStateText($this->cmdb->f('status')), 'Count' => $this->cmdb->f('c')];
		}
		$this->cmdb->free();
		return $summary;
	}
	
	/**
	 * Get a list of report suites in the given status
	 * @param int $status The status we are asking about
	 * 
	 * @return array of report suites
	 * @throws VCookieTransferException
	 */
	public function getReportSuitesByStatus($status) {
		if (!array_key_exists($status, static::$dump_truck_state_names)) {
			throw new VCookieTransferException("ERROR: $status is not a valid status.");
		}
		$rsids = [];
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				username as rsid
			FROM
				vcookie_migration
			WHERE
				status = $status
SQL;
		
		if (!$this->cmdb->query($sql)) {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: \nSQL: $sql \nERRNO: {$this->cmdb->Errno} \nERROR: {$this->cmdb->Error}");
		}
		while ($this->cmdb->next_record(MYSQL_ASSOC)) {
			$rsids[] = $this->cmdb->f('rsid');
		}
		$this->cmdb->free();
		
		return $rsids;
	}

	private function getDumpTruckProcessStatus($rsid) {
			
		$rsConfig = new ReportSuiteConfig($rsid);
		$numeric_rsid = $rsConfig->get_userid();
		
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				status,
				added_dt_tm,
				tables_found_dt_tm,
				transfers_complete_dt_tm,
				check_mysql_disabled_dt_tm,
				vcookie_tables_deleted_dt_tm
			FROM
				vcookie_migration
			WHERE
				userid=$numeric_rsid
SQL;
		if ($this->cmdb->squery($sql)) {
			$ret = array(
				'status' => $this->cmdb->f('status'),
				'added' => $this->cmdb->f('added_dt_tm'),
				'tables found' => $this->cmdb->f('tables_found_dt_tm'),
				'xfer complete' => $this->cmdb->f('transfers_complete_dt_tm'),
				'mysql disabled' => $this->cmdb->f('check_mysql_disabled_dt_tm'),
				'tables deleted' => $this->cmdb->f('vcookie_tables_deleted_dt_tm'),
			);
			$ret['state'] = static::getStateText($ret['status']);
			$this->cmdb->free();
	
			array_walk($ret, 'VCookieTransfer::dateToDash');
		} else {
			if ($this->cmdb->Errno) {
				throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
			}
			$ret = array(
				'status' => static::STATUS_UNKNOWN,
				'added' => static::NO_DATA,
				'tables found' => static::NO_DATA,
				'xfer complete' => static::NO_DATA,
				'mysql disabled' => static::NO_DATA,
				'tables deleted' => static::NO_DATA,
			);
			if ($rsConfig->get_vcookie_handler_info_flag() && 
				static::VALID_SHORT_HANDLER == $rsConfig->get_short_vcookie_handler_info()
			) {
				$ret['state'] = 'Not Scheduled';
			} else {
				$ret['state'] = 'Not Ready for Transfer';
			}
		}
		
		return $ret;
	
	}
	
	/**
	 * Get a list of report suites is any status except "Complete"
	 * @return array of report suites
	 * @throws VCookieTransferException
	 */
	public function getRsidsInProgress() {
		$rsids = array();
		$sql = sprintf(<<<SQL
			SELECT %s
				username as rsid
			FROM
				vcookie_migration
			WHERE
				status != %d
SQL
			, $this->sql_comment, static::STATUS_COMPLETE);
		if ($this->cmdb->query($sql)) {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$rsids[] = $this->cmdb->f('rsid');
			}
			$this->cmdb->free();
		} else {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
		}
		return $rsids;
	}
	
	/**
	 * Gets a list of Report Suites that were scheduled for transfer in a given date range
	 * 
	 * @param string $start_date The beginning date - Default today
	 * @param string $end_date The ending date - Default $start_date
	 * @throws Exception If database access fails
	 * @return array The report suites scheduled in the given period
	 */
	public function getRsidsScheduledInDateRange($start_date = null, $end_date = null) {
		if (null === $start_date) {
			$start_date = date(MYSQL_DATE_ONLY_FORMAT);
		} else {
			$start_date = date(MYSQL_DATE_ONLY_FORMAT, strtotime($start_date));
		}
		if (null === $end_date) {
			$end_date = $start_date;
		} else {
			$end_date = date(MYSQL_DATE_ONLY_FORMAT, strtotime($end_date));
		}
		if (strtotime($end_date) < strtotime($start_date)) {
			$x = $start_date;
			$start_date = $end_date;
			$end_date = $x;
		}
		
		$rsids = array();
		$sql = sprintf(<<<SQL
			SELECT %s
				username as rsid
			FROM
				vcookie_migration
			WHERE
				added_dt_tm >= '%s 00:00:00'
				AND
				added_dt_tm <= '%s 23:59:59'
SQL
			, $this->sql_comment, $start_date, $end_date);
		if (!$this->cmdb->query($sql)) {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
		}
		while ($this->cmdb->next_record(MYSQL_ASSOC)) {
			$rsids[] = $this->cmdb->f('rsid');
		}
		$this->cmdb->free();
		return $rsids;
		
	}
	
	/**
	 * Get a string representation of the given state
	 * @param int $status
	 * @return string represtation of the given state
	 */
	public static function getStateText($status) {
		if (array_key_exists($status, static::$dump_truck_state_names)) {
			return $status . ':' . static::$dump_truck_state_names[$status];
		}
		return "$status:Unknown State";
	}
	
	private function getDumpTruckTableTransferProgress($rsid) {
		$rsConfig = new ReportSuiteConfig($rsid);
		$numeric_rsid = $rsConfig->get_userid();
		
		$done = $total = $inprogress = 0;
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				status,
				COUNT(*) AS count
			FROM
				vcookie_migration_tablename_details
			WHERE
				userid=$numeric_rsid
			GROUP BY
				status
SQL;
		if ($this->cmdb->query($sql)) {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				switch ($this->cmdb->f('status')) {
					case 9:
						$done += $this->cmdb->f('count');
						break;
					case 1:
						break;
					default:
						$inprogress += $this->cmdb->f('count');
						break;
				}
				$total += $this->cmdb->f('count');
			}
			$this->cmdb->free();
		} else {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
		}
		return array($done, $total, $inprogress);
	
	}
	
	/**
	 * Change the location for a given table (Used when the table is moved)
	 * @param int $userid Numeric userid of the report suite
	 * @param string $tablename The table that was moved
	 * @param string $src_host The host the tabled moved from
	 * @param string $src_db The database the table moved from
	 * @param string $dest_host The host the table moved to
	 * @param string $dest_db The database the table moved to
	 * 
	 * @return bool True if the change was successful
	 * @throws VCookieTransferException
	 */
	public function updateDumpTruckTableDetailLocation($userid, $tablename, $src_host, $src_db, $dest_host, $dest_db) {
		$ret = false;
		$sql = <<<SQL
		UPDATE {$this->sql_comment}
			vcookie_migration_tablename_details
		SET
			host = '$dest_host',
			db = '$dest_db'
		WHERE
			userid = $userid
			AND
			tablename = '$tablename'
			AND
			host = '$src_host'
			AND
			db = '$src_db'
SQL;
		if ($this->cmdb->query($sql)) {
			if ($this->cmdb->affected_rows()) {
				$ret = true;
			}
		} else {
			throw new VCookieTransferException("Problem updating location for $tablename in vcookie_migration_tablename_details (Old: $src_host $src_db New: $dest_host $dest_db) in cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
		}
		return $ret;
	}

	/**
	 * Get a list of pids that the table transfer process believes to be running on the given host
	 * @param string $host The host to get the pids for
	 * 
	 * @return array of the pids
	 * @throws VCookieTransferException
	 */
	public function getLockedTableTransferProcesses($host = '') {
		$procs = array();
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				userid,
				tablename,
				num,
				lock_host,
				lock_pid
			FROM
				vcookie_migration_tablename_details
			WHERE
				status != 9
				AND lock_pid != 0
				AND lock_host
SQL;
		$sql .= $host?" = '$host'":" != ''";
		
		if ($this->cmdb->query($sql)) {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$procs[] = $this->cmdb->Record;
			}
			$this->cmdb->free();
		} else {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
		}
		
		return $procs;
		
	}
	
	/**
	 * Get a list of pids that the transfer process believes to be running on the given host
	 * @param string $host The host to get the pids for
	 *
	 * @return array of the pids
	 * @throws VCookieTransferException
	 */
	public function getLockedMainTransferProcesses($host = '') {
		$procs = array();
		$sql = <<<SQL
			SELECT {$this->sql_comment}
				userid,
				lock_host,
				lock_pid
			FROM
				vcookie_migration
			WHERE
				status != 14
				AND lock_pid != 0
				AND lock_host
SQL;
		$sql .= $host?" = '$host'":" != ''";
		
			if ($this->cmdb->query($sql)) {
				while ($this->cmdb->next_record(MYSQL_ASSOC)) {
					$procs[] = $this->cmdb->Record;
				}
				$this->cmdb->free();
			} else {
				throw new VCookieTransferException("Problem querying the cache_maintenance database: ERRNO: {$this->cmdb->Errno} ERROR: {$this->cmdb->Error}");
			}

		return $procs;
	}
	
	private static function dateToDash(&$date, $key) {
		if ('0000-00-00 00:00:00' == $date) {
			$date = static::NO_DATA;
		}
	}

	/**
	 * Returns whether the vcookie transfer process is complete for a given report suite
	 * @param string $rsid The report suite in question
	 * @return bool True if the process is complete or if the report suite is set up to only use HBase
	 */
	public function isDumpTruckComplete($rsid) {
		$isComplete = false;

		$status = $this->getDumpTruckProcessStatus($rsid);
		if (static::STATUS_COMPLETE == $status['status']) {
			$isComplete = true;
		} else if (static::STATUS_UNKNOWN == $status['status']) {
			$rsConfig = new ReportSuiteConfig($rsid);
			if ($rsConfig->get_vcookie_handler_info_flag()
				&& !$rsConfig->has_mysql_vcookie_handler()
			) {
				$isComplete = true;
			}
		}

		return $isComplete;
	}
	
	/**
	 * Returns whether a report suite is in the process of being transferred
	 * or waiting for/doing deletion of mysql data
	 * @param string $rsid
	 * @return boolean
	 */
	public function isDumpTruckRunning($rsid) {
		$status = $this->getDumpTruckProcessStatus($rsid);
		return $status['status'] >= 0 && $status['status'] != self::STATUS_COMPLETE; 
	}
	
	/**
	 * Returns whether a report suite is in the process of being transferred
	 * @param string $rsid
	 * @return boolean
	 */
	public function isDumpTruckTransferring($rsid) {
		$status = $this->getDumpTruckProcessStatus($rsid);
		return $status['status'] >= 0 && $status['status'] < self::STATUS_WAITING;
	}
	
	/**
	 * Returns whether a report suite is waiting for deletion
	 * @param string $rsid
	 * @return boolean
	 */
	public function isDumpTruckWaitingForDeletion($rsid) {
		$status = $this->getDumpTruckProcessStatus($rsid);
		return $status['status'] == self::STATUS_WAITING;
	}
	
	/**
	 * Returns whether a report suite is deleting mysql data
	 * @param string $rsid
	 * @return boolean
	 */
	public function isDumpTruckDeleting($rsid) {
		$status = $this->getDumpTruckProcessStatus($rsid);
		return $status['status'] == self::STATUS_DELETING;
	}
	
	/**
	 * Returns if the lock_host and lock_pid field matches for the given rsid
	 * @param string $rsid
	 * @param string $current_host the current lock_host field value
	 * @param string $current_pid the current lock_pid field value
	 * @return boolean true if locked, false if not
	 */
	public function doesDumpTruckLockMatch($rsid, $current_host, $current_pid) {
		$rsConfig = new ReportSuiteConfig($rsid);
		$numeric_rsid = $rsConfig->get_userid();

		if (empty($current_pid)) {
			$current_pid = 0;
		}

		// Escape input parameters
		$current_host = $this->cmdb->escape_string($current_host);
		$current_pid = $this->cmdb->escape_string($current_pid);

		$ret = false;
		$sql = <<<SQL
		SELECT {$this->sql_comment}
			*
		FROM
			vcookie_migration
		WHERE
			userid = $numeric_rsid
			AND
			lock_host = '$current_host'
			AND
			lock_pid = $current_pid
SQL;
		if (!$this->cmdb->query($sql)) {
			throw new VCookieTransferException("Problem querying the cache_maintenance database: \nSQL: $sql \nERRNO: {$this->cmdb->Errno} \nERROR: {$this->cmdb->Error}");
		}
		if ($this->cmdb->num_rows() > 0) {
			$ret = true;
		}
		return $ret;
	}
	
	/**
	 * Sets the lock_host and lock_pid fields in the vcookie_migration table if the 
	 * current host and pid match
	 * @param string $rsid
	 * @param string $current_host the current lock_host field value
	 * @param string $current_pid the current lock_pid field value
	 * @param string $new_host the new lock_host field value
	 * @param string $new_pid the new lock_pid field value
	 * @return boolean true on success, false on failure
	 */
	protected function setDumpTruckLocks($rsid, $current_host, $current_pid, $new_host, $new_pid) {
		$rsConfig = new ReportSuiteConfig($rsid);
		$numeric_rsid = $rsConfig->get_userid();

		// Escape input parameters
		$current_host = $this->cmdb->escape_string($current_host);
		$current_pid = $this->cmdb->escape_string($current_pid);
		$new_host = $this->cmdb->escape_string($new_host);
		$new_pid = $this->cmdb->escape_string($new_pid);

		$ret = false;
		$sql = <<<SQL
		UPDATE {$this->sql_comment}
			vcookie_migration
		SET
			lock_host = '$new_host',
			lock_pid = $new_pid
		WHERE
			userid = $numeric_rsid
			AND
			lock_host = '$current_host'
			AND
			lock_pid = $current_pid
SQL;
		if ($this->cmdb->query($sql)) {
			if ($this->cmdb->affected_rows()) {
				$ret = true;
			}
		}
		return $ret;
	}
	
	/**
	 * Locks dump truck by setting the lock_host and lock_pid columns so dump truck will not 
	 * attempt processing
	 * @param string $rsid
	 * @param string $host
	 * @param string $pid
	 * @return boolean true on success, false on failure
	 */
	public function lockDumpTruck($rsid, $host, $pid) {
		if (empty($host) || empty($pid) || $pid <= 0) {
			throw new VCookieTransferException("A valid host and pid must be specified to lock dump truck");
		}
		return $this->setDumpTruckLocks($rsid, '', 0, $host, $pid);
	}
	
	/**
	 * Unlocks dump truck by clearing the lock_host and lock_pid columns so dump truck will not 
	 * attempt processing. This only clears the locks when the host and pid match.
	 * @param string $rsid
	 * @param string $host
	 * @param string $pid
	 * @return boolean true on success, false on failure
	 */
	public function unlockDumpTruck($rsid, $host, $pid) {
		if (empty($host) || empty($pid) || $pid <= 0) {
			throw new VCookieTransferException("A valid host and pid must be specified to unlock dump truck");
		}
		return $this->setDumpTruckLocks($rsid, $host, $pid, '', 0);
	}
	
}
