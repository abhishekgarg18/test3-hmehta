<?php
/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require_once 'application.inc';
require_once '/home/omniture/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/Retriever.php';
require_once '/home/omniture/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/SecretRetriever.php';
require_once '/home/omniture/bin/p/secret_retrieval.php/1.0/Dms/Shared/SecretRetrieval/RetrieverFactory.php';
require_once 'Config.class.php';

/**
 * Provides a way to get an IMS access token to use with WebAPIs.
 * 
 * @author mgould
 *
 */
class DPO_IMS {
	private static $SECRET_TOKEN;
	private static $IMS_ENDPOINT;
	
	/*
	 * Initializes static variables
	 */
	public static function __init() {
		static $initialized = false;
		if (!$initialized) {
			$config = new BertConfig(__CLASS__);
			self::$SECRET_TOKEN = $config->filter(
					'IMS_token',
					'dpo_ims',
					FILTER_VALIDATE_REGEXP,
					['options' => ['regexp' => '/./']]
				);
			self::$IMS_ENDPOINT = $config->filter(
					'IMS_endpoint',
					(DATA_CENTER == DATA_CENTER_DEV)?'https://ims-na1-stg1.adobelogin.com/ims/token/v1':'https://ims-na1.adobelogin.com/ims/token/v1',
					FILTER_VALIDATE_URL
				);
			$initialized = true;
		}
	}
	
	/**
	 * Gets an IMS access token.
	 * @return string The access token needed for calling other WebAPIs
	 */
	public static function getBearerToken() {
		// encode and decode to make sure object is an array instead of stdClass
		$secret = json_decode(json_encode(Dms_Shared_SecretRetrieval_RetrieverFactory::getCurrentRetriever()->getSecrets([self::$SECRET_TOKEN])), true)[self::$SECRET_TOKEN];

		return self::getBearerTokenWorker(
			self::$IMS_ENDPOINT,
			$secret['username'],
			$secret['password'],
			$secret['meta']['code']
		);
	}
	
	private static function getBearerTokenWorker($endpoint, $client_id, $secret, $code) {
		$ch = curl_init($endpoint);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$post_fields_list = array(
			"client_id"     => $client_id,
			"client_secret" => $secret,
			"code"          => $code
		);
		$post_fields_string = "grant_type=authorization_code";
		foreach ($post_fields_list as $key => $value) {
			$post_fields_string .= "&$key=$value";
		}
		$options = array(
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => $post_fields_string
		);
		curl_setopt_array($ch, $options);
		$response = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if ($status != 200) {
			throw new Exception("There was an error logging in to $endpoint. Raw Response: $response");
		}
		$decoded_response = json_decode($response, true);
		if ($decoded_response == NULL) {
			throw new Exception("There was an error decoding the response from $endpoint. Raw Response: $response");
		}
		return $decoded_response["access_token"];
	}
}

DPO_IMS::__init();