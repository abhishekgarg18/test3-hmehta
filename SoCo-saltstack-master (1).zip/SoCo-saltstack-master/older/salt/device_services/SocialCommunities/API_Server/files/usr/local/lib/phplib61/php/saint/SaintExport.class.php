<?php

require_once("application.inc");
require_once(SC_DIR . "/reports/includes/object_functions.inc");

require_once 'SaintAPI.class.php';
require_once 'saint_export.class';

class CampaignDateRangeFilter
{
	private $_campaign_start_date = "";
	private $_campaign_end_date = "";

	private $_error_array;

	function __construct()
	{
	}

	function setDateRange($start_date, $end_date)
	{
		$this->_campaign_start_date = $start_date;
		$this->_campaign_end_date = $end_date;
	}

	function getStartDate()
	{
		return $this->_campaign_start_date;
	}

	function getEndDate()
	{
		return $this->_campaign_end_date;
	}

	function validate()
	{
		if(!isset($this->_campaign_start_date) ||
				!isset($this->_campaign_end_date))
		{
			$this->add_error(OM_L10n::getString('lib://campaign-start-and-end-date-set', 'A campaign start and end date must be set.'));
		}

		// check for a valid date
		if (!eregi("[0-9]{7}", $this->_campaign_start_date))
		{
			$this->add_error(sprintf(OM_L10n::getString('lib://invalid-start-date', 'Invalid start date: %s'), $this->_campaign_start_date));
		}
		if (!eregi("[0-9]{7}", $this->_campaign_end_date))
		{
			$this->add_error(sprintf(OM_L10n::getString('lib://invalid-end-date', 'Invalid end date: %s'), $this->_campaign_end_date));
		}

		if (count($this->get_errors()) > 0)
		{
			return false;
		}
		return true;
	}

	function add_error($err_string)
	{
		$this->_error_array[] = $err_string;
	}

	function get_errors()
	{
		return $this->_error_array;
	}
}

class SaintExport
{
	private $_select_data_rows_option = 2;
	private $_data_row_limit = 0;
	private $_encoding;

	private $_row_filters = array();

	private $_date_received_filter;

	private $_campaign_filter_option = 0;
	private $_campaign_began_date_range; // = new CampaignDateRangeFilter();
	private $_campaign_end_date_range; // = new CampaignDateRangeFilter();

	private $DATA_FILE_TYPE;
	private $DATA_FILE_VALUE;

	private $_company;
	private $_company_id;
	private $_api_login;
	private $_relid;
	private $_rsid;
	private $_job_id;
	private $_quoted;

	private $_api_helper;
	private $_error_array = array();

	private $_matchWithEmptyColumn;
	private $_matchRelation;

	function __construct($company, $company_id, $api_login, $rsid, $relid, $email)
	{
		$this->_company = $company;
		$this->_company_id = $company_id;
		$this->_api_login = $api_login;
		$this->_relid = $relid;
		$this->_rsid = $rsid;
		$this->_email = $email;
		$this->_api_helper = new SaintAPI($this->_company);
		$this->_quoted = 1; // API Exports are quoted by default unless explicitly asked for non-quoted.
		// do some validation
	}

	function getMatchWithEmptyColumn() {
		return $this->_matchWithEmptyColumn;
	}

	function getMatchRelation() {
		return $this->_matchRelation;
	}

	function addRowMatchWithEmptyColumn($colNum) {
		$this->_matchWithEmptyColumn = $colNum;
	}

	function addRowMatchRelation($colNum) {
		$this->_matchRelation = $colNum;
	}

	function setSelectAllDataRows($selectAll = true)
	{
		// consider exposing these options (not sure what template even does) --ns
		$SELECT_ROWS_TEMPLATE = 0;
		$SELECT_ALL_ROWS = 2;
		$SELECT_LIMITED_ROWS = 3;
		if ($selectAll == true)
		{
			$this->_select_data_rows_option = $SELECT_ALL_ROWS;
		}
		else
		{
			$this->_select_data_rows_option = $SELECT_LIMITED_ROWS;
		}
	}

	function setDataRowLimit($numRows)
	{
		$this->_data_row_limit = $numRows;
	}

	function setDateReceivedFilter($filter)
	{
		$this->_date_received_filter = $filter;
	}

	function addRowMatchFilter($filter)
	{
		$this->_row_filters[] = $filter;
	}

	function clearRowMatchFilters()
	{
		$this->_row_filters = array();
	}

	public static $CAMPAIGN_NO_FILTER = 0;
	public static $CAMPAIGN_ONLY_ACTIVE = 1;
	public static $CAMPAIGN_LIMIT_BY_DATE = 2;

	function setCampaignDateFilterOption($filterOption)
	{
		$this->_campaign_filter_option = $filterOption;
	}

	public static $CAMPAIGN_BEGAN = 1;
	public static $CAMPAIGN_ENDED = 2;

	function addCampaignDateFilter($event, $filter)
	{
		if ($event == SaintExport::$CAMPAIGN_BEGAN)
		{
			$this->_campaign_began_date_range = $filter;
		}
		else if ($event == SaintExport::$CAMPAIGN_ENDED)
		{
			$this->_campaign_end_date_range = $filter;
		}
	}

	function clearCampaignDateFilters()
	{
		unset($this->_campaign_began_date_range);
		unset($this->_campaign_end_date_range);
	}

	function setDataFileTypes()
	{
	}

	function setEncoding($encoding)
	{
		$this->_encoding = $encoding;
	}
	function setQuoted($quoted)
	{
		$this->_quoted = $quoted ? 1 : 0;
	}

	function getJobId()
	{
		return $this->_job_id;
	}

	function validateMatchEmptyColumn() {
		if ($this->_matchWithEmptyColumn == 1024 || $this->_matchWithEmptyColumn == 1025) {
			return true;
		} else {
			// See if the is a div_num
			$divs = $this->getDivNums();
			if (isset($divs[$this->_matchWithEmptyColumn])) {
				return true;
			}
		}
		$this->add_error(OM_L10n::getString('lib://match-empty-column-not-valid', 'Match Empty Column is not valid'));
		return false;
	}

	function validateMatchRelation() {
		if ($this->_matchRelation == 0) {
			return true;
		} else {
			// See if the is a div_num
			$divs = $this->getDivNums();
			if (isset($divs[$this->_matchRelation])) {
				return true;
			}
		}
		$this->add_error(OM_L10n::getString('lib://match-relation-not-valid', 'Match Relation is not valid'));
		return false;
	}

	function getDivNums() {
		if (is_array($this->_divs)) {
			return $this->_divs;
		}
		$db = new masterdb;
		setuserdb($db, $this->_rsid[0]);
		$sql = "SELECT userid FROM user WHERE username = '" . $this->_rsid[0] . "'";
		if ($db->squery($sql)) {
			$uid = $db->f(0);
		} else {
			return array();
		}

		$sql = "SELECT div_num FROM division_setup WHERE userid='{$uid}' AND rel_id=$this->_relid";
		$db->query($sql);
		$this->_divs = array();
		while ($db->next_record()) {
			$this->_divs[$db->f('div_num')] = 1;
		}
		return $this->_divs;
	}

	function addMatchValue($val) {
		$this->_matchValue = $val;
	}

	function validate()
	{
		//
		// Do validation, extract info for job execution
		//
		$ROW_MATCH_EMPTY_FILTER = 1;
		$ROW_MATCH_FILTER = 2;
		$row_filter_val = 0;
		$row_match = 0;
		$row_match_value = "";
		{
			// TODO: commenting out for now
			//      if (!$rf->validate())
			//      {
			//        array_push($this->_error_array, $rf->get_errors());
			//      }
			if (isset($this->_matchWithEmptyColumn) && $this->validateMatchEmptyColumn())
			{
				//echo "found row match with empty column\n";
				$row_filter_val += $ROW_MATCH_EMPTY_FILTER;
				$row_match &= $this->_matchWithEmptyColumn << 8;
			}
			if (isset($this->_matchRelation) && $this->validateMatchRelation()) {
				$row_filter_val += $ROW_MATCH_FILTER;
				$row_match &= $this->_matchRelation & 0xFFFF;
				$row_match_value = $this->_matchValue;
			}
		}
		if (isset($this->_date_received_filter))
		{
			if (!$this->_date_received_filter->validate())
			{
				$this->_error_array = array_merge((array)$this->_error_array, (array)$this->_date_received_filter->get_errors());
				// array_push($this->_error_array, $this->_date_received_filter->get_errors());
			}
		} 
		if ($this->_campaign_filter_option == SaintExport::$CAMPAIGN_LIMIT_BY_DATE)
		{
			if (!isset($this->_campaign_began_date_range) || 
					!isset($this->_campaign_end_date_range))
			{
				$this->add_error(OM_L10n::getString('lib://campaign-limited-by-dates-ranges-missing', 'Specified campaign to be limited by dates, but one or more date ranges are missing'));
			}
			if (!$this->_campaign_began_date_range->validate())
			{
				$this->_error_array = array_merge((array)$this->_error_array, (array)$this->_campaign_began_date_range->get_errors());
			}
			if (!$this->_campaign_end_date_range->validate())
			{
				$this->_error_array = array_merge((array)$this->_error_array, (array)$this->_campaign_end_date_range->get_errors());
			}
		}

		if (count($this->_error_array) > 0)
		{
			// handle errors
			return false;
		}

		//
		// build campaign date range string
		//

		$cb = "::";
		$ce = ":";
		if (isset($this->_campaign_began_date_range))
		{
			$cb = $this->_campaign_began_date_range->getStartDate() . ":" . $this->_campaign_began_date_range->getEndDate() . ":";
		}
		if (isset($this->_campaign_end_date_range))
		{
			$ce = $this->_campaign_end_date_range->getStartDate() . ":" . $this->_campaign_end_date_range->getEndDate();
		}
		$campaign_range = $cb . $ce;

		return true;
	}

	// must call validate() before calling execute()
	function execute()
	{
		// TODO: clean out duplicated code that is used in validation...
		// leave for now to avoid adding bugs and allow variables to still
		// get set that are needed, but this should be fixed.

		//
		// Do validation, extract info for job execution
		//
		$ROW_MATCH_EMPTY_FILTER = 1;
		$ROW_MATCH_FILTER = 2;
		$row_filter_val = 0;
		$row_match = 0;
		$row_match_value = "";
		{
			// TODO: commenting out for now
			//      if (!$rf->validate())
			//      {
			//        array_push($this->_error_array, $rf->get_errors());
			//      }
			if (isset($this->_matchWithEmptyColumn) && $this->validateMatchEmptyColumn())
			{
				$row_filter_val += $ROW_MATCH_EMPTY_FILTER;
				$row_match |= $this->_matchWithEmptyColumn << 8;
			}
			if (isset($this->_matchRelation) && $this->validateMatchRelation()) {
				$row_filter_val += $ROW_MATCH_FILTER;
				$row_match |= $this->_matchRelation & 0xFFFF;
				$row_match_value = $this->_matchValue;
			}
		}

		if (isset($this->_date_received_filter))
		{
			if (!$this->_date_received_filter->validate())
			{
				$this->_error_array = array_merge((array)$this->_error_array, (array)$this->_date_received_filter->get_errors());
				// array_push($this->_error_array, $this->_date_received_filter->get_errors());
			}
		} 
		//    if ($this->_campaign_filter_option == $this->CAMPAIGN_LIMIT_BY_DATE)
		//    {
		//      if (!isset($this->_campaign_began_date_range) || 
		//          !isset($this->_campaign_end_date_range))
		//      {
		//				print "\n\n\n***** this is a freakin error\n\n";
		//        $this->add_error("Specified campaign to be limited by dates, but one or more date ranges are missing");
		//      }
		//      if (!$this->_campaign_began_date_range->validate())
		//      {
		//				print "\n\n\n***** this is a freakin error 12\n\n";
		//        array_push($this->_error_array, $this->_campaign_began_date_range->get_errors());
		//      }
		//      if (!$this->_campaign_end_date_range->validate())
		//      {
		//				print "\n\n\n***** this is a freakin error 13\n\n";
		//        array_push($this->_error_array, $this->_campaign_end_date_range->get_errors());
		//      }
		//    }

		if (count($this->_error_array) > 0)
		{
			// handle errors
			return false;
		}

		//
		// build campaign date range string
		//

		$cb = "::";
		$ce = ":";
		if (isset($this->_campaign_began_date_range))
		{
			$cb = $this->_campaign_began_date_range->getStartDate() . ":" . $this->_campaign_began_date_range->getEndDate() . ":";
		}
		if (isset($this->_campaign_end_date_range))
		{
			$ce = $this->_campaign_end_date_range->getStartDate() . ":" . $this->_campaign_end_date_range->getEndDate();
		}
		$campaign_range = $cb . $ce;

		//
		// create job and put in export table
		//


		$this->_job_id = $this->_api_helper->createJob($this->_api_login, "export");
		if ($this->_job_id)
		{
			$sql =  "insert into saint_export_queue set ";
			$sql .= " rel_id=" . intval($this->_relid);
			$sql .= ", row_count_type=" . $this->_select_data_rows_option;
			$sql .= ", rows=" . intval($this->_data_row_limit);
			$sql .= ", filter_date=\"" . $this->_date_received_filter->getStartDateNum() . $this->_date_received_filter->getEndDateNum() . "\"";  //"\"1070310709\"";
			$sql .= ", filter_type=" . $row_filter_val;
			$sql .= ", filter_classification=\"" . $row_match . "\""; //"0";
			$sql .= ", filter_match=\"" . $row_match_value . "\""; //"(Use * as a wildcard)";
			$sql .= ", export_date_type=" . $this->_campaign_filter_option;
			$sql .= ", export_date_range=\"" . $campaign_range . "\"";
			$sql .= ", report_suites=\"" . implode("*", $this->_rsid) . "\"";
			$sql .= ", email=\"" . $this->_email . "\""; // "\"myemail@omniture.com\"";
			//      $sql .= ", ftp_host=" . "\"ftp1.dev\"";
			//      $sql .= ", ftp_username=" . "\"bugzilla.www14_2714431\"";
			//      $sql .= ", ftp_password=" . "\"ZX5E.0fP\"";
			//      $sql .= ", ftp_port=" . "21";
			//      $sql .= ", ftp_path=" . "\"a\"";
			$sql .= ", company=\"" . $this->_company . "\"";
			$sql .= ", companyid=" . $this->_company_id;
			$sql .= ", login=\"" . $this->_api_login . "\"";
			$sql .= ", encoding=\"" . $this->_encoding . "\"";
			$sql .= ", queue_time=now()";
			$sql .= ", status=" . "NULL";
			$sql .= ", status_msg=". "NULL";
			$sql .= ", status_time=now()";
			$sql .= ", api_id=" . $this->_job_id;
			$sql .= ", quoted=" . $this->_quoted;

			//echo "sql: $sql\n";
			//return false; /// XXX: for testing only

			$db = new DB_Sql("masterdb");
			$db->squery($sql);
			if($db->affected_rows() > 0)
			{
				return true;
			}
			return false;

			return false;
		}
	}

	function add_error($err_string)
	{
		$this->_error_array[] = $err_string;
	}

	function get_errors()
	{
		return $this->_error_array;
	}

	function get_last_error_string()
	{
		return $this->_error_array[(count($this->_error_array)-1)];
	}
}
