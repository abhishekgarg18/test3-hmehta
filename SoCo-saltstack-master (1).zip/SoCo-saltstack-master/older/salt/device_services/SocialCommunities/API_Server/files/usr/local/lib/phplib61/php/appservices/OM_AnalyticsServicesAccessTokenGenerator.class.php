<?php

/**
 * The purpose of this class is to generate access tokens for the new analytics services APIs.
 * The usage pattern is that you would use this class to generate an access token when you initially load up a page that needs to access the Analytics Services APIs.
 * You would then expose that access token to the page as a javascript variable. This javascript variable would then be included as one of the headers on all Analytics Services APIs.
 * The API would verify that this request is an active access token and would also identify the current context (meaning the login company and user ID) based on the access token.
 */
class OM_AnalyticsServicesAccessTokenGenerator
{

	const TOKENTYPE_SITECATALYSTSESSION = 1; //Initially we only support generating an access token from a SiteCatalyst session, but in the future we may support additional types such as IMS.

	const TOKENTYPE_DRTEETHSESSION = 4; //Support generating an access token from a DrTeeth session.

	const HOURS_UNTIL_EXPIRATION = 1; //The default number of hours that an access token will be valid for

	//This should match the values in the AppServiceConstants in the app service
	const CLIENT_ID_ADMINMODULE = 'AM';
	const CLIENT_ID_SITECATALYST = 'SC';
	const CLIENT_ID_SUITE = 'SC';
	const CLIENT_ID_MOBILE = 'MOB';
	const CLIENT_ID_DLREPORTS = 'DL';
	const CLIENT_ID_API = 'WEBSERVICES';
	const CLIENT_ID_ADMINSERVICE = 'ADMINSERVICE';

	private static $clientId = '';

	public function setClientId($id)
	{
		if (is_string($id)) {
			OM_AnalyticsServicesAccessTokenGenerator::$clientId = $id;
		}
	}


	/**
	 * Get an access token that is tied to a specific SiteCatalyst ssSession. This may be an existing token if a token has already been tied to the session. Otherwise it will generate a new access token
	 * @param ssSession $session
	 * @param $companyname
	 * @param $companyid
	 * @param $loginid
	 * @return bool|string        False if a token couldn't be generated or the access token string if successful
	 */
	public function getTokenForSiteCatalystSession($session, $companyname, $loginname, $companyid, $loginid, $clientId = "")
	{
		$token_id = false;
		if ($session instanceof ssSession) {
			$secure_session_id = $session->getSecId(); //Get the secure session ID for the SiteCatalyst. We tie the access token to the secure session ID because 1 user could have multiple session ID query string parameters in a single session, but these are all tied to the same secure session ID.
			if (!$secure_session_id) {
				$session->sec_id(); //When the appservice was first deployed there were a number of errors caused by sessions not having a secure ID. Ideally all callers would have one, but this is a fallback method for sessions that do not have one.
				$secure_session_id = $session->getSecId();
			}
			if ($secure_session_id) {
				$token_type = self::TOKENTYPE_SITECATALYSTSESSION;
				$token_id = $this->getExistingTokenID($token_type, $secure_session_id, $companyid, $loginid);
				if ($clientId == "") {
					$clientId = OM_AnalyticsServicesAccessTokenGenerator::$clientId;
				}
				if (!$token_id) {
					//Company and user IDs need to be stored in the DB so that on the Java side Analytics Services can determine what user and company the access token belongs to. 
					//This information is available in the sessiondb, but isn't in a format that be accessed easily in Java
					$token_id = $this->generateTokenID($companyname . ":" . $loginname);
					$token_id = $this->saveTokenToDB($token_id, $token_type, $secure_session_id, $companyid, $loginid, $clientId);
				}
			}
		}
		return $token_id;
	}

	public function getTokenForUser(User $user, $clientId = "")
	{
		$session = $user->getSession();
		$sess_login = $user->getAttribute('company_login');
		$companyname = $sess_login->company->company;
		$loginname = $sess_login->login;
		$companyid = $sess_login->company->companyid;
		$loginid = $sess_login->loginid;
		return $this->getTokenForSiteCatalystSession($session, $companyname, $loginname, $companyid, $loginid, $clientId);
	}

	public static function getTokenForCurrentUser($clientId = "")
	{
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$session = $GLOBALS['sess'];
		$sess_login = $GLOBALS['sess_login'];
		$companyname = $sess_login->company->company;
		$loginname = $sess_login->login;
		$companyid = $sess_login->company->companyid;
		$loginid = $sess_login->loginid;
		$token_id = $token_generator->getTokenForSiteCatalystSession($session, $companyname, $loginname, $companyid, $loginid, $clientId);
		return $token_id;
	}

	/**
	 * Retrieves an IMS service token. Note that not all appservice endpoints are accessible via a service token.
	 */
	public static function getIMSServiceToken($clientId = IMS_SITECATALYST_SERVICE_CLIENT_ID, $clientSecret = IMS_SITECATALYST_SERVICE_CLIENT_SECRET, $clientAuthCode = IMS_SITECATALYST_SERVICE_CLIENT_AUTHCODE)
	{
		$token = OM_IMSServiceUtil::getServiceAccessToken($clientId, $clientSecret, $clientAuthCode); //TODO: Move OM_IMSServiceUtil to phplib (or just this function) to avoid circular dependency
		if ($token && isset($token->access_token)) {
			return $token->access_token;
		}
		return null;

	}

	/**
	 * Delete an access token from the DB
	 * @param    String $token_id
	 * @return    bool        True if the access token was found in the DB and successfully deleted
	 */
	public function revokeToken($token_id)
	{
		$return_value = false;
		$params = array('token_id' => $token_id);
		$ims_session_db = new DB_Sql(DATABASE_IMS_SESSION);
		$sql = "DELETE FROM analytics_services_access_tokens WHERE token_id=%s{token_id}";
		$query = new DBQuery($ims_session_db, $sql, $params);
		$rs = $query->execute();
		if ($rs->affectedRows()) {
			$return_value = true;
		}
		return $return_value;
	}

	/**
	 * Retrieve an existing token from the DB if there is one of $token_type tied to the $session_id
	 * @param $token_type        For example OM_AnalyticsServicesAccessTokenGenerator::TOKENTYPE_SITECATALYSTSESSION
	 * @param $session_id
	 * @return bool
	 */
	public function getExistingTokenID($token_type, $session_id, $companyid = "", $loginid = "")
	{
		$return_value = false;
		$params = array('token_type' => $token_type, "session_id" => $session_id);
		$ims_session_db = new DB_Sql(DATABASE_IMS_SESSION);
		$sql = "SELECT token_id FROM analytics_services_access_tokens WHERE token_type=%s{token_type} AND session_id=%s{session_id}";

		//Make sure that the token retrieved belongs to the user who is trying to retrieve a token - AN-115121
		if($companyid && $loginid){
			$params["company_id"] = $companyid;
			$params["user_id"] = $loginid;
			$sql .= " AND company_id = %s{company_id} AND user_id = %s{user_id}";
		}

		$query = new DBQuery($ims_session_db, $sql, $params);
		$rs = $query->execute();
		if (!$rs->hasError()) {
			while ($rs->hasNext()) {
				$row = $rs->next();
				$return_value = $row['token_id']; //There should only ever be one token tied to a session
				break;
			}

		}
		$query->free();

		return $return_value;
	}

	protected function saveTokenToDB($token_id, $token_type, $session_id, $company_id = "", $user_id = "", $clientId = "")
	{
		$return_value = $token_id;
		$params = array(
			'token_id' => $token_id,
			'token_type' => $token_type,
			'session_id' => $session_id,
			'company_id' => $company_id,
			'user_id' => $user_id,
			'expiration_time' => $this->getExpirationTime(),
			'client_id' => $clientId
		);

		$ims_session_db = new DB_Sql(DATABASE_IMS_SESSION);
		$sql = "INSERT INTO analytics_services_access_tokens SET token_id=%s{token_id}, token_type=%s{token_type}, session_id=%s{session_id}, company_id=%s{company_id}, user_id=%s{user_id}, expiration_time=%s{expiration_time}, client_id=%s{client_id}";
		$query = new DBQuery($ims_session_db, $sql, $params);
		$query->setErrorTrap(array(1062));
		$rs = $query->execute();
		if ($query->hasError()) {
			if ($query->getErrorCode() == 1062) {
				throw new Exception("Generated duplicate appservice token");
			} else {
				return false;
			}
		} else if ($rs->hasError()) {
			$return_value = false;
		}
		$query->free();
		return $return_value;
	}

	private function getExpirationTime()
	{
		$expiration_time = date("Y-m-d H:i:s", strtotime("+" . self::HOURS_UNTIL_EXPIRATION . " hours"));
		return $expiration_time;
	}

	protected function generateTokenID($salt = "")
	{
		$secure_id = hash("sha256", uniqid($salt, true));
		return $secure_id;
	}
}
