<?php

require_once 'pun/dao/ConfigDao.php';

/**
 * 
 * This class provides services for managing configurations such as email templates and drop down options in the UI
 * 
 *
 */
class ConfigService
{
	private $configDao;
	
	public function __construct()
	{
		$this->configDao = new ConfigDao();
	}
	
	/** 
	 *  Returns the notification email text for the given type and version.
	 */
	public function getEmailTemplate($type, $version = 0)
	{
		return $this->configDao->getLatencyEmailTemplate($type,$version);		
	}

	/**
	 * 
	 * Retrieve the email template for the initial latency notification. This is the email sent when an rsid is newly latent.
	 * @param int $version
	 */
	public function getExternalLatencyEmailTemplate($version = 0)
	{
		return $this->getEmailTemplate(1,$version);		
	}
	
	public function getExternalNewLatencyEmailSubject($version = 0)
	{
		return $this->getEmailTemplate(11,$version);		
	}
	
	public function getExternalContinuingLatencyEmailSubject($version = 0)
	{
		return $this->getEmailTemplate(12,$version);		
	}
	
	public function getExternalEndLatencyEmailSubject($version = 0)
	{
		return $this->getEmailTemplate(13,$version);		
	}
/**
	 * 
	 * This is the email text sent to internal adobe addresses when an rsid looks like it might 
	 * send a notification to the costomer soon.
	 * @param int $version
	 */
	public function getInternalPreLatencyEmailTemplate($version = 0)
	{
		return $this->getEmailTemplate(2,$version);		
	}
	
	public function getInternalPreLatencyEmailSubject($version = 0)
	{
		return $this->getEmailTemplate(22,$version);		
	}
	
	/**
	 * Retrieves the current version of the email template for the given type
	 * @param lint $type
	 */
	public function getCurrentTemplateVersion($type)
	{
		return $this->configDao->getCurrentTemplateVersion($type);
	}

	/**
	 * This method returns an array of available email frequency values to display in the GUI drop down
	 */
	public function getEmailFrequencyOptions()
	{
		return $this->configDao->getEmailFrequencyOptionList();	
	}
	
	/**
	 * replaces all values in the config db for email frequency with the given comma delimited list.
	 * @param string $list comma delimited list of integers.
	 */
	public function replaceEmailFrequencyOptionList($list)
	{
		$this->configDao->replaceEmailFrequencyOptionList($list);
	}

	/**
	 * This method returns an array of available latency threshold values to display in the GUI drop down
	 */
	public function getLatencyThresholdOptions()
	{
		return $this->configDao->getLatencyThresholdOptionList();	
	}
	
	/**
	 * replaces all values in the config db for latency thresholds with the given comma delimited list.
	 * @param string $list comma delimited list of integers.
	 */
	public function replaceLatencyThresholdOptionList($list)
	{
		$this->configDao->replaceLatencyThresholdOptionList($list);
	}

	/**
	 * This method returns an array of strings for notification states available in the UI drop down
	 */
	public function getNotificationStateOptions()
	{
		return $this->configDao->getNotificationStateOptionList();
	}
	
	public function useExtenalEmails()
	{
		$val = $this->configDao->getConfigMiscValue("send_external_emails");
		settype($val,"boolean");
		return $val;
	}
	
	public function isLatencyMonitoringEnabled()
	{
		$val = $this->configDao->getConfigMiscValue("latency_monitoring_enabled");
		settype($val,"boolean");
		return $val;
	}
	
	public function saveLatencyMonitoringEnabled($val)
	{
		$this->configDao->saveConfigMiscValue("latency_monitoring_enabled",$val);
	}
	
	/**
	 * 
	 * sets teh boolean value in the config_misc table which controls whether external emails are sent or not
	 * @param integer $val 0 == false, non zero == true
	 */
	public function saveUseExternalEmails($val)
	{
		$this->configDao->saveConfigMiscValue("send_external_emails",$val);
	}
	
	public function enforceEligibility()
	{
		$val = $this->configDao->getConfigMiscValue("enforce_eligibility");
		settype($val,"boolean");
		return $val;
	}
	
	/**
	 * 
	 * sets the boolean value in the config_misc table which controls whether eligibility for report suites to be monitored is enforced
	 * @param integer $val 0 == false, non zero == true
	 */
	public function saveEnforceEligibility($val)
	{
		$this->configDao->saveConfigMiscValue("enforce_eligibility",$val);
	}
	
	public function getAllClearTime()
	{
		$val = $this->configDao->getConfigMiscValue("all_clear_time");
		settype($val,"integer");
		return $val;
	}
	
	/**
	 * 
	 * sets the integer value in the config_misc table which controls the all clear time. The time in minutes for which a report suite must be under the latency threshold before sending the all clear email
	 * @param integer $val 
	 */
	public function saveAllClearTime($val)
	{
		$this->configDao->saveConfigMiscValue("all_clear_time",$val);
	}
	
	
	public function getPreNotificationlatencyTime()
	{
		$val = $this->configDao->getConfigMiscValue("pre_notification_latency_time");
		settype($val,"integer");
		return $val;
		
	}
	
	/**
	 * 
	 * sets the integer value in the config_misc table which controls the pre latency notification time. The time in minutes under the configured latency threshold for pre notifying internal contacts
	 * @param integer $val 
	 */
	public function savePreNotificationLatencyTime($val)
	{
		$this->configDao->saveConfigMiscValue("pre_notification_latency_time",$val);
	}
	
	public function getV14OperationsContacts()
	{
		$val = $this->configDao->getConfigMiscValue("v14_operations_contacts");
		//settype($val,"string");
		return $val;
		
	}
	
	public function saveV14OperationsContacts($contacts)
	{
		$this->configDao->saveConfigMiscValue("v14_operations_contacts",$contacts);
	}
	
	public function getV15OperationsContacts()
	{
		$val = $this->configDao->getConfigMiscValue("v15_operations_contacts");
		//settype($val,"string");
		return $val;
		
	}
	
	public function saveV15OperationsContacts($contacts)
	{
		$this->configDao->saveConfigMiscValue("v15_operations_contacts",$contacts);
	}
	
	public function getV14PagerContacts()
	{
		$val = $this->configDao->getConfigMiscValue("v14_pager_contacts");
		//settype($val,"string");
		return $val;
	}
	
	public function saveV14PagerContacts($contacts)
	{
		$this->configDao->saveConfigMiscValue("v14_pager_contacts",$contacts);
	}
	
	public function getEmailReturnAddressText()
	{
		$val = $this->configDao->getConfigMiscValue("email_return_address");
		return $val;
	}
	
	public function saveEmailReturnAddressText($returnAddressText)
	{
		$this->configDao->saveConfigMiscValue("email_return_address",$returnAddressText);
	}
	
	public function getPreLatencyNoticeInterval()
	{
		$val = $this->configDao->getConfigMiscValue("prenotice_interval");
		settype($val,"integer");
		return $val;
	}
	
	public function savePreLatencyNoticeInterval($interval)
	{
		$this->configDao->saveConfigMiscValue("prenotice_interval",$interval);
	}
	
	public function getEligibleUserIds()
	{
		return $this->configDao->getEligibleUserIds();
	}
	
	public function isUsernameEligible($username)
	{
		$userid = userid_lookup($username);
		if(!is_null($userid) && $userid != '')
		{
			return $this->isUserIdEligible($userid);
		}
		throw new InvalidParameterException(__METHOD__, "rsid $username is not valid for this data center");
	}
	
	public function isUserIdEligible($userid)
	{
		$id = $this->configDao->getEligibleUserId($userid);
		return (!is_null($id) && $id == $userid); 
	}
	
	public function saveEligibleUserId($id)
	{
		$this->configDao->saveEligibleUserId($id);
	}
	
	public function deleteAllEligibleUserIds()
	{
		$this->configDao->deleteAllEligibleUserIds();
	}
}
