<?php
include ("application.inc");
require_once("pun/services/LatencyEventService.php");
require_once("pun/model/LatencyEvent.php");
require_once("pun/model/LatencyEventSelector.php");

class LatencyEventServiceTest  extends PHPUnit_Framework_TestCase
{
	private $service;
	
	public function __construct()
	{
		$this->service = new LatencyEventService();
	}
	
	public function testCRUD()
	{
		$event = new LatencyEvent();
		$event->setDefId(111);
		$event->setEventType(1);
		$event->setLatency(13456);
		$event->setNoticeId(222);
		$event->setSiteCatalystVersion(14);
		$event->setUserid(444);
		
		$newEvent = $this->service->saveLatencyEvent($event);
		$this->assertNotNull($newEvent);
		$this->assertTrue($newEvent->getId() > 0);
		
		$rEvent = $this->service->getLatencyEvent($newEvent->getId());
		$this->assertNotNull($newEvent);
		$this->assertTrue($newEvent->getId() == $rEvent->getId());

		try 
		{
			$this->service->getLatencyEvent(-1);
			$this->assertTrue(false);
		}
		catch(Exception $ex)
		{
			
		}
		
		$this->service->deleteLatencyEvent($rEvent->getId());
		$rrEvent = $this->service->getLatencyEvent($rEvent->getId());
		$this->assertNull($rrEvent);

		$event = new LatencyEvent();
		$event->setDefId(111);
		$event->setEventType(1);
		$event->setLatency(13456);
		$event->setNoticeId(222);
		$event->setSiteCatalystVersion(14);
		$event->setUserid(444);
		
		$newEvent = $this->service->saveLatencyEvent($event);
		$rEvent = $this->service->getLatencyEvent($newEvent->getId());
		$this->assertNotNull($rEvent);
		$this->assertTrue($newEvent->getId() == $rEvent->getId());
		
		$this->service->deleteLatencyEvents($rEvent->getNoticeId());
		$this->service->deleteLatencyEvents($rEvent->getNoticeId());
		
		$rrEvent = $this->service->getLatencyEvent($rEvent->getId());
		$this->assertNull($rrEvent);
	}
}	
