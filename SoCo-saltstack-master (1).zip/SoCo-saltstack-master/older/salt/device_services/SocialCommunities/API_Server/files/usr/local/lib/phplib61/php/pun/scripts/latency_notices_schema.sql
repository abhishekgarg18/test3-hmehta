
CREATE DATABASE IF NOT EXISTS compass;

USE compass;

DROP TABLE IF EXISTS `latency_event`;
CREATE TABLE IF NOT EXISTS `latency_event` (
  `event_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `event_def_id` bigint(20) unsigned NOT NULL, /* foreign key into latency_event_definition */
  `notice_id` bigint(20) unsigned NOT NULL, /* foreign key into latency_notice */
  `userid` int(10) unsigned NOT NULL, 
  `latency` int(10) unsigned NOT NULL default '0',
  `event_type` int(10) unsigned NOT NULL default '1',
  `event_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `sitecatalyst_version` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY (`event_id`),
  UNIQUE KEY `userid_eventtime` (`userid`,`event_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `latency_event_definition`;
CREATE TABLE IF NOT EXISTS `latency_event_definition` (
  `event_def_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notice_def_id` bigint(20) unsigned NOT NULL, /* foreign key into latency_notice_definition */  
  `userid` int(10) unsigned NOT NULL,
  `username` char(40) NOT NULL,
  `latency_threshold` int(10) unsigned NOT NULL default '0', /* Overrides the latency value in the latency_notice_definition, if it is non zero */
  PRIMARY KEY (`event_def_id`),
  UNIQUE KEY `userid_noticedefid` (`userid`,`notice_def_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `latency_notice`;
CREATE TABLE IF NOT EXISTS `latency_notice` (
  `notice_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `notice_def_id` bigint(20) unsigned NOT NULL, /* foreign key into latency_notice_definition */
  `to_email` varchar(512) NOT NULL,
  `cc_email` varchar(512) default NULL,
  `bcc_email` varchar(512) default NULL,
  `text_version` int(10) unsigned NOT NULL default '1',
  `sent_time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`notice_id`),
  UNIQUE KEY `sent_time_idx` (`sent_time`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `latency_notice_definition`;
CREATE TABLE IF NOT EXISTS `latency_notice_definition` (
  `notice_def_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `billing_customer_id` int(10) unsigned NOT NULL,
  `billing_customer_name` varchar(255) NOT NULL,
  `companyid` int(10) unsigned NOT NULL,
  `company` varchar(50) NOT NULL,
  `adobe_email` varchar(255) default NULL,
  `ha_email` varchar(255) default NULL,
  `email_frequency` int(10) unsigned NOT NULL default '2',
  `latency_threshold` int(10) unsigned NOT NULL default '4',
  `notify_state` varchar(255) default NULL,
  PRIMARY KEY  (`notice_def_id`),
  UNIQUE KEY `companyid` (`companyid`),
  KEY `billing_customer_id_key` (`billing_customer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `latency_notice_def_cust_login_id`;
CREATE TABLE IF NOT EXISTS `latency_notice_def_cust_login_id` (
  `latency_notice_def_id` bigint(20) unsigned NOT NULL,
  `cust_login_id` bigint(20) unsigned NOT NULL,
  `subscribed` tinyint(1) unsigned default 1,
  PRIMARY KEY (`latency_notice_def_id`,`cust_login_id`)
  ) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `email_templates`;
CREATE TABLE IF NOT EXISTS `email_templates` (
  `template_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `template_text` TEXT CHARACTER SET latin1 default NULL,
  `version` int(10) unsigned NOT NULL default '0',
  `type` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`template_id`),
  UNIQUE KEY `verion_type` (`version`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO email_templates (template_text,version,type) values("Latency Notification:  <#COMPANY_NAME#>

<#DATA#>

For any further questions please contact Adobe ClientCare or your supported user. 

Best Regards,
Adobe ClientCare
 
If you would like to unsubscribe to this latency notification email, click the following url:",1,1) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);  /* Need to add this url for unsubscribe https://vm???.dev.omniture.com/p/suite/current/index.html?a=Company.Unsubscribe&c=<companyid>&l=<loginid> */ 
INSERT INTO email_templates (template_text,version,type) values("New Latency Event  <#DATA#>",1,11) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Continuing Latency Event  <#DATA#>",1,12) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("End Latency Event  <#DATA#>",1,13) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Pre Latency Notification.\r\n\r\n <#DATA#>\r\n\r\n",1,2) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Pre Latency Event <#DATA#>",1,22) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);

CREATE TABLE IF NOT EXISTS `config_email_frequency_options` (
  `frequency_option` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`frequency_option`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO config_email_frequency_options (frequency_option) values(2);
INSERT INTO config_email_frequency_options (frequency_option) values(3);
INSERT INTO config_email_frequency_options (frequency_option) values(4);
INSERT INTO config_email_frequency_options (frequency_option) values(5);
INSERT INTO config_email_frequency_options (frequency_option) values(6);
INSERT INTO config_email_frequency_options (frequency_option) values(7);
INSERT INTO config_email_frequency_options (frequency_option) values(8);

CREATE TABLE IF NOT EXISTS `config_latency_threshold_options` (
  `threshold_option` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`threshold_option`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO config_latency_threshold_options (threshold_option) values(4);
INSERT INTO config_latency_threshold_options (threshold_option) values(6);
INSERT INTO config_latency_threshold_options (threshold_option) values(8);

CREATE TABLE IF NOT EXISTS `config_notification_state_options` (
  `notification_state_option` varchar(255) NOT NULL ,
  PRIMARY KEY  (`notification_state_option`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO config_notification_state_options (notification_state_option) values('Hold');
INSERT INTO config_notification_state_options (notification_state_option) values('Active');

CREATE TABLE IF NOT EXISTS `eligible_users` (
  `userid` int(10) unsigned NOT NULL, 
  PRIMARY KEY  (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

CREATE TABLE IF NOT EXISTS `config_misc` (
  `label` varchar(255) NOT NULL, 
  `value` varchar(255) NOT NULL, 
  PRIMARY KEY  (`label`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO config_misc (`label`,`value`) values('latency_monitoring_enabled',1)  ON DUPLICATE KEY UPDATE value=VALUES(value); /* 0 = false, not 0 = true */
INSERT INTO config_misc (`label`,`value`) values('send_external_emails',0)  ON DUPLICATE KEY UPDATE value=VALUES(value); /* 0 = false, not 0 = true */
INSERT INTO config_misc (`label`,`value`) values('enforce_eligibility',0)  ON DUPLICATE KEY UPDATE value=VALUES(value);  /* 0 = false, not 0 = true */
INSERT INTO config_misc (`label`,`value`) values('all_clear_time','120')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('pre_notification_latency_time','30')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('v14_operations_contacts','HA-Operations@adobe.com') ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('v15_operations_contacts','Engineering_GridManager@adobe.com')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('v14_pager_contacts','ertpager@adobe.com')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('email_return_address','PowerUp Notice <NoReply@adobe.com>')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('prenotice_interval','1440')  ON DUPLICATE KEY UPDATE value=VALUES(value);




CREATE TABLE IF NOT EXISTS `apps` ( 
	`app_id` int NOT NULL PRIMARY KEY, 
	`app_uri` varchar(65) NOT NULL UNIQUE, 
	`app_name` varchar(65) NOT NULL, 
	`app_desc` varchar(255) NOT NULL 
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
	
CREATE TABLE IF NOT EXISTS `menus` ( 
	`menu_id` int NOT NULL PRIMARY KEY, 
	`menu_uri` varchar(65) NOT NULL UNIQUE, 
	`app_id` int NOT NULL, 
	`menu_name` varchar(65) NOT NULL, 
	`menu_desc` varchar(255) NOT NULL, 
	`menu_sort_order` int NOT NULL, 
	key(`app_id`,`menu_sort_order`, `menu_name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
	
CREATE TABLE IF NOT EXISTS `pages` ( 
	`page_id` int NOT NULL PRIMARY KEY, 
	`page_uri` varchar(65) NOT NULL UNIQUE, 
	`page_name` varchar(65) NOT NULL, 
	`page_desc` varchar(255) NOT NULL, 
	`page_perm_groups` varchar(255) NOT NULL, /* a comma-delimited list of dr teeth groups */ 
	`page_perms` varchar(255) NOT NULL /* a comma-delimited list of dr teeth perms */ 
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
	
CREATE TABLE IF NOT EXISTS `menu_pages` ( 
	`menu_page_id` int NOT NULL PRIMARY KEY auto_increment, 
	`menu_id` int NOT NULL, 
	`page_id` int NOT NULL, 
	`page_sort_order` int NOT NULL, 
	key(`menu_id`,`page_sort_order`) 
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
