<?php
include ("application.inc");
require_once("pun/dao/LatencyNoticeDefinitionDao.php");
require_once("pun/model/LatencyNoticeDefinition.php");
require_once("pun/model/LatencyNoticeDefinitionSelector.php");

if (! class_exists('LatencyNoticeDefinitionDaoTest'))
{

class LatencyNoticeDefinitionDaoTest extends PHPUnit_Framework_TestCase
{
	private $dao;
	 

	public function __construct()
	{
		$this->dao = new LatencyNoticeDefinitionDao();
	}
	
	public function testSaveLatencyNoticeDefinition()
	{
		
		$def = $this->createLatencyDefinition("test1", 444);
		
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		
		$this->assertNotNull($def);
		$this->assertNotNull($def->getID());
		$this->assertTrue($def->getID() > 0);
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
		
	}
	
	public function testModifyLatencyNoticeDefinition()
	{
		$def = $this->createLatencyDefinition("test1", 444);
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		$def->setAdobeEmail("blah");
		$def->setEmailFrequency(9);
		$def->setLatencythreshold(40);
		$def->setNotifyState("blue");
		$testDef = $this->dao->saveLatencyNoticeDefinition($def);
		
		$this->assertEquals($def->getID(),$testDef->getID());
		$this->assertEquals("blah",$testDef->getAdobeEmail());
		$this->assertEquals(9,$testDef->getEmailFrequency());
		$this->assertEquals("blue",$testDef->getNotifyState());
		
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->setRsid("test1");
		
		$defs = $this->dao->getLatencyNoticeDefinitions($selector);
		$this->assertType('array', $defs);
//		$this->assertTrue((count($defs) == 1), 'returning wrong number of logins');
//		$myDef = $defs[0];
//		$this->assertEquals($testDef->getID(),$myDef->getID());
//		$this->assertEquals("IDs are not equal, they should be.",$def->getID(),$myDef->getID());
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function testGetLatencyNoticeDefinition()
	{
		$def = $this->createLatencyDefinition("test1", 111);
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		
		$newDef = $this->dao->getLatencyNoticeDefinition($def->getID());
		
		$this->assertEquals($newDef->getLoginCompanyName(),'test1');
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function testGetLatencyNoticeDefinitionByUserid()
	{
		$def = $this->createLatencyDefinition("test666", 666);
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		
		$newDef = $this->dao->getLatencyNoticeDefinitionByUserid(666);
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function testGetLatencyNoticeDefinitions()
	{
		$def = $this->createLatencyDefinition("test777", 777);
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->setNoticeDefId($def->getID());

		$newDefs = $this->dao->getLatencyNoticeDefinitions($selector);
		
		$this->assertType('array', $newDefs);
		$this->assertTrue((count($newDefs) == 1), 'returning wrong number of logins');
		$this->assertEquals($newDefs[0]->getLoginCompanyName(),"test777");
		
		$selector->setNoticeState("Active");
		$selector->setLatencyThreshold("4");
		$selector->setEmailFrequency(2);
		$selector->setLoginCompanyName("Company");
		$selector->setLoginCompany(1);
		$selector->setBillingCustomerName("Cust");
		$selector->setBillingCustomerId(4);
		$selector->setCustomerLogin(1);
		
		$newDefs = $this->dao->getLatencyNoticeDefinitions($selector);
		$this->assertType('array', $newDefs);
		$this->assertTrue((count($newDefs) == 0), 'returning wrong number of logins');
		
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function testGetlatencyNoticeDefinitionByCompany()
	{
		$ids = array();
		$def1 = $this->createLatencyDefinition("test88", 88);
		$def1 = $this->dao->saveLatencyNoticeDefinition($def1);
		
		$def2 = $this->createLatencyDefinition("test99", 99);
		$def2 = $this->dao->saveLatencyNoticeDefinition($def2);
		
		$testDef = $this->dao->getLatencyNoticeDefinitionByCompany(88);
		$this->assertNotNull($testDef);
		$this->assertTrue($testDef->getLoginCompanyId()==88);
		$this->assertTrue($testDef->getLoginCompanyName()=="test88");
		
		
		$this->dao->deleteLatencyNoticeDefinition($def1->getID());
		$this->dao->deleteLatencyNoticeDefinition($def2->getID());
	}
	
	public function testSaveCustomerLogins()
	{
		$def = $this->createLatencyDefinition("test555", 555);
		$def = $this->dao->saveLatencyNoticeDefinition($def);
		
		$logins = array();
		$logins[] = 77;
		$logins[] = 88;
		
		$this->dao->saveCustomerLogins($def->getID(), $logins);
		
		$newLogins = $this->dao->getCustomerLogins($def->getID());
		$this->assertType('array', $newLogins);
		$this->assertTrue((count($newLogins) == 2), 'returning wrong number of logins');
		$this->assertContains('77', $newLogins);
		$this->assertContains('88', $newLogins);
		
		$this->dao->deleteLatencyNoticeDefinition($def->getID());
		
	}
	
	public static function createLatencyDefinition($companyName,$companyId)
	{
		$def = new LatencyNoticeDefinition();
		$def->setBillingCustomerName("b1");
		$def->setBillingCustomerId(10);
		$def->setLoginCompanyId($companyId);
		$def->setLoginCompanyName($companyName);
		$def->setEmailFrequency(2);
		$def->setAdobeEmail("test_adobe@adobe.com");
		$def->setHaEmail("test_ha@adobe.com");
		$def->setLatencyThreshold(4);
		$def->setNotifyState("Notify");
		
		return $def;
	}
	
}

}

