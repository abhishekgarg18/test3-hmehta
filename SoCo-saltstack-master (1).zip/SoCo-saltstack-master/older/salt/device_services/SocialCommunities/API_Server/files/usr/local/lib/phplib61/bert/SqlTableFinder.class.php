<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2016 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * @file
 * SqlTableFinder.class.php Get a list of tables using various methods
 * 
 * @author  Matt Gould <mgould@adobe.com>
 *
 */
require_once 'application.inc';

class SqlTableFinderException extends Exception {}
class SqlTableFinderQueryException extends SqlTableFinderException {}
class SqlTableFinderInvalidDbException extends SqlTableFinderException {}

class SqlTableFinder
{
	private $tables; // Each element is in the form Host:Database:Tablename => [Host, Database, Tablename]
	
	private $db;
	
	/** @const */
	private static $invalid_dbs = ['information_schema', 'mysql'];
	
	public function __construct() {
		$this->db = new masterdb();
		$this->db->halt_on_error = false;
		
		$this->reset();
	}
	
	public function reset() {
		$this->tables = [];
	}
	
	public function get_table_list() {
		 return array_values($this->tables);
	}
	
	public function load_tables_from_host($host, $database_like = '', $database_regex = '', $table_like = '', $table_regex = '') {
		$databases = [];
		$this->db->set($host, '');
		if (!$this->db->connect(true)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		
		$sep = 'WHERE';
		$sql = 'SHOW DATABASES';
		if ($database_like) {
			$sql .= " $sep `Database` LIKE '$database_like'";
			$sep = 'AND';
		}
		if ($database_regex) {
			$sql .= " $sep `Database` REGEXP '$database_regex'";
		}
		
		if (!$this->db->query($sql)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		while ($this->db->next_record(MYSQL_NUM)) {
			$databases[] = $this->db->f(0);
		}
		$this->db->free();
		
		foreach ($databases as $database) {
			try {
				$this->load_tables_from_database($host, $database, $table_like, $table_regex);
			} catch (SqlTableFinderInvalidDbException $e) {
				// Do nothing... this is fine when we are searching for databases
			}
		}
	}
	
	public function load_tables_from_database($host, $database, $table_like = '', $table_regex = '') {
		if (in_array($database, self::$invalid_dbs)) {
			throw new SqlTableFinderInvalidDbException("You are not allowed to load tables from $database.");
		}
		
		$this->db->set($host, $database);
		if (!$this->db->connect(true)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		
		$sep = 'WHERE';
		$sql = <<<SQL
			SHOW TABLES
SQL;
		if ($table_like) {
			$sql .= " $sep `Tables_in_$database` LIKE '$table_like'";
			$sep = 'AND';
		}
		if ($table_regex) {
			$sql .= " $sep `Tables_in_$database` REGEXP '$table_regex'";
		}
		
		if (!$this->db->query($sql)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		while ($this->db->next_record(MYSQL_NUM)) {
			$tablename = $this->db->f(0);
			$this->tables["$host:$database:$tablename"] = [$host, $database, $tablename];
		}
		
		$this->db->free();
	
		if (!$table_like && !$table_regex) {
			$this->add_required_tables($host, $database);
		}
	}
	
	public function load_tables_from_failed_query_table($cachehost) {
		$this->load_tables_from_failed_table($cachehost, 'failed_query');
	}
	
	public function load_tables_from_failed_query_queue_table($cachehost) {
		$this->load_tables_from_failed_table($cachehost, 'failed_query_queue');
	}
	
	public function load_tables_from_other_failed_insert_table($cachehost) {
		$this->load_tables_from_failed_table($cachehost, 'other_failed_insert');
	}

	public function load_tables_from_other_failed_insert_queue_table($cachehost) {
		$this->load_tables_from_failed_table($cachehost, 'other_failed_insert_queue');
	}
	
	private function load_tables_from_failed_table($cachehost, $failed_table) {
		$this->db->set($cachehost, 'lobby');
		if (!$this->db->connect(true)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		
		$sql = <<<SQL
		SELECT
			`host`,
			`db`,
			CASE
				WHEN `sqlInsert` LIKE 'insert%' THEN SUBSTRING_INDEX(SUBSTRING(`sqlInsert`, LOCATE('INTO', `sqlInsert`) + 5) , ' ', 1)
				WHEN `sqlInsert` LIKE 'update%' THEN SUBSTRING_INDEX(SUBSTRING(`sqlInsert`, LOCATE('UPDATE', `sqlInsert`) + 7), ' ', 1)
				WHEN `sqlInsert` LIKE 'select%' THEN SUBSTRING_INDEX(SUBSTRING(`sqlInsert`, LOCATE('FROM', `sqlInsert`) + 5), ' ', 1)
				ELSE ''
			END AS `table_name`
		FROM
			`$failed_table`
		GROUP BY
			`host`,
			`db`,
			`table_name`
SQL;
		if (!$this->db->query($sql)) {
			throw new SqlTableFinderQueryException($this->db->Error, $this->db->Errno);
		}
		while ($this->db->next_record(MYSQL_ASSOC))
		{
			$hostname = $this->db->f('host');
			$dbname = $this->db->f('db');
			$tablename = $this->db->f('table_name');
		
			if ($hostname && $dbname && $tablename) {
				$this->tables["$hostname:$dbname:$tablename"] = [$hostname, $dbname, $tablename];
			}
		}
		$this->db->free();
		
	}
	
	public function keep_tables($host_regex = '', $database_regex = '', $tablename_regex = '') {
		if (false !== strpos($host_regex.$database_regex.$tablename_regex, '/')) {
			throw new SqlTableFinderException('The regular expressions used in keep_tables should not contain "/"');
		}
		foreach ($this->tables as $key => $table) {
			if ($host_regex) {
				if (!preg_match('/' . $host_regex . '/i', $table[0])) {
					unset($this->tables[$key]);
					continue;
				}
			}
			if ($database_regex) {
				if (!preg_match('/' . $database_regex . '/i', $table[1])) {
					unset($this->tables[$key]);
					continue;
				}
			}
			if ($tablename_regex) {
				if (!preg_match('/' . $tablename_regex . '/i', $table[2])) {
					unset($this->tables[$key]);
					continue;
				}
			}
		}
	}
	
	private function add_required_tables($hostname, $dbname) {
	
		foreach (self::get_required_tables($dbname) as $tablename) {
			$this->tables["$hostname:$dbname:$tablename"] = [$hostname, $dbname, $tablename];
		}
	}
	
	public static function get_all_required_tables() {
		$tables = [];
		foreach ([
			'cache_commands',
			'config',
			'elevator',
			'lobby',
			'metrics',
			'suite',
			'visits',
		] as $dbname) {
			$tables[$dbname] = self::get_required_tables($dbname);
		}
		return $tables;
	}
	
	public static function get_required_tables($dbname) {
		$tables = [];
		switch ($dbname) {
			case 'cache_commands':
				$tables[] = 'cache_command_queue';
				$tables[] = 'cache_command_results';
				break;
					
			case 'config':
				$tables[] = 'config_overrides';
				break;
		
			case 'elevator':
				$tables[] = 'counter';
				$tables[] = 'current_tables';
				$tables[] = 'failed_visit_cookie_query';
				$tables[] = 'table_defs';
				$tables[] = 'type99_userids';
				break;
		
			case 'lobby':
				$tables[] = 'counter';
				$tables[] = 'counter_minitag';
				$tables[] = 'duplicated_hit_usernames';
				$tables[] = 'failed_cluster_query';
				$tables[] = 'failed_cluster_query_queue';
				$tables[] = 'failed_query';
				$tables[] = 'failed_query_queue';
				$tables[] = 'other_failed_insert';
				$tables[] = 'other_failed_insert_queue';
				$tables[] = 'table_defs';
				$tables[] = 'www_server_stats';
				$tables[] = 'lobby99';
				for ($i = 1; $i <= 20; $i++) {
					$tables[] = "lobby$i";
				}
				break;
		
			case 'metrics':
				$tables[] = 'daemon_configuration';
				$tables[] = 'daemon_stop_reason';
				$tables[] = 'elev_metrics';
				$tables[] = 'elev_host_metrics';
				$tables[] = 'elev_process_metrics';
				$tables[] = 'lobby_metrics';
				$tables[] = 'lobby_host_metrics';
				break;
		
			case 'suite':
				$tables[] = 'processed_info';
				$tables[] = 'suite999';
				for ($i = 1; $i <= 20; $i++) {
					$tables[] = "suite$i";
				}
				break;
		
			case 'visits':
				foreach (['clicks', 'main', 'pages'] as $type) {
					for ($i = 0; $i <= 99; $i++) {
						$tables[] = "visit_cookie_{$type}_$i";
					}
				}
				break;
		}
		
		return $tables;
	}
}

/**
 * SELFTEST
 * Usage: php SqlTableFinder.class.php <host> [<num_samples>]
 */
if (count(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
	(version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
		debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1))) == 0) {
	if (function_exists('xdebug_break')) xdebug_break();
	
	function SqlTableFinder_self_test() {
		global $argv, $argc;
		if (2 > $argc || 3 < $argc) {
			echo "Usage: php SqlTableFinder.class.php <host> [<num_samples>]\n";
			exit(1);
		}
		try {
			$tf = new SqlTableFinder();
			
			$num_samples = $argv[2]?:5;
			$regex = 'c';
			$like = '%c%';
			
			echo "\nFinding all tables on $argv[1]\n";
			$tf->load_tables_from_host($argv[1]);
			$tables = $tf->get_table_list();
			
			echo "Found " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
			echo "\nKeeping only tables from the list where tablename matches '$regex'\n";
			$tf->keep_tables('', '', $regex);
			$tables = $tf->get_table_list();
			echo "Kept " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
			echo "\nKeeping only tables from the list where database name matches '$regex'\n";
			$tf->keep_tables('', $regex);
			$tables = $tf->get_table_list();
			echo "Kept " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
			echo "\nFinding all tables on $argv[1] where database name matches '$regex' and tablename matches '$regex'\n";
			$tf->reset();
			$tf->load_tables_from_host($argv[1], '', $regex, '', $regex);
			$tables = $tf->get_table_list();
			echo "Found " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
			echo "\nFinding all tables on $argv[1] where database name like '$like' and tablename like '$like'\n";
			$tf->reset();
			$tf->load_tables_from_host($argv[1], $like, '', $like, '');
			$tables = $tf->get_table_list();
			echo "Found " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
			echo "\nFinding tables from the failed_query_queue table on $argv[1]\n";
			$tf->reset();
			$tf->load_tables_from_failed_query_queue_table($argv[1]);
			$tables = $tf->get_table_list();
			echo "\nFound " . count($tables) . " tables\n";
			echo "Sample:\n";
			print_r(array_slice($tables, 0, $num_samples));
			
		} catch (Exception $e) {
			fprintf(STDERR, "caught %s%s%s\n", get_class($e),
				$e->getCode() ? sprintf(', code=%d', $e->getCode()) : '',
				$e->getMessage() ? sprintf(', message="%s"', $e->getMessage()) : '');
			exit(1);
		}
	}
	SqlTableFinder_self_test();
}
