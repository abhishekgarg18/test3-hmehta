<?php 
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

class OM_Appservice_Metrics extends OM_AppServiceBase {
	private static $_instance = null;
	private static $_metrics_by_loginid_by_rsid = array();

	const PATH = "/metrics";

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_Appservice_Metrics();
		}
		return self::$_instance;
	}

	public static function getPermissionedMetricsForUser($companyid, $loginid,$rsid, $cached=true){

		// Check static cache
		if($cached && is_array(self::$_metrics_by_loginid_by_rsid[$loginid]) && is_array(self::$_metrics_by_loginid_by_rsid[$loginid][$rsid])){
			return self::$_metrics_by_loginid_by_rsid[$loginid][$rsid];
		}
		
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$appservice = self::getInstance();
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		if(!$token){
			throw new Exception("Failed to generate IMS Service token for retrieving report suites from Appservice");
		}

		$response = $appservice->makeAnalyticsEndpointRequest(self::PATH . "?rsid=" . $rsid, $token, self::GET_REQUEST,"",true,"","",$companyid,$loginid);
		if ($response->hasForbiddenResponseCode()){
			throw new OM_Appservice_PermissionException($response->getErrorMessage()." errorId=".$response->getErrorId());
		} else if ($response->hasErrors()) {
			throw new Exception("Dimensions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		$ret = json_decode($response->getResponse(),true);
		if(is_array($ret) && is_array($content = $ret['content'] )){
			$ret = $content;
		}

		$converted = array();
		foreach ($ret as $metric) {
			$converted[$metric['id']] = $metric;
		}

		// Set cache
		self::$_metrics_by_loginid_by_rsid[$loginid][$rsid] = $converted;

		return $converted;
	}
}