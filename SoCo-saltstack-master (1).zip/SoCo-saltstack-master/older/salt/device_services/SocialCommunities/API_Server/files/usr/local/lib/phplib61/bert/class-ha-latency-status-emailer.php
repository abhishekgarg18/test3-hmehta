<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com
// This is a multi-datacenter helper class

require_once 'application.inc';

define("HA_LATENCY_STATUS_MAIL_RECIPIENTS", 'Latency Report Recipients <Adobe-Analytics-Latency-Report@adobe.com>');
define("HA_LATENCY_STATUS_MAIL_REPLY", 'Latency Operations Group <Adobe-Analytics-Latency@adobe.com>');
define("HA_LATENCY_STATUS_MAIL_FROM", 'Latency Monitor <Adobe-Analytics-Latency-Monitor@adobe.com>');
define("HA_LATENCY_STATUS_MAIL_OUTPUT_FILE_NAME", '/tmp/ha-latency-message.txt');

class HA_Latency_Status_Emailer extends HA_Utilities {

	function __construct($args = array()) {
        $this->log_level(HA_LOG_LEVEL_DEBUG);
		
		parent::__construct($args);
	}
    
    function send($subject, $email_html, $recipients = HA_LATENCY_STATUS_MAIL_RECIPIENTS, $from = HA_LATENCY_STATUS_MAIL_FROM, 
            $reply = HA_LATENCY_STATUS_MAIL_REPLY) {

        // OUTPUT HTML TO FILE
        $b64_html_out = chunk_split(base64_encode($email_html));
        $fp = fopen(HA_LATENCY_STATUS_MAIL_OUTPUT_FILE_NAME, "w");
        fwrite($fp, $email_html);
        fclose($fp);
        
        // PREPARE SYSTEMHEALTH MAIL MESSAGE
        $eol = "\r\n";
	if (!empty($subject)) {
		$email_subject = $subject;
	}
	else {
	        $email_subject = "Latency Report (BETA)";
	}
        $boundary = uniqid("REPORTGEN");
        $headers =      "From: " . $from . "\r\n".
                                "Reply-To: " . $reply . "\r\n".
                                "MIME-Version: 1.0\r\n".
                                "Content-Type: multipart/alternative; boundary = $boundary\r\n\r\n".
                                "This is a MIME encoded message.\r\n\r\n".
                                "--$boundary\r\n".
                                "Content-Type: text/plain; charset=ISO-8859-1\r\n".
                                "Content-Transfer-Encoding: base64\r\n\r\n".
                                chunk_split(base64_encode("This is the plain text version!")).
                                "--$boundary\r\n".
                                "Content-Type: text/html; charset=ISO-8859-1\r\n".
                                "Content-Transfer-Encoding: base64\r\n\r\n".
                                $b64_html_out;
        
        // SEND THE EMAIL
        $retval = mail($recipients, $email_subject, "", $headers);
        $this->debug("Email '$email_subject' sent to $recipients: $retval " . HA_LATENCY_STATUS_MAIL_OUTPUT_FILE_NAME . "\n");
        
        if ($retval === false) {
            $this->error("Error sending email!\n");
            $this->debug_r($headers);
        }
    }

}
