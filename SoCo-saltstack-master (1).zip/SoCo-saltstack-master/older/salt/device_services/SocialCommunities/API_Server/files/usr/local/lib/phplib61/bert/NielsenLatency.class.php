<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * NielsenLatency.class.php Retrieve and update information regarding the vcookie_clusters_base_distribution table and individual cluster usage
 *
 * @author Matt Gould <mgould@adobe.com>
 *        
 */
require_once 'application.inc';
require_once 'common_functions.inc';
require_once 'BertApiClient.class.php';
require_once 'Config.class.php';
require_once 'ConfigValidate.class.php';
require_once "latencyAPI.inc";

class NielsenLatency
{

	private $ndb;
	private $bac;
	private $latency;
	private $rsids;
	private $last_realtime;
	private $listnum;
	private $end_of_processing_day;
	private $must_be_exported_by;
	private $update_buffer;
	private $crit_factor;
	private $warn_factor;
	private $latency_by_userid; // array of arrays - rows are keyed on userid, each row is an array of (severity, latency, acknowledged, acknowledged_by, acknowledge_reset_time)
	private $rsid_cache_time;
	private $latency_cache_time;
	private $cache_timeout;
	private $sqlComment;

	const CRITICAL = 2;
	const WARNING = 1;
	const OKAY = 0;
	const UNKNOWN = - 1;
	
	const REPORT_SUITE_LIST_ENDPOINT = 'v1/report_suite_list/list/';

	public function __construct()
	{
		$this->sqlComment = sprintf(" /* MODULE: bertlib FILE: %s CLASS: %s */ ", basename(__FILE__), __CLASS__);
		$this->bac = new BertApiClient();
		
		$this->ndb = new DB_Sql('nielsendb');
		
		$config = new BertConfig(get_class($this));
		
		$this->cache_timeout = $config->filter('cache_timeout', 300, FILTER_VALIDATE_INT, array(
			'options' => array(
				'min_range' => 0
			)
		));
		
		$this->update_buffer = $config->filter('alert_update_buffer', 45, FILTER_VALIDATE_INT, array(
			'options' => array(
				'min_range' => 1
			)
		));
		
		$this->listnum = $config->filter('listnum', 30, FILTER_VALIDATE_INT, array(
			'options' => array(
				'min_range' => 1
			)
		));
		
		$this->end_of_processing_day = strtotime($config->filter('endOfProcessingDay', '03:00', FILTER_CALLBACK, array(
			'options' => array(
				new ValidateTime('H:i'),
				'validate'
			)
		)));
		$this->must_be_exported_by = strtotime($config->filter('mustBeExportedBy', '15:00', FILTER_CALLBACK, array(
			'options' => array(
				new ValidateTime('H:i'),
				'validate'
			)
		)));
		$this->crit_factor = $config->filter('crit_factor', 2.0, FILTER_CALLBACK, array(
			'options' => array(
				new ValidateFloat(0.001),
				'validate'
			)
		));
		$this->warn_factor = $config->filter('warn_factor', $this->crit_factor * 2, FILTER_CALLBACK, array(
			'options' => array(
				new ValidateFloat($this->crit_factor),
				'validate'
			)
		));
		
		$this->latency = new latencyAPI();
	}
	
	public static function get_severity_text($severity) {
		static $severity_text = array(
			self::CRITICAL => 'CRITICAL',
			self::WARNING => 'WARNING',
			self::OKAY => 'OKAY',
			self::UNKNOWN => 'UNKNOWN',
		);
		return array_key_exists($severity, $severity_text)?$severity_text[$severity]:$severity_text[self::UNKNOWN];
	}

	/**
	 * Inserts the latency that we know about into the alerts table
	 */
	public function update_alerts_table()
	{
		$sqlformat = <<<SQL
			INSERT INTO {$this->sqlComment}
				nielsen_latency_alerts
					(userid, rsid, severity, latency, alert_time)
			VALUES
				%s
			ON DUPLICATE KEY UPDATE
				severity = VALUES(severity),
				latency = VALUES(latency)
				
SQL;
		$values = array();
		$value_format = "(%d, '%s', %d, %d, NOW())";
		foreach ($this->latency_by_userid as $userid => $info) {
			$values[] = sprintf($value_format, $userid, $this->rsids[$userid], $info[0], $info[1]);
		}
		if ($values) {
			$this->ndb->query(sprintf($sqlformat, implode(',', $values)));
			$this->ndb->free();
		}
		
		$this->clear_okay_alerts();
		
		$this->set_update_time('latency');
	}

	/**
	 * Updates the nielsen_latency_update table with the current time for the specified type.
	 * @param string $type
	 */
	private function set_update_time($type)
	{
		$sql = <<<SQL
			INSERT INTO {$this->sqlComment}
				nielsen_latency_update
					(problem_type, last_update)
			VALUES
				('$type', NOW())
			ON DUPLICATE KEY UPDATE
				last_update=NOW()
SQL;
		
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Gets the timestamp of when the given type was last updated.
	 * @param string $type
	 * @return number
	 */
	private function get_update_time($type)
	{
		$sql = <<<SQL
			SELECT {$this->sqlComment}
				last_update
			FROM
				nielsen_latency_update
			WHERE
				problem_type = '$type'
SQL;
		if ($this->ndb->squery($sql)) {
			$last_update = strtotime($this->ndb->f('last_update'));
			
			$this->ndb->free();
		}
		
		return $last_update;
	}

	/**
	 * Gets the timestamp of when the alerts were last updated.
	 * @return number
	 */
	public function get_alert_update_time()
	{
		return $this->get_update_time('latency');
	}

	/**
	 * Sets the time when the all_clear message was sent.
	 */
	public function set_all_clear_sent()
	{
		$this->set_update_time('all_clear');
	}

	/**
	 * Gets the timestamp of when the all_clear message was sent.
	 * @return number
	 */
	public function get_all_clear_time()
	{
		return $this->get_update_time('all_clear');
	}

	/**
	 * Gets the max number of minutes that should pass between when the alerts are updated.
	 * @return number
	 */
	public function get_update_buffer()
	{
		return $this->update_buffer;
	}

	/**
	 * Removes "Okay" alerts from the table.
	 * 
	 * @param bool $also_acked        	
	 */
	public function clear_okay_alerts($also_acked = false)
	{
		$sql = sprintf(<<<SQL
			DELETE FROM %s
				nielsen_latency_alerts
			WHERE
				severity = %d
SQL
			, $this->sqlComment, self::OKAY);
		
		if (! $also_acked) {
			$sql .= <<<SQL
				AND acknowledged = 0
SQL;
		}
		$this->ndb->query($sql);
		$this->ndb->free();
		
		$this->load_report_suites();
		$sql = sprintf(<<<SQL
			DELETE %s FROM
				nielsen_latency_alerts
			WHERE
				rsid NOT IN ('%s');
SQL
			, $this->sqlComment, implode("','", $this->rsids));
		
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Acknowledges the alert for the given userid
	 * @param number $userid
	 * @param string $acked_by
	 * @param number $ack_hours
	 */
	public function acknowledge_alert($userid, $acked_by, $ack_hours)
	{
		$sql = <<<SQL
			UPDATE {$this->sqlComment}
				nielsen_latency_alerts
			SET
				acknowledged = 1,
				acknowledged_by = '$acked_by',
				acknowledge_reset_time = NOW() + INTERVAL $ack_hours HOUR
			WHERE
				userid = $userid
SQL;
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Removes the acknowledgement for a given userid
	 * @param number $userid
	 * @param string $acked_by
	 */
	public function unacknowledge_alert($userid, $acked_by)
	{
		$sql = <<<SQL
			UPDATE {$this->sqlComment}
				nielsen_latency_alerts
			SET
				acknowledged = 0,
				acknowledged_by = '$acked_by',
				acknowledge_reset_time = 0
			WHERE
				userid = $userid
SQL;
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Acknowledges all critical alerts for the specified number of hours.
	 * @param string $acked_by
	 * @param number $ack_hours
	 */
	public function acknowledge_unacked_critical_alerts($acked_by, $ack_hours)
	{
		$sql = sprintf(<<<SQL
			UPDATE %s
				nielsen_latency_alerts
			SET
				acknowledged = 1,
				acknowledged_by = '%s',
				acknowledge_reset_time = NOW() + INTERVAL %d HOUR
			WHERE
				severity = %d
				AND
				acknowledged = 0
				
SQL
			, $this->sqlComment, $acked_by, $ack_hours, self::CRITICAL);
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Unsets the acknowledged flag for any acknowledgements whos reset time has passed.
	 */
	public function unacknowledge_expired()
	{
		$sql = <<<SQL
			UPDATE {$this->sqlComment}
				nielsen_latency_alerts
			SET
				acknowledged = 0
			WHERE
				acknowledged = 1
				AND
				acknowledge_reset_time < NOW()
SQL;
		$this->ndb->query($sql);
		$this->ndb->free();
	}

	/**
	 * Gets the list of Nielsen report suites
	 * @param bool $force_reload
	 */
	private function load_report_suites($force_reload = false)
	{
		if ($force_reload || time() > $this->rsid_cache_time + $this->cache_timeout) {
			$this->rsid_cache_time = time();
			$this->rsids = [];
			if (DATA_CENTER == DATA_CENTER_DEV) {
				$this->rsids[2667748] = 'ha-testing-as';
				$this->rsids[2667751] = 'ha-testing-as-dev';
				$this->rsids[2667752] = 'ha-testing-as-deva';
				$this->rsids[2667753] = 'ha-testing-as-devb';
				$this->rsids[2667754] = 'ha-testing-as-devc';
				$this->rsids[2667759] = 'ha-testing-as-devd';
				$this->rsids[2667749] = 'ha-testing-as-prod';
				$this->rsids[2667755] = 'ha-testing-as-proda';
				$this->rsids[2667756] = 'ha-testing-as-prodb';
				$this->rsids[2667757] = 'ha-testing-as-prodc';
				$this->rsids[2667750] = 'HA-testing-as-proddev';
				$this->rsids[2712774] = 'ha-testing-jkt-clean';
				$this->rsids[2711701] = 'ha-testing-jkt-dev1';
				$this->rsids[2713023] = 'ha-testing-jkt-dev10';
				$this->rsids[2711702] = 'ha-testing-jkt-dev2';
				$this->rsids[2713024] = 'ha-testing-jkt-dev20';
				$this->rsids[2711703] = 'ha-testing-jkt-dev3';
				$this->rsids[2711704] = 'ha-testing-jkt-dev4';
				$this->rsids[2667828] = 'ha-testing-kh-rs1dev';
				$this->rsids[2667829] = 'ha-testing-kh-rs1prod';
				$this->rsids[2667830] = 'ha-testing-kh-rs2dev';
				$this->rsids[2667831] = 'ha-testing-kh-rs2prod';
				$this->rsids[2712790] = 'ha-testing-kk-cm-jkt-clean';
				$this->rsids[2712791] = 'ha-testing-kk-cm-jkt-clean-2';
				$this->rsids[2712792] = 'ha-testing-kk-cm-jkt-clean-3';
				$this->rsids[2712799] = 'ha-testing-kk-cm-jkt-clean-4';
				$this->rsids[2712787] = 'ha-testing-kk-cm-rs3dev';
				$this->rsids[2667874] = 'ha-testing-km-dev1';
				$this->rsids[2667875] = 'ha-testing-km-dev2';
				$this->rsids[2667876] = 'ha-testing-km-dev3';
				$this->rsids[2667877] = 'ha-testing-km-dev4';
				$this->rsids[2667878] = 'ha-testing-km-dev5';
				$this->rsids[2712330] = 'ha-testing-lc-dev1';
				$this->rsids[2712331] = 'ha-testing-lc-dev2';
				$this->rsids[2712332] = 'ha-testing-lc-dev3';
				$this->rsids[2712333] = 'ha-testing-lc-dev4';
				$this->rsids[2712334] = 'ha-testing-lc-dev5';
				$this->rsids[2712335] = 'ha-testing-lc-dev6';
				$this->rsids[2712336] = 'HA-testing-lc-dev7';
				$this->rsids[2667787] = 'ha-testing-mg-rs1dev';
				$this->rsids[2667786] = 'ha-testing-mg-rs1prod';
				$this->rsids[2667789] = 'ha-testing-mg-rs2dev';
				$this->rsids[2667788] = 'ha-testing-mg-rs2prod';
				$this->rsids[2667791] = 'ha-testing-mg-rs3dev';
				$this->rsids[2667790] = 'ha-testing-mg-rs3prod';
			} else {
				$list_info = $this->bac->makeRequest(self::REPORT_SUITE_LIST_ENDPOINT . $this->listnum);
				if ($list_info->reportSuites) {
					foreach ($list_info->reportSuites as $rs_info) {
						if (DATA_CENTER == $rs_info->data_center) { // For now only work with report suites in the local data center
							$this->rsids[$rs_info->userid] = $rs_info->rsid;
						}
					}
				}
				
				//Get list from local nielsendb
				$local_rsids = [];
				$sql = <<<SQL
					SELECT {$this->sqlComment}
						username as rsid,
						userid
					FROM
						feed_control_dw_templates
					WHERE
						status = 'active'
					GROUP BY
						1,2
SQL;
				$this->ndb->query($sql);
				while ($this->ndb->next_record(MYSQL_ASSOC)) {
					$local_rsids[$this->ndb->f('userid')] = $this->ndb->f('rsid');
				}
				$this->ndb->free();
				
				//Remove report suites from rsl that aren't in the local list
				$remove = array_diff_assoc($this->rsids, $local_rsids);
				foreach ($remove as $userid => $rsid) {
					$this->bac->doDelete(self::REPORT_SUITE_LIST_ENDPOINT . $this->listnum . '/' . DATA_CENTER . '/' . $rsid);
				}
				
				//Add report suites to rsl that are in the local list but not in the rsl
				$add = array_diff_assoc($local_rsids, $this->rsids);
				foreach ($add as $userid => $rsid) {
					$this->bac->doPost(self::REPORT_SUITE_LIST_ENDPOINT . $this->listnum . '/' . DATA_CENTER . '/' . $rsid);
				}
				
				// Update rsid list with current information.
				$this->rsids = $local_rsids;
			}
		}
	}

	/**
	 * Loads the export latency for all of the Nielsen report suites
	 * @param bool $realtime Get the actual latency instead of just reading the alert table.
	 * @param bool $force_reload
	 */
	private function load_latency($realtime = true, $force_reload = false)
	{
		$this->load_report_suites();
		if ($realtime !== $this->last_realtime) {
			$this->last_realtime = $realtime;
			$force_reload = true;
		}
		if ($realtime) {
			$this->load_realtime_latency($force_reload);
		} else {
			$this->load_alert_latency($force_reload);
		}
	}

	/**
	 * Gets the actual export latency for all Nielsen report suites.
	 * @param bool $force_reload
	 */
	private function load_realtime_latency($force_reload = false)
	{
		if ($force_reload || time() > $this->latency_cache_time + $this->cache_timeout) {
			$this->latency_cache_time = $now = time();
				
			$this->load_alert_latency($force_reload);
			$alert_latency = $this->latency_by_userid;
			
			$this->latency_by_userid = array();
			
			$allowed_latency = $now - $this->end_of_processing_day;
			$time_remaining = max($this->must_be_exported_by - $now, 0);
			
			foreach (array_keys($this->rsids) as $userid) {
				@ $export_latency = max($this->latency->getExportLatencyByUser($userid)) + 0;
				$effective_latency = max($export_latency - $allowed_latency, 0);
				
				if ($effective_latency > $time_remaining / $this->crit_factor) {
					$severity = self::CRITICAL;
				} elseif ($effective_latency > $time_remaining / $this->warn_factor) {
					$severity = self::WARNING;
				} else {
					$severity = self::OKAY;
				}
				
				$this->latency_by_userid[$userid] = array(
					$severity,
					$effective_latency,
					$alert_latency[$userid][2],
					$alert_latency[$userid][3],
					$alert_latency[$userid][4]
				);
			}
		}
	}

	/**
	 * Gets the latency that we have stored in the alert table.
	 * @param bool $force_reload
	 */
	private function load_alert_latency($force_reload = false)
	{
		if ($force_reload || time() > $this->latency_cache_time + $this->cache_timeout) {
			$this->latency_cache_time = time();
				
			$this->latency_by_userid = array();
			$this->acked_alerts = array();
			
			$sql = <<<SQL
				SELECT {$this->sqlComment}
					userid,
					severity,
					latency,
					acknowledged,
					acknowledged_by,
					acknowledge_reset_time
				FROM
					nielsen_latency_alerts
SQL;
			$this->ndb->query($sql);
			while ($this->ndb->next_record(MYSQL_ASSOC)) {
				$this->latency_by_userid[$this->ndb->f('userid')] = array(
					$this->ndb->f('severity'),
					$this->ndb->f('latency'),
					$this->ndb->f('acknowledged'),
					$this->ndb->f('acknowledged_by'),
					$this->ndb->f('acknowledge_reset_time') > 0 ? strtotime($this->ndb->f('acknowledge_reset_time')) : null
				);
			}
		}
	}

	/**
	 * Gets the export latency for a given userid.
	 * Returns whether the latency is considered problematic and how far earlier than the end of day the latency is.
	 * @param integer $userid        	
	 * @return array(number, number)
	 */
	public function get_latency_for_rsid($userid, $realtime = true)
	{
		$this->load_latency($realtime);
		
		return $this->latency_by_userid[$userid] ? $this->latency_by_userid[$userid] : array(
			self::UNKNOWN,
			0,
			null,
			null,
			null
		);
	}

	/**
	 * Returns the latency array
	 * @param bool $realtime        	
	 * @param bool $force_reload        	
	 * @return array of arrays - rows are keyed on userid, each row is an array of (severity, latency, acknowleged, acknowleged_by, acknowledge_reset_time)
	 */
	public function get_latency($realtime = false, $force_reload = false)
	{
		$this->load_latency($realtime, $force_reload);
		return $this->latency_by_userid;
	}

	/**
	 * Returns the list of Nielsen report suites 
	 * @return array
	 */
	public function get_report_suites()
	{
		$this->load_report_suites();
		return $this->rsids;
	}
}
