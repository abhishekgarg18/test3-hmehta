<?php

include 'application.inc';
require_once 'pun/webclient/LatencyNoticeWebClient.php';

class WebClientConfigTest extends PHPUnit_Framework_TestCase
{
    private $webapi;

    public function __construct()
    {   
        $this->webapi = new LatencyNoticeWebClient();
    }   

	public function test_LatencyThresholdOptions()
	{
		$options = $this->webapi->getLatencyThresholdOptions();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 3), 'returning no threshold options');
		$this->assertContains('4', $options);
		$this->assertContains('6', $options);
		$this->assertContains('8', $options);
	}
	
	public function test_EmailFrequencyOptions()
	{
		$options = $this->webapi->getEmailFrequencyOptions();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) > 0), 'returning no email frequency options');
	}
	
	public function test_NoticeStateOptions()
	{
		$options = $this->webapi->getNoticeStateOptions();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) > 0), 'returning no notice state options');
	}
}

