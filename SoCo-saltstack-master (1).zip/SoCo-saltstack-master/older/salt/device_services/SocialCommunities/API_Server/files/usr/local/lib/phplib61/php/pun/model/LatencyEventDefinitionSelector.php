<?php
class LatencyEventDefinitionSelector
{
	private $defid;
	private $noticeDefId;
	private $username;
	private $userid;
	private $resultCountLimit;
	private $resultStartindex;
	
	
	public function __construct()
	{
		
	}
	
	public function getDefid()
	{
		return $this->defid;
	}

	public function setDefid($defid) 
	{
		$this->defid = $defid;
	}

	public function getNoticeDefId() 
	{
		return $this->noticeDefId;
	}

	public function setNoticeDefId($noticeDefId) 
	{
		$this->noticeDefId = $noticeDefId;
	}

	public function getUserid() 
	{
		return $this->userid;
	}

	public function setUserid($userid) 
	{
		$this->userid = $userid;
	}

	public function getUsername()
	{
		return $this->username;
	}

	public function setUsername($username) 
	{
		$this->username = $username;
	}

	public function getResultCountLimit() 
	{
		return $this->resultCountLimit;
	}

	public function setResultCountLimit($resultCountLimit) 
	{
		$this->resultCountLimit = $resultCountLimit;
	}

	public function getResultStartindex() 
	{
		return $this->resultStartindex;
	}

	public function setResultStartindex($resultStartindex) 
	{
		$this->resultStartindex = $resultStartindex;
	}
}