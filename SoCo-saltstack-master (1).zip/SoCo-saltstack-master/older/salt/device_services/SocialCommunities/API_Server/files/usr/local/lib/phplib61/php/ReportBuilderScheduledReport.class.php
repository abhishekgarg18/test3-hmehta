<?
/**
 * @file
 * Handles initializing the Report_Schedule from the web service and 
 * delete for a ReportBuilder scheduled Report.
 *
 * Copyright 2009 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt
 *
 * @author      Frank Snedecor <fsnedecor@omniture.com>
 * 
 * @version     CVS: $Id$
 */

require_once ('rptsched.class');

class ReportBuilderScheduledReport extends Report_Schedule {
	
	/**
	 * Total times this report has failed.
	 *
	 * @var string
	 */
	private $_failureCount = 0;
	
	private $_lastSent = "0000-00-00 00:00:00";
	
	function ReportBuilderScheduledReport($pId = -999) {
		parent::Report_Schedule ( $pId );
	}
	
	/**
	 * Gets total times report has failed.  
	 *
	 * @return string
	 */
	public function getFailureCount() {
		return $this->_failureCount;
	}
	
	/**
	 * Sets how many times this report has failed since last successful run.
	 *
	 * @param string $failureCount
	 */
	public function setFailureCount($failureCount) {
		$this->_failureCount = $failureCount;
	}
	
	public function setLastSent($date){
		$this->_lastSent = $date;
	}
	
	public function getLastSent(){
		return $this->_lastSent;
	}
	/**
	 * Returns an array that represents the Report
	 *
	 * @return array
	 */
	public function toArray() {
		$scheduledReport = array ();
		$scheduledReport ["id"] = $this->id;
		
		// Workbook
		$workbook = array ();
		$workbook ["filename"] = $this->filename;
		$workbook ["owner"] = "";
		$workbook ["description"] = $this->file_comments;
		
		$lastSent = $this->getLastSent();
		
		// x64bit returns invalid date for x86 win
		if($lastSent === "0000-00-00 00:00:00")
		{
			$lastSent = null;
		}
		
		$workbook ["lastModified"] = date('c', strtotime($lastSent));
		$scheduledReport ["excelWorkbook"] = $workbook;
		$scheduledReport["reportSuiteID"] = $this->account;	
		
		// TODO Could have not run in time also we should update this.
		$scheduledReport["isFailed"] = $this->getFailureCount() >= 3;
		//DeliveryParameters
		$deliveryParameters = array ();
		$deliveryParameters ["emailTo"] = $this->email_to;
		$deliveryParameters ["emailFrom"] = $this->email_from;
		
		$deliveryParameters ["publishingList"] = $this->distribution_list_ids;
		$deliveryParameters ["emailSubject"] = $this->email_subject;
		$deliveryParameters ["emailNotes"] = $this->email_notes;
		$deliveryParameters ["ftpHost"] = $this->ftp_host;
		$deliveryParameters ["ftpUser"] = $this->ftp_usrname;
		$deliveryParameters ["ftpPassword"] = $this->ftp_usrpswd;
		$deliveryParameters ["ftpPort"] = $this->ftp_port;
		$deliveryParameters ["ftpPath"] = $this->ftp_dir;

		switch($this->locale){
			case 'ja_JP':
			case 'jp_JP':
				$deliveryParameters ["locale"] = 'jp_JP';
				break;
			case 'en_US':
			case 'de_DE';
			case 'es_ES';
			case 'fr_FR';
			case 'ko_KR';
			case 'zh_CN';
			case 'zh_TW';
			case 'pt_BR';
				$deliveryParameters ["locale"] = $this->locale;
				break;
			default:
				$deliveryParameters ["locale"] = 'en_US';
				break;
		}
		
		switch ($this->file_format) {
			case "rtf" :
				$deliveryParameters ["fileFormat"] = "Word";
				break;
			case "xlsx" :
				$deliveryParameters ["fileFormat"] = "Excel2007";
				break;
			case "xls" : 
				$deliveryParameters ["fileFormat"] = "Excel2003";
				break;
			case "mob_html" :
				$deliveryParameters ["fileFormat"] = "Mobile";
				break;
			case "html" :
				$deliveryParameters ["fileFormat"] = "Html";
				break;
			case "csv" :
				$deliveryParameters ["fileFormat"] = "Csv";
				break;
			case "pdf" :
				$deliveryParameters ["fileFormat"] = "Pdf";
				break;
			case "mht" :
				$deliveryParameters ["fileFormat"] = "Mht";
				break;
			case "txt" :
				$deliveryParameters ["fileFormat"] = "Txt";
				break;
			case "xml" :
				$deliveryParameters ["fileFormat"] = "Xml";
				break;

		}
				
		switch ($this->send_type) {
			case SEND_EMAIL :
				$deliveryParameters ["deliveryType"] = "Email";
				break;
			default :
				$deliveryParameters ["deliveryType"] = "Ftp";
		}
		
		$deliveryParameters ["isCompressed"] = $this->compress_file;
		$deliveryParameters ["hideUnsubscribe"] = $this->hide_unsubscribe;
		
		$scheduledReport ["deliveryParameters"] = $deliveryParameters;
		
		//ScheduleParameters
		$scheduleParams = array ();
		
		$freq = "Run Once";
		switch ($this->freq) {
			case OM_SCHEDULE_FREQ_RUN_ONCE :
				$freq = "Run Once";
				break;
			case OM_SCHEDULE_FREQ_HOURLY :
				$freq = "Hourly";
				break;
			case OM_SCHEDULE_FREQ_DAILY_BY_DAYS :
				$freq = "Daily By Days";
				break;
			case OM_SCHEDULE_FREQ_DAILY_WEEKDAYS :
				$freq = "Daily weekdays";
				break;
			case OM_SCHEDULE_FREQ_WEEKLY :
				$freq = "Weekly";
				break;
			case OM_SCHEDULE_FREQ_MONTHLY_BY_DOM :
				$freq = "Monthly by DOM";
				break;
			case OM_SCHEDULE_FREQ_MONTHLY_BY_WEEK :
				$freq = "Monthly by week";
				break;
			case OM_SCHEDULE_FREQ_YEARLY_BY_DOM :
				$freq = "Yearly by DOM";
				break;
			case OM_SCHEDULE_FREQ_YEARLY_BY_WEEK :
				$freq = "Yearly by Week";
				break;
			case "None" :
				$freq = 0;
				break;
		}
		
		$scheduleParams ["frequency"] = $freq;
		
		$dayOfWeek = "None";
		switch ($this->dow) {
			case SUNDAY :
				$dayOfWeek = "Sunday";
				break;
			case MONDAY :
				$dayOfWeek = "Monday";
				break;
			case TUESDAY :
				$dayOfWeek = "Tuesday";
				break;
			case WEDNESDAY :
				$dayOfWeek = "Wednesday";
				break;
			case THURSDAY :
				$dayOfWeek = "Thursday";
				break;
			case FRIDAY :
				$dayOfWeek = "Friday";
				break;
			case SATURDAY :
				$dayOfWeek = "Saturday";
				break;
		}
		
		$scheduleParams ["dayOfWeek"] = $dayOfWeek;
		$scheduleParams ["dayOfMonth"] = $this->dom;
		$scheduleParams ["runHour"] = $this->run_hour;
		$scheduleParams ["runMinute"] = date('i', strtotime(date($this->run_when)));	
		$scheduleParams ["recurrence"] = $this->recur;
		
		$scheduleParams ["startDate"] = $this->run_when;
		$sequence = "None";
		switch ($this->seq) {
			case FIRST :
				$sequence = "First";
				break;
			case SECOND :
				$sequence = "Second";
				break;
			case THIRD :
				$sequence = "Third";
				break;
			case FOURTH :
				$sequence = "Fourth";
				break;
			case LAST :
				$sequence = "Last";
				break;
		}
		
		$scheduleParams ["sequence"] = $sequence;
		
		switch ($this->cancel_type) {
			case CANCEL_NEVER :
				$scheduleParams ["cancelType"] = "Never";
				break;
			case CANCEL_AFTER :
				$scheduleParams ["cancelType"] = "After";
				break;
			case CANCEL_WHEN :
				$scheduleParams ["cancelType"] = "When";
				$scheduleParams ["endDate"] = $this->cancel_date; 
				break;
		}
		
		$scheduleParams ["cancelOccurence"] = $this->cancel_recur;
		
		$month = "None";
		switch ($this->month) {
			case JANUARY :
				$month = "January";
				break;
			case FEBRUARY :
				$month = "February";
				break;
			case MARCH :
				$month = "March";
				break;
			case APRIL :
				$month = "April";
				break;
			case MAY :
				$month = "May";
				break;
			case JUNE :
				$month = "June";
				break;
			case JULY :
				$month = "July";
				break;
			case AUGUST :
				$month = "August";
				break;
			case SEPTEMBER :
				$month = "September";
				break;
			case OCTOBER :
				$month = "October";
				break;
			case NOVEMBER :
				$month = "November";
				break;
			case DECEMBER :
				$month = "December";
				break;
		}
		
		$scheduleParams ["month"] = $month;
		$scheduleParams ["timezoneOffset"] = $this->timezone_offset;
		$scheduledReport ["scheduleRecurrenceParameter"] = $scheduleParams;
		return $scheduledReport;
	}

	function updateReportSuiteID($reportSuiteID){
		$account = new Account($reportSuiteID);
		$this->timezone_offset = $account->timezone_offset;
		$db = new DB_Sql(DWDBNAME);
		$sql = 'UPDATE rpt_schedule SET account="' . $reportSuiteID . '" WHERE id = ' . intval($this->id);
		$db->query($sql);
	}
	
	/**
	 * Initializes the scheduled report from an array
	 *
	 * @param array $scheduledReport
	 */
	function initFromArray($scheduledReport) {
		$scheduleRecurrenceParam = $scheduledReport ["scheduleRecurrenceParameter"];
		$deliveryParameter = $scheduledReport ["deliveryParameters"];
		
		$reportSuiteID = $scheduledReport["reportSuiteID"];
		if($reportSuiteID != $this->account){
			$this->updateReportSuiteID($reportSuiteID);
		}

		$this->account = $scheduledReport["reportSuiteID"];	
		// Now we can just translate
		$runHour =  $scheduleRecurrenceParam ["runHour"];
		$runMinute = 0;
		
		if(isset($scheduleRecurrenceParam ["runMinute"]))
		{
			$runMinute = intval($scheduleRecurrenceParam ["runMinute"]);
			if($runMinute > 60 ||  $runMinute < 0)
			{
				$runMinute = 0;
			}
		}
		
		$runWhen = OM_L10n::formatDate(strtotime($scheduleRecurrenceParam["startDate"]), 'short');
		$this->filename = $scheduledReport ["excelWorkbook"] ["filename"];
		$this->file_comments = $scheduledReport ["excelWorkbook"] ["description"];

		switch($deliveryParameter ['locale']){
			case 'jp_JP':
				$this->locale = 'ja_JP';
				break;
			case 'en_US':
			case 'de_DE';
			case 'es_ES';
			case 'fr_FR';
			case 'ko_KR';
			case 'zh_CN';
			case 'zh_TW';
			case 'pt_BR';
				$this->locale = $deliveryParameter ['locale'];
				break;
			default:
				$this->locale = 'en_US';
				break;
		}

		if ($deliveryParameter ["deliveryType"] == "Email") {
			$this->setEmail ( $deliveryParameter ["emailTo"], $deliveryParameter ["emailSubject"], $deliveryParameter ["emailFrom"], $deliveryParameter ["emailNotes"] );
			$this->send_type = SEND_EMAIL;
		} else {
			$this->send_type = SEND_FTP;
			$this->setFTP ( $deliveryParameter ["ftpHost"], $deliveryParameter ["ftpPort"], $deliveryParameter ["ftpPath"], $deliveryParameter ["ftpUser"], $deliveryParameter ["ftpPassword"] );
			$this->setEmail($deliveryParameter ["emailTo"]);
		}
		
		switch ($deliveryParameter ["fileFormat"]) {
			case "Word" :
				$this->file_format = "rtf";
				break;
			case "Excel2007" :
				$this->file_format = "xlsx";
				break;
			case "Excel2003" :
				$this->file_format = "xls";
				break;
			case "Mobile" :
				$this->file_format = "mob_html";
				break;
			case "Html" :
				$this->file_format = "html";
				break;
			case "Csv" :
				$this->file_format = "csv";
				break;
			case "Pdf" :
				$this->file_format = "pdf";
				break;
			case "Mht" :
				$this->file_format = "mht";
				break;
			case "Txt" :
				$this->file_format = "txt";
				break;
			case "Xml" :
				$this->file_format = "xml";
				break;
			default:
				$this->file_format = "xlsx";
		
		}
		
		$this->compress_file = $deliveryParameter ["isCompressed"];
		if(isset($deliveryParameter ["hideUnsubscribe"]))
		{
			$this->hide_unsubscribe = $deliveryParameter ["hideUnsubscribe"];
		}
		
		$this->cancel_date = null;
		$distList = array ();
		$i = 0;
		if (isset ( $deliveryParameter ["publishingList"] )) {
			foreach ( $deliveryParameter ["publishingList"] as $c ) {
				$distList [$i] = $c;
				$i ++;
			}
		}
		$this->setDistributionLists ( $distList );
		
		switch ($scheduleRecurrenceParam ["cancelType"]) {
			case "Never" :
				$this->cancel_type = CANCEL_NEVER;
				break;
			case "After" :
				$this->cancel_type = CANCEL_AFTER;
				$this->cancel_recur = $scheduleRecurrenceParam ["cancelOccurence"];
				break;
			case "When" :
				$this->cancel_type = CANCEL_WHEN;
				$this->cancel_date = date ( 'Y-m-d H:i:s', strtotime ( $scheduleRecurrenceParam ["endDate"] ) );
				break;
		}
		
		$dayOfWeek = 0;
		switch ($scheduleRecurrenceParam ["dayOfWeek"]) {
			case "Sunday" :
				$dayOfWeek = SUNDAY;
				break;
			case "Monday" :
				$dayOfWeek = MONDAY;
				break;
			case "Tuesday" :
				$dayOfWeek = TUESDAY;
				break;
			case "Wednesday" :
				$dayOfWeek = WEDNESDAY;
				break;
			case "Thursday" :
				$dayOfWeek = THURSDAY;
				break;
			case "Friday" :
				$dayOfWeek = FRIDAY;
				break;
			case "Saturday" :
				$dayOfWeek = SATURDAY;
				break;
		}
		
		$month = 0;
		switch ($scheduleRecurrenceParam ["month"]) {
			case "January" :
				$month = JANUARY;
				break;
			case "February" :
				$month = FEBRUARY;
				break;
			case "March" :
				$month = MARCH;
				break;
			case "April" :
				$month = APRIL;
				break;
			case "May" :
				$month = MAY;
				break;
			case "June" :
				$month = JUNE;
				break;
			case "July" :
				$month = JULY;
				break;
			case "August" :
				$month = AUGUST;
				break;
			case "September" :
				$month = SEPTEMBER;
				break;
			case "October" :
				$month = OCTOBER;
				break;
			case "November" :
				$month = NOVEMBER;
				break;
			case "December" :
				$month = DECEMBER;
				break;
		}
		
		$sequence = 0;
		switch ($scheduleRecurrenceParam ["sequence"]) {
			case "First" :
				$sequence = FIRST;
				break;
			case "Second" :
				$sequence = SECOND;
				break;
			case "Third" :
				$sequence = THIRD;
				break;
			case "Fourth" :
				$sequence = FOURTH;
				break;
			case "Last" :
				$sequence = LAST;
				break;
		}

		$recurrence =  $scheduleRecurrenceParam ["recurrence"];	
		switch ($scheduleRecurrenceParam ["frequency"]) {
			case "Run Once" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_RUN_ONCE, 1, 1, 1, 1, 1 ); 
				break;
			case "Hourly" :
				// Ensure when scheduling hourly that only one report is sent to start.
				$now = strtotime("now");
				$currentHour = date('H', $now);
				if($runWhen === OM_L10n::formatDate($now, 'short') && $currentHour > $runHour)
				{
					$runHour = $currentHour;
				}
				
				$this->setFrequency ( OM_SCHEDULE_FREQ_HOURLY, $recurrence, 0, 0, 0,0, $runWhen, $runHour, $runMinute);
				break;
			case "Daily By Days" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_DAILY_BY_DAYS, $recurrence, 0, 0, 0, 0, $runWhen, $runHour ,$runMinute);
				break;
			case "Daily weekdays" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_DAILY_WEEKDAYS, 0, 0, 0, 0, 0, $runWhen, $runHour,$runMinute );
				break;
			case "Weekly" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_WEEKLY, $recurrence, 0, $dayOfWeek, 0, 0, $runWhen, $runHour,$runMinute );
				break;
			case "Monthly by DOM" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_MONTHLY_BY_DOM, $recurrence, 0, 0, $scheduleRecurrenceParam ["dayOfMonth"], 0, $runWhen, $runHour,$runMinute );
				break;
			case "Monthly by week" :	
				$this->setFrequency ( OM_SCHEDULE_FREQ_MONTHLY_BY_WEEK, $recurrence, $sequence, $dayOfWeek, 0, 0, $runWhen, $runHour ,$runMinute);
				break;
			case "Yearly by DOM" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_YEARLY_BY_DOM, 0, 0, 0, $scheduleRecurrenceParam ["dayOfMonth"], $month, $runWhen, $runHour ,$runMinute);
				break;
			case "Yearly by Week" :
				$this->setFrequency ( OM_SCHEDULE_FREQ_YEARLY_BY_WEEK, 0, $sequence, $dayOfWeek, 0, $month, $runWhen, $runHour,$runMinute );
				break;

		}
		$this->product_id = REPORTBUILDER_PUBLISH;
		$this->UpdateDB (true);
	}
	
	/**
	 * Removes an excel generated downloadable report
	 * 
	 * Overrides parent Delete function.
	 *
	 * @return (boolean) true on success false otherwise
	 */
	function Delete() {
		
		$this->deleteFromFileStorageScheduled ();
		return parent::Delete ();
	}
	
	/**
	 * Deletes record from file_storage_scheduled
	 *
	 * @return unknown
	 */
	function deleteFromFileStorageScheduled() {
		$db = new DB_Sql ( DWDBNAME );
		
		$sql = "DELETE FROM file_storage_scheduled WHERE `schedule_id` = %i{id} LIMIT 1 ";
		
		$query = new DBQuery ( $db, $sql, array ('id' => $this->id ) );
		$queryResult = $query->execute ();
		
		if ($queryResult->affectedRows () != 1) {
			return (FALSE);
		}
		
		$query->free ();
		return true;
	}

}
