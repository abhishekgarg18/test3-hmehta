<?php
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 *	   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * MODIFICATION: This class name (and all others in the project) has been prefixed with 'L4P_'
 * to avoid namespace collisions in PHP 5.2.4.   --David Cardon (dcardon@adobe.com)
 *
 * @package log4php
 */

/**
 * This is a very simple filter based on level matching.
 *
 * <p>The filter admits two options <b><var>LevelToMatch</var></b> and
 * <b><var>AcceptOnMatch</var></b>. If there is an exact match between the value
 * of the <b><var>LevelToMatch</var></b> option and the level of the 
 * {@link L4P_LoggerLoggingEvent}, then the {@link decide()} method returns 
 * {@link L4P_LoggerFilter::ACCEPT} in case the <b><var>AcceptOnMatch</var></b> 
 * option value is set to <i>true</i>, if it is <i>false</i> then 
 * {@link L4P_LoggerFilter::DENY} is returned. If there is no match, 
 * {@link L4P_LoggerFilter::NEUTRAL} is returned.</p>
 * 
 * <p>
 * An example for this filter:
 * 
 * {@example ../../examples/php/filter_levelmatch.php 19}
 *
 * <p>
 * The corresponding XML file:
 * 
 * {@example ../../examples/resources/filter_levelmatch.xml 18}
 * 
 * @version $Revision$
 * @package log4php
 * @subpackage filters
 * @since 0.6
 */
class L4P_LoggerFilterLevelMatch extends L4P_LoggerFilter {
  
	/** 
	 * Indicates if this event should be accepted or denied on match
	 * @var boolean
	 */
	private $acceptOnMatch = true;

	/**
	 * The level, when to match
	 * @var L4P_LoggerLevel
	 */
	private $levelToMatch;
  
	/**
	 * @param boolean $acceptOnMatch
	 */
	public function setAcceptOnMatch($acceptOnMatch) {
		$this->acceptOnMatch = L4P_LoggerOptionConverter::toBoolean($acceptOnMatch, true); 
	}
	
	/**
	 * @param string $l the level to match
	 */
	public function setLevelToMatch($l) {
		if($l instanceof L4P_LoggerLevel) {
		    $this->levelToMatch = $l;
		} else {
			$this->levelToMatch = L4P_LoggerOptionConverter::toLevel($l, null);
		}
	}

	/**
	 * Return the decision of this filter.
	 * 
	 * Returns {@link L4P_LoggerFilter::NEUTRAL} if the <b><var>LevelToMatch</var></b>
	 * option is not set or if there is not match.	Otherwise, if there is a
	 * match, then the returned decision is {@link L4P_LoggerFilter::ACCEPT} if the
	 * <b><var>AcceptOnMatch</var></b> property is set to <i>true</i>. The
	 * returned decision is {@link L4P_LoggerFilter::DENY} if the
	 * <b><var>AcceptOnMatch</var></b> property is set to <i>false</i>.
	 *
	 * @param L4P_LoggerLoggingEvent $event
	 * @return integer
	 */
	public function decide(L4P_LoggerLoggingEvent $event) {
		if($this->levelToMatch === null) {
			return L4P_LoggerFilter::NEUTRAL;
		}
		
		if($this->levelToMatch->equals($event->getLevel())) {	
			return $this->acceptOnMatch ? L4P_LoggerFilter::ACCEPT : L4P_LoggerFilter::DENY;
		} else {
			return L4P_LoggerFilter::NEUTRAL;
		}
	}
}
