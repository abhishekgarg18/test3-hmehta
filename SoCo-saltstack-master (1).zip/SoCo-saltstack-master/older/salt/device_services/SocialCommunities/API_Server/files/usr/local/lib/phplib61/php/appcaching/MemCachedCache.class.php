<?php
/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2010-2011 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require_once 'appcaching/CacheInterface.class.php';
require_once 'productarray/product_functions.inc';
/*
 * This is very simple wrapper around memcached.
 * It should help correctly configure memcached and allow us to do some basic changes to memcached methods
 * If you want to add more intrusive features such as key generation etc please subclass this class and add them there.
 */
class MemCachedCache implements CacheInterface {
	private static $instance = array();
	private $cache = null;

	//populates the cache and sets up internal data structures
	private function __construct($productID) {
		if (class_exists('memcache') && isset($GLOBALS['localConfig'])) {
			$this->cache = new Memcache();
			if ($productID === PRODUCT_ID_SITECATALYST && is_array($GLOBALS['localConfig']['sc_memcache_servers']) && count($GLOBALS['localConfig']['sc_memcache_servers'])>0) {
				foreach ($GLOBALS['localConfig']['sc_memcache_servers'] as $server) {
					$this->cache->addServer($server[0], $server[1], true);
				}
			} else if ($productID === 'frag_api' && is_array($GLOBALS['localConfig']['frag_api_memcache_servers']) && count($GLOBALS['localConfig']['frag_api_memcache_servers'])>0) {
				foreach ($GLOBALS['localConfig']['frag_api_memcache_servers'] as $server) {
					$this->cache->addServer($server[0], $server[1], true);
				}
			} else {
				//if this product doesn't have any servers defined then use a fake cache
				$this->cache = new FakeMemCachedCache();
			}
		} else {
			//if we don't have the information necessary to set up the cache them make a fake cache
			$this->cache = new FakeMemCachedCache();
		}

		if ($GLOBALS['loki']['memcachedcache'] == 1) {
			var_dump($this->cache->getExtendedStats());
		}
	}

	//pass in a default product id
	public function getInstance($productID=PRODUCT_ID_SITECATALYST){
		if (is_null(MemCachedCache::$instance[$productID])) {
			MemCachedCache::$instance[$productID] = new MemCachedCache($productID); 
		} 
		return MemCachedCache::$instance[$productID];
	}

	/*
	 * Retrieves a value from memcached
	 */
	public function get($key){
		return $this->cache->get($key);
	}

	/*
	 * Sets a key into memcached
	 * default expire is 30 min (30*60)
	 *
	 * returns true on success and false on failure
	 */
	public function set($key,$value,$expire=1800,$compressed=false){ 
		$flag = ($compressed===true?MEMCACHE_COMPRESSED:0);
		return $this->cache->set($key,$value,$flag,$expire);
	}
	
	/**
	 * Delete/Flush a key from the cache
	 * 
	 * @param string $key
	 * @return bool
	 */
	public function delete($key) {
		return $this->cache->delete($key);
	}

}

/**
 * A dummy caching object for use in this class 
 * so that scripts will perform normally even if a memcached is not available
 *
 * Ignore all calls by using the magic __call method
 * to capture all calls
 */
class FakeMemCachedCache {
	public function __call($name, $arguments) {
	}
}
