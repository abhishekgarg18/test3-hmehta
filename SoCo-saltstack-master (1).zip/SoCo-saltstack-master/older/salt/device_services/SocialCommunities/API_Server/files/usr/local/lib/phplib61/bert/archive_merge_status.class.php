<?php
require_once 'application.inc';
class archive_merge_status {
	private $db;
	private $wait = 200;
	private $retries = 3;
	const DATACENTER_DAL = "db4043.da2";
	const DATACENTER_CAL = "db3202.oak1";
	const DATACENTER_LON = null;
	const DATACENTER_SIN = null;
	const DATACENTER_DEV = null;

	public function __construct($datacenter) {
		switch ($datacenter) {
			case self::DATACENTER_CAL:
				break;
			case self::DATACENTER_DAL:
				break;
			case self::DATACENTER_LON:
				break;
			case self::DATACENTER_SIN:
				break;
			case self::DATACENTER_DEV:
				break;
			default:
				exit("Must provide valid datacenter.\n");
		}

		if($datacenter == null)
		{
			exit("The datacenter provided has not been implemented yet.\n");
		}

		$this->db = new masterdb;
		$this->db->set($datacenter, "archive_merge");
	}

	public function disable_userid($userid) {
		$this->db->query("update am_user_config set enabled = 0, check_after_dt = date(now()) + interval 10 year where userid = '".$userid."'");
		$retry = 0;
		while(true) {
			$this->db->squery("select count(*) still_processing from am_user_config where userid = '".$userid."' and processing_host != ''");
			$still_processing = $this->db->f('still_processing');
			if((int)$still_processing === 0) {
				echo "Userid:".$userid." has been disabled.\n";
				return true;
			} else {
				$retry++;
				if($retry > $this->retries) {
					echo "Userid:".$userid." could not be disabled and still has active jobs.\n";
					return false;
				}
				echo "Userid:".$userid." has active jobs, sleeping for ".$this->wait."s.\n";
				sleep($this->wait);
			}
		}
	}

	public function enable_userid($userid) {
		$this->db->query("update am_user_config set enabled = 1, check_after_dt = date(now()) + interval 7 day where userid = '".$userid."'");
		echo "Userid:".$userid." has been enabled\n";
		return true;
	}
}
