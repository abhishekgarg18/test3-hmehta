<?php
class LatencyEvent
{
	private $id;
	private $defId;
	private $noticeId;
	private $username;
	private $userid;
	private $siteCatalystVersion;
	private $latency;
	private $eventType;
	private $eventTime;
	
	public function __construct()
	{
		
	}
	public function getId() 
	{
		return $this->id;
	}

	public function setId($id) 
	{
		$this->id = $id;
	}

	public function getDefId() 
	{
		return $this->defId;
	}

	public function setDefId($defId) 
	{
		$this->defId = $defId;
	}
	
	public function getNoticeId() 
	{
		return $this->noticeId;
	}

	public function setNoticeId($noticeId) 
	{
		$this->noticeId = $noticeId;
	}

	public function getUsername()
	{
		return $this->username;
	}
	
	public function setUsername($username)
	{
		$this->username = $username;
	}
	
	public function getUserid()
	{
		return $this->userid;
	}
	
	public function setUserid($userid)
	{
		$this->userid = $userid;
	}
	
	public function getSiteCatalystVersion()
	{
		return $this->siteCatalystVersion;
	}
	
	public function setSiteCatalystVersion($siteCatalystVersion)
	{
		$this->siteCatalystVersion = $siteCatalystVersion;
	}

	public function getLatency() 
	{
		return $this->latency;
	}

	public function setLatency($latency) 
	{
		$this->latency = $latency;
	}

	public function getEventType() 
	{
		return $this->eventType;
	}

	public function setEventType($eventType) 
	{
		$this->eventType = $eventType;
	}

	public function getEventTime() 
	{
		return $this->eventTime;
	}

	public function setEventTime($eventTime) 
	{
		$this->eventTime = $eventTime;
	}
}