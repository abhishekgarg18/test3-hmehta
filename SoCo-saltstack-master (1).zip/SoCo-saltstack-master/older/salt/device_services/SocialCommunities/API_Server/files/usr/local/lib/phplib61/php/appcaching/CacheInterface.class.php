<?php
/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2010-2011 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/*
 * This interface is intented to keep caching implementations consistent 
 *	and to make it easy to switch between caching implementation 
 */
interface CacheInterface {
	public function get($key);
	public function set($key,$value,$expire=1800,$compressed=false);
}
