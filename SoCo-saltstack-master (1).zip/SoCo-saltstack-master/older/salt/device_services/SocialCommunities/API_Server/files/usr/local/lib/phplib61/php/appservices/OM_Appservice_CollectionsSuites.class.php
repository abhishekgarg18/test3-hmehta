<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");
require_once("appservices/OM_Appservice_PermissionException.class.php");

class OM_Appservice_CollectionsSuites extends OM_AppServiceBase{
	private static $_instance = null;
	private static $_single_suites_by_loginid = array();
	private static $_company_suite_lists_by_loginid = array();

	const COLLECTIONS_SUITES_PATH = "/collections/suites/";

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_Appservice_CollectionsSuites();
		}
		return self::$_instance;
	}

	/*
	 * Does the user have permissions to the passed RS or VRS?
	 */
	public static function doesUserHaveSuiteAccess($companyid,$loginid,$rsid){
		if(!$rsid){
			return false;
		}
		try {
			$suite = self::getSingleSuiteForCurrentUser($companyid,$loginid,$rsid);
		} catch (OM_Appservice_PermissionException $e){
			return false;
		}
		if(is_array($suite) && $suite['rsid']==strtolower($rsid)){
			return true;
		}
		return false;
	}

	public static function getSingleSuiteForCurrentUser($companyid,$loginid,$rsid){
		if(!$rsid){
			return null;
		}

		// Check cache
		if(is_array(self::$_single_suites_by_loginid[$loginid]) && is_array(self::$_single_suites_by_loginid[$loginid][$rsid])){
			return self::$_single_suites_by_loginid[$loginid][$rsid];
		}

		$path = self::COLLECTIONS_SUITES_PATH . $rsid . "?expansion=isBlocked,isDeleted";
		$suite = self::makeCollectionsRequest($companyid,$loginid,$path);
		if($suite['isBlocked']){
			throw new OM_Appservice_PermissionException("Access denied: RS " . $rsid . " is a blocked suite");
		}

		// Set cache
		self::$_single_suites_by_loginid[$loginid][$rsid] = $suite;

		return $suite;
	}

	public static function getAllSuitesForUser($companyid, $loginid,$include_vrs=false, $cached=true, $include_num_groups = false){

		// Check static cache
		if($cached && is_array(self::$_company_suite_lists_by_loginid[$loginid]) && is_array(self::$_company_suite_lists_by_loginid[$loginid][$include_vrs])){
			return self::$_company_suite_lists_by_loginid[$loginid][$include_vrs];
		}

		$path = self::COLLECTIONS_SUITES_PATH . "?limit=0&expansion=name,numericRsid,parentRsid";
		if ($include_num_groups) {
			$path .=",numGroups";
		}
		if(!$cached){
			$path .= "&cached=false";
		}
		if(!$include_vrs) {
			$path .= "&types=base,asi,rollup";
		}

		$ret = array();
		$suites = self::makeCollectionsRequest($companyid,$loginid,$path);
		if(is_array($suites) && is_array($content = $suites['content'] )){
			$ret = $content;
		}

		// Set cache
		self::$_company_suite_lists_by_loginid[$loginid][$include_vrs] = $ret;

		return $ret;
	}

	// Used by company_group.class to list all suites for a given Permissions Group. Appears to only be used for Admin UI (edit group).
	public static function getAllSuitesForUserGroup($companyid,$loginid,$groupid,$get_blocked){
		$path = self::COLLECTIONS_SUITES_PATH . "?expansion=name,numericRsid&limit=0&userGroupId=$groupid";
		if($get_blocked){
			$path .= "&includeType=blocked";
		}
		$suites = self::makeCollectionsRequest($companyid,$loginid,$path);
		if(is_array($suites) && is_array($content = $suites['content'] )){
			return $content;
		}
		return array();
	}

	private static function makeCollectionsRequest($companyid,$loginid,$path){
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$appservice_suites = self::getInstance();
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		if(!$token){
			throw new Exception("Failed to generate IMS Service token for retrieving report suites from Appservice");
		}

		$response = $appservice_suites->makeAnalyticsEndpointRequest($path, $token, self::GET_REQUEST,"",true,"","",$companyid,$loginid);
		if ($response->hasForbiddenResponseCode()){
			throw new OM_Appservice_PermissionException($response->getErrorMessage()." errorId=".$response->getErrorId());
		} else if ($response->hasErrors()) {
			throw new Exception("Collections service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(),true);
	}
}
