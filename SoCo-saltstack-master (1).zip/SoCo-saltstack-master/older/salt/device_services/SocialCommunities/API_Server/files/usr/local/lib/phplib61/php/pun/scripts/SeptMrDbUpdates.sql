INSERT INTO email_templates (template_text,version,type) values("Latency Notification:  <#COMPANY_NAME#>

<#DATA#>

For any further questions please contact Adobe ClientCare or your supported user. 

Best Regards,
Adobe ClientCare
 
If you would like to unsubscribe to this latency notification email, click here.",1,1) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);  /* Need to add this url for unsubscribe https://vm???.dev.omniture.com/p/suite/current/index.html?a=Company.Unsubscribe&c=<companyid>&l=<loginid> */ 
INSERT INTO email_templates (template_text,version,type) values("New Latency Event  <#DATA#>",1,11) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Continuing Latency Event  <#DATA#>",1,12) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("End Latency Event  <#DATA#>",1,13) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Pre Latency Notification.\r\n\r\n <#DATA#>\r\n\r\n",1,2) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);
INSERT INTO email_templates (template_text,version,type) values("Pre Latency Event <#DATA#>",1,22) ON DUPLICATE KEY UPDATE template_text=VALUES(template_text);

INSERT INTO config_misc (`label`,`value`) values('latency_monitoring_enabled',1) ON DUPLICATE KEY UPDATE label=VALUES(label);
INSERT INTO config_misc (`label`,`value`) values('v14_operations_contacts','HA-Operations@adobe.com') ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('email_return_address','PowerUp Notice <NoReply@adobe.com>')  ON DUPLICATE KEY UPDATE value=VALUES(value);
INSERT INTO config_misc (`label`,`value`) values('prenotice_interval','1440')  ON DUPLICATE KEY UPDATE value=VALUES(value);

DELETE FROM latency_notice_definition; /* Drop all of the definitions. The final list will be re-added post release via the import utlity */
DELETE FROM latency_event_definition;  
DELETE FROM eligible_users;
DELETE FROM latency_notice_def_cust_login_id;


