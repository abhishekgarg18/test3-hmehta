<?php
require_once "application.inc";
require_once "pun/services/ConfigService.php";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');


$configUtil = new ConfigUtil();
$configUtil->config($argv);

class ConfigUtil
{
	private $log;
	private $configService;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
		$this->configService = new ConfigService();	
	}
	
	public function config($argv)
	{
		$vals = $this->parseCommandlineArguments($argv);
		$this->setValues($vals);
	}

	/**
	 * saves the label,value pairs in the given array to the database. Assumes the data has been validated.
	 * 
	 * @param array $vals label value pairs with labels corresponding the command line argument names.
	 */
	public function setValues($vals)
	{
		if(array_key_exists("enforce_eligibility",$vals))
		{
			$this->log->debug("Setting the enforce_eligibility configuration value in the database to ".$vals['enforce_eligibility']);
			$this->configService->saveEnforceEligibility($vals['enforce_eligibility']);	
		}
		
		if(array_key_exists('send_external_emails',$vals))
		{
			$this->log->debug("Setting the send_external_emails configuration value in the database to ".$vals['send_external_emails']);
			$this->configService->saveUseExternalEmails($vals['send_external_emails']);	
		}
		
		if(array_key_exists('pre_notification_time',$vals))
		{
			$this->log->debug("Setting the pre_notification_time configuration value in the database to ".$vals['pre_notification_time']);
			$this->configService->savePreNotificationlatencyTime($vals['pre_notification_time']);	
		}
		
		if(array_key_exists('all_clear_time',$vals))
		{
			$this->log->debug("Setting the all_clear_time configuration value in the database to ".$vals['all_clear_time']);
			$this->configService->saveAllClearTime($vals['all_clear_time']);
		}
		
		if(array_key_exists('v14_operations_contacts',$vals))
		{
			$this->log->debug("Setting the v14_operations_contacts configuration value in the database to ".$vals['v14_operations_contacts']);
			$this->configService->saveV14OperationsContacts($vals['v14_operations_contacts']);	
		}
		
		if(array_key_exists('v14_pager_contacts',$vals))
		{
			$this->log->debug("Setting the v14_pager_contacts configuration value in the database to ".$vals['v14_pager_contacts']);	
			$this->configService->saveV14PagerContacts($vals['v14_pager_contacts']);
		}
		
		if(array_key_exists('v15_operations_contacts',$vals))
		{
			$this->log->debug("Setting the v15_operations_contacts configuration value in the database to ".$vals['v15_operations_contacts']);
			$this->configService->saveV15OperationsContacts($vals['v15_operations_contacts']);	
		}
		
		if(array_key_exists('email_frequency_options',$vals))
		{
			$this->log->debug("Setting the email_frequency_options configuration value in the database to ".$vals['email_frequency_options']);	
			$this->configService->replaceEmailFrequencyOptionList($vals['email_frequency_options']);
		}
		
		if(array_key_exists('latency_threshold_options',$vals))
		{
			$this->log->debug("Setting the latency_threshold_options configuration value in the database to ".$vals['latency_threshold_options']);	
			$this->configService->replaceLatencyThresholdOptionList($vals['latency_threshold_options']);
		}
		
		if(array_key_exists('latency_monitoring_enabled',$vals))
		{
			$this->log->debug("Setting the latency_monitoring_enabled configuration value in the database to ".$vals['latency_monitoring_enabled']);	
			$this->configService->saveLatencyMonitoringEnabled($vals['latency_monitoring_enabled']);
		}
		
		if(array_key_exists('prenotice_interval',$vals))
		{
			$this->log->debug("Setting the prenotice_interval configuration value in the database to ".$vals['prenotice_interval']);	
			$this->configService->savePreLatencyNoticeInterval($vals['prenotice_interval']);
		}
		
		if(array_key_exists('email_return_address',$vals))
		{
			$this->log->debug("Setting the email_return_address configuration value in the database to ".$vals['email_return_address']);	
			$this->configService->saveEmailReturnAddressText($vals['email_return_address']);
		}
	}
	
	public function parseCommandlineArguments($argv)
	{
		$vals = array();
		$this->log->debug("Parsing command line arguments.");
		if ( count($argv) > 0 ) 
		{
		
		    // If asking for help, ignore any errors in options they might have
		    if ( in_array( '-h', $argv ) || in_array( '--help', $argv ) ) 
		    {
		    	$this->display_usage();
				$this->log->info("Displayed help. Exiting");
		    	exit(0);
		    }
		
		    while ( count( $argv ) ) 
		    {
		        array_shift($argv);
		        $arg = $argv[ 0 ];
		        $optarg = $argv[ 1 ];
		        
		        switch( $arg ) 
		        {
		
		            case '-e':
		            case '--enforce_eligibility':
		            	$vals['enforce_eligibility'] = $optarg;
		            	$this->log->debug("Command line arg enforce_eligibility set to $optarg");
		                array_shift( $argv );
		            	continue 2;
		
		            case '-s':
		            case '--send_external_emails':
		                $vals['send_external_emails'] = $optarg;
		            	$this->log->debug("Command line arg send_external_emails set to $optarg");
		                array_shift( $argv );
		            	continue 2;
		
		            case '-p':
		            case '--pre_notification_time':
		            	if(is_numeric($optarg))
		            	{
		            		$vals['pre_notification_time'] = $optarg;
		            		$this->log->debug("Command line arg pre_notification_time set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for pre_notification_time. Expecting integer numeric (minutes)");
		            		exit(1);
		            	}
		                array_shift( $argv );
		                continue 2;
		
		            case '-a':
		            case '--all_clear_time':
		            	if(is_numeric($optarg))
		            	{
		            		$vals['all_clear_time'] = $optarg;
		            		$this->log->debug("Command line arg all_clear_time set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for all_clear_time. Expecting integer numeric (minutes)");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-b':
		            case '--v14_operations_contacts':
		            	if(isset($optarg) && is_string($optarg) && $this->validateEmailAddressList(explode(",",$optarg)))
		            	{
		            		$vals['v14_operations_contacts'] = $optarg;
		            		$this->log->debug("Command line arg v14_operations_contacts set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for v14_operations_contacts. Expecting comma delimited valid email addresses.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-c':
		            case '--v14_pager_contacts':
		            	if(isset($optarg) && is_string($optarg) && $this->validateEmailAddressList(explode(",",$optarg)))
		            	{
			            	$vals['v14_pager_contacts'] = $optarg;
		            		$this->log->debug("Command line arg v14_pager_contacts set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for v14_pager_contacts Expecting comma delimited valid email addresses.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-d':
		            case '--v15_operations_contacts':
		            	if(isset($optarg) && is_string($optarg) && $this->validateEmailAddressList(explode(",",$optarg)))
		            	{
			            	$vals['v15_operations_contacts'] = $optarg;
		            		$this->log->debug("Command line arg v15_operations_contacts set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for v15_operations_contacts. Expecting comma delimited valid email addresses.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-f':
		            case '--email_frequency_options':
		            	if(isset($optarg) && is_string($optarg) && $this->validateNumericValues(explode(",",$optarg)))
		            	{
			            	$vals['email_frequency_options'] = $optarg;
		            		$this->log->debug("Command line arg email_frequency_options set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for email_frequency_options. Expecting comma delimited integers.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-t':
		            case '--latency_threshold_options':
		            	if(isset($optarg) && is_string($optarg) && $this->validateNumericValues(explode(",",$optarg)))
		            	{
			            	$vals['latency_threshold_options'] = $optarg;
		            		$this->log->debug("Command line arg latency_threshold_options set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for latency_threshold_options. Expecting comma delimited integers.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		                continue 2;
		                
		            case '-n':
		            case '--latency_monitoring_enabled':
		                $vals['latency_monitoring_enabled'] = $optarg;
		            	$this->log->debug("Command line arg latency_monitoring_enabled set to $optarg");
		                array_shift( $argv );
		            	continue 2;
		            	
		            case '-i':
		            case '--prenotice_interval':
		            	if(is_numeric($optarg))
		            	{
		            		$vals['prenotice_interval'] = $optarg;
		            		$this->log->debug("Command line arg prenotice_interval set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for prenotice_interval. Expecting integer numeric (minutes)");
		            		exit(1);
		            	}
		                array_shift( $argv );
		            	continue 2;
		            	
		            case '-r':
		            case '--email_return_address':
		            	if(isset($optarg) && is_string($optarg) && $this->validateEmailAddressList(explode(",",$optarg)))
		            	{
			            	$vals['email_return_address'] = $optarg;
		            		$this->log->debug("Command line arg email_return_address set to $optarg");
		            	}
		            	else
		            	{
		            		$this->log->Error("Invalid value $optarg provided for email_return_address. Expecting valid email addresse.");
		            		exit(1);
		            	}
		            	array_shift( $argv );
		            	continue 2;
		            	
		            default:
	            	if(isset($arg))
	            	{
	            		$this->log->error("Unknown command line parameter $arg");
	            	}
	            	continue 2;
		        }
		    }
		}
	    else
	    {
	    	$this->display_usage();
	    }
		return $vals;
	}
	
	private function validateNumericValues($vals)
	{
		$retVal = true;
		foreach($vals as $val)
		{
			if(!is_numeric($val))
			{
				$retVal = false;
				break;
			}
		}
		return $retVal;
	}
	
	private function validateEmailAddresslist($vals)
	{
		$retVal = true;
		
		foreach($vals as $val)
		{
			if(! filter_var($val, FILTER_VALIDATE_EMAIL)) 
			{
				$retVal = false;
				break;
			}
		}
		return $retVal;
	}
	
	private function display_usage()
	{
		echo("-h --help \t\t\tPrints this help and exits.\r\n\r\n");
		echo("-e --enforce_eligibility \tSets whether eligibility is enforced when checking latency. Default: 0 Non zero for true.\r\n");
		echo("-s --send_external_emails \tSets whether emails are sent to external customer email addresses, or jsut internal addresses. Default: 0 (false) Non zero for truen\r\n");
		echo("-p --pre_notification_time \tSets the amount of time, in minutes, before the configured latency threshold where the internal operations team is contacted with a pre latency event. (in minutes) Default: 30 minutes \r\n");
		echo("-a --all_clear_time \t\tSets the amount of time, in minutes, that must pass with a report suite under the configured latency threshold before the no longer latent notice is sent.  (in minutes) Default: 120 minutes\r\n");
		echo("-b --v14_operations_contacts \t Sets the email addresses, comma delimited no spaces, for SiteCatalyst V14 operations contacts. Used for pre-latency notices.\r\n");
		echo("-c --v14_pager_contacts \t Sets the email addresses, comma delimited no spaces, for SiteCatalyst V14 pager contacts. Used for pre-latency notices.\r\n");
		echo("-d --v15_operations_contacts \t Sets the email addresses, comma delimited no spaces, for SiteCatalyst V15 operations contacts. Used for pre-latency notices.\r\n");
		echo("-f --email_frequency_options \t sets the email frequency options list. Comma delimited list of integer values.\r\n");
		echo("-t --latency_threshold_options \t sets the latency threshold options list. Comma delimited list of integer values.\r\n");
		echo("-i --prenotice_interval \t sets the time interval for sending a pre notice for a given report suite. Default: 1440 minutes (24 hours)\r\n");
		echo("-r --email_return_address \t sets the return address used by all notices. default: PowerUp Notice <NoReply@adobe.com>\r\n");
	}
}