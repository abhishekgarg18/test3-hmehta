<?php
require_once('application.inc');
require_once('reverse_userid_lookup.inc');

class SaintAPISuperUser
{
	private $api_login;
	private $company;
	private $report_suite_id;
	private $relation_id;
	private $db;

	function __construct($api_login, $login_company, $relation_id)
	{
		$this->db = new DB_Sql("masterdb");
		$this->api_login = $api_login;
		$this->relation_id = $relation_id;
		$this->company = $login_company;	
	}

	function addSuperUser()
	{
		$sql = "insert into saint_super_users set api_login = '$this->api_login', company = '$this->company', relation_id = $this->relation_id, enabled = 1";
		$this->db->squery($sql);

		if($this->db->affected_rows() == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function deleteSuperUser()
	{
		$sql = "delete from saint_super_users where api_login = '$this->api_login' and company = '$this->company' and relation_id = $this->relation_id";
		$this->db->squery($sql);

		if($this->db->affected_rows() == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function enableSuperUser()
	{
		$sql = "update saint_super_users set enabled = 0 where api_login = '$this->api_login' and company = '$this->company' and relation_id = $this->relation_id";
		$this->db->squery($sql);

		if($this->db->affected_rows() == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function disableSuperUser()
	{
		$sql = "update saint_super_users set enabled = 1 where api_login = '$this->api_login' and company = '$this->company' and relation_id = $this->relation_id";
		$this->db->squery($sql);

		if($this->db->affected_rows() == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function isSuperUser()
	{
		$sql = "select enabled from saint_super_users where api_login = '$this->api_login' and company = '$this->company' and relation_id = $this->relation_id";
		$this->db->squery($sql);
		$enabled = $this->db->f('enabled');

		if($enabled == 1)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>