#! /usr/local/bin/php -q
<?

//Configuration
$BackupStoreDir = '/tmp/backups';
$UnzipDir = '/tmp/backups';
$DeleteOriginalStore = 0;
$GunzipCmd = '/bin/gunzip';
$UntarCmd = '/bin/tar -xvf';
$HeadCmd = '/usr/bin/head';
$GrepCmd = '/bin/grep';
$HostToImportInto = 'localhost';
$DBUser = "root";
$DBPassword = "db48lb9";
$MysqlCmd = "/usr/bin/mysql";

if ($BackupStoreDir != $UnzipDir) {

	//Delete current tmp dir
	echo "Deleting current unzip directory\n";
	exec("rm -rf $UnzipDir/*");

	//Copy or move files to unzip dir
	if ($DeleteOriginalStore) {
		$CopyCmd = 'mv';
	} else {
		$CopyCmd = 'cp';
	}
	echo "Moving backup files from original store to unzip directory\n";
	exec("$CopyCmd $BackupStoreDir/* $UnzipDir");
}

//Unzip files
echo "Unzipping files:\n";
$dir = opendir($UnzipDir);
while(($file = readdir($dir))!=false) {
	if (strtolower(substr($file, -2)) == 'gz') {
		echo "  unzipping $file\n";
		exec("$GunzipCmd $UnzipDir/$file");
	}
}
closedir($dir);

//Untar files
echo "Untar-ing files:\n";
$dir = opendir($UnzipDir);
while(($file = readdir($dir))!=false) {
	if (strtolower(substr($file, -3)) == 'tar') {
		echo "  untar-ing $file\n";
		exec("$UntarCmd $UnzipDir/$file -C $UnzipDir");
		unlink("$UnzipDir/$file");
	}
}
closedir($dir);


//Import databases
echo "Importing databases:\n";
$dir = opendir($UnzipDir);
while(($file = readdir($dir))!=false) {

	if (($file!=".")&&($file!="..")) {

		//Find database to import into
		$DBString = exec("$HeadCmd $UnzipDir/$file | $GrepCmd Database");
		$DBString = substr($DBString, strpos($DBString, "Database") + 10);

		if ($DBString) {
			echo "  Database $DBString\n";

			echo "    Dropping and recreating database\n";
			exec("echo 'drop database $DBString;' | $MysqlCmd -f -u$DBUser -p$DBPassword -h$HostToImportInto");
			exec("echo 'create database $DBString;' | $MysqlCmd -f -u$DBUser -p$DBPassword -h$HostToImportInto");

			echo "    Importing database\n";
			$starttime = time();
			exec("$MysqlCmd -f -u$DBUser -p$DBPassword -h$HostToImportInto $DBString < $UnzipDir/$file");
			$duration = time() - $starttime;
			echo "    Took $duration seconds to import data\n";

			echo "    Deleting file $file\n";
			unlink("$UnzipDir/$file");
		}
	}
}
closedir($dir);

?>

