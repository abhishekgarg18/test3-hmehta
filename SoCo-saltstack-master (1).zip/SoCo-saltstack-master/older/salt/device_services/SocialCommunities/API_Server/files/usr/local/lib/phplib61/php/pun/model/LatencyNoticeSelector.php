<?php

class LatencyNoticeSelector
{
	private $latencyNoticeDefinitionId;
	private $rsid;
	private $userid;
	private $billingCustomerName;
	private $billingCustomerId;
	private $loginCompany;
	private $companyId;
	private $adobeEmail;
	private $customerLoginName;
	private $customerEmail;
	private $emailFrequency;
	private $latencyThreshold;
	private $noticeState;
	private $dateStart;
	private $dateEnd;
	private $resultCountLimit;
	private $resultStartindex;
	
	public function getLatencyNoticeDefinitionId() 
	{
		return $this->latencyNoticeDefinitionId;
	}

	public function getRsid() 
	{
		return $this->rsid;
	}
	
	public function getUserId()
	{
		return $this->userId;
	}
	
	public function setUserId($userId)
	{
		$this->userId = $userId;
	}

	public function getBillingCustomerName() 
	{
		return $this->billingCustomerName;
	}
	
	public function getBillingCustomerId()
	{
		return $this->billingCustomerId;
	}
	
	public function setBillingCustomerId($billingCustomerId)
	{
		$this->billingCustomerId = $billingCustomerId;
	}

	public function getLoginCompany() 
	{
		return $this->loginCompany;
	}
	
	public function getCompanyId()
	{
		return $this->companyId;
	}
	
	public function setCompanyId($companyId)
	{
		$this->companyId = $companyId;
	}

	public function getAdobeEmail() 
	{
		return $this->adobeEmail;
	}

	public function getCustomerLoginName() 
	{
		return $this->customerLoginName;
	}

	public function getCustomerEmail() 
	{
		return $this->customerEmail;
	}

	public function getEmailFrequency() 
	{
		return $this->emailFrequency;
	}

	public function getLatencyThreshold() 
	{
		return $this->latencyThreshold;
	}

	public function getNoticeState() 
	{
		return $this->noticeState;
	}

	public function getDateRange() 
	{
		return $this->dateRange;
	}

	public function getResultCountLimit() 
	{
		return $this->resultCountLimit;
	}

	public function getResultStartindex() 
	{
		return $this->resultStartindex;
	}

	public function setLatencyNoticeDefinitionId($latencyNoticeDefinitionId) 
	{
		$this->latencyNoticeDefinitionId = $latencyNoticeDefinitionId;
	}

	public function setRsid($rsid) 
	{
		$this->rsid = $rsid;
	}

	public function setBillingCustomerName($billingCustomerName) 
	{
		$this->billingCustomerName = $billingCustomerName;
	}

	public function setLoginCompany($loginCompany) 
	{
		$this->loginCompany = $loginCompany;
	}

	public function setAdobeEmail($adobeEmail) 
	{
		$this->adobeEmail = $adobeEmail;
	}

	public function setCustomerLoginName($customerLoginName) 
	{
		$this->customerLoginName = $customerLoginName;
	}

	public function setCustomerEmail($customerEmail) 
	{
		$this->customerEmail = $customerEmail;
	}

	public function setEmailFrequency($emailFrequency) 
	{
		$this->emailFrequency = $emailFrequency;
	}

	public function setLatencyThreshold($latencyThreshold) 
	{
		$this->latencyThreshold = $latencyThreshold;
	}

	public function setNoticeState($noticeState) 
	{
		$this->noticeState = $noticeState;
	}

	public function setDateRange($dateStart, $dateEnd) 
	{
		$this->dateStart = $dateStart;
		$this->dateEnd = $dateEnd;
	}
	
	public function getStartDate()
	{
		return $this->dateStart;
	}
	
	public function getEndDate()
	{
		return $this->dateEnd;
	}

	public function limitResult($resultCountLimit, $resultStartIndex =  0)
	{
		$this->resultCountLimit = $resultCountLimit;
		$this->resultStartindex = $resultStartIndex;
	}
}
	
