<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2016 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property laws,
 * including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

require_once("appservices/OM_AppServiceBase.class.php");

class OM_Appservice_Alerts extends OM_AppServiceBase
{

	public function getAlerts($token,$ownerId=0){
		$path =  "/alerts?limit=0";
		if($ownerId){
			$path .= "&ownerId=$ownerId";
		}
		$response_obj = $this->makeAnalyticsEndpointRequest($path,$token);
		if(!$response_obj || $response_obj->hasErrors()){
			return null;
		}
		$response_json = $response_obj->getResponse();
		$response_page = json_decode($response_json,true);

		if(!is_array($response_page['content']) || sizeof($response_page['content']) == 0){
			return null;
		}
		return $response_page['content'];
	}

	// Returns the updated alert object so we create a log entry with the alert friendly name
	public function changeOwner($alert_id, $new_owner_loginid, $token){
		if($alert_id && $new_owner_loginid){
			$path = "/alerts/$alert_id";
			$request_body = json_encode(array("owner" => array("id" => $new_owner_loginid)));
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::PUT_REQUEST,$request_body);
		}
		if(!$response_obj || $response_obj->hasErrors()){
			return null;
		}
		$response_json = $response_obj->getResponse();
		return json_decode($response_json,true);
	}

	public function deleteAlert($alert_id, $token){
		if($alert_id){
			$path = "/alerts/$alert_id";
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::DELETE_REQUEST);
			if(!$response_obj || $response_obj->hasErrors()){
				return null;
			}
			return $response_obj->getResponse();
		}
	}

}