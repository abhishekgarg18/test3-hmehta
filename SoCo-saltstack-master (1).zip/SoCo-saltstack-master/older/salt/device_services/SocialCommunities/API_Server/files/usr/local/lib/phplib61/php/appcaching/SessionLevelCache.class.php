<?php
/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2010-2011 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/*
 * This object is responsible to cache information that should be cached for the duration of the session
 *  and should be cleared every time the user logs out 
 */
class SessionLevelCache {
	private static $instance = null;
	private static $enabled = false;
	private $values = array();
	private $session = null;
	const CACHE_KEY = 'SC_QUERY_CACHE_SESS';

	//populates the cache and sets up internal data structures
	private function __construct($sess) {
		$this->session = $sess;
		$this->values = $this->session->get(self::CACHE_KEY); 

		if (!is_array($this->values)) {
			$this->values = array();
		}
	}
	//bundles up the cached data and puts it in the session
	public function persist() {
		$this->session->set(self::CACHE_KEY,$this->values);
	}

	//resets private variables to initial state
	public function reset() {
		SessionLevelCache::$instance = null;
		$this->session  = null;
		$this->values   = array();
	}

	//enabled and disables session level caching 
	public function setEnabled($enabled) {
		if ($enabled===true) {
			SessionLevelCache::$enabled = true;
		} else {
			SessionLevelCache::$enabled = false;
		}
	}

	public function getInstance($sess=null) {

		//try and get a session for the persistance container
		if (SessionLevelCache::$enabled ==false) {
			//make sure that the cache is cleared if we are no longer caching
			if (isset($this->session)) {
				$this->session->set(self::CACHE_KEY,null);
			}
			SessionLevelCache::$instance = new SessionLevelCache(new FakeCacheSession()); 
		} else if (is_null(SessionLevelCache::$instance)) {
			//try to pull the session out of global scope
			if ($sess == null) {
				if (is_null($sess) && isset($GLOBALS['sess'])) {
					$sess = $GLOBALS['sess'];
				} else { 
					//create a dummy object
					$sess = new FakeCacheSession();
				}
			}
			SessionLevelCache::$instance = new SessionLevelCache($sess); 
		} 

		return SessionLevelCache::$instance;
	}

	//get an attribute from the cache
	public function get($key) {
		if (SessionLevelCache::$enabled ==false || $GLOBALS['loki']['sessionlevelcacheoff']) {
			return null;
		}
		return $this->values[$key];
	}

	//set a cache attribute
	public function set($key,$value) {
		$this->values[$key] = $value;
		$this->persist();
	}

	//this shouldn't be needed since we are storing the data in the session
	//and it will expire when the user logs out
	public function invalidateCache() {
		$this->session->set(self::CACHE_KEY,null);
	}
}

/**
 * A dummy session object for use in this class 
 * so that scripts will perform normally even if a session is not available
 *
 * Ignore all calls by using the magic __call method
 * to capture all calls
 */
class FakeCacheSession {
	public function __call($name, $arguments) {
	}
}
