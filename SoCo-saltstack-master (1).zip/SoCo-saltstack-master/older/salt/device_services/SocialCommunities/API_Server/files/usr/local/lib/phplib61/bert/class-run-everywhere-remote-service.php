<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com
// This is a multi-datacenter helper class


require_once 'application.inc';
require_once 'class-ha-utilities.php';

// this class is meant to be run once in all of the environment's data centers at a scheduled interval via cron
// data will be aggregated by Run_Everywhere_Central_Service
// this class will put data in a db table in this data center.
class Run_Everywhere_Remote_Service extends HA_Utilities 
{
    // args & database fields
    protected $id;
    protected $run_name;
    protected $app_name;
    protected $start_time;
    protected $end_time;
    protected $status_code;
    protected $status_details;
    protected $output_data;
    protected $output_data_type_code;
    protected $error_details;
    protected $error_code;
    protected $picked_up;

    // used inside the class only
    protected $row_exists = false;
    
    const STATUS_IN_PROGRESS = 'inprogress';
    const STATUS_COMPLETE_OK = 'complete-OK';
    const STATUS_COMPLETE_ERROR = 'complete-ERR';
    const SERVER_PICKED_UP = 1;
    const SERVER_WAITING = 2;
    const SERVER_GAVE_UP = 3;
    
    const OUTPUT_DATA_TYPE_JSON = 'JSON';
    const OUTPUT_DATA_TYPE_PHP = 'PHP';
    
    const ERROR_RUNTIME = 'RUNTIME_ERROR';
    
    const DB_TABLE = 'run_everywhere_remote_service_log';
    const DB_NAME = 'latencydb';
    const SQL_COMMENT = " /* MODULE: bertlib FILE: class-run-everywhere-remote-service.php */ ";
    
	// anything you put in $args will override the default value
	function __construct( $args = array() ) {
	    parent::__construct($args);
        
        if (!$this->check_for_table()) {
            $this->create_table();
        }
        
        $this->load_args($args);
    }
    
    function pick_up_latest_run() {
        $this->debug('Picking up ' . $this->app_name . ' latest run from ' . $this->target_datacenter() . ' get DB handle....');
        $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
        $sql = 'SELECT * FROM ' . self::DB_TABLE . ' WHERE app_name = "' . $this->app_name() . '" ORDER BY start_time DESC LIMIT 1';
        $this->debug('Pickup query is ' . $sql);
        $db->halt_on_error = false;
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error loading run ID ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            // TODO throw an error here? maybe?
        }
        
        if ($db->next_record()) {
            $this->init_from_table_row($db);
            
            // the run state will tell me if the central server can pickup the data.
            switch($this->status_code()) {
                case self::STATUS_IN_PROGRESS:
                    $this->picked_up( self::SERVER_WAITING );
                    break;
                case self::STATUS_COMPLETE_OK:
                    $this->picked_up( self::SERVER_PICKED_UP );
                    break;
                case self::STATUS_COMPLETE_ERROR:
                    $this->picked_up( self::SERVER_GAVE_UP );
                    break;
                default:
                    $this->picked_up( self::SERVER_WAITING );
            }
            
            $this->debug('pickup value from ' . $this->app_name . ' output from ' . $this->target_datacenter() . ": " . $this->picked_up() );
            return true;
        }
        else {
            $this->debug('NO DATA found when picking up ' . $this->app_name . ' output from ' . $this->target_datacenter());
            $this->picked_up( self::SERVER_GAVE_UP );
            return false;
        }
    }
    
    function start($args = array()) {
        if (count($args) > 0) {
            $this->load_args($args);
        }
        
        $this->save();
    }
    
    function finish($args = array()) {
        // set default codes for finishing properly
        $this->status_code(self::STATUS_COMPLETE_OK);
        $this->status_details('This run completed with no errors.');
        
        // overwrite default data with the args in the parameters
        $this->load_args($args);
        
        $this->save();
    }
    
    function error($error_message) {
        parent::error($error_message);
        
        // set default error code
        $this->error_code(self::ERROR_RUNTIME);
        $this->error_details('There was a problem running the remote service in ' . $this->target_datacenter() . '.');
        
        $this->save();
    }

    function load_args($args) {
        
        //$this->debug('Loading args');
        
        if (isset($args['id'])) {
			$this->id($args['id']);
		}
        if (isset($args['run_name'])) {
			$this->run_name($args['run_name']);
		}
        if (isset($args['app_name'])) {
			$this->app_name($args['app_name']);
		}
        if (isset($args['start_time'])) {
			$this->start_time($args['start_time']);
		}
        if (isset($args['end_time'])) {
			$this->end_time($args['end_time']);
		}
        if (isset($args['status_code'])) {
			$this->status_code($args['status_code']);
		}
        if (isset($args['status_details'])) {
			$this->status_details($args['status_details']);
		}
        if (isset($args['output_data'])) {
			$this->output_data($args['output_data']);
		}
        if (isset($args['output_data_type_code'])) {
			$this->output_data_type_code($args['output_data_type_code']);
		}
        if (isset($args['error_details'])) {
			$this->error_details($args['error_details']);
		}
        if (isset($args['error_code'])) {
			$this->error_code($args['error_code']);
		}
        if (isset($args['picked_up'])) {
			$this->picked_up($args['picked_up']);
		}
    }
    
    function init_from_table_row($db) {
        $this->id( intval($db->f('remote_service_log_id')) );
        $this->run_name( $db->f('run_name') );
        $this->app_name( $db->f('app_name') );
        $this->start_time( $db->f('start_time') );
        $this->end_time( $db->f('end_time') );
        $this->status_code( $db->f('status_code') );
        $this->status_details( $db->f('status_details') );
        $this->output_data( $db->f('output_data') );
        $this->output_data_type_code( $db->f('output_data_type_code') );
        $this->error_details( $db->f('error_details') );
        $this->error_code( $db->f('error_code') );
        $this->picked_up( $db->f('picked_up') );
    }

	function id( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->id = $new_value;
		}
		return $this->id;
	}
    
    // pass in a 0 to have the system generate a run ID
	function run_name( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
            if ($new_value === 0) {
                $this->run_name = 'Run ' . date('Y-m-d H:i:s T');
            }
            else {
    			$this->run_name = $new_value;
            }
		}
		return $this->run_name;
	}
    
	function app_name( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->app_name = $new_value;
		}
		return $this->app_name;
	}
    
	function start_time( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->start_time = $new_value;
		}
		return $this->start_time;
	}
    
	function end_time( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->end_time = $new_value;
		}
		return $this->end_time;
	}
    
	function status_code( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->status_code = $new_value;
		}
		return $this->status_code;
	}
    
	function status_details( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->status_details = $new_value;
		}
		return $this->status_details;
	}
    
	function output_data( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->output_data = $new_value;
		}
		return $this->output_data;
	}
    
	function output_data_type_code( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->output_data_type_code = $new_value;
		}
		return $this->output_data_type_code;
	}
    
	function error_details( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->error_details = $new_value;
		}
		return $this->error_details;
	}
    
	function error_code( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->error_code = $new_value;
		}
		return $this->error_code;
	}
    
    // picked up must be an int!
	function picked_up( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->picked_up = intval($new_value);
            
            // if flagging the picked up flag, we need to save that setting.
            if ( ($new_value > 0) && ($this->id() > 0) ) {
                $sql = ' UPDATE ' . self::DB_TABLE . ' SET picked_up=' . intval($new_value) . ' WHERE remote_service_log_id=' . intval($this->id());
                
                $this->debug(' PICKUP query is: ' . $sql);
                
                $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
                $db->halt_on_error = false;
                $db->query($sql);
        
                if ($db->Errno != 0) {
                    $this->error('Error checking for table ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
                }
            }
		}
		return $this->picked_up;
	}
    
    // save state in the table row.  if no row, create a new one
    function save() {
        $action = 'INSERT INTO ';
        $where = '';
        $limit = '';
        $create_flag = true;
        // update if the row already exists
        if ($this->row_exists) {
            $action = 'UPDATE ';
            $where = ' WHERE remote_service_log_id=' . intval($this->id());
            $limit = ' LIMIT 1';
            $create_flag = false;
        }
        
        //$this->debug('saving with action ' . $action);
        
        $columns = array();
        if (!is_null($this->run_name())) {
            $columns[] = ' run_name= "' . addslashes($this->run_name()) . '" ';
        }
        if (!is_null($this->app_name())) {
            $columns[] = ' app_name= "' . addslashes($this->app_name()) . '" ';
        }
        if ($action == 'INSERT INTO ') {
            $columns[] = ' start_time= now() ';
        }
        if (!is_null($this->status_code())) {
            $columns[] = ' status_code= "' . addslashes($this->status_code()) . '" ';
            $columns[] = ' end_time= now() ';
        }
        if (!is_null($this->status_details())) {
            $columns[] = ' status_details= "' . addslashes($this->status_details()) . '" ';
        }
        if (!is_null($this->output_data())) {
            // encoding puts the data in quotes, so we don't have to do that here - right?
            $columns[] = ' output_data= "' . addslashes($this->output_data()) . '" ';
        }
        if (!is_null($this->output_data_type_code())) {
            $columns[] = ' output_data_type_code= "' . addslashes($this->output_data_type_code()) . '" ';
        }
        if (!is_null($this->error_details())) {
            $columns[] = ' error_details= "' . addslashes($this->error_details()) . '" ';
        }
        if (!is_null($this->error_code())) {
            $columns[] = ' error_code= "' . addslashes($this->error_code()) . '" ';
        }
        if (!is_null($this->picked_up())) {
            $columns[] = ' picked_up= "' . addslashes($this->picked_up()) . '" ';
        }
        
        $sql = $action . self::DB_TABLE . self::SQL_COMMENT .
            ' SET ' . join(' , ', $columns) . $where . $limit;
        //$this->debug(' SAVE query for ' . $this->target_datacenter() . ' is: ' . $sql);
        $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
        //$this->debug_r($db);
        $db->halt_on_error = false;
        $db->query($sql);
        
        //$this->debug(' query is over.');

        if ($db->Errno != 0) {
            $this->error('Error checking for table ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            // TODO throw an error here
        }
        
        if ($create_flag === true) {
            
            // get the ID assigned to this row
            $sql = 'SELECT LAST_INSERT_ID() as id';
            $db->query($sql);
            
            if ($db->Errno != 0) {
                $this->error('Error getting ID for new everywhere client record: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            }

            if ($db->next_record()) {
                $this->id( intval( $db->f('id') ) );
                $this->row_exists = true;
            }
        }
        
        return true;
    }
    
    // reload data from table without saving data here.
    // needed by the server to pull data set by the client.
    function refresh() {
        $sql = 'SELECT * from ' . self::DB_TABLE . ' WHERE remote_service_log_id=' . intval($this->id());
        //$this->debug('Refresh query is ' . $sql);
        $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
        $db->halt_on_error = false;
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error loading run ID ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            // TODO throw an error here
        }
        
        if ($db->next_record()) {
            $this->init_from_table_row($db);
            $this->picked_up(self::SERVER_PICKED_UP);
            $this->debug('Success picking up ' . $this->app_name . ' output from ' . $this->target_datacenter());
            return true;
        }
    }

    function check_for_table() {
        $table_exists = false;
        $sql = 'SHOW TABLES LIKE "' . self::DB_TABLE . '"' . self::SQL_COMMENT;
        $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
        $db->halt_on_error = false;
        $db->query($sql);
        
        if ($db->Errno != 0) {
            $this->error('Error checking for table ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
        }
        if ($db->next_record()) {
            $table_exists = true;
        }
        
        return $table_exists;
    }
    
    function create_table() {
        $sql = 'CREATE TABLE IF NOT EXISTS ' . self::DB_TABLE . self::SQL_COMMENT . '(
            remote_service_log_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            run_name VARCHAR(20) NOT NULL,
            app_name VARCHAR(30) NOT NULL,
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP DEFAULT 0,
            status_code VARCHAR(20),
            status_details VARCHAR(255),
            output_data MEDIUMTEXT,
            output_data_type_code VARCHAR(20),
            error_details VARCHAR(255),
            error_code VARCHAR(20),
            picked_up TINYINT NOT NULL DEFAULT 0
            )';
        //$this->debug('Creating run everywhere client table: ' . $sql);
        $sql = preg_replace('/\s+/', ' ', $sql);
        $db = $this->db_handle( self::DB_NAME, $this->target_datacenter() );
        $db->halt_on_error = false;
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error creating table: ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
        }

        return $this->check_for_table();
    }
    
}