<?php
require_once("application.inc");
require_once("pun/services/IdentityService.php");
require_once("pun/services/ConfigService.php");
require_once("pun/model/LatencyNoticeDefinition.php");
require_once("pun/model/LatencyEventDefinition.php");
require_once("pun/services/LatencyNoticeDefinitionService.php");
require_once("pun/services/LatencyEventDefinitionService.php");
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

$import = new ImportDefs();
$import->doImport($argv);

class ImportDefs
{
	private $log;
	private $importFilename;
	private $importLatencyNoticeDefinitions = false;
	private $importEligibleReportSuiteIds = false;
	private $identityService;
	private $latencyNoticeDefService;
	private $eventDefService;
	private $configService;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
		$this->identityService = new IdentityService();
		$this->latencyNoticeDefService = new LatencyNoticeDefinitionService();
		$this->eventDefService = new LatencyEventDefinitionService();
		$this->configService = new ConfigService();
	}
	
	/**
	 * Imports the given tab delimited file with fields datacenter,username,adobe_emails,customer_logins(comma seperated),email_frequency,latency_threshold,notify_state
	 */
	public function doImport($argv)
	{
		$this->parseCommandlineArguments($argv);
		if($this->importFilename == null)
		{
			$this->display_usage();
			exit(1);
			
		}
		if($this->importLatencyNoticeDefinitions)
		{
			$this->importLatencyNoticeDefinitions($this->importFilename);
		}
		else if($this->importEligibleReportSuiteIds)
		{
			$this->importEligibleReportsuiteIds($this->importFilename);
		}
		else
		{
			$this->display_usage();
		}
	}
	
	public function importLatencyNoticeDefinitions($fileName)
	{
		if(file_exists($fileName))
		{
			$this->log->info("Importing latency notice definitions from file ".$fileName);
			foreach (file($fileName) as $line) 
			{
				// skip column headers
				if(strstr($line,"Billing Customer ID"))
				{
					continue;
				}
				$this->log->debug("Processing data for line $line");
				$fields = explode("\t",$line);
				$this->log->debug("Processing fields ".implode($fields));
				
				$username = $fields[1];
				list($companyId,$companyName) = $this->identityService->getPrimaryLoginCompanyIdForRSID($username);
				list($billingCustomerId,$billingCustomerName) = $this->identityService->getPrimaryBillingCustomerForRSID($username);
				$this->log->debug("username: $username companyid: $companyId companyname: $companyName billingcustomer ID: $billingCustomerId bcname: $billingCustomerName");
				$def = $this->latencyNoticeDefService->getLatencyNoticeDefinitionByCompany($companyId);
				if(is_null($def))
				{
					$this->log->debug("Creating new latencyNoticeDefinition for login company $companyName");
					$def = new LatencyNoticeDefinition();
					$def->setBillingCustomerId(0);
					$def->setLoginCompanyId(0);
					if($billingCustomerId != null && $billingCustomerId > 0)
					{
						$def->setBillingCustomerId($billingCustomerId);
						$def->setBillingCustomerName($billingCustomerName);
					}
					if($companyId != null && $companyId > 0)
					{
						$def->setLoginCompanyId($companyId);
						$def->setLoginCompanyName($companyName);
//						$login = $identityService->getPrimaryLoginForCompany($companyName,$companyId);
//						$this->log->debug("primary customer login for $companyName is ".$login->getLoginId());
//						if(!is_null($login))
//						{
//							$def->addCustomerLogin($login->getLoginId());
//						}
					}
					$def->setAdobeEmail($fields[2]);
					$def->setHaEmail($fields[3]);
					$loginIds = explode(",",$fields[4]);
					foreach($loginIds as $loginId)
					{
						$def->addCustomerLogin($loginId);
					}
					$def->setEmailFrequency($fields[5]);
					$def->setLatencyThreshold($fields[6]);
					$def->setNotifyState(trim($fields[7]));
					
					try
					{
						$this->latencyNoticeDefService->validateDefinition($def);
						$def = $this->latencyNoticeDefService->saveLatencyNoticeDefinition($def);
					}
					catch(InvalidParameterException $ex)
					{
						$this->log->error("Error creating LatencyNoticeDefinition for login Company $companyName. ".$ex->getMessage());
						continue;
					}
					
					
				}
				$this->log->debug("Creating new LatencyEventDefinition for suite $username");
				$this->log->debug("notice def id is ".$def->getID());				
				$eventDef = new LatencyEventDefinition();
				$eventDef->setNoticeDefId($def->getID());
				$eventDef->setUsername($username);
				$eventDef->setUserid(userid_lookup($username));
				$this->log->debug("user id is ".$eventDef->getUserid());

				try 
				{
					$def->addEventDefinition($eventDef);
					$this->latencyNoticeDefService->validateLatencyEventDefinitions($def);
					$this->eventDefService->saveLatencyEventDefinition($eventDef);
				}
				catch(InvalidParameterException $ex)
				{
					$this->log->error("Error creating LatencyEventDefinition for login Company $companyName report suite $eventDef->getUsername(). ".$ex->getMessage());
					continue;
					
				}
				
//				$loginIds = explode(",",$fields[4]);
//				$this->log->debug("Adding login ids for suite $fields[1]: ".implode(",",$loginIds));
//				foreach($loginIds as $loginId)
//				{
//					$def->addCustomerLogin($loginId);
//				}
				
//				$latencyNoticeDefService->saveLatencyNoticeDefinition($def);
			}
			$this->log->info("Done importing latency notice definitions.");
		}
		else
		{
			$this->log->info("Filename $fileName does not exist.");
		}
	}
	
	public function importEligibleReportsuiteIds($fileName)
	{
		if(file_exists($fileName))
		{
			$this->configService->deleteAllEligibleUserIds();
			$this->log->info("Importing eligible report suite ids from file ".$fileName);
			foreach (file($fileName) as $line) 
			{
				$this->log->debug("Processing data for line $line");
				$fields = explode("\t",$line);
				$this->log->debug("Processing fields ".implode($fields));
				
				$username = trim($fields[1]);
				$userId = $this->identityService->getRSIDFromRSName($username);
				$this->log->debug("username: $username userid: $userId");
				$this->configService->saveEligibleUserId($userId);
			}
			$this->log->info("Done importing eligible report suite ids.");
		}
		else
		{
			$this->log->info("Filename $fileName does not exist.");
		}
		
	}
	
	public function parseCommandlineArguments($argv)
	{
		$this->log->debug("Parsing command line arguments.");
		if ( count($argv) > 0 ) 
		{
		
		    // If asking for help, ignore any errors in options they might have
		    if ( in_array( '-h', $argv ) || in_array( '--help', $argv ) ) 
		    {
		    	$this->display_usage();
				$this->log->info("Displayed help. Exiting");
		    	exit(0);
		    }
		
		    while ( count( $argv ) ) 
		    {
		        array_shift($argv);
		        $arg = $argv[ 0 ];
		        $optarg = $argv[ 1 ];
		        
		        switch( $arg ) 
		        {
		            case '-e':
		            case '--eligibility_import':
						$this->importEligibleReportSuiteIds = true;
		            	$this->importFilename = $optarg;
						$this->log->debug("Command line arg eligibility_import set to TRUE. Import file is $this->importFilename");
						array_shift( $argv );
		                continue 2;
		
		            case '-i':
		            case '--import_defs':
						$this->importLatencyNoticeDefinitions = true;
		            	$this->importFilename = $optarg;
						$this->log->debug("Command line arg import_defs set to TRUE Import file is $this->importFilename");
						array_shift( $argv );
						continue 2;
		                
		            default:
		            	if(isset($arg))
		            	{
		            		$this->log->error("Unknown command line parameter $arg");
		            	}
		            	continue 2;
		        }
		    }
		}
	}
	
	
	
	private function display_usage()
	{
		echo("-h --help \tPrints this help and exits.\r\n\r\n");
		echo("-i --import_defs \tInstructs the application import latency notice definitions and latency event definitions from the given text file\r\n\r\n");
		echo("-e --eligibility_import \tInstructs the application to import a list of eligible report suite ids.\r\n\r\n");
	}
	
}