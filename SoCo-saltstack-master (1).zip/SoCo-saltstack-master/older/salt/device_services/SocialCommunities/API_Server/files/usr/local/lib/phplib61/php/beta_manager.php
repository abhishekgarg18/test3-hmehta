<?php
require_once 'database/DBQuery.class.php';

function get_betas()
{
	$admindb = new DB_Sql('admindb');
	$sql = 'SELECT beta_prefix FROM beta_server WHERE beta_prefix LIKE \'%beta%\'';
	$query = new DBQuery($admindb, $sql);
	$betas = array();
	$result = $query->execute();
	while($result->hasNext()){
		$data = $result->next();
		$betas[] = $data['beta_prefix'];
	}
	sort($betas);
	return $betas;
}

function load_all_betas()
{
	$admindb = new DB_Sql('admindb');
	$sql = 'SELECT beta_id, beta_prefix FROM beta_server ORDER BY beta_id';
	$query = new DBQuery($admindb, $sql);
	$betas = array();
	$result = $query->execute();
	while($result->hasNext()){
		$data = $result->next();
		$betas[$data['beta_id']] = $data['beta_prefix'];
	}
	return $betas;
}

function get_version_access ($cid) {
	$status = array ();
	if (!$cid)	return $status;
	$cdb = new DB_Sql ('companydb');
	$sql = "SELECT * FROM version_access WHERE companyid=%i{companyid}";
	$q = new DBQuery($cdb, $sql, array('companyid' => $cid));
	$res = $q->execute();
	if($data = $res->next()){
		$status = explode ('|', $data['versions_allowed']);
	} else {
		$status = array();
	}
	$cdb->free ();
	return $status;
}

function populate_from_list($list) {
	$company_array=explode("\n",$list);
	$return = array();
	foreach ($company_array as $c) {
		$c = trim($c);
		$tmpCompany = Company::getInstance($c);
		if ($tmpCompany->companyid) {
			$return[] = array(
				'companyid'	=> $tmpCompany->companyid,
				'company' => $tmpCompany->company,
				'description' => $tmpCompany->description,
				'beta_tester' => $tmpCompany->beta_tester,
				'max_logins' => $tmpCompany->max_logins,
				'version_access' => $tmpCompany->get_version_access()
			);
		} else {
			$return[] = array(
				'companyid' => 0,
				'company' => "Invalid Company: $c",
				'beta_tester' => 0,
				'logins' => array()
			);
		}
	}
	
	return $return;
}

function remove_version_access($req,$version) {
	$companies = array();
	foreach ($req as $k => $v) {
		if (substr($k,0,8) == 'company_') {
			list(,$id) = preg_split('/_/',$k);
			$companies[] = $id;
		}
	}
	
	if (!count($companies)) { return; }
	
	$db = new DB_Sql('companydb');
	$query = "UPDATE version_access SET versions_allowed=REPLACE(versions_allowed,'$version','') WHERE companyid IN (" . implode(",",$companies) . ")";
	$db->query($query);
	$query = "UPDATE version_access SET versions_allowed=REPLACE(versions_allowed,'||','|') WHERE companyid IN (" . implode(",",$companies) . ")";
	$db->query($query);
}

function enable_version_access($req,$version) {
	$companies = array();
	foreach ($req as $k => $v) {
		if (substr($k,0,8) == 'company_') {
			list(,$id) = preg_split('/_/',$k);
			$companies[] = $id;
		}
	}
	
	if (!count($companies)) { return; }
	
	$db = new DB_Sql('companydb');
	$query = "UPDATE version_access SET versions_allowed = 
		IF(LOCATE('$version',versions_allowed), versions_allowed, CONCAT(versions_allowed,'|$version')) WHERE 
		companyid IN (" . implode(",",$companies) . ")";
	$db->query($query);
}

function populate_from_search($search) {
	$companyInstance = new Company();
	$companies = $companyInstance->get_company_list($search);
	
	for ($i=0;$i<count($companies);$i++) {
		$companies[$i]['version_access'] = get_version_access($companies[$i]['companyid']);
	}
	
	return $companies;
}

function toggle_beta_access ($req,$enable_array) {
	global $betas;
	$companies = array();
	foreach ($req as $k => $v) {
		if (substr($k,0,8) == 'company_') {
			list(,$id) = preg_split('/_/',$k);
			$companies[] = $id;
		}
	}
	
	if (!count($companies)) { return; }

	$beta_access_array = '';
	$enabled = 0;
	foreach($betas as $i => $beta){
		if($enable_array[$i] == 1){
			$beta_access_array[$beta] = '1';
			$enabled = 1;
		} else {
			$beta_access_array[$beta] = '0';
		}

		if(strtolower($beta) == 'beta'){
			$beta_access_array['trial'] = $beta_access_array[$beta]; 
		}
	}
	
	$db = new DB_Sql('companydb');
	$sql = "UPDATE company SET beta_tester=%i{beta_tester}, beta_access=%s{beta_access} WHERE companyid IN (%a{companies})";
	$param = array(
		'beta_tester' => $enabled,
		'beta_access' => json_encode($beta_access_array),
		'companies' => $companies
	);
	$query = new DBQuery($db, $sql, $param);
	$query->execute();;
}

function update_beta_servers($beta_servers)
{
	$admindb = new DB_Sql('admindb');
	$sql = 'DELETE FROM beta_server WHERE beta_id IS NOT NULL';
	$query = new DBQuery($admindb, $sql);
	$query->execute();
	
	$new_betas = array_values($beta_servers);
	$sql = 'INSERT INTO beta_server (beta_id, beta_prefix) VALUES ';
	$value = array();
	foreach($new_betas as $i => $beta){
		$value[] = '('. ($i + 1). ', \''. $beta. '\')';
	}
	$sql .= implode(',', $value);
	$query = new DBQuery($admindb, $sql);
	$query->execute();
}
