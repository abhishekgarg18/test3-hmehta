<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AppServiceBase.class.php");

class OM_GuidActionService extends OM_AppServiceBase {

	public function executeGuidAction($guidId) {
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();

		$path = "/scheduler/guidaction/" . $guidId . "/execute";
		$response = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::PUT_REQUEST,"",true);
		if ($response->hasErrors()) {
			throw new Exception("Error:" . $response->getErrorMessage());
		}
		return json_decode($response->getResponse(), true);
	}
}
