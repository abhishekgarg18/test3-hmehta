<?php

class LoginSelector
{
	private $loginIds;
	private $rsids;
	private $loginCompany;
	private $resultCountLimit;
	private $resultStartindex;
	private $subscribed;
	
	public function getLoginIds() 
	{
		return $this->loginIds;
	}

	public function getRsids() 
	{
		return $this->rsids;
	}

	public function getLoginCompany() 
	{
		return $this->loginCompany;
	}

	public function setLoginIds($loginIds) 
	{
		$this->loginIds = $loginIds;
	}

	public function setRsids($rsids) 
	{
		$this->rsids = $rsids;
	}

	public function setLoginCompany($loginCompany) 
	{
		$this->loginCompany = $loginCompany;
	}

	public function limitResult($resultCountLimit, $resultStartIndex =  0)
	{
		$this->resultCountLimit = $resultCountLimit;
		$this->resultStartindex = $resultStartIndex;
	}
	
	public function getSubscribed() 
	{
		return $this->subscribed;
	}

	public function setSubscribed($subscribed) 
	{
		$this->subscribed = $subscribed;
	}

}

