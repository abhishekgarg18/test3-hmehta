<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * ConfigValidate - Provides callback functions for specialized config validation.
 * 
 * Any classes added should provide a validate function that takes a single value as input.
 * The validate function should return the value if it is valid or FALSE if it is not.
 *
 * @author  Matt Gould <mgould@adobe.com>
 *
 * @version $Id: $
 */

require_once 'application.inc';
require_once 'common_functions.inc';

class ValidateTime {
	private $format;
	
	function __construct($format = MYSQL_DATE_FORMAT)
	{
		$this->format = $format;
	}
	
	function validate($time)
	{
		return (date($this->format, strtotime($time)) == $time)?$time:FALSE;
	}
}

class ValidateTimeString {
	private $min = null;
	private $max = null;

	function __construct($min = null, $max = null) {
		if (null !== $min) {
			$time = strtotime($min);
			if (false !== $time) {
				$this->min = $time;
			} else {
				throw new Exception("'$min' does not parse to a valid time");
			}
		}

		if (null !== $max) {
			$time = strtotime($max);
			if (false !== $time) {
				$this->max = $time;
			} else {
				throw new Exception("'$max' does not parse to a valid time");
			}
		}

	}

	function validate($val) {
		$time = strtotime($val);
		if (false === $time) return FALSE;
		if (null !== $this->min && $this->min > $time) return FALSE;
		if (null !== $this->max && $this->max < $time) return FALSE;
		return $val;
	}

}

class ValidateFloat{
	private $min;
	private $max;
	
	function __construct($min = null, $max = null) {
		$this->min = $min;
		$this->max = $max;
	}
	
	function validate($val) {
		if ((string)(float)$val != (string)$val) return FALSE;
		if (null !== $this->min && $this->min > $val) return FALSE;
		if (null !== $this->max && $this->max < $val) return FALSE;
		return (float)$val;
	}
}


/**
 * SELFTEST
 * Usage: php ConfigValidate.class.php
 */
if (count(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
	(version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
		debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1))) == 0) {
			if (function_exists('xdebug_break'))
				xdebug_break();

			try {
				echo "\nTesting ValidateTime\n";
				$date = date(MYSQL_DATE_FORMAT);
				$x = new ValidateTime();
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect bool(false)) ";
				var_dump($x->validate('03:00'));
				echo "(expect string(19) \"$date\") ";
				var_dump($x->validate($date));
				
				$x = new ValidateTime('H:i');
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect string(5) \"03:00\") ";
				var_dump($x->validate('03:00'));
				echo "(expect bool(false)) ";
				var_dump($x->validate($date));
				
				echo "\nTesting ValidateTimeString\n";
				$x = new ValidateTimeString();
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect string(19) \"2015-11-01 00:01:02\") " ;
				var_dump($x->validate('2015-11-01 00:01:02'));
				echo "(expect string(5) \"today\") " ;
				var_dump($x->validate('today'));
				
				$x = new ValidateTimeString('yesterday', 'tomorrow');
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect bool(false)) ";
				var_dump($x->validate('2 days ago'));
				echo "(expect bool(false)) ";
				var_dump($x->validate('3 days from now'));
				echo "(expect string(5) \"today\") " ;
				var_dump($x->validate('today'));
				
				
				echo "\nTesting ValidateFloat\n";
				$x = new ValidateFloat();
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect double(1.1)) ";
				var_dump($x->validate(1.1));
				echo "(expect double(0)) ";
				var_dump($x->validate(0));
				echo "(expect double(1)) ";
				var_dump($x->validate(1));
				
				$x = new ValidateFloat(1);
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect double(1.1)) ";
				var_dump($x->validate(1.1));
				echo "(expect bool(false)) ";
				var_dump($x->validate(0));
				echo "(expect double(1)) ";
				var_dump($x->validate(1));
				
				$x = new ValidateFloat(1,1);
				echo "(expect bool(false)) ";
				var_dump($x->validate('foo'));
				echo "(expect bool(false)) ";
				var_dump($x->validate(1.1));
				echo "(expect bool(false)) ";
				var_dump($x->validate(0));
				echo "(expect double(1)) ";
				var_dump($x->validate(1));
				
			} catch (Exception $e) {
				fprintf(
					STDERR,
					"caught %s%s%s\n",
					get_class($e),
					$e->getCode() ? sprintf(', code=%d', $e->getCode()) : '',
					$e->getMessage() ? sprintf(', message="%s"', $e->getMessage()) : ''
				);
				exit(1);
			}
		}
