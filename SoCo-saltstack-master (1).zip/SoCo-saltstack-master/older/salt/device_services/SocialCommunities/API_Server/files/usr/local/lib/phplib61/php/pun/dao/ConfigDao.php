<?php
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

/**
 * 
 * This class manages persistent storage for various configurations for the PowerUp Notices application
 *
 */
class ConfigDao
{
	private $log;
	private $qc = '/*PowerUp Notices: ConfigDao*/';
	private $emailTableName = 'email_templates';
	private $emailFrequencyOptionsTable = 'config_email_frequency_options';
	private $latencyThresholdOptionsTable = 'config_latency_threshold_options';
	private $notificationstateOptionsTable = 'config_notification_state_options';
	private $configMiscTable = "config_misc";
	private $eligibleUsersTableName = 'eligible_users';
	private $databaseName = 'compassdb';
	
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);		
	}
	

	/**
	 * 
	 * Retrieves the email text body for the given email type and version
	 * @param int $type
	 * @param int $version
	 */
	public function getLatencyEmailTemplate($type,$version = 0)
	{
		if($version < 1)
		{
			$version = $this->getCurrentTemplateVersion($type);
		}
		$db = new DB_Sql($this->databaseName);
		$this->log->debug("Retrieving email template for type $type, version $version");
		$sql = "SELECT $this->qc template_text 
				FROM $this->emailTableName
				WHERE type = $type AND version = $version";
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		
		return $db->f("template_text");
	}
	
	/**
	 * retrieves the current version for the given email template type
	 * @param int $type
	 */
	public function getCurrentTemplateVersion($type)
	{
		$this->log->debug("retrieving current email template version for type $type");		
		$db = new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc max(version) as version
				FROM $this->emailTableName
				WHERE type = $type";
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$version = $db->f("version");
		$db->close();
		return $version;
	}
		

	/**
	 * 
	 * Retrieves the list of avaialable email frequency options
	 */
	public function getEmailFrequencyOptionList()
	{
		$this->log->debug('Retrieving email frequency option list.');
		$db = new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc frequency_option 
			    FROM $this->emailFrequencyOptionsTable";

		$values = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$values[] = $db->f('frequency_option');
		}
		$db->close();
		
		return $values;
	}
	
	public function replaceEmailFrequencyOptionList($list)
	{
		$this->log->debug("replacing email frequency option list with $list");
		$db = new DB_Sql($this->databaseName);
		$deleteSql = "DELETE $this->qc FROM $this->emailFrequencyOptionsTable";
		$db->squery($deleteSql);
		$vals = explode(",",$list);
		foreach($vals as $val)
		{
			$sql = "INSERT INTO $this->emailFrequencyOptionsTable (frequency_option) VALUES($val)";
			$db->squery($sql);
		}
		$db->close();
	}

	/**
	 * 
	 * Retreives the list of available latency threshold options
	 */
	public function getLatencyThresholdOptionList()
	{
		$this->log->debug('Retreiving latency threshold option list');
		$db = new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc threshold_option 
			    FROM $this->latencyThresholdOptionsTable";

		$values = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$values[] = $db->f('threshold_option');
		}
		$db->close();
		
		return $values;
		
	}

	/**
	 * Replaces all existing latency threshold options with the values in the given list
	 * @param string $list Comma delimited string
	 */
	public function replaceLatencyThresholdOptionList($list)
	{
		$this->log->debug("Saving latency threshold option list $list");
		$db = new DB_Sql($this->databaseName);
		$deleteSql = "DELETE $this->qc FROM $this->latencyThresholdOptionsTable";
		$db->squery($deleteSql);
		$vals = explode(",",$list);
		foreach($vals as $val)
		{
			$sql = "INSERT INTO $this->latencyThresholdOptionsTable (threshold_option) VALUES($val)";
			$db->squery($sql);
		}
		$db->close();
	}

	/**
	 * 
	 * Retrieves the list of notification state options
	 */
	public function getNotificationStateOptionList()
	{
		$this->log->debug('Retrieving notification state option list');
		$db = new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc notification_state_option 
			    FROM $this->notificationstateOptionsTable";

		$values = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$values[] = $db->f('notification_state_option');
		}
		$db->close();
		
		return $values;
		
	}
	
	public function getConfigMiscValue($label)
	{
		$this->log->debug("Retrieving config_misc value with label $label");
		$db = new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc value 
			    FROM $this->configMiscTable
			    WHERE label = '$label'";

		$values = array();
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$value= $db->f('value');
		}
		$db->close();
		
		return $value;
	}
	
	public function saveConfigMiscValue($label,$value)
	{
		$this->log->debug("Updating config_misc $label with value $value");
		$db = new DB_Sql($this->databaseName);
		$sql = "UPDATE $this->qc $this->configMiscTable SET value = '$value' WHERE label = '".addslashes($label)."'";
		$db->squery($sql);
	}
	
		/**
	 * Retrieves a list of userids that are eligible for latency monitoring
	
	 */
	public function getEligibleUserIds()
	{
		$db =  new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc $this->qc userid 
			    FROM $this->eligibleUsersTableName";
		
		$userids = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$userids[] = $db->f('userid');	
		}
		$db->close();
		
		return $userids;		
	}
	
	public function getEligibleUserId($userid)
	{
		$db =  new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc $this->qc userid 
			    FROM $this->eligibleUsersTableName
			    WHERE userid = $userid";
		
		$userid = null;
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$userid = $db->f('userid');	
		}
		$db->close();
		
		return $userid;		
		
	}
	
	public function saveEligibleUserId($id)
	{
		$db =  new DB_Sql($this->databaseName);
		$sql = "INSERT $this->qc $this->qc INTO $this->eligibleUsersTableName (userid)
				VALUES ($id)"; 
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	public function deleteAllEligibleUserIds()
	{
		$db =  new DB_Sql($this->databaseName);
		$sql = "DELETE $this->qc $this->qc FROM $this->eligibleUsersTableName";
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	public function deleteEligibleUserId($id)
	{
		$db =  new DB_Sql($this->databaseName);
		$sql = "DELETE $this->qc $this->qc FROM $this->eligibleUsersTableName WHERE userid = $id";
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
}
