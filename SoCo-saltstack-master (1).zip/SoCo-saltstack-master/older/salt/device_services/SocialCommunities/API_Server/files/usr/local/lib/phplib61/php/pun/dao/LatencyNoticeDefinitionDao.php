<?php
require_once "pun/model/LatencyNoticeDefinition.php";
require_once "pun/model/LatencyNoticeDefinitionSelector.php";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

class LatencyNoticeDefinitionDao
{
	private $qc = '/*PowerUp Notices: LatencyNoticeDefinitionDao*/';
	private $tableName = 'latency_notice_definition';
	private $loginIdTableName = 'latency_notice_def_cust_login_id';
	private $eligibleUsersTableName = 'eligible_users';
	private $databaseName = 'compassdb';
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * Retrieves a single LatencyNoticeDefinition record from the database based on the given id
	 * 
	 * @param int $id database id for the desired db record.
	 */
	public function getLatencyNoticeDefinition($id)
	{
		$this->log->debug("Retrieving LatencyNoticeDefinition with id of $id");
		$latencyNoticeDefinition = null;
		$db =  new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc notice_def_id,billing_customer_id,billing_customer_name,companyid,company,adobe_email,ha_email,email_frequency,latency_threshold,notify_state 
			    FROM $this->tableName 
			    WHERE notice_def_id = $id";
		
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyNoticeDefinition = new LatencyNoticeDefinition();
			$latencyNoticeDefinition->setId($db->f('notice_def_id'));
			$latencyNoticeDefinition->setBillingCustomerId($db->f('billing_customer_id'));
			$latencyNoticeDefinition->setBillingCustomerName($db->f('billing_customer_name'));
			$latencyNoticeDefinition->setLoginCompanyId($db->f('companyid'));
			$latencyNoticeDefinition->setLoginCompanyName($db->f('company'));
			$latencyNoticeDefinition->setAdobeEmail($db->f('adobe_email'));
			$latencyNoticeDefinition->sethaEmail($db->f('ha_email'));
			$latencyNoticeDefinition->setEmailFrequency($db->f('email_frequency'));
			$latencyNoticeDefinition->setLatencyThreshold($db->f('latency_threshold'));
			$latencyNoticeDefinition->setNotifyState($db->f('notify_state'));
			$latencyNoticeDefinition->setCustomerLogins($this->getCustomerLogins($latencyNoticeDefinition->getID()));
		}
		$db->close();

		return $latencyNoticeDefinition;
	}
	
	public function getLatencyNoticeDefinitionByUserid($userid)
	{
		$this->log->debug("Retreiving LatencyNoticeDefinition with rsid of $userid");
		$latencyNoticeDefinition = null;
		$db =  new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc notice_def_id,billing_customer_id,billing_customer_name,companyid,company,adobe_email,ha_email,email_frequency,latency_threshold,notify_state 
			    FROM $this->tableName 
			    WHERE notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE userid = $userid)";
		
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyNoticeDefinition = new LatencyNoticeDefinition();
			$latencyNoticeDefinition->setID($db->f('notice_def_id'));
			$latencyNoticeDefinition->setBillingCustomerId($db->f('billing_customer_id'));
			$latencyNoticeDefinition->setBillingCustomerName($db->f('billing_customer_name'));
			$latencyNoticeDefinition->setLoginCompanyId($db->f('companyid'));
			$latencyNoticeDefinition->setLoginCompanyName($db->f('company'));
			$latencyNoticeDefinition->setAdobeEmail($db->f('adobe_email'));
			$latencyNoticeDefinition->sethaEmail($db->f('ha_email'));
			$latencyNoticeDefinition->setEmailFrequency($db->f('email_frequency'));
			$latencyNoticeDefinition->setLatencyThreshold($db->f('latency_threshold'));
			$latencyNoticeDefinition->setNotifyState($db->f('notify_state'));
			$latencyNoticeDefinition->setCustomerLogins($this->getCustomerLogins($latencyNoticeDefinition->getID()));
		}
		$db->close();

		return $latencyNoticeDefinition;
		
	}
	
	public function getLatencyNoticeDefinitionByCompany($companyid)
	{
		$this->log->debug("Retreiving LatencyNoticeDefinition with company id of $companyid");
		$latencyNoticeDefinition = null;
		$db =  new DB_Sql($this->databaseName);
		$sql = "SELECT $this->qc notice_def_id,billing_customer_id,billing_customer_name,companyid,company,adobe_email,ha_email,email_frequency,latency_threshold,notify_state 
			    FROM $this->tableName 
			    WHERE companyid = $companyid";
		
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyNoticeDefinition = new LatencyNoticeDefinition();
			$latencyNoticeDefinition->setID($db->f('notice_def_id'));
			$latencyNoticeDefinition->setBillingCustomerId($db->f('billing_customer_id'));
			$latencyNoticeDefinition->setBillingCustomerName($db->f('billing_customer_name'));
			$latencyNoticeDefinition->setLoginCompanyId($db->f('companyid'));
			$latencyNoticeDefinition->setLoginCompanyName($db->f('company'));
			$latencyNoticeDefinition->setAdobeEmail($db->f('adobe_email'));
			$latencyNoticeDefinition->sethaEmail($db->f('ha_email'));
			$latencyNoticeDefinition->setEmailFrequency($db->f('email_frequency'));
			$latencyNoticeDefinition->setLatencyThreshold($db->f('latency_threshold'));
			$latencyNoticeDefinition->setNotifyState($db->f('notify_state'));
			$latencyNoticeDefinition->setCustomerLogins($this->getCustomerLogins($latencyNoticeDefinition->getID()));
		}
		$db->close();

		return $latencyNoticeDefinition;
		
	}
	
	/**
	 * Saves a single LatencyNoticeDefinition to the database as a new record
	 * String fields are scrubbed with addslashes
	 * @param LatencyNoticeDefinition $latencyNoticeDefinition
	 */
	public function saveLatencyNoticeDefinition(LatencyNoticeDefinition $latencyNoticeDefinition)
	{
		$this->log->debug("Saving LatencyNoticeDefinition");
		$db =  new DB_Sql($this->databaseName);
		$sql = "INSERT INTO $this->qc $this->tableName (billing_customer_id,billing_customer_name,companyid,company,adobe_email,ha_email,email_frequency,latency_threshold,notify_state)
				VALUES (".$latencyNoticeDefinition->getBillingCustomerId().",
						'".addslashes($latencyNoticeDefinition->getBillingCustomerName())."',
						".$latencyNoticeDefinition->getLoginCompanyId().",
						'".addslashes($latencyNoticeDefinition->getLoginCompanyName())."',
						'".addslashes($latencyNoticeDefinition->getAdobeEmail())."',
						'".addslashes($latencyNoticeDefinition->getHaEmail())."',
						".$latencyNoticeDefinition->getEmailFrequency().",
						".$latencyNoticeDefinition->getLatencyThreshold().",
						'".addslashes($latencyNoticeDefinition->getNotifyState())."')
				ON DUPLICATE KEY UPDATE notice_def_id=LAST_INSERT_ID(notice_def_id),adobe_email=VALUES(adobe_email),email_frequency=VALUES(email_frequency),latency_threshold=VALUES(latency_threshold),notify_state=VALUES(notify_state)";
				// Edits can modify adobe emails, customer logins, email frequency, latency threshold and notice status. 
				
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		
		if($db->squery("SELECT LAST_INSERT_ID()") && ($latencyNoticeDefinition->getID() == NULL || $latencyNoticeDefinition->getID() < 1))
		{
			$latencyNoticeDefinition->setID($db->f('LAST_INSERT_ID()'));
		}
		
		$this->saveCustomerLogins($latencyNoticeDefinition->getID(),$latencyNoticeDefinition->getCustomerLogins());
		$db->close();
		
		return $latencyNoticeDefinition;
	}
	
	/**
	 * Deletes a latency notice definition with the given id
	 * @param int $id
	 */
	public function deleteLatencyNoticeDefinition($id)
	{
		$this->log->debug("Deleting LatencyNoticeDefinition with id of $id");
		$db =  new DB_Sql($this->databaseName);
		$sql = "DELETE from $this->tableName where notice_def_id = $id";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
		$this->deleteCustomerLogins($id);
	}

	/**
	 * retrieves all LatencyNoticeDefinition rows from the database
	 */
	public function getLatencyNoticeDefinitions($latencyNoticeDefinitionSelector)
	{
		$this->log->debug("Retrieving LatencyNoticeDefinitions with selector");
		$db =  new DB_Sql($this->databaseName);
		
		$sql = "SELECT $this->qc notice_def_id,billing_customer_id,billing_customer_name,companyid,company,adobe_email,ha_email,email_frequency,latency_threshold,notify_state
			    FROM $this->tableName";
		
		$fieldValues = $this->getPopulatedFieldsFromSelector($latencyNoticeDefinitionSelector);
		if(sizeof($fieldValues) > 0)
		{
			$sql .= "\n\t\t\tWHERE ".implode(" AND ",$fieldValues);
		}

		if ($latencyNoticeDefinitionSelector->getResultCountLimit()) 
		{
			$count = $latencyNoticeDefinitionSelector->getResultCountLimit();
			$start = $latencyNoticeDefinitionSelector->getResultStartindex();
			$sql .= "\n\t\t\tLIMIT $start, $count";
		}
		
		$latencyNoticeDefinitionRows = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyNoticeDefinition = new LatencyNoticeDefinition();
			$latencyNoticeDefinition->setID($db->f('notice_def_id'));
			$latencyNoticeDefinition->setBillingCustomerId($db->f('billing_customer_id'));
			$latencyNoticeDefinition->setBillingCustomerName($db->f('billing_customer_name'));
			$latencyNoticeDefinition->setLoginCompanyId($db->f('companyid'));
			$latencyNoticeDefinition->setLoginCompanyName($db->f('company'));
			$latencyNoticeDefinition->setAdobeEmail($db->f('adobe_email'));
			$latencyNoticeDefinition->sethaEmail($db->f('ha_email'));
			$latencyNoticeDefinition->setEmailFrequency($db->f('email_frequency'));
			$latencyNoticeDefinition->setLatencyThreshold($db->f('latency_threshold'));
			$latencyNoticeDefinition->setNotifyState($db->f('notify_state'));
			$latencyNoticeDefinition->setCustomerLogins($this->getCustomerLogins($latencyNoticeDefinition->getID()));
			
			$latencyNoticeDefinitionRows[] = $latencyNoticeDefinition;
		}
		$db->close();
		
		return $latencyNoticeDefinitionRows;
	}
	
	public function getCustomerLogins($latencyDefinitionId)
	{
		$db =  new DB_Sql($this->databaseName);
		
		$sql = "SELECT $this->qc cust_login_id 
			    FROM $this->loginIdTableName
			    WHERE latency_notice_def_id = $latencyDefinitionId AND subscribed = 1";
		
		$customerLogins = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$customerLogins[] = $db->f('cust_login_id');	
		}
		
		$db->close();
		
		$this->log->debug("Retrieved ".sizeof($customerLogins)." customer logins associated with the LatencyDefinitionId of $latencyDefinitionId");
		return $customerLogins;		
	}
	
	public function setLoginSubscription($companyid, $loginId, $subscribed)
	{
		//clean input values
		$companyid = intval($companyid);
		$loginid = intval($loginId);
		$subscribed = intval($subscribed);

		$this->log->debug("Setting login subscription for $loginId to $subscribed");
		$db =  new DB_Sql($this->databaseName);
		
		$sql = "UPDATE $this->loginIdTableName set subscribed = $subscribed
			WHERE cust_login_id = $loginId
		   	AND latency_notice_def_id = (SELECT notice_def_id FROM latency_notice_definition WHERE companyid = $companyid)";
		
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	public function getLoginSubscription($companyId, $loginId)
	{
		//clean input values
		$companyid = intval($companyId);
		$loginid = intval($loginId);
		$subscribed = false;
		$this->log->debug("Getting login subscription for $loginId");
		$db =  new DB_Sql($this->databaseName);
		
		$sql = "SELECT subscribed 
				FROM $this->loginIdTableName
				WHERE cust_login_id = $loginId 	AND latency_notice_def_id = (SELECT notice_def_id FROM latency_notice_definition WHERE companyid = $companyid)";
		
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$subscribed = $db->f('subscribed');	
		}
		$db->close();
		
		return $subscribed;
	}
	
	public function deleteCustomerLogins($latencyDefinitionId)
	{
		$this->log->debug("Deleting customer logins associated with the LatencyDefinitionId of $latencyDefinitionId");
		$db =  new DB_Sql($this->databaseName);
		$sql = "DELETE FROM $this->loginIdTableName WHERE latency_notice_def_id = $latencyDefinitionId";
		$db->squery($sql);
		$db->close();
		
	}
	
	public function saveCustomerLogins($latencyDefinitionId, $customerLogins)
	{
		$this->log->debug("Saving ".sizeof($customerLogins)." customer logins associated with the LatencyDefinitionId of $latencyDefinitionId");
		$db =  new DB_Sql($this->databaseName);
		
		// remove all old login ids so that if the given list of login ids has removed any, they will be removed from the db
		$deleteSql = "DELETE FROM $this->loginIdTableName WHERE latency_notice_def_id = $latencyDefinitionId";
		$db->squery($deleteSql);
		
		foreach($customerLogins as $customerLogin)
		{
			// Using IGNORE because a duplicate key error requires no action in this table.  
			$sql = "INSERT IGNORE INTO $this->qc $this->loginIdTableName (latency_notice_def_id,cust_login_id)
					VALUES ($latencyDefinitionId,$customerLogin)";
			$this->log->debug("Executing SQL $sql");
			$db->squery($sql);
		}

		$db->close();
	}

	/*
	 * Builds an array of database field names and associated values. eg, (userid => 'sistr2')
	 * This is used in building where clauses dynamically.
	 * String fields are scrubbed with addslashes
	 * 
	 * @param LatencyNoticeDefinitionSelector  $selector  
	 */
	private function getPopulatedFieldsFromSelector(LatencyNoticeDefinitionSelector $selector)
	{
		$values = array();
		
		if($selector->getNoticeDefId() != null && $selector->getNoticeDefId() > 0)
		{
			$values[] = "notice_def_id = '".$selector->getNoticeDefId()."'"; 
		}

		if($selector->getRsid() != null && strlen($selector->getRsid()) > 0)
		{
			$values[] = "notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE username = '" . $selector->getRsid() . "')";
		}
		
		if($selector->getUserid() != NULL && $selector->getUserid() > 0)
		{
			
			$values[] = "notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE userid = " . $selector->getUserId() . ")";
		}
			
		if($selector->getLoginCompanyName() != null && strlen($selector->getLoginCompanyName()) > 0)
		{
			$values[] = "company = '".addslashes($selector->getLoginCompanyName())."'"; 
		}	
		
		if($selector->getLoginCompany() != null && $selector->getLoginCompany() > 0)
		{
			$values[] = "companyid = ".$selector->getLoginCompany(); 
		}	
		
		if($selector->getBillingCustomerName() != null && strlen($selector->getBillingCustomerName()) > 0)
		{
			$values[] = "billing_customer_name = '".addslashes($selector->getBillingCustomerName())."'"; 
		}	
		
		if($selector->getBillingCustomerId() != null && $selector->getBillingCustomerId() > 0)
		{
			$values[] = "billing_customer_id = ".$selector->getBillingCustomerId(); 
		}

		if($selector->getEmailFrequency() != NULL && $selector->getEmailFrequency() > 0)
		{
			$values[] = "email_frequency = ".$selector->getEmailFrequency();
		}
		
		if($selector->getLatencyThreshold() != NULL && $selector->getLatencyThreshold() > 0)
		{
			$values[] = "latency_threshold = ".$selector->getLatencyThreshold();
		}
		
		if($selector->getNoticeState() != NULL && strlen($selector->getNoticeState()) > 0)
		{
			$values[] = "notify_state = '".$selector->getNoticeState()."'";
		}
		
		if($selector->getCustomerLogin() != NULL && $selector->getCustomerLogin() > 0)
		{
			$values[] = "notice_def_id = (SELECT latency_notice_def_id FROM latency_notice_def_cust_login_id WHERE cust_login_id = ".$selector->getCustomerLogin()." LIMIT 1)";
		}
		
		$this->log->debug("Selector field values: ".implode($values));
					
		return $values;
	}
}

