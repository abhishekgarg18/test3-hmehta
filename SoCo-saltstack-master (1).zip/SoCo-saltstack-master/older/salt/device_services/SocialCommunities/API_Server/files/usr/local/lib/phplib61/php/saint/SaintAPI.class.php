<?php
require_once("application.inc");
require_once(SC_DIR . "/reports/includes/object_functions.inc");
require_once("account_superstats.class");
require_once("ftp.class");

class SaintAPI{

	private $rsid_classifications_array;
	private $relations;
	private $error_array;
	private $classifications;
	private $relations_details;
	private $company;
	private $api_login;
	private $ftp;
	private $relations_details_api;
	private $ftp_user = 'mysql';
	private $ftp_pass = 'D8aB4$3!';

	function __construct($company = false)
	{
		if($company)
		{
			$this->company = $company;
            if ($this->safelyLoadDivisionFunctions()) {
                $this->setClassificationsAndRelations($company);
            }
		}
	}

    private function safelyLoadDivisionFunctions() {
        $file = PLATFORM_DIR . '/model/division/division_functions.inc';
        if(file_exists($file)) {
            require_once ($file);
            return true;
        }
        return false;
    }

	private function setClassificationsAndRelations($company_name)
	{
		$relations = array();
		$classifications = get_company_classifications($company_name);

		if(!count($classifications)){
			$this->error("No classifications found for $company_name");
		}

		$rsid_classifications = array();
		foreach ($classifications as $classification) {
			foreach ($classification['report_suites'] as $report_suite) {
				$rsid_classifications[$classification['relation_id']][$report_suite['username']] = $classification['classification_hash'];
				$relations[$classification['relation_id']][] = $report_suite;
			}
		}

		// need to sort report suites alphabetically (includes function and logic after it)
		foreach($relations as $tmp_relid => $tmprsid_list){
			usort($tmprsid_list,"SaintAPI::rsid_sort");
			$relations[$tmp_relid] = $tmprsid_list;
		}

		$this->rsid_classifications_array = $rsid_classifications;
		$this->relations = $relations;
		$this->classifications = $classifications;
	}

	function setupGlobals($account)
	{
		global $sess_account_superstats;
		$sess_account_superstats = AccountSuperStats::getInstance($account);
	}

	function populateSaintArray($account)
	{
		if(!$this->relations || !$this->rsid_classifications_array)
		{
			return false;
		}
		//check to see if $account belongs to company.
		$this->setupGlobals($account);

		$div_b = new division_base($account);
		$relation_info = $div_b->init_relation_info();
		$sess_objectArray = populate_object_array();

		// relation_sort
		$relation_array = array();
		foreach($this->relations as $k => $v){
			if(!$sess_objectArray[$relation_info[$k]['oid']]['name']) // eliminate items with no names
			{
				continue;
			}
			foreach($v as $sub_k => $sub_v)
			{
				if(strtolower($sub_v['username']) == strtolower($account))
				{
					$this->relations_details[$k][$account]['userid'] = $sub_v['userid'];
					$this->relations_details[$k][$account]['site_title'] = $sub_v['site_title'];
					$this->relations_details[$k][$account]['relation_name'] = $sess_objectArray[$relation_info[$k]['oid']]['name'];
					$this->relations_details[$k][$account]['compatability_hash'] = $this->rsid_classifications_array[$k][$account];

					//and one for the web-services.
					$this->relations_details_api[] = array(
						'relation_id'=>$k,
						'relation_name'=>$sess_objectArray[$relation_info[$k]['oid']]['name'],
						'report_suite'=>$account,
						'site_title'=>$sub_v['site_title'],
						'compatability_hash' =>$this->rsid_classifications_array[$k][$account]
					);
				}
			}
		}
	}

	function getClassifications()
	{
		return $this->classifications;
	}

	function getRsidClassifications()
	{
		return $this->rsid_classifications_array;
	}

	function getRelations()
	{
		return $this->relations;
	}

	function getRelationsArray()
	{
		return $this->relations_details;
	}

	function getAPIRelationsArray()
	{
		return $this->relations_details_api;
	}

	function clearRealtionDetails()
	{
		unset($this->relations_details);
	}

	static function rsid_sort($a,$b){
		return strcasecmp($a['site_title'],$b['site_title']);
	}

	function relation_select_sort($a,$b){
		return strcasecmp($a['name'],$b['name']);
	}

	/**
	 * Validates that the provided report_suite_array (ex: array('reportsuite1', 'reportsuite2')) and relation_id have compatible divisions.
	 *
	 * @param array $report_suites_array
	 * @param int $relation_id
	 * @return bool
	 */
	function reportSuiteDivisionsMatch(&$report_suites_array, &$relation_id)
	{
		$first_hash = $this->rsid_classifications_array[$relation_id][$report_suites_array[0]];
		//TODO:Only do if > 1
		for($x = 1; $x<count($report_suites_array); $x++)
		{
			if($first_hash != $this->rsid_classifications_array[$relation_id][$report_suites_array[$x]])
			{
				$this->error("Report Suites Divisions do not match");
				return false;
			}
		}
		return true;
	}

	function reportSuitesShareRelation($report_suites_array, $relation_id)
	{
		for($x = 0; $x<count($report_suites_array); $x++)
		{
			echo $report_suites_array[$x] . "\n\n";
			echo $this->rsid_classifications_array[$relation_id][$report_suites_array[$x]] . "\n\n";
			if(!$this->rsid_classifications_array[$relation_id][$report_suites_array[$x]])
			{
				$this->error("Report Suite $x does not share relation_id $relation_id");
				return false;
			}
		}
		return true;
	}

	//Corny error handling.
	function error($error_string)
	{
		//Adds an error to the errors array.
		$this->error_array[count($this->errors_array)] = $error_string;
	}

	//error stuff
	function get_errors()
	{
		return $this->error_array;
	}

	function get_last_error_string()
	{
		return $this->error_array[(count($this->error_array)-1)];
	}

	//create/edit job functions
	function createJob($api_login, $job_type, $new_status = 1, $new_progress = 0, $integration_id = 0)
	{
		$integration_id = 0 + $integration_id; // coerce to integer
		
		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_job set api_login = %s{api_login}, "
				. "company = %s{company}, job_type = %s{job_type}, "
				. "status_code = %i{new_status}, progress = %i{new_progress}, genesis_integration_id = %i{integration_id}";
		if($job_type == "export") {
            $sql .= ", date_committed = NOW()";
        }
        
        $parms = array(
        	'api_login' => $api_login,
        	'company' => $this->company,
        	'job_type' => $job_type,
        	'new_status' => $new_status,
        	'new_progress' => $new_progress,
        	'integration_id' => $integration_id
        );
        $query = new DBQuery($db, $sql, $parms);
        $query->execute();
        
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			return $db->f('id');
		}
		else
		{
			return false;
		}
	}

	function createImportConfig($description, $rel_id, $report_suites, $overwrite = 0, $email, $export = 0, $api_id, $company, $company_id)
	{
		$db = new DB_Sql("masterdb");
		
		$sql = "insert into saint_api_import_config	set 
		description = %s{description},
		report_suites = %s{report_suites},
		rel_id = %i{rel_id},
		overwrite = %i{overwrite},
		email = %s{email},
		export = %i{export},
		api_id = %i{api_id},
		company = %s{company},
		company_id = %i{company_id}";
		$parms = array(
			'description' => $description,
			'report_suites' => $report_suites,
			'rel_id' => $rel_id,
			'overwrite' => $overwrite,
			'email' => $email,
			'export' => $export,
			'api_id' => $api_id,
			'company' => $this->company,
			'company_id' => $company_id
		);
		
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function getJobStatusArray($job_id, $api_login = 0)
	{

		$status_codes = array(
		0 => 'Waiting for user data',
		1 => 'In Progress',
		2 => 'In Progress',
		3 => 'Completed',
		4 => 'Completed - With Errors : '
		);

		$file_status_codes = array(
		0 => 'Waiting for user input',
		1 => 'Building Results',
		2 => 'Ready',
		3 => 'Downloaded'
		);

		$counter = 0;
		//todo: make check validate api user.
		$db = new DB_Sql("masterdb");

		$sql = "select status_code, progress, error_message from saint_api_job where api_id = %i{job_id}";
		$parms = array('job_id' => $job_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			$db->next_record();
			$status = $db->f('status_code');
			$error_message = $db->f('error_message');

			if(strlen($error_message) > 0)
			{
				$status = 4; //we completed, but have errors.
			}
			$progress = $db->f('progress'); //not using this right this second.

			$status_text = $status_codes[$status];

			if($status > 1 && $status < 3) //show progress
			{
				$status_text .= " - " . $db->f('progress') . "% Complete";
			}
			else if($status >= 4)
			{
				$status_text .= "$error_message";
			}

			$jobdetails[] = array(
				'id'=>$job_id,'type'=>'job_id',
				'viewable_pages'=>0,
				'status'=>$status_text
			);
		}
		else
		{
			return "The specified job_id does not exist";
		}

		$db = new DB_Sql("masterdb");
		$sql = "select f.file_id, f.status_code, sum(IF(s.file_id is null, 0, 1)) segments "
				. " from saint_api_files f left join saint_api_file_segments s on f.file_id = s.file_id
		where file_type = 'download' and f.api_id = %i{job_id}
		group by f.file_id";
		$parms = array('job_id' => $job_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			while($db->next_record())
			{
				$file_id = $db->f('file_id');
				$status = $db->f('status_code');
				$pages = $db->f('segments');
				$jobdetails[] = array('id'=>$file_id,'type'=>'file_id','viewable_pages'=>$pages,'status'=>$file_status_codes[$status]);
			}
		}
		return $jobdetails;
	}

	function checkFileStatus($job_id, $api_login = 0)
	{
		//todo: make check validate api user.
		$db = new DB_Sql("masterdb");
		$sql = "select status_code, progress from saint_api_job where api_id = %i{job_id}";
		$parms = array('job_id' => $job_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		if($db->affected_rows() > 0)
		{
			$db->next_record();
			$status = $db->f('status_code');
			$progress = $db->f('progress');

			$status_codes = array(
			0 => 'Record Only',
			1 => 'Waiting to Start',
			2 => 'In Progress',
			3 => 'Completed'
			);
			return "$status_codes[$status] - $progress% Complete";
		}
		else
		{
			return "The specified job_id does not exist";
		}
	}

	function checkJobOwner($job_id, $api_login, $company)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select status_code from saint_api_job where api_id = %i{job_id} and api_login = %s{api_login} and company = %s{company}";
		$parms = array(
				'job_id' => $job_id,
				'api_login' => $api_login,
				'company' => $company
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();

		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	static function checkFileOwner($file_id, $api_login, $company)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select f.file_id from saint_api_job j join saint_api_files f on j.api_id = f.api_id "
				. "where j.api_login = %s{api_login} and j.company = %s{company} and f.file_id = %i{file_id}";
		$parms = array(
			'api_login' => $api_login,
			'company' => $company,
			'file_id' => $file_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	static function updateJobStatus($job_id, $new_status = false, $new_progress = false, $set_date_committed = false)
	{
		$db = new DB_Sql("masterdb");
		
		$set_sql = "";
		if(!$new_status && $new_progress) //just update progress
		{
			$set_sql = "progress = %i{new_progress}";
		}
		if($new_status && !$new_progress) //just update status
		{
			$set_sql = "status_code = %i{new_status}, progress = 0";
		}
		if($new_status && $new_progress) //update progress and status
		{
			$set_sql = "status_code = %i{new_status}, progress = %i{new_progress}";
		}
        if ($set_date_committed) {
            if($set_sql != "") {
                $set_sql .= ", ";
            }
           $set_sql .= "date_committed = NOW()";
        }

		$sql = "update saint_api_job set $set_sql where api_id = %i{job_id}";
		$parms = array(
			'new_progress' => $new_progress,
			'new_status' => $new_status,
			'job_id' => $job_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return "No change made";
		}
	}

	static function getPendingImportAPIJobIDs()
	{
		$db = new DB_Sql("masterdb");
		$sql = "SELECT j.api_id, c.report_suites, c.rel_id, c.company_id, f.filename, "
				. "f.file_path, f.file_size, f.date_recieved FROM saint_api_job j "
				. "JOIN saint_api_files f ON j.api_id = f.api_id "
				. "JOIN saint_api_import_config c ON c.api_id = j.api_id WHERE j.status_code = 1 AND f.status_code = 2";
		$db->query($sql);

		if ($db->affected_rows() > 0) {
			$api_ids = array();
			while ($db->next_record()) {
				$api_ids[$db->f('api_id')] = array(
					'report_suites' => $db->f('report_suites'),
					'rel_id' => $db->f('rel_id'),
					'company_id' => $db->f('company_id'),
					'file_name' => $db->f('file_path') . $db->f('filename'),
					'file_size' => $db->f('file_size'),
					'file_date'	=> $db->f('date_recieved')
				);
			}
			return $api_ids;
		} else {
			return false;
		}
	}

	static function getImportFileInfo($api_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select j.api_id, description, rel_id, report_suites, overwrite, export, c.company, company_id, c.email, f.hostname
		from saint_api_job j join saint_api_files f on j.api_id = f.api_id
		join saint_api_import_config c on c.api_id = j.api_id
		where j.status_code = 2
		and f.status_code = 2
		and f.file_type = 'upload'
		and j.api_id = %i{api_id}";
		$parms = array('api_id' => $api_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			$db->next_record();
			$api_ids = array();
			$api_ids = array(
				'description' => $db->f('description'),
				'rel_id' => $db->f('rel_id'),
				'report_suites' => $db->f('report_suites'),
				'overwrite' => $db->f('overwrite'),
				'export' => $db->f('export'),
				'company' => $db->f('company'),
				'company_id' => $db->f('company_id'),
				'email' => $db->f('email'),
				'host' => $db->f('hostname'),
                'username' => '',
                'password' => '');

			return $api_ids;
		}
		else
		{
			return false;
		}
	}

	function getImportAPIDetails($api_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select description, rel_id, report_suites, overwrite, export, company, company_id from saint_api_import_config c where c.api_id = %i{api_id}";
		$parms = array('api_id' => $api_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();

		if($db->affected_rows() > 0)
		{
			$api_ids = array();
			$x = 0;
			while($db->next_record())
			{
				$api_details = array(
				'description' => $db->f('description'),
				'rel_id' => $db->f('rel_id'),
				'report_suites' => $db->f('report_suites'),
				'overwrite' => $db->f('overwrite'),
				'export' => $db->f('export'),
				'company' => $db->f('company'),
				'company_id' => $db->f('company_id')
				);
			}
			return $api_details;
		}
		else
		{
			return false;
		}
	}

	function addImportID($job_id, $import_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "update saint_api_job set import_queue_id = %i{import_id} where api_id = %i{job_id}";
		$parms = array(
			'import_queue_id' => $import_id,
			'api_id' => $job_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function addExportID($job_id, $export_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "update saint_api_job set export_queue_id = %i{export_id} where api_id = %i{job_id}";
		$parms = array(
			'export_id' => $export_id,
			'api_id' => $job_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();

		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//File Stuff.

	function addRemoteFile($job_id, $filename, $file_type, &$file, $status_code = 0, $md5sum = 0)
	{
		//should we do the whole write the update thing?
		$file_id = 0;
		//get the md5 sum of the file and compare it to what it should be.
		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_files set api_id = %i{job_id}, filename = %s{filename},
		file_path = '/home/httpd/saint_api_files/uploads/', file_type = %s{file_type},
		status_code = %i{status_code}, hostname = %s{hostname}, md5 = %s{md5sum}, date_recieved = now()"; //status is record only
		
		$parms = array(
			'job_id' => $job_id,
			'filename' => $filename,
			'file_type' => $file_type,
			'status_code' => $status_code,
			'hostname' => $_SERVER['HOSTNAME'],
			'md5sum' => $md5sum
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			$file_id = $db->f('id');

			$file_path = "/home/httpd/saint_api_files/uploads/" . $file_id . "_" . $filename;
			//write file to disk.
			$fh = fopen("$file_path", 'wb');
			fwrite($fh, $file);
			fclose($fh);
		}
		else
		{
			return false;
		}

		$new_md5sum = md5_file($file_path); //should we use this... documention mentions speed increase from doing it through the command line.
		if($md5sum)
		{
			if($new_md5sum == $md5sum)
			{
				$file_size = filesize($file_path);
				$sql = "update saint_api_files set status_code = 1, file_size = %i{file_size} where file_id = %i{file_id}"; //set status to file is present
				$parms = array(
						'file_size' => $file_size,
						'file_id' => $file_id
				);
				$query = new DBQuery($db, $sql, $parms);
				$query->execute();
				
				if($db->affected_rows() > 0)
				{
					return $file_id;
				}
				else
				{
					false;
				}
			}
			else
			{
				return false;
			}
		}

		return true;
	}

	static function addFileRecord($job_id, $local_filename, $local_file_path, $file_type, $host_name, $status_code = 1)
	{
		//Filepath fix for saint_export
		if(strlen($local_file_path) > 0)
		{
			$full_path = $local_file_path . $local_filename;
		}
		else
		{
			$fdetails = explode('/', $local_filename);

			$local_filename = $fdetails[(count($fdetails)-1)];

			$lfile = '/';
			for($x=1; $x < (count($fdetails)-1); $x++)
			{
				$lfile .= $fdetails[$x] . '/';
			}
			$local_file_path = $lfile;
		}

		//get the md5 sum of the file and compare it to what it should be.
		//$new_md5sum = md5_file($full_path); //should we use this... documention mentions speed increase from doing it through the command line.
		$host = get_hostname();

		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_files set api_id = %i{job_id}, filename = %s{local_filename}, file_path = %s{local_file_path}, "
				. " file_type = %s{file_type}, status_code = %i{status_code}, hostname = %s{host}, date_recieved = now()";
		
		$parms = array(
			'job_id' => $job_id, 
			'local_filename' => $local_filename,
			'local_file_path' => $local_file_path,
			'file_type' => $file_type,
			'status_code' => $status_code,
			'host' => $host
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			return $db->f('id');
		}
		else
		{
			return false;
		}
	}

	function updateFileStatus($file_id, $new_status = -1, $new_progress = -1)
	{
		$status_codes = array(
		0 => 'Record Only',
		1 => 'Ready For Import',
		2 => 'Ready For Download',
		3 => 'Downloaded'
		);
		$update_string = '';

		$db = new DB_Sql("masterdb");
		
		if($new_status > -1 && $new_progress == -1)
		{
			$update_string = "status_code = %i{new_status}";
		}
		if($new_progress > -1 && $new_status == -1)
		{
			$update_string = "progress = %i{new_progress}";
		}
		if($new_progress > -1 && $new_status > -1)
		{
			$update_string = "status_code = %i{new_status}, progress = %i{new_progress}";
		}

		$sql = "update saint_api_files set $update_string where file_id = %i{file_id}";
		$parms = array(
			'file_id' => $file_id,
			'new_progress' => $new_progress,
			'new_status' => $new_status
		);
		
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();

		if($db->affected_rows() > 0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	function getFileDetailsArray($file_id)
	{
		//TODO:need ftp server to test. Need to possibly override
		$db = new DB_Sql("masterdb");
		$sql = "select hostname, filename, file_path from saint_api_files where file_id = %i{file_id}";
		$parms = array('file_id' => $file_id);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
		$db->next_record();
		$src_dir = $db->f('file_path');
		$filename = $db->f('file_name');
		$file_path = "/home/httpd/saint_api_files/downloads/";
		$dest_name = $file_id . "_" . $file_name;

		$ftp = new ftp_transfer($src_host, $_SERVER["HOST_NAME"]);
		if ($ftp->start() && $ftp->transfer_file_with_rename($filename, $src_dir, $dest_name, $_SERVER["HOST_NAME"])){
			echo "SUCCESS!\n";
		} else {
			echo "ERROR\n";
		}
		$ftp->close();

		$handle = @fopen($file_path . $dest_name, "rb");
		if ($handle) {
			//read through file and get bytes.
			while (!feof($handle)) {
				$buffer .= fgets($handle, 4096);
			}
			fclose($handle);
			$file_details[] = array('file_name'=>$filename,'file_data'=>base64_encode($buffer));
			$this->updateFileStatus($file_id, 3, 100);
			return $file_details;
		}
	}

	static function addFileErrors($file_id, $error_array)
	{
		$sarrs = serialize($error_array);

		$db = new DB_Sql("masterdb");
		$sql = "insert into saint_api_errors set serialized_error = %s{sarrs}, "
				. " date_recieved = NOW(), file_id = %i{file_id} on duplicate key "
				. "update serialized_error = %s{sarrs}, date_recieved = NOW();";
		$parms = array(
			'sarrs' => $sarrs,
			'file_id' => $file_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		
	}

	static function addJobErrorMessage($api_id, $error)
	{
		$db = new DB_Sql("masterdb");
		$sql = "update saint_api_job set error_message = %s{errorm}, status_code = 4 where api_id = %i{api_id}";
		
		$parms = array(
			'errorm' => $error,
			'api_id' => $api_id
		);
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
	}

	static function getFileErrors($file_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select serialized_error from saint_api_errors where file_id = %i{file_id}";
		$parms = array('file_id' => $file_id);
		
		$query = new DBQuery($db, $sql, $parms);
		$query->execute();
		$db->next_record();
		
		$sarrs = unserialize($db->f('serialized_error'));

		return $sarrs;
	}
}

/*Example $rsid_classifications_array

Array(
[1004] => Array
(
[bugzilla.www14] => 2259728765
[bugzilla.frag] => 2133360624
)

[102] => Array
(
[bugzilla.www14] => 2541805415
[bugzilla.frag] => 1882645352
)
}*/

/*	Example $relations
 Array(
 [1004] => Array
 (
 [0] => Array
 (
 [username] => bugzilla.www14
 [userid] => 2659380
 [site_title] => Bugzilla (www14)
 )

 [1] => Array
 (
 [username] => bugzilla.frag
 [userid] => 2663910
 [site_title] => bugzilla.frag
 )
 )*/
?>
