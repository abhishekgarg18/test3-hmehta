<?
/**
* @file OM_SamAuthnReqGen
* Generates AuthnRequest to POST to the client if the user came to the SP (Omniture) first
*
*
* @author Kole Winters <kwinters@omniture.com>
* @copyright 2006 Omniture, Inc. All Rights Reserved
* @version CVS: $Id$
*/

require_once 'application.inc';
require_once 'GenerateAssertion.class.php';



/**
 * Creates a SAML AuthnRequest
 */
class OM_SamlAuthnReqGen extends GenerateAssertion
{
	/**
	 * The name of the company
	 */
	var $_company           = '';
	
	/**
	 * The username to send in the AuthnRequest
	 */
	var $_username          = '';

	/**
	 * The URL where the IdP needs to POST their assertion. This
	 * URL will change for SC, ClickMap, Excel, etc.
	 */
	var $_sp_url			= '';

	/**
	 *  The product ID of the product
	 */
	var $_pid				= '';
	
	/**
	 * constructor
	 * Sets the company, username and pid
	 *
	 * @param (string) Name of the company
	 * @param (string) The username of who wants to login
	 * @param (string) The PID of the product
	 */
	function OM_SamlAuthnReqGen($company,$username)
	{
		$this->setCompany($company);
		$this->setUsername($username);
		$this->setPid($pid);
	}
	
	/**
	 * Sets the Company name
	 *
	 * @param (string) $company   the company name
	 */
	function setCompany($company)
	{
		$this->_company = $company;
	}

	/**
	 * Sets the username
	 *
	 * @param (string) $username the username of who wants to login
	 */
	function setUsername($username)
	{
		$this->_username = $username;
	}
	
	/**
	 * Sets the product ID
	 *
	 * @param (string) $pid the pid of the product that needs authentication
	 */
	function setPid($pid)
	{
		$this->_pid = $pid;
	}

	/**
	 * Creates the AuthnRequest XML
	 *
	 * @returns (string) a base64 encoded version of the AuthnRequest XML data
	 */
	function generateANR()
	{
		$request = 
'
<samlp:AuthnRequest
  xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol"
  ID="'.$this->createSamlId().'"
  Version="2.0"
  IssueInstant="'.$this->createUTCTimestamp().'"
  ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"
  AssertionConsumerServiceURL="https://sitecatalyst.omniture.com/login.html?'.$_SERVER["QUERY_STRING"].'">
  
  <saml:Issuer xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion">
        http://sitecatalyst.omniture.com
  </saml:Issuer>

  <saml:Subject>
  		'.$this->_username.'
  </saml:Subject>

  <scoping>
  		'.$this->_company.'
  </scoping>
</samlp:AuthnRequest>
';
	$this->toSingleLine($request);
	return base64_encode($request);

	}

}
