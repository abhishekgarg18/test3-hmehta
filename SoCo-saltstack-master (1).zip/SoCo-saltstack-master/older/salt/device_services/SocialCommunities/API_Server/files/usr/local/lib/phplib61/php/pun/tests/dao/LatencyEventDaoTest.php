<?php
require_once("application.inc");
require_once("pun/dao/LatencyEventDao.php");
require_once("pun/model/LatencyEvent.php");
require_once("pun/dao/LatencyEventDefinitionDao.php");

class LatencyEventDaoTest extends PHPUnit_Framework_TestCase
{
	private $eventDao;
	private $eventDefDao;
	
	public function __construct()
	{
		$this->eventDao = new LatencyEventDao();
		$this->eventDefDao = new LatencyEventDefinitionDao();	
	}
	
	public function testSaveLatencyEvent()
	{
		$event = new LatencyEvent();
		$event->setDefId(4);
		$event->setNoticeId(12);
		$event->setEventType(1);
		$event->setLatency(13);
		$event->setUserid(4);
		$event->setusername("sistr2");
		
		$newEvent = $this->eventDao->saveLatencyEvent($event);
		$this->assertNotNull($newEvent);
		$this->assertNotNull($newEvent->getId());
		$this->assertTrue($newEvent->getId() > 0);
		
		$this->eventDao->deleteLatencyEvent($newEvent->getId());
		
	}
	
	public function testGetLatencyEvent()
	{
		$def = new LatencyEventDefinition();
		$def->setLatencyThreshold(54);
		$def->setUserid(4);
		$def->setNoticeDefId(12);
		$def->setUsername("sistr2");
		
		$def = $this->eventDefDao->saveLatencyEventDefinition($def);
		
		$event = new LatencyEvent();
		$event->setDefId($def->getEventDefId());
		$event->setUsername("sistr2");
		$event->setNoticeId(12);
		$event->setUserid(4);
		$event->setLatency(6);
		$event->setEventType(2);
		
		$event = $this->eventDao->saveLatencyEvent($event);
		
		$newEvent = $this->eventDao->getLatencyEvent($event->getId());
		$this->assertNotNull($newEvent);
		$this->assertNotNull($newEvent->getId());
		$this->assertTrue($newEvent->getId() > 0);
		$this->assertEquals($event->getId(),$newEvent->getId());
		
		$this->eventDao->deleteLatencyEvent($newEvent->getId());
		$this->eventDefDao->deleteLatencyEventDefinition($def->getEventDefId());
		
	}
	
	
	
	public function testGetLatencyEvents()
	{
		
	}
}
