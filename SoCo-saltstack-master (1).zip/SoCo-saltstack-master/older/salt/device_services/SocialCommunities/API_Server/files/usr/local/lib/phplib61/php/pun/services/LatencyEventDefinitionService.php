<?php
require_once "pun/dao/LatencyEventDefinitionDao.php";
require_once "pun/model/LatencyEventDefinition.php";

class LatencyEventDefinitionService
{
	private $defDao;
	
	public function __construct()
	{
		$this->defDao = new LatencyEventDefinitionDao();	
	}

	/**
	 * Retrieves a LatencyEventDefinition using the given id
	 *   
	 * @param int $id
	 */
	public function getLatencyEventDefinition($id)
	{
		return $this->defDao->getLatencyEventDefinition($id);	
	}

	/**
	 * Retrieves all LatencyEventdefinitions that meet the criteria given in the selector
	 * 
	 * @param LatencyEventDefinitionSelector $selector
	 */
	public function getLatencyEventDefinitions(LatencyEventDefinitionSelector $selector)
	{
		$selector->setUserid(userid_lookup($selector->getUsername()));
		$selector->setUsername(NULL);			
		return $this->defDao->getLatencyEventDefinitions($selector);		
	}
	
	/**
	 * Saves the given LatencyEventDefinition
	 * 
	 * @param LatencyEventDefinition $def
	 */
	public function saveLatencyEventDefinition(LatencyEventDefinition $def)
	{
		$def->setUserid(userid_lookup($def->getUsername()));
		return $this->defDao->saveLatencyEventDefinition($def);
	}
	
	/**
	 * Saves the given arrayof LatencyEventDefinitions
	 * 
	 * @param array $eventDefs
	 */
	public function saveLatencyEventDefinitions($eventDefs)
	{
		foreach($eventDefs as $eventDef)
		{
			$this->saveLatencyEventDefinition($eventDef);
		}
	}
	
	/**
	 * Deletes a LatencyEventDefinition with the given id
	 * 
	 * @param int $id
	 */
	public function deleteLatencyEventDefiniton($id)
	{
		$this->defDao->deleteLatencyEventDefinition($id);
	}
	
	/**
	* Deletes all event definitions associated with the given notice definition 
	 * @param int $noticeDefId
	 */
	public function deleteAllLatencyEventDefinitions($noticeDefId)
	{
		$this->defDao->deleteAllEventDefinitions($noticeDefId);	
	}
	
}