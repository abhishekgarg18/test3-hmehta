<?
/**
 * @file
 * ResultIterator
 *
 * Copyright 2006 Omniture, Inc.. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt
 *
 * @author Trenton Davies <tdavies@omniture.com>
 * @version CVS: $Id: $
 **/

/**
 * Iterates over a result set returned by DBQuery.
 *
 * The most common usage will be:<br />
 * $query = new DBQuery($dbHandle, $sqlString, $arrayOfParams);<br />
 * $result = $query->execute();<br />
 * $data = $result->toArray(); OR <br />
 * while($result->hasNext()) $data = $result->next();<br />
 *
 * @see DBQuery
 * @ingroup database
 * @author Trenton Davies <tdavies@omniture.com>
 **/
class ResultIterator
{
	/**
	 * (DB_Sql) DB handler
	 *
	 **/
	var $_db;

	/**
	 * (mixed) The current Record stack
	 *
	 **/
	var $_currentRecord = NULL;

	/**
	 * (DBQuery) DBQuery object
	 *
	 **/
	var $_query;

	/**
	 * Constructor
	 *
	 * @param (DBQuery) A Database Query object
	 * @return void
	 **/
	function ResultIterator($query)
	{
		//don't get reference of query -- get copy.
		$db = $query->getDB();
		$this->setDB($db);
		$this->setQuery($query);
	}

	/**
	 * get the Database handle
	 *
	 * @return (DB_Sql) A database handle
	 **/
	function &getDB()
	{
		return $this->_db;
	}

	/**
	 * Sets the DB_Sql object
	 *
	 * @param DB_Sql $db
	 * @return void
	 **/
	function setDB(&$db)
	{
		$this->_db =& $db;
	}

	/**
	 * set the query object
	 *
	 * @param &$query
	 * @return void
	 **/
	function setQuery(&$query)
	{
		$this->_query =& $query;
	}

	/**
	 * get the query
	 *
	 * @return DBQuery
	 **/
	function &getQuery()
	{
		return $this->_query;
	}
	/**
	 * Determines if another record exists and if it
	 * does, pulls it down for availability with the
	 * "next" call of next()
	 *
	 * @return boolean
	 **/
	function hasNext()
	{
		//if there's an error, we don't have a record
		if ($this->hasError()) {
			return FALSE;
		}
		// do we currently have a record
		if (sizeof($this->_currentRecord)) {
			return TRUE;
		}
		//move to the next record, or return false if we don't have one
		if ($this->_db->next_record($this->_query->result_type)) {
			$this->_currentRecord[] =& $this->_db->Record;
			return TRUE;
		} else {
			return FALSE;
		}

	}

	/**
	 * Returns the next array in the result set.
	 *
	 * The value returned is an
	 * associative array of name-value pairs for the current record. Next
	 * must be called to retrieve the first record. If no records exist,
	 * or if the end of the result set has been reached, the method will
	 * return an empty array.
	 *
	 * @return (array) The next row in the result set as an assoc. array
	 **/
	function next()
	{
		if (sizeof($this->_currentRecord)) {
			return array_shift($this->_currentRecord);
		} elseif ($this->hasNext()) {
			return array_shift($this->_currentRecord);
		} else {
			return array();
		}
	}

	/**
	 * Returns the full record set as an array of arrays.
	 *
	 * The inner array has the same structure as the array
	 * returned by next() -- it is an associative array of
	 * name-value pairs at the current index. If no records
	 * exist the method will return an empty array.
	 *
	 * @return (array)
	 **/
	function toArray()
	{
		$recordSet = array();
		while ($record = $this->next()) {
			$recordSet[] = $record;
		}
		return $recordSet;
	}

	/**
	 * Returns an array (not associative) of the values
	 * indicated by the selected field.  This should only
	 * be used if one field was selected with the query.
	 * If no records exist, the method will return an
	 * empty array.
	 *
	 * @return (array)
	 **/
	function toSelectedFieldArray()
	{
		$field_name = $this->_db->field_name(0);
		$selected_field_values = array();
		while ($record = $this->next()) {
			$selected_field_values[] = $record[$field_name];
		}
		return $selected_field_values;
	}

	/**
	 * Displays the rows affected in the result
	 *
	 * @return (int)
	 **/
	function affectedRows()
	{
		return $this->_db->affected_rows();
	}

	/**
	 * Displays the rows matched by the query
	 *
	 * @return (int)
	 **/
	function matchedRows()
	{
		return $this->_db->matched_rows();
	}

	/**
	 * Returns the last insert id of the result
	 *
	 * @return (int)
	 **/
	function insertId()
	{
		return $this->_db->last_insert();
	}

	/**
	 * Returns the number of rows in the result
	 *
	 * @return (int)
	 **/
	function numRows()
	{
		return $this->_db->num_rows();
	}

	/**
	 * Does the query associated with this result
	 * have any errors?
	 *
	 * @return boolean
	 **/
	function hasError()
	{
		return $this->_query->hasError();
	}

} // END class

