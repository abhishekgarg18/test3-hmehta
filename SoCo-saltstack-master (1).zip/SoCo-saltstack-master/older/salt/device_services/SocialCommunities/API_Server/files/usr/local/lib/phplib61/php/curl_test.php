#! /usr/local/bin/php
<?
require_once('curl_proxy.inc');

$ch = curl_init('https://login.rd.dartmail.net/dmconnect45/dmconnect.exe');

$post_data = 'Servername=qacore1dm1&Username=omnituredev&Password=Password1&Version=4.5&XML=<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE DMConnect SYSTEM "dmconnect.dtd"><DMConnect><GetObjectNames><AcknowledgementsTo><EmailAddress>dwebb@omniture.com</EmailAddress><Option>0</Option></AcknowledgementsTo><Depth>MAILINGDETAIL</Depth><ClientName>QA_Omniture_Dev</ClientName><SiteName>QA_Omniture_Dev1</SiteName><CampaignName/><Parameters><Parameter><Name>FromDate</Name><Value>2005-03-23</Value></Parameter><Parameter><Name>EndDate</Name><Value>2005-03-24</Value></Parameter></Parameters></GetObjectNames></DMConnect>
';

curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
print_r($ch);

print_r(curl_exec($ch));

curl_close($ch);
?>
