<?php
require_once "application.inc";
require_once "DwTemplate.class.php";
require_once "rptsched.class";
require_once "DwRequest.class.php";
require_once "reverse_userid_lookup.inc";

class DWHelper{

	private $account = '';
	private $account_id = NULL;
	private $company = '';
	private $company_id = NULL;
	private $contact_info_email_to = '';
	private $contact_info_phone = '';
	private $contact_info_report_desc = '';
	private $contact_name = '';
	private $data_constraints = NULL;
	private $data_set = '';
	private $email_from = NO_REPLY_EMAIL;
	private $email_notes;       // If e-mailing the report, notes to include in the e-mail.
	private $email_subject;     // If e-mailing the report, the subject line of the e-mail.
	private $email_to;          // If e-mailing the report, e-mail address to send to.
	private $file_type = 0;
	private $login = '';
	private $partitioning = '';
	private $report_name = '';
	private $report_type = DW_REQUEST;       // The type of report.  Each type corresponds to a specific DB and table.
	private $send_type =  1;         // indicates which method to send the report. 0 = default account e-mail, 1 = e-mail in rpt_schedule.
	private $product_id = 0;       // Genesis ProductId (if applicable)
	private $integration_id = 0;   // Genesis IntegrationId (if applicable)
	private $template_id = NULL;
	private $Errors = array(); //Holds all errors
	private $send_empty_report = "default";

	private $segment_guid;
	private $beta = 0;

	//Data Constraints
	private $dc_date_type;
	private $dc_date_preset;
	private $dc_date_from;
	private $dc_date_to;
	private $dc_date_granularity;
	private $dc_segment_id;
	private $dc_item_list;
	private $dc_metric_list;

	//Report Schedule Variables.
	private $ftp_dir;           // If FTPing the report, the directory of the host to send the report to.
	private $ftp_host;          // If FTPing the report, the name of the host to send the report to.
	private $ftp_notify_email;  // If FTPing the report, e-mail address to send a notification that the report was sent.
	private $ftp_port;          // If FTPing the report, the port number of the host to send the report to.
	private $ftp_usrname;       // If FTPing the report, the username of the host to send the report to.
	private $ftp_usrpswd;       // If FTPing the report, the password to the username of the host to send the report to.
	private $filename = 'Report.csv';
	private $file_format = 'csv';

	//Included Class Variables
	private $dwr; //DWRequest.class.php
	private $dwt; //DWTemplate.class.php
	private $sch; //rptsched.class.php

	// Misc. Configuration options
	/**
	 * Should we allow breakdowns for lookup strings to succeed?
	 *
	 * The original behaviour of this class is quite broken (?browser is 
	 * translated to browser in the database tables, and there is no way to 
	 * obtain ?browser, for example.
	 *
	 * If this flag is set to true, via enableBreakdownLookups, we will allow
	 * ?browser to be requested via consumers of this class.  Eventually, this 
	 * should become the default behaviour, but since I'm not 100% aware of all 
	 * users of this class, this will have to do for now.
	 */
	private $allow_breakdown_lookups = false;

	function PrepOneTimeRequest()
	{
		$this->sch = new Report_Schedule(); //TODO: Remove this line.
		$this->sch->Set_Report_Type();
		$this->sch->Set_Freq_Once();

		$this->sch->setEmail(); //send_type = 1
		$this->sch->setFTP(); //send_type = 2

		$this->sch->setFileInfo();
	}

	public function ValidateTemplateID($company, $login, $api_template_id)
	{
		$this->dwt = new DwTemplate($api_template_id);
		if($this->dwt->getCompany() == $company && $this->dwt->getLogin() == $login)
		{
			return TRUE;
		}

		return FALSE;
	}

	public function CheckRequestStatusCode($api_template_id)
	{
		$db = new Db_SQL("superstatsdb");
		$sql = "select status from dw_templates where id = $api_template_id";
		$db->squery($sql);
		$template_status = intval($db->f('status'));

		if($template_status == 4)
		{
			return $template_status;
		}
		else
		{
			$sql = "select status from data_warehouse_requests where template_id = $api_template_id";
			$db->squery($sql);
			$request_status = intval($db->f('status'));
			if(!$request_status){ $request_status = 0; }
			return $request_status; 
		}
	}
	
	/** Kept this function around as it's still used in several places */
	public function CheckRequestStatus($api_template_id)
	{
		$status_code = $this->CheckRequestStatusCode($api_template_id);
		return $GLOBALS['DW_STATUS_LOC'][$status_code];
	}

	public function Cancel($api_template_id = 0)
	{
		if($api_template_id > 0)
		{
			$this->dwt->cancel();
			$this->sch = new Report_Schedule($this->dwt->getScheduleId());

			$db = new Db_SQL("superstatsdb");
			$sql = "select id from data_warehouse_requests where template_id = $api_template_id";
			$db->squery($sql);
			$this->dwr = new DwRequest($db->f('id'));
			$this->dwr->cancel();
			return true;
		}
		return false;
	}

	public function isValidPresetDate($preset)
	{
		switch($preset)
		{
			case 'Last month':
				return true;
			case 'Last week':
				return true;
			case 'Last 2 weeks':
				return true;
			case 'Last 4 weeks':
				return true;
			case 'Last 7 days':
				return true;
			case 'Last 30 days':
				return true;
			case 'Last hour':
				return true;
			case 'This month':
				return true;
			case 'This week':
				return true;
			case 'Today':
				return true;
			case 'Yesterday':
				return true;
			default:
				return false;
		}
	}

	public function isValidMetric($metric_array)
	{
		$metric_list = basic_lists_get_metric_list(false, true);
			
		foreach($metric_array as $k => $v)
		{
			$found = false;
			foreach ($metric_list as $metric_num => $metric)
			{
				if($metric['id'] == $v)
				{
					$found = true;
					break;
				}
			}

			if($found){ continue;}
			else{ return false; }
		}
		return true;
	}

	public function isValidBreakdown($breakdown_array, $item_list)
	{
		foreach($breakdown_array as $k => $v)
		{
			$found = false;
			foreach ($item_list as $item_num => $item)
			{
				if ( $item['element_name'] == $v
					|| ($this->allow_breakdown_lookups &&
						strstr($item['element_name'], '?') === 0 &&
						substr($item['element_name'], 1) === $v ) )
				{
					$found = true;
					break;
				}
			}
			if($found){ continue;}
			else{ return false; }
		}
		return true;
	}
	
	//this is some silly code to temporarily work around a potential bug in the API string_array or because I don't know what I'm doing... either way...
	function PrepAPIArray($api_array)
	{
		$array = array();
		$return_array = array();

		if(is_array($api_array))
		{
			foreach($api_array as $k => $subArray)
			{
				if(is_array($subArray))
				{
					foreach($subArray as $subK => $v)
					{
						$array[$v] = 0; //cheat to remove dupes.
					}
				}
				else
				{
					$array[$subArray] = 0; //cheat to remove dupes.
				}
			}

			$count = 0;
			foreach($array as $k => $v)
			{
				$return_array[$count] = $k;
				$count++;
			}
			return $return_array;
		}
	}

	public function isValidGranularity($Granularity)
	{
		switch($Granularity)
		{
			case DW_GRANULARITY_NONE:
				return true;
				break;
			case DW_GRANULARITY_DAY:
				return true;
				break;
			case DW_GRANULARITY_WEEK:
				return true;
				break;
			case DW_GRANULARITY_MONTH:
				return true;
				break;
			case DW_GRANULARITY_QUARTER:
				return true;
				break;
			case DW_GRANULARITY_YEAR:
				return true;
				break;
			case DW_GRANULARITY_HOUR:
				return true;
				break;
			default:
				return false;
		}
	}

	public function isValidDateType($date_type)
	{
		switch($date_type)
		{
			case 'range':
				return true;
				break;
			case 'preset':
				return true;
				break;
			default:
				return false;
				break;
		}
		return true;
	}

	//ToDo flag for API Requests...
	public function Submit($DefineRequestedBy)
	{
		if($DefineRequestedBy)
		{
			$this->dwt = new DwTemplate();
			$this->sch = new Report_Schedule();
				
			//set defaults;
			if(!$this->report_name)
			{
				$this->report_name = get_text('Data Warehouse Request');
			}
			if(!$this->report_name)
			{
				$this->report_name = get_text('report.csv');
			}
			$this->email_to = $this->contact_info_email_to;
			$this->account_id = userid_lookup($this->account);

			if($this->sch)
			{
				//Set Report Schedule
				$this->sch->Create_Schedule(DW_REQUEST, $this->account, $this->company_id);
				$this->sch->file_format = $this->file_format;
				$this->sch->filename = $this->filename;
				$this->sch->send_type = 1;
				$this->sch->Set_Report_Type($this->report_type);
				$this->sch->Set_Freq_Once();
				$this->sch->setEmail($this->email_to, $this->email_subject, $this->email_from, $this->email_notes);
				$this->sch->setIntegration($this->product_id, $this->integration_id);

				if($this->ftp_host)
				{
					$this->sch->setFTP($this->ftp_host, $this->ftp_port, $this->ftp_dir, $this->ftp_usrname, $this->ftp_usrpswd);
					$this->sch->send_type = 2;
				}

				$this->sch->UpdateDB();
			}
				
			//Set DW Template Values
			$this->dwt->setScheduleId($this->sch->id);
			$this->dwt->setAccount($this->account);
			$this->dwt->setAccountId($this->account_id); //optional
			$this->dwt->setCompany($this->company);
			$this->dwt->setReportName($this->report_name);
			$this->dwt->setContactName($this->contact_name);
			$this->dwt->setContactInformationField("email_to", $this->contact_info_email_to);
			$this->dwt->setContactInformationField("phone", $this->contact_info_phone);
			$this->dwt->setContactInformationField("report_desc", $this->contact_info_report_desc);
			$this->dwt->setLogin($this->login);
			$this->dwt->setFileTypeCode($this->file_type); //optional
			$this->dwt->setPartitioning($this->partitioning); //optional
			$this->dwt->setDataSet($this->data_set); //optional

			$this->dwt->setSegmentGUID($this->segment_guid);
			$this->dwt->setBeta($this->beta);

			//Data Constraints.
			$this->dwt->setDataConstraint('date_type', $this->dc_date_type);
			if($this->dc_date_type == 'preset')
			{
				$this->dwt->setDataConstraint('date_preset', $this->dc_date_preset);
			}
			else
			{
				$this->dwt->setDataConstraint('date_preset', 'none');
				$this->dwt->setDataConstraint('date_from', $this->dc_date_from); //optional if preset
				$this->dwt->setDataConstraint('date_to', $this->dc_date_to); //optional if preset
			}

			$this->dwt->setDataConstraint('date_granularity', $this->dc_date_granularity);
			$this->dwt->setDataConstraint('segment_id', $this->dc_segment_id);


			$this->dwt->setRequestedBy($DefineRequestedBy);
			$this->dwt->setSendEmptyReports($this->send_empty_report);


			if(is_array($this->dc_item_list))
			{
				$order = 1;
				foreach($this->dc_item_list as $k => $v)
				{
					$this->dwt->addToItemList($order,  $v, $this->allow_breakdown_lookups);
					$order++;
				}
			}

			if(is_array($this->dc_metric_list))
			{
				$order = 1;
				foreach($this->dc_metric_list as $k => $v)
				{
					$this->dwt->addToMetricList($order,  $v);
					$order++;
				}
			}


			if(count($this->Errors) <= 0) //check if we have any local errors in DWHelper and submit.
			{
				$this->template_id = $this->dwt->commit(); //submits dw_template
				if($this->template_id > 0)
				{
					return "SUCCESS: DW Request " . $this->template_id . " was succefully submitted.";
				}
				else
				{
					$this->Errors[] = $this->dwt->getLastError();
				}
			}
		}
		else
		{
			$this->Errors[] = 'INTERNAL ERROR: Must specify Requested_By value.';
		}

		if(count($this->Errors > 0))
		{
			$this->ReturnErrorString();
		}
	}

	/**
	 * Returns a formatted error string
	 *
	 * @return string
	 */
	private function ReturnErrorString()
	{
		$message = '';
		$errorCount = count($this->Errors);

		for($x = 0; $x < $errorCount; $x++)
		{
			$message .= $this->Errors[$x];
			if($x+1 < $errorCount)
			{
				$message .= '\n';
			}
		}
		return $message;
	}
	
	public function setCompanyId($value){$this->company_id = $value;}

	public function getReportType(){return $this->report_type;}									public function setReportType($value){$this->report_type = $value;}
	public function getTemplate_ID(){return $this->template_id;}								public function setTemplate_ID($new){$this->template_id = $new;}
	public function getAccount(){return $this->account;}										public function setAccount($newAccount){$this->account = $newAccount;}
	public function getAccountID(){return $this->account_id;} 									public function setAccountID($newAccountID){$this->account_id = $newAccountID;}
	public function getCompany(){return $this->company;} 										public function setCompany($newCompany){$this->company = $newCompany;}
	public function getReportName(){return $this->report_name;} 								public function setReportName($newReportName){$this->report_name = $newReportName;}
	public function getContactName(){return $this->contact_name;} 								public function setContactName($newContactName){$this->contact_name = $newContactName;}
	public function getContactInfo_EmailTo(){return $this->contact_info_email_to;} 				public function setContactInfo_EmailTo($newContactInfoEmailTo){$this->contact_info_email_to = $newContactInfoEmailTo;}
	public function getContactInfo_Phone(){return $this->contact_info_phone;} 					public function setContactInfo_Phone($newContactInfoPhone){$this->contact_info_phone = $newContactInfoPhone;}
	public function getContactInfo_ReportDescription(){return $this->contact_info_report_desc;} public function setContactInfo_ReportDescription($newContactInfoReportDescription){$this->contact_info_report_desc = $newContactInfoReportDescription;}
	public function getLogin(){return $this->login;} 											public function setLogin($newLogin){$this->login = $newLogin;}
	public function getFileTypeCode(){return $this->file_type;} 								public function setFileTypeCode($newFileTypeCode){$this->file_type = $newFileTypeCode;}
	public function getPartitioning(){return $this->partitioning;} 								public function setPartitioning($newPartitioning){$this->partitioning = $newPartitioning;}
	public function getDataSet(){return $this->data_set;} 										public function setDataSet($newDataSet){$this->data_seta = $newDataSet;}
	public function getFilename(){return $this->filename;}										public function setFilename($new){$this->filename = $new;}
	public function getSendEmptyReports() {return $this->send_empty_report;}	public function setSendEmptyReports($newSendEmptyReports) {$this->send_empty_report = $newSendEmptyReports;}
	public function getFileFormat(){return $this->file_format;}									public function setFileFormat($fileFormat){$this->file_format = $fileFormat;}
	public function getSegmentGUID(){return $this->segment_guid;}								public function setSegmentGUID($guid){$this->segment_guid = $guid;}
	public function getBeta() { return $this->beta; }											public function setBeta($key) {$this->beta = $key;}
	
	//Date Constraints.
	public function getConstraint_DateType(){return $this->dc_date_type;}						public function setConstraint_DateType($newDateType){$this->dc_date_type = $newDateType;}
	public function getConstraint_DatePreset(){return $this->dc_date_preset;}					public function setConstraint_DatePreset($newDatePreset){$this->dc_date_preset = $newDatePreset;}
	public function getConstraint_DateFrom(){return $this->dc_date_from;}						public function setConstraint_DateFrom($newDateFrom){$this->dc_date_from = $newDateFrom;}
	public function getConstraint_DateTo(){return $this->dc_date_to;}							public function setConstraint_DateTo($newDateTo){$this->dc_date_to = $newDateTo;}
	public function getConstraint_DateGranularity(){return $this->dc_date_granularity;}			public function setConstraint_DateGranularity($newDateGranularity){$this->dc_date_granularity = $newDateGranularity;}
	public function getConstraint_SegmentId(){return $this->dc_segment_id;}						public function setConstraint_SegmentId($newSegmentId){$this->dc_segment_id = $newSegmentId;}
	public function getConstraint_ItemList(){return $this->dc_item_list;}						public function setConstraint_ItemList($newItemList){$this->dc_item_list = $newItemList;}
	public function getConstraint_MetricList(){return $this->dc_metric_list;}					public function setConstraint_MetricList($newMetricList){$this->dc_metric_list = $newMetricList;}

	//schedule
	public function getFtp_Host(){return $this->ftp_host;} 										public function setFtp_Host($new){$this->ftp_host = $new;}
	public function getFtp_Port(){return $this->ftp_port;} 										public function setFtp_Port($new){$this->ftp_port = $new;}
	public function getFtp_Dir(){return $this->ftp_dir;} 										public function setFtp_Dir($new){$this->ftp_dir = $new;}
	public function getFtp_Usrname(){return $this->ftp_usrname;} 								public function setFtp_Usrname($new){$this->ftp_usrname = $new;}
	public function getFtp_Usrpswd(){return $this->ftp_usrpswd;} 								public function setFtp_Usrpswd($new){$this->ftp_usrpswd = $new;}
	public function getEmail_To(){return $this->email_to;} 										public function setEmail_To($new){$this->email_to = $new;}
	public function getEmail_From(){return $this->email_from;} 									public function setEmail_From($new){$this->email_from = $new;}
	public function getEmail_Subject(){return $this->email_subject;} 							public function setEmail_Subject($new){$this->email_subject = $new;}
	public function getSendType(){return $this->send_type;} 									public function setSendType($new){$this->send_type = $new;}
	public function getProductId() { return $this->product_id; }                          public function setProductId($id) { $this->product_id = $id; }
	public function getIntegrationId() { return $this->integration_id; }                  public function setIntegrationId($id) { $this->integration_id = $id; }

	public function enableBreakdownLookups() {
		$this->allow_breakdown_lookups = true;
	}
	public function disableBreakdownLookups() {
		$this->allow_breakdown_lookups = false;
	}
	public function areBreakdownLookupsAllowed() {
		return $this->allow_breakdown_lookups;
	}
}
