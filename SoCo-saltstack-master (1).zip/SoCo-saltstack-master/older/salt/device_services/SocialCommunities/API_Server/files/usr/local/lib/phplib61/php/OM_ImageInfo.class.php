<?php

require_once('local.inc');

class OM_ImageInfo
{

	private static $addedLocations = array();
	
	private static $extensions = array('gif','jpg','png','bmp','tiff');
	
	private $_info = array();
	
	private static $_keys = array(
									'directory',
									'path',
									'file_name',
									'file_type',
									'file_size',
									'basename',
									'src',
									'width',
									'height'
									);
	
	public static function addLocation($dir, $url, $localized = FALSE)
	{
		$location = array();
		$location['dir'] = $dir;
		$location['url'] = $url;
		$location['localized'] = $localized;

		array_unshift(self::$addedLocations, $location);
	}

	public static function getAddedLocations()
	{
		return self::$addedLocations;
	}

	public static function clearAddedLocations()
	{
		self::$addedLocations = array();
	}

	public static function getObject($filename, $locale = NULL)
	{
		// default and validate the locale
		if(OM_L10N_ENABLED === TRUE){
			$locale = ($locale == NULL ? OM_L10n_Locale::getDefaultLocale() : $locale);
			if(!OM_L10n_Locale::isValidLocale($locale)){
				$locale = OM_L10n_Locale::getRootLocale();
			}
		} else {
			$locale = ($locale == NULL ? $GLOBALS['locale'] : $locale);
		}
		
		// image directories are set up according to old system that uses 'jp_JP' instead of 'ja_JP'
		$locale = ($locale == 'ja_JP' ? 'jp_JP' : $locale);

		$locations = array();
		// add any locations added dynamically
		if(!empty(self::$addedLocations)){
			foreach(self::$addedLocations as $location){
				if($location['localized'] != FALSE){
					$localized1 = array(
						'dir' => $location['dir'] . '/l10n/' . $locale,
						'url' => $location['url'] . '/l10n/' . $locale
						);
					$locations[] = $localized1;
					$localized2 = array(
						'dir' => $location['dir'] . '/' . $locale,
						'url' => $location['url'] . '/' . $locale
						);
					$locations[] = $localized2;
				}
				$nonLocalized = array(
					'dir' => $location['dir'],
					'url' => $location['url']
					);
				$locations[] = $nonLocalized;
			}
		}

		// add these default locations to all searches
		$staticLocalized = array(
			'dir' => STATIC_DIR . '/images/l10n/' . $locale,
			'url' => STATIC_URL . '/images/l10n/' . $locale
			);
		$locations[] = $staticLocalized;

		$staticNonLocalized = array(
			'dir' => STATIC_DIR . '/images',
			'url' => STATIC_URL . '/images'
			);
		$locations[] = $staticNonLocalized;

		$staticSuiteHeader = array(
			'dir' => STATIC_DIR . '/images/suite_header',
			'url' => STATIC_URL . '/images/suite_header'
			);
		$locations[] = $staticSuiteHeader;

		$numLocations = count($locations);
		$numExtensions = count(self::$extensions);

		$imageFound = FALSE;
		for($i = 0; $i < $numLocations; $i++){
			if($imageFound) break;
			$location = $locations[$i];

			for($j = 0; $j < $numExtensions; $j++){
				$extension = self::$extensions[$j];

				$path = $location['dir'] . '/' . $filename . '.' . $extension;

				if(file_exists($path)){
					$imageFound = TRUE;
					$img = new self();
					$img->path = $path;
					$img->directory = $location['dir'];
					$img->file_name = $filename;
					$img->file_size = filesize($img->path);
					$img->file_type = $extension;
					$img->basename = basename($img->path);
					$img->src = $location['url'] . '/' . $filename . '.' . $extension;
					$dimensions = @getimagesize($img->path);
					$img->width = $dimensions[0];
					$img->height = $dimensions[1];
					break;
				}
			}
		}

		if(!$imageFound){
			$img = new self();
			$img->path = STATIC_DIR . '/images/dot.gif';
			$img->directory = STATIC_DIR . '/images';
			$img->file_name = 'dot';
			$img->file_size = filesize($img->path);
			$img->file_type = 'gif';
			$img->basename = basename($img->path);
			$img->src = STATIC_URL . '/images/dot.gif';
			$dimensions = @getimagesize($img->path);
			$img->width = $dimensions[0];
			$img->height = $dimensions[1];
		}

		if($GLOBALS['HTTPS']){
			$img->src = str_replace('http://', 'https://', $img->src);
		}

		return $img;
	}

	public static function getArray($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->toArray();
	}

	public static function getPath($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->path;
	}

	public static function getUrl($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->src;
	}

	public static function getDimensions($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		$dimensions = array(
			'width' => $img->width,
			'height' => $img->height,
			);
		return $dimensions;
	}
	
	public static function getHeight($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->height;
	}
	
	public static function getWidth($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->width;
	}

	
	public static function getFileName($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->file_name;
	}

	public static function getFileSize($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->file_size;
	}
	
	public static function getFileType($filename, $locale = NULL)
	{
		$img = self::getObject($filename, $locale);
		return $img->file_type;
	}
	
	public static function getDirectory($filename, $locale = NULL){
		$img = self::getObject($filename, $locale);
		return $img->directory;
	}

	public static function getBasename($filename, $locale = NULL){
		$img = self::getObject($filename, $locale);
		return $img->basename;
	}

	
	public function __get($key)
	{
		if(array_key_exists($key, $this->_info)){
			return $this->_info[$key];
		} else {
			return NULL;
		}
	}
	
	public function __set($key, $value)
	{
		if(in_array($key, self::$_keys)){
			$this->_info[$key] = $value;
			return TRUE;
		} else {
			throw new Exception('Invalid image property.');
			return FALSE;
		}
	}
	
	public function toArray()
	{
		$output = array(
			'path' => $this->_info['path'],
			'directory' => $this->_info['directory'],
			'file_name' => $this->_info['file_name'],
			'file_size' => $this->_info['file_size'],
			'file_type' => $this->_info['file_type'],
			'basename' => $this->_info['basename'],
			'attributes' => array(
				'src' => $this->_info['src'],
				'width' => $this->_info['width'],
				'height' => $this->_info['height']
				)
			);
		return $output;
	}
	

}