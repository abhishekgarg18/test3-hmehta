<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_ReportSuiteService extends OM_AppServiceBase {

	const REPORTSUITES_PATH = "/reportsuites/";

	private static $_instance = null;
	private static $_reportsuite_lists_by_companyid = array();

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_ReportSuiteService();
		}
		return self::$_instance;
	}

	public function resetCache($companyid, $loginid) {
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$path = "/collections/suites/cacheReset";
		$response = $this->makeAnalyticsEndpointRequest($path, $token, self::GET_REQUEST, "", true, "","", $companyid,$loginid);
		return json_decode($response->getResponse(), true);
	}

	public static function getAllCompanyReportSuites($companyid, $include_num_groups=false, $search="", $get_blocked=false){
		$resp_array = array();
		if(!$companyid || !($companyid > 0)){
			return $resp_array;
		}

		// Check cache
		if(!$include_num_groups && !$search && !$get_blocked && is_array(self::$_reportsuite_lists_by_companyid[$companyid])){
			return self::$_reportsuite_lists_by_companyid[$companyid];
		}

		$path = self::REPORTSUITES_PATH . "?companyIds=".$companyid."&limit=0";

		// Expansions
		$path .= "&expansion=reportSuiteName";
		if($include_num_groups){
			$path .= ",numGroups";
		}

		if($get_blocked){
			$path .= "&includeType=blocked";
		}

		if($search){
			$path .= "&rsidContains=". $search;
		}

		$response = self::makeReportSuitesPlatformRequest($path);
		if(is_array($response) && is_array($response['content'])){
			$resp_array = $response['content'];
		}

		if(!$include_num_groups && !$search && !$get_blocked){
			self::$_reportsuite_lists_by_companyid[$companyid] = $resp_array;
		}

		return $resp_array;
	}

	private function makeReportSuitesPlatformRequest($path,$http_method=self::GET_REQUEST,$body=""){
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$rs_instance = self::getInstance();
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$response = $rs_instance->makePlatformEndpointRequest($path, $token, $http_method, $body);
		if ($response->hasErrors()) {
			throw new Exception("ReportSuiteService Error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}
}
