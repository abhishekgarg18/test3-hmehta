<?php
class LatencyEventDefinition
{
	private $eventDefId;
	private $noticeDefId;
	private $userid;
	private $username;
	private $latencyThreshold;
	
	public function __construct()
	{
		
	}
	
	public function getEventDefId() 
	{
		return $this->eventDefId;
	}

	public function setEventDefId($eventDefId) 
	{
		$this->eventDefId = $eventDefId;
	}
	
	public function getNoticeDefId() 
	{
		return $this->noticeDefId;
	}

	public function setNoticeDefId($noticeDefId) 
	{
		$this->noticeDefId = $noticeDefId;
	}

	public function getUserid() 
	{
		return $this->userid;
	}

	public function setUserid($userid) 
	{
		$this->userid = $userid;
	}

	public function getUsername() 
	{
		return $this->username;
	}

	public function setUsername($username) 
	{
		$this->username = $username;
	}

	public function getLatencyThreshold() 
	{
		return $this->latencyThreshold;
	}

	public function setLatencyThreshold($latency) 
	{
		$this->latencyThreshold = $latency;
	}

}