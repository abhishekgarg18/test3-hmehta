<?php
require_once("application.inc");
require_once("pun/dao/LatencyNoticeDao.php");
require_once("pun/dao/LatencyEventDao.php");
require_once("pun/dao/LatencyNoticeDefinitionDao.php");
require_once("pun/model/LatencyNotice.php");
require_once("pun/model/LatencyNoticeDefinition.php");
require_once("pun/model/LatencyNoticeSelector.php");
require_once("pun/tests/dao/LatencyNoticeDefinitionDaoTest.php");

class LatencyNoticeDaoTest extends PHPUnit_Framework_TestCase
{
	
	private $latencyNoticeDao;
	private $latencyNoticeDefinitionDao;
	
	public function __construct()
	{
		$this->latencyNoticeDao = new LatencyNoticeDao();
		$this->latencyNoticeDefinitionDao = new LatencyNoticeDefinitionDao();	
	}
	
	public function testSaveLatencyNotice()
	{
		$def = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("111",111);
		$def = $this->latencyNoticeDefinitionDao->saveLatencyNoticeDefinition($def);
		
		$latencyNotice = $this->createLatencyNotice($def->getID());
		$latencyNotice = $this->latencyNoticeDao->saveLatencyNotice($latencyNotice);
		
		$this->assertNotNull($latencyNotice);
		$this->assertNotNull($latencyNotice->getID());
		$this->assertTrue($latencyNotice->getID() > 0);
		
		$this->latencyNoticeDao->deleteLatencyNotice($latencyNotice->getID());
		$this->latencyNoticeDefinitionDao->deleteLatencyNoticeDefinition($def->getID());
	}
	
	public function testGetLatencyNotices()
	{
		$def = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("111",111);
		$def = $this->latencyNoticeDefinitionDao->saveLatencyNoticeDefinition($def);
		$def1 = LatencyNoticeDefinitionDaoTest::createLatencyDefinition("222",222);
		$def1 = $this->latencyNoticeDefinitionDao->saveLatencyNoticeDefinition($def);
		
		$latencyNotice = $this->createLatencyNotice($def->getID());
		$latencyNotice = $this->latencyNoticeDao->saveLatencyNotice($latencyNotice);
		
		$latencyNotice1 = $this->createLatencyNotice($def1->getID());
		$latencyNotice1 = $this->latencyNoticeDao->saveLatencyNotice($latencyNotice1);
		
		$selector = new LatencyNoticeSelector();
		$selector->setLatencyNoticeDefinitionId($def->getID());
		$notices = $this->latencyNoticeDao->getLatencyNotices($selector);
		$this->assertNotNull($notices);
		$this->assertType('array', $notices);
		$this->assertTrue((count($notices) == 2), 'returning wrong number of notices: ' . count($notices));
		
		$this->latencyNoticeDao->deleteLatencyNotice($latencyNotice->getID());
		$this->latencyNoticeDao->deleteLatencyNotice($latencyNotice1->getID());
		$this->latencyNoticeDefinitionDao->deleteLatencyNoticeDefinition($def->getID());
		$this->latencyNoticeDefinitionDao->deleteLatencyNoticeDefinition($def1->getID());
	}
	
	public function testGetLastLatencyNotice()
	{
	}
	
	public function testGetLastLatencyStartNotice()
	{
	}
	
	public static function createLatencyNotice($defId)
	{
		$latencyNotice = new LatencyNotice();
		$latencyNotice->setDefId($defId);
		$latencyNotice->setEmailVersion(1);
		$latencyNotice->setTo("testTo@email.com");
		$latencyNotice->setCc("testCc@email.com");
		$latencyNotice->setBcc("testBcc@email.com");

		return $latencyNotice;
	}
}
