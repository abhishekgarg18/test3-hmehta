<?
/**
 * @file 
 * XMLHandler
 *
 * Copyright 2006 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Kole Winters <kwinters@omniture.com>
 * @version
 **/

	/**
	* A class designed to parse any XML document and return an associate array
	* 
	* @author Kole Winters <kwinters@omniture.com>
	* @copyright 2006 Omniture, Inc. All Rights Reserved
	* @version CVS:
	*
	*/

	require_once 'application.inc';
	require_once 'minixml.inc.php';
	
	
	/**
	* Class that parses a XML file
	*
	* @ingroup Admin
	* @author Kole Winters
	*/
	class XMLHandler
	{
	
		
		var $minixml; //the MiniXMLDoc class

		function XMLHandler()
		{
			$this->minixml = new MiniXMLDoc();
			// currently no functionality
		}
		
		/**
		 * Canonicalizes the XML data based on the $type passed in
		 * @param string $type is the type of canonicalization desired
		 *
		 * @return string The canonicalized string on success and '' on failure
		 * @public
		 */	
		function canonicalize($type,$xml_data){
			$rtn = '';
			if ($type == "exclusive"){
				$rtn = $this->_canon_Excl_C14N($xml_data);
			}
			return $rtn;
		
		}

		/**
		 * Canonicalizes the XML data according to the W3C spec Excl-C14N (Exclusive Canonicalization)
		 * located here: http://www.w3.org/TR/xml-exc-c14n/
		 *
		 * @param string $xml_data is the XML to be canonicalized
		 *
		 * @return string The canonicalized string on success and '' on failure
		 * @public
		 */	
		function _canon_Excl_C14N($xml_data){
			$rtn = '';
			return $rtn;
		}

		/**
		 * Removes a tag and its children from an XML document
		 *
		 * @param string $xml_data
		 * @param string $tag_name  This is the tag that needs to be removed.  If it has a namespace
		 *                          prefix then send in "prefix:tagName"
		 *
		 * @return string The $xml_data minux the deleted tag and children and data 
		 */
		function removeTag($xml_data,$tag_name){
			// first remove any tags that are self contained <$tag_name />
			$pattern = '/<'.$tag_name.' [^\/>]*>/ims';
			$xml_data = preg_replace($pattern,'',$xml_data);

			// second remove any tags that have an opening and closing tag <$tag_name>...</$tag_name>
			$pattern = '/<'.$tag_name.'\s[^>]*>.*<\/'.$tag_name.'>/ims';
			return preg_replace($pattern,'',$xml_data);
		}

		/**
	 	* Overrides the minixml's getElement.  Provides error handling in case the
		* element wasn't there.  Returns the value of the element
	 	*
		* @param string the element wanted
		* @return object the element node
	 	*/
		function getElementValue($element_name) {
			if (!$element_name) return '';

			$elementValue = '';
			$elementNode = $this->minixml->getElement($element_name);
			if ($elementNode) {
				$elementValue = $elementNode->getValue();
			}
			return $elementValue;
	
		}

		/**
		 * Get an Element's attribute value
		 *
		 * @param string $element_name - the name of the node
		 * @param string $attribute_name - the name of the attribute
		 * @return string the value of the requested attribute
		 */
		function getElementAttributeValue($element_name,$attribute_name){
			if (!$element_name || !$attribute_name) return '';

			$elementNode = $this->minixml->getElement($element_name);
			if ($elementNode) {
				return $elementNode->xattributes[$attribute_name];
			}
			return '';

		}
	}
