<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2016 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_Appservice_RankedReports extends OM_AppServiceBase{

	const REPORTS_RANKED_PATH = "/reports/ranked";

	public function runRankedReport($rankedReport, $companyid, $loginid, $token=null){
		$path = self::REPORTS_RANKED_PATH;
		return self::makeRankedReportRequest($path, json_decode($rankedReport), $companyid, $loginid, $token);
	}

	private function makeRankedReportRequest($path, $rankedJson, $companyid, $loginid, $token=null){

		if (!isset($token)) {
			$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
			$token = $token_generator->getIMSServiceToken();
		}

		return $this->makeAnalyticsEndpointRequest($path, $token, self::POST_REQUEST,$rankedJson,true,"","",$companyid,$loginid);
	}
}
