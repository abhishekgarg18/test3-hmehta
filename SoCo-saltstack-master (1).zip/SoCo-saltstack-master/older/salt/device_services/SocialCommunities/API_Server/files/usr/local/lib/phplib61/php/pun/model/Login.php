<?php

class Login
{
	private $loginId;
	private $loginName;
	private $firstName;
	private $lastName;
	private $email;
	private $subscribed;

	public function getLoginId() 
	{
		return $this->loginId;
	}

	public function getLoginName()
	{
		return $this->loginName;
	}

	public function getFirstName() 
	{
		return $this->firstName;
	}

	public function getLastName() 
	{
		return $this->lastName;
	}

	public function getEmail() 
	{
		return $this->email;
	}

	public function setLoginId($loginId) 
	{
		$this->loginId = $loginId;
	}
	
	public function setLoginName($loginName) 
	{
		$this->loginName = $loginName;
	}

	public function setFirstName($firstName) 
	{
		$this->firstName = $firstName;
	}

	public function setLastName($lastName) 
	{
		$this->lastName = $lastName;
	}

	public function setEmail($email) 
	{
		$this->email = $email;
	}
	
	public function getSubscribed() 
	{
		return $this->subscribed;
	}

	public function setSubscribed($subscribed) 
	{
		$this->subscribed = $subscribed;
	}

}
	
