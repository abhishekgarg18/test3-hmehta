<?

/*************************************************************************
 * ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright [2014] Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property laws,
* including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * MySqlUtils provides some utility functions around mysql extension.
 *
 **/
class MySqlUtils
{
	/**
	 * This function parses the return value of mysql_info function and
	 * returns an array containing the values of various fields returned by the 
	 * function.
	 * In some cases mysql_info function returns FALSE and in that case this
	 * function returns an empty array.
	 * 
	 * @param $strInfo - Return value of mysql_info function
	 */
	public static function parseMySqlInfo($strInfo) {
		
		$returnVal = array();
		
		if ($strInfo === FALSE)
			return $returnVal;
		
		preg_match ("/Records: ([0-9]*)/", $strInfo, $records);
		preg_match ("/Duplicates: ([0-9]*)/", $strInfo, $dupes);
		preg_match ("/Warnings: ([0-9]*)/", $strInfo, $warnings);
		preg_match ("/Deleted: ([0-9]*)/", $strInfo, $deleted);
		preg_match ("/Skipped: ([0-9]*)/", $strInfo, $skipped);
		preg_match ("/Rows matched: ([0-9]*)/", $strInfo, $rows_matched);
		preg_match ("/Changed: ([0-9]*)/", $strInfo, $changed);
		
		$returnVal['total_records'] = $records[1];
		$returnVal['rows_duplicates'] = $dupes[1];
		$returnVal['warnings'] = $warnings[1];
		$returnVal['rows_deleted'] = $deleted[1];
		$returnVal['rows_skipped'] = $skipped[1];
		$returnVal['rows_matched'] = $rows_matched[1];
		$returnVal['rows_changed'] = $changed[1];
		
		return $returnVal;
	}
}