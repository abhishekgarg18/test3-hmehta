<?php
require_once "pun/dao/LatencyEventDao.php";
require_once "pun/model/LatencyEventSelector.php";
require_once("log4php/Logger.php");
require_once("reverse_userid_lookup.inc");
L4P_Logger::configure('pun/LogConfig.xml');

class LatencyEventService
{
	private $latencyEventDao;
	private $log;
	
	public function __construct()
	{
		$this->latencyEventDao = new LatencyEventDao();	
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * Retrieves the LatencyEvent with the given id
	 * 
	 * @param int $id
	 */
	public function getLatencyEvent($id)
	{
		// To avoid joins and missing event defs (from deleting) set the username manually
		$event = $this->latencyEventDao->getLatencyEvent($id);
		if(!is_null($event))
		{
			$event->setUsername(reverse_userid_lookup($event->getUserid()));
		}
		return $event;
	}
	
	/**
	 * Retrieves all LatencyEvents that meet the criteria in the given selector
	 *  
	 * @param LatencyEventSelector $selector
	 */
	public function getLatencyEvents(LatencyEventSelector $selector)
	{
		// replace username with userid so queries can be more efficient by using indexes
		$username = $selector->getUsername();
		if(!is_null($username) && strlen($username) > 0)
		{
			$userid = userid_lookup($username);
			if(!is_null($userid) && $userid > 0)
			{
				$selector->setUserid($userid);
				$this->log->debug("suite $username converted to id $userid to better use table indexes.");
			}
		}
		// To avoid joins and missing event defs (from deleting) set the username manually
		$events = $this->latencyEventDao->getLatencyEvents($selector);
		foreach($events as $event)
		{
			$event->setUsername(reverse_userid_lookup($event->getUserid()));
		}
		return $events;
	}
	
	public function getLatencyEventsByNoticeId($noticeId)
	{
		$events = $this->latencyEventDao->getLatencyEventsByNoticeId($noticeId);
		foreach($events as $event)
		{
			$event->setUsername(reverse_userid_lookup($event->getUserid()));
		}
		return $events;
	}
	
	/**
	 * Saves the given LatencyEvent
	 * 
	 * @param LatencyEvent $event
	 */
	public function saveLatencyEvent(LatencyEvent $event)
	{
		return $this->latencyEventDao->saveLatencyEvent($event);	
	}
	
	/**
	 * Deletes the LatencyEvent with the given id
	 * 
	 * @param int $id
	 */
	public function deleteLatencyEvent($id)
	{
		$this->latencyEventDao->deleteLatencyEvent($id);
	}
	
	/**
	 * Deletes all latency events associated with the given notice id
	 * 
	 * @param int $noticeId
	 */
	public function deleteLatencyEvents($noticeId)
	{
		$this->latencyEventDao->deleteLatencyevents($noticeId);
	}
	
	/**
	 * Reteieves the most recent start of latency event for the given username
	 * 
	 * @param string $username
	 */
	public function getMostRecentStartLatencyEvent($username)
	{
		return $this->getMostRecentLatencyEvent($username,1); // type 1 is newly latent event type
				
	}
	
	/**
	 * Retrieves the most recent end latency event for the given user.
	 * Enter description here ...
	 * @param unknown_type $username
	 */
	public function getMostRecentEndLatencyEvent($username)
	{
		return $this->getMostRecentLatencyEvent($username,3); // type 3 is end of latency event type		
	}
	
	/**
	 * Retreives the most recent event of the given type for the guien username;
	 * Only latency events will be returned. pre latent events will not be returned, even if asked for. See getMostRecentEvent()
	 * 
	 * @param string $username
	 * @param int $eventType
	 */
	public function getMostRecentLatencyEvent($username, $eventType = NULL)
	{
		$userid = userid_lookup($username);
		$this->log->debug("userid for username $username is $userid");
		$event =  $this->latencyEventDao->getMostRecentLatencyEvent($userid, $eventType);
		if(!is_null($event))
		{
			$event->setUsername($username);
		}
		return $event; 
	}

	/**
	 * Returns the most recent event of any type, including pre latent events.
	 * @param string $username
	 */
	public function getMostRecentEvent($username)
	{
		$userid = userid_lookup($username);
		$this->log->debug("userid for username $username is $userid");
		$event =  $this->latencyEventDao->getMostRecentEvent($userid);
		if(!is_null($event))
		{
			$event->setUsername($username);
		}
		return $event; 
	}
	
	public function hasLatencyEventsForSiteCatalystVersion($events,$scVersion)
	{
		$retVal = false;
		foreach($events as $event)
		{
			if($event->getSiteCatalystVersion() == $scVersion)
			{
				$retVal = true;
				$this->log->debug("Found latency event for siteCatalyst verion $scVersion");
				break;
			}
		}
		return $retVal;
	}
}