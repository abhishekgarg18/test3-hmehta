<?php

require_once "pun/dao/IdentityDao.php";

require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

class IdentityService
{
	private $log;
	private $identityDao;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
		$this->identityDao = new IdentityDao();	
	}
	
	public function getPrimaryLoginForCompany($companyname,$companyId)
	{
		return $this->identityDao->getPrimaryLoginForCompany($companyname,$companyId);
	}
	
	public function getCompanyName($companyId)
	{
		return $this->identityDao->getCompanyName($companyId);
	}
	
	public function getCompanyId($companyName)
	{
		return $this->identityDao->getCompanyId($companyName);
	}
	
	public function getCompanyForRsid($rsid)
	{
		return $this->identityDao->getCompanyForRsid($rsid);
	}

	public function getLoginsForRSID($rsid)
	{
		//NOTE will use the company api found in phplib/php/company_db.inc
	}
	
	public function getLoginsFromIDs($ids, $company_id, $company_name)
	{
		$this->log->debug("Retrieving emails for login company $company_name with id $company_id with login ids".implode(",",$ids));
		return $this->identityDao->getLoginsFromIDs($ids, $company_id, $company_name);
	}
	

	public function getBillingCustomerForRSID($rsid)
	{
	}

	public function getRSIDsForBillingCustomer($billing_customer)
	{
	}
	
	public function getBillingCustomerId($bcname)
	{
		return $this->identityDao->getBillingCustomerId($bcname);
	}
	
	public function getPrimaryLoginCompanyIdForRSID($rsid)
	{
		return $this->identityDao->getCompanyForRsid($rsid);
	}
	
	public function getPrimaryBillingCustomerForRSID($rsid)
	{
		return $this->identityDao->getBillingCustomerForRsid($rsid);
	}

	public function getLoginCompaniesForRSID($rsid)
	{
	}

	public function getRSIDsForLoginCompany($login_company)
	{
	}

	/* this is the list of of top report suites from top 100 customers
	 * TODO is there a better name?
	 */
	public function getImportantRSIDs()
	{
		$rsids = array(2659611 => 'sistr2');

		return $rsids;
	}

	public function getRSIDFromRSName($rsname)
	{
		return $this->identityDao->getSuiteIDFromSuiteName($rsname);
	}

	public function getRSNameFromRSID($userid)
	{
		return $this->identityDao->getSuiteNameFromSuiteID($userid);
	}
	
	public function getLoginCompanyName($loginCompanyId)
	{
		return $this->identityDao->getCompanyName($loginCompanyId);
	}
	
	public function getBillingCustomerName($bcId)
	{
		return $this->identityDao->getBillingCustomerName($bcId);
	}
	
	public function isV15Rsid($rsid)
	{
		return $this->identityDao->rsIsV15($rsid);
	}
}



