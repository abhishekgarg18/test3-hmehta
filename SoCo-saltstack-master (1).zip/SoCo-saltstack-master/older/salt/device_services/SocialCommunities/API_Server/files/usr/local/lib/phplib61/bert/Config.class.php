<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2013 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * class Config - standardize config table operations.
 *
 * @author  Jack Thomasson <thomasso@adobe.com>
 *
 * @version $Id: $
 */
/**
 * the constructor provides the name field and overloading provides the k and v fields.
 * 'k' and 'v' are used specifically to avoid conflict with reserved words 'key' and 'value'.
 */
require_once 'application.inc';

/**
 * @class Config
 */
abstract class Config {
  const sqlComment = '/*MODULE:bertlib FILE:Config*/';
  const HANDLE = 0;
  const COUNT = 1;

  static private $dbs = array();              //< shared database handles and usage counts organized by DB()
  protected $name = NULL;                     //< corresponds to name field in TABLE()
  private $db = NULL;                         //< cache DB()
  private $table = NULL;                      //< cache TABLE()

  abstract protected function DB();           //< database name
  abstract protected function TABLE();        //< table name

  /**
   * create Config table
   * @param[in] string $name
   * @throws Exception
   */
  function __construct($name) {
    $this->name = $name;
    $this->db = $this->DB();
    $this->table = $this->TABLE();
    if (NULL === self::$dbs[$this->db][self::HANDLE])
      self::$dbs[$this->db][self::COUNT] = 0;
    if (1 == ++self::$dbs[$this->db][self::COUNT]) {
      $dbh = self::$dbs[$this->db][self::HANDLE] = new DB_Sql($this->db);
      $dbh->halt_on_error = false;
    }
    else {
      $dbh = self::$dbs[$this->db][self::HANDLE];
    }
  }

  function __destruct() {
    if (0 == --self::$dbs[$this->db][self::COUNT]) {
      self::$dbs[$this->db][self::HANDLE]->close();
      unset(self::$dbs[$this->db]);
    }
  }

  /**
   * update table with value
   * @param[in] string $k
   * @param[in] string $v
   * @throws Exception
   */
  function __set($k, $v) {
    $dbh = self::$dbs[$this->db][self::HANDLE];
    if (!$dbh->query((null === $v)
                     ? 'DELETE '.self::sqlComment." FROM {$this->table} WHERE name='{$this->name}' AND k='$k'"
                     : 'REPLACE '.self::sqlComment." INTO {$this->table} SET name='{$this->name}', k='$k', v='$v'")
        and $dbh->Errno)
      throw new Exception($dbh->Error, $dbh->Errno);
  }

  /**
   * fetch value from table
   * @param[in] string $k
   * @throws Exception
   * @return string
   */
  function __get($k) {
    $dbh = self::$dbs[$this->db][self::HANDLE];
    $stat = $dbh->squery('SELECT '.self::sqlComment." v FROM {$this->table} WHERE name='{$this->name}' AND k='$k'", 0, MYSQL_NUM);
    if ($dbh->Errno)
      throw new Exception($dbh->Error, $dbh->Errno);
    if (!$stat)
      return NULL;
    return $dbh->f(0);
  }

  /**
   * list all keys and values for the current item
   * @throws Exception
   * @return array k => v
   */
  function list_all() {
    $ret_all = array();
    $dbh = self::$dbs[$this->db][self::HANDLE];
    $dbh->query('SELECT '.self::sqlComment." k, v FROM {$this->table} WHERE name='{$this->name}'");
    if ($dbh->Errno)
      throw new Exception($dbh->Error, $dbh->Errno);
    while ($dbh->next_record(MYSQL_NUM))
      $ret_all[$dbh->f(0)] = $dbh->f(1);
    return $ret_all;
  }

	/**
	 * use filter_var to verify a value else set to known value
	 * @param[in] string $k
	 * @param[in] string $default
	 * @param[in] int $filter
	 * @param[in] mixed $options
	 * @return filtered value
	 * @throw DomainException
	 */
	function filter($k, $default, $filter = FILTER_DEFAULT, $options = 0) {
		$ret = $this->$k;
		switch ($filter) {
		case FILTER_VALIDATE_BOOLEAN:
			$options = FILTER_NULL_ON_FAILURE;
			$fail = NULL;
			if (NULL === $ret)
				$ret = 'bad';
			break;
		default:
			$fail = FALSE;
			break;
		}
		if ($fail !== ($ret = filter_var($ret, $filter, $options)))
			return $ret; // saved value passes filter
		if ($fail !== ($ret = filter_var($default, $filter, $options))) {
			$this->$k = $default;
			return $ret;
		}
		foreach (filter_list() as $f)
			if (filter_id($f) == $filter)
				throw new DomainException("default='$default' out of range for $f filter");
		throw new DomainException("default='$default' out of range for unknown filter");
	}
}

/**
 * Generic Config class for use when you don't need the extra flexibility
 * of specifying the same key for different names.
 * @author mgould
 *
 */
class BertConfig extends Config {
  protected function DB() { return 'cache_maintenance'; }
  protected function TABLE() { return 'bert_config'; }
}

/**
 * SELFTEST
 * Usage: php Config.class.php
 */
if (!debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)) {
  if (function_exists('xdebug_break')) xdebug_break();

  try {
    $c = new BertConfig('SELFTEST');
    $d = new BertConfig('SELFTEST2');
    $value = 'xyzzy';
    echo "(probably empty) $value='".$c->$value."'\n";
    echo "(probably empty) $value='".$d->$value."'\n";
    echo "(expect 'xyzzy') $value='".$c->filter($value, $value, FILTER_VALIDATE_REGEXP, array('options' => array('regexp' => "/^$value$/")))."'\n";
    echo "(expect 'xyzzy') $value='".$d->filter($value, $value, FILTER_VALIDATE_REGEXP, array('options' => array('regexp' => "/^$value$/")))."'\n";
    $c->$value = 999;
    $d->$value = 999;
    echo "(expect 999) $value='".$c->$value."'\n";
    echo "(expect 999) $value='".$d->$value."'\n";
    
    require_once 'ConfigValidate.class.php';    
    echo "(expect 999) $value='".$c->filter($value, 4.2, FILTER_CALLBACK, array('options' => array(new ValidateFloat(), 'validate')))."'\n";
    echo "(expect 999) $value='".$c->filter($value, 1.1, FILTER_CALLBACK, array('options' => array(new ValidateFloat(), 'validate')))."'\n";
    echo "(expect 1.2) $value='".$c->filter($value, 1.2, FILTER_CALLBACK, array('options' => array(new ValidateFloat(null,4), 'validate')))."'\n";
    echo "(expect 1.2) $value='".$c->filter($value, 1.1, FILTER_CALLBACK, array('options' => array(new ValidateFloat(null,4), 'validate')))."'\n";
    echo "(expect 9.1) $value='".$c->filter($value, 9.1, FILTER_CALLBACK, array('options' => array(new ValidateFloat(5), 'validate')))."'\n";
    echo "(expect 9.1) $value='".$c->filter($value, 8.0, FILTER_CALLBACK, array('options' => array(new ValidateFloat(5), 'validate')))."'\n";
    echo "(expect 4.2) $value='".$c->filter($value, 4.2, FILTER_CALLBACK, array('options' => array(new ValidateFloat(1,4.5), 'validate')))."'\n";
    echo "(expect 4.2) $value='".$c->filter($value, 1.1, FILTER_CALLBACK, array('options' => array(new ValidateFloat(1,4.5), 'validate')))."'\n";
    
    echo "(expect '2015-01-01 01:02:03') $value='".$c->filter($value, '2015-01-01 01:02:03', FILTER_CALLBACK, array('options' => array(new ValidateTime(), 'validate')))."'\n";
    echo "(expect '2015-01-01 01:02:03') $value='".$c->filter($value, '2014-12-01 02:03:04', FILTER_CALLBACK, array('options' => array(new ValidateTime(), 'validate')))."'\n";
    echo "(expect '03:04') $value='".$c->filter($value, '03:04', FILTER_CALLBACK, array('options' => array(new ValidateTime('H:i'), 'validate')))."'\n";
    echo "(expect '03:04') $value='".$c->filter($value, '12:30', FILTER_CALLBACK, array('options' => array(new ValidateTime('H:i'), 'validate')))."'\n";

    // test validate default
    echo "(expect false) $value='".($c->filter($value, 'no', FILTER_VALIDATE_BOOLEAN)?'true':'false')."'\n";
    echo "(expect no) $value='".$c->$value."'\n";
    echo "(expect 5) $value='".$c->filter($value, 5, FILTER_VALIDATE_INT, ['options' => ['min_range' => 5]])."'\n";
    // test invalid default
    try {
	    echo "(expect 5) $value='".$c->filter($value, 5, FILTER_VALIDATE_INT, ['options' => ['min_range' => 10]])."'\n";
    } catch (DomainException $e) {
	    echo "good: caught '{$e->getMessage()}'\n";
    }
    try {
	    echo "(expect false) $value='".$c->filter($value, 'bad', FILTER_VALIDATE_BOOLEAN)."''\n";
    } catch (DomainException $e) {
	    echo "good: caught '{$e->getMessage()}'\n";
    }
    
    $c->$value = null;
    $d->$value = null;
    echo "(expect empty) $value='".$c->$value."'\n";
    echo "(expect empty) $value='".$d->$value."'\n";
  }
  catch (Exception $e) {
    fprintf(STDERR, "caught %s%s%s\n", get_class($e),
      $e->getCode() ? sprintf(', code=%d', $e->getCode()) : '',
      $e->getMessage() ? sprintf(', message="%s"', $e->getMessage()) : '');
    exit(1);
  }

  function SELFTESTFatalError() {
    $e = error_get_last();
    echo "good: caught '{$e['message']}'\n";
  }

  register_shutdown_function('SELFTESTFatalError');
  error_reporting(0);
  $c = new Config(SELFTEST::TABLE); // Fatal Error: Cannot instantiate abstract class Config
}
?>
