<?php

class LatencyNotice
{
	private $noticeID;
	private $defId;
	private $rsid;
	private $suiteId;
	private $loginCompany;
	private $loginCompanyId;
	private $sentTime;
	private $latency;
	private $to;
	private $cc;
	private $bcc;
	private $emailSubject;
	private $emailText;
	private $emailType;
	private $emailVersion;
	private $latencyEvents;
	
	public function __construct()
	{
		$this->latencyEvents = array();
	}

	public function getID()
	{
		return $this->noticeID;
	}
	
	public function setID($id)
	{
		$this->noticeID = $id;
	}

	public function getDefId()
	{
		return $this->defId;
	}
	
	public function setDefId($id)
	{
		$this->defId = $id;
	}

	public function getRsid() 
	{
		trigger_error('Function getRsid() is deprecated', E_USER_DEPRECATED);
		return $this->rsid;
	}
	
	public function getLoginCompanyId() 
	{
		return $this->loginCompanyId;
	}

	public function getSuiteId() 
	{
		trigger_error('Function getSuiteId() is deprecated', E_USER_DEPRECATED);
		return $this->suiteId;
	}

	public function setSuiteId($suiteId) 
	{
		trigger_error('Function setSuiteId() is deprecated', E_USER_DEPRECATED);
		$this->suiteId = $suiteId;
	}

	public function getTo() 
	{
		return $this->to;
	}

	public function getCc() 
	{
		return $this->cc;
	}

	public function getBcc() 
	{
		return $this->bcc;
	}

	public function setLoginCompanyId($loginCompanyId) 
	{
		$this->loginCompanyId = $loginCompanyId;
	}

	public function getNoticeID()
	 {
		return $this->noticeID;
	}

	public function setNoticeID($noticeID) 
	{
		$this->noticeID = $noticeID;
	}

	public function getLoginCompany() 
	{
		return $this->loginCompany;
	}

	public function setLoginCompany($loginCompany) 
	{
		$this->loginCompany = $loginCompany;
	}

	public function setTo($to)
	 {
		$this->to = $to;
	}

	public function setCc($cc) 
	{
		$this->cc = $cc;
	}

	public function setBcc($bcc) 
	{
		$this->bcc = $bcc;
	}

	public function getSentTime() 
	{
		return $this->sentTime;
	}

	public function getShortText() 
	{
		if (strlen($this->emailText) > 20)
		{
          return substr($this->emailText,0, 20);
      	}
		return $this->emailText;
	}

	public function setSubject($emailSubject)
	{
		$this->emailSubject = $emailSubject;
	}

	public function getSubject()
	{
		return $this->emailSubject;
	}

	public function getLatency() 
	{
		return $this->latency;
	}

	public function getEmailText() 
	{
		return $this->emailText;
	}

	public function setRsid($rsid) 
	{
		trigger_error('Function setRsid() is deprecated', E_USER_DEPRECATED);
		$this->rsid = $rsid;
	}

	public function setSentTime($sentTime) 
	{
		$this->sentTime = $sentTime;
	}

	public function setShortText($text) 
	{
		$this->shortText = $text;
	}

	public function setLatency($latency) 
	{
		$this->latency = $latency;
	}

	public function setEmailText($email) 
	{
		$this->emailText = $email;
	}
	
	public function setEmailType($emailType)
	{
		trigger_error('Function setEmailType() is deprecated', E_USER_DEPRECATED);
		$this->emailType = $emailType;
	}
	
	public function getEmailType()
	{
		trigger_error('Function getEmailType() is deprecated', E_USER_DEPRECATED);
		return $this->emailType;
	}
	
	public function setEmailVersion($emailVersion)
	{
		$this->emailVersion = $emailVersion;
	}
	
	public function getEmailversion()
	{
		return $this->emailVersion;
	}
	
	public function getLatencyEvents()
	{
		return $this->latencyEvents;
	}
	
	public function setLatencyEvents($latencyEvents)
	{
		$this->latencyEvents = $latencyEvents;
	}
	
	public function addLatencyEvent($event)
	{
		$this->latencyEvents[] = $event;
	}

	public function getEventsByType($type)
	{
		$retVal = array();
		$events = $this->getLatencyEvents();
		foreach($events as $event)
		{
			if($event->getEventType() == $type)
			{
				$retVal[] = $event;
			}
		}
		return $retVal;
	}
	
	public function isPrelatencyNotice()
	{
		return sizeof($this->getEventsByType(4)) > 0;
	}
		
}
