<?php
include ("application.inc");
require_once("pun/services/ConfigService.php");

class ConfigServiceTest  extends PHPUnit_Framework_TestCase
{
	private $configService;
	private $configDao;
	
	public function __construct()
	{
		$this->configService = new ConfigService();
		$this->configDao = new ConfigDao();	
	}
	
	public function testGetExternalLatencyEmailTemplate()
	{
		$template = $this->configService->getExternalLatencyEmailTemplate();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetExternalNewLatencyEmailSubject()
	{
		$template = $this->configService->getExternalNewLatencyEmailSubject();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetExternalContinuingLatencyEmailSubject()
	{
		$template = $this->configService->getExternalContinuingLatencyEmailSubject();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetExternalEndLatencyEmailSubject()
	{
		$template = $this->configService->getExternalEndLatencyEmailSubject();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetInternalPreLatencyEmailTemplate()
	{
		$template = $this->configService->getInternalPreLatencyEmailTemplate();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetInternalPreLatencyEmailSubject()
	{
		$template = $this->configService->getInternalPreLatencyEmailSubject();
		$this->assertNotNull($template);
		$this->assertType('string',$template);
		$this->asserttrue(strlen($template) > 0);
	}
	
	public function testGetCurrentTemplateVersion()
	{
		$this->assertTrue($this->configService->getCurrentTemplateVersion(1) > 0);	
		$this->assertTrue($this->configService->getCurrentTemplateVersion(11) > 0);	
		$this->assertTrue($this->configService->getCurrentTemplateVersion(12) > 0);	
		$this->assertTrue($this->configService->getCurrentTemplateVersion(13) > 0);	
		$this->assertTrue($this->configService->getCurrentTemplateVersion(2) > 0);	
	}
	
	public function testGetEmailFrequencyOptions()
	{
		$options = $this->configService->getEmailFrequencyOptions();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 7), 'returning wrong number of email frequency options');
		$this->assertContains('2', $options);
		$this->assertContains('3', $options);
		$this->assertContains('4', $options);
		$this->assertContains('5', $options);
		$this->assertContains('6', $options);
		$this->assertContains('7', $options);
		$this->assertContains('8', $options);
	}
	
	public function testGetLatencyThresholdOptions()
	{
		$options = $this->configService->getLatencyThresholdOptions();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 3), 'returning wrong number of options');
		$this->assertContains('4', $options);
		$this->assertContains('6', $options);
		$this->assertContains('8', $options);
	}
	
	public function testGetNotificationStateOptions()
	{
		$options = $this->configService->getNotificationStateOptions();		
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 2), 'returning wrong number of state options');
		$this->assertContains('Active', $options);
		$this->assertContains('Hold', $options);
	}
	
	public function testUseExtenalEmails()
	{
		$val = $this->configService->useExtenalEmails();
		$this->assertNotNull($val);
		$this->assertType('boolean',$val);
	}
	
	public function testEnforceEligibility()
	{
		$val = $this->configService->enforceEligibility();
		$this->assertNotNull($val);
		$this->assertType('boolean',$val);
	}
	
	public function testGetAllClearTime()
	{
		$val = $this->configService->getAllClearTime();
		$this->assertNotNull($val);
		$this->assertType('integer',$val);
		$this->assertTrue($val > 0);
	}
	
	public function testGetPreNotificationlatencyTime()
	{
		$val = $this->configService->getPreNotificationlatencyTime();
		$this->assertNotNull($val);
		$this->assertType('integer',$val);
		$this->assertTrue($val > 0);
	}
	
	public function testGetV14OperationsContacts()
	{
		$contacts = $this->configService->getV14OperationsContacts();
		$this->assertNotNull($contacts);
		$this->assertType('string',$contacts);
		$this->asserttrue(strlen($contacts) > 0);
	}
	
	public function testGetV15OperationsContacts()
	{
		$contacts = $this->configService->getV15OperationsContacts();
		$this->assertNotNull($contacts);
		$this->assertType('string',$contacts);
		$this->asserttrue(strlen($contacts) > 0);
	} 
	
	public function testGetV14PagerContacts()
	{
		$contacts = $this->configService->getV14PagerContacts();
		$this->assertNotNull($contacts);
		$this->assertType('string',$contacts);
		$this->asserttrue(strlen($contacts) > 0);
		
	}
	
	public function testGetEligibleUserIds()
	{
		$ids = $this->configService->getEligibleUserIds();	
		$this->assertNotNull($ids);
		$this->assertType('array',$ids);
	}
	
	public function testIsUserIdEligible()
	{
		$this->configService->saveEligibleUserId(77777);
		$this->assertTrue($this->configService->isUserIdEligible(77777));  
		$this->configDao->deleteEligibleUserId(77777);		
		$this->assertFalse($this->configService->isUserIdEligible(999999));  	
	}
	
	
	public function testSaveEligibleUserId()
	{
		$this->configService->saveEligibleUserId(998877);
		$ids = $this->configService->getEligibleUserIds();
		$this->assertContains('998877', $ids);
		$this->configDao->deleteEligibleUserId(998877);		
	}
	
}