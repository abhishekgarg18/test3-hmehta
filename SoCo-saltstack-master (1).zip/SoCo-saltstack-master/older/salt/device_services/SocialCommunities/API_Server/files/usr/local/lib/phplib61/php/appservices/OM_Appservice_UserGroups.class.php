<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_Appservice_UserGroups extends OM_AppServiceBase{
	private static $_instance = null;

	const USERGROUPS_PATH_COMPANY = "/usergroups/custom";
	const USERGROUPS_PATH_USER = "/usergroups/custom/me";

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_Appservice_UserGroups();
		}
		return self::$_instance;
	}

	public static function getAllGroupsForCompany($companyid,$loginid){
		$path = self::USERGROUPS_PATH_COMPANY . "?limit=0";
		return self::makeUserGroupsRequest($path,$companyid,$loginid);
	}

	public static function getAllGroupsForSpecificUser($companyid,$loginid){
		$path = self::USERGROUPS_PATH_USER . "?limit=0";
		return self::makeUserGroupsRequest($path,$companyid,$loginid);
	}

	public static function getAllGroupsForSpecificUserAndRsid($rsid,$companyid,$loginid){
		if(!$rsid){
			return false;
		}
		$path = self::USERGROUPS_PATH_USER . "?limit=0&rsid=" . $rsid;
		return self::makeUserGroupsRequest($path,$companyid,$loginid);
	}

	private static function makeUserGroupsRequest($path,$companyid,$loginid){
		$groups = array();
		$usergroups_client = self::getInstance();

		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();

		$response = $usergroups_client->makeAnalyticsEndpointRequest($path, $token, self::GET_REQUEST,"",true,"","",$companyid,$loginid);
		$data = json_decode($response->getResponse());
		if(is_object($data) && $data->content){
			$groups = $data->content;
		}
		return $groups;
	}
}
