<?
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/


require_once 'user_account.class';
require_once 'UserInfo.class';
require_once 'ServerInventory.class';


/** 
 * Implements frag locking functionality
 *
 * 2015-06-09 Ken Milliett, Lee Christiansen  Initial Version
 */

define(OLD_LOCKS_HOST, 'frag_locks_v1');
define(OLD_LOCKS_PID, 1010);
define(FRAG_LOCKS_CTL, 101);
define(EXPIRE_HOURS, 24);
define(MAX_HOST_LOCK_WEIGHT, 100);
define(DEPRECATED_LOCKED_BY, 'deprecated');
define(HOST_AND_REPORT_SUITE,1);
define(HOST_ONLY,2);


class FragLocks
{
	private $sql_comment = '/* MODULE: bertlib FILE: FragLocks.class.php */';
	private $lock_names = array();
	private $lock_types = array();
	private $lock_resources = array();
	private $lock_names_and_types = array();
	private $lock_names_and_types_shortcuts = array();
	private $matched_hosts_and_rsids = array();
	private $hosts = array();
	private $rsids = array();
	private $my_locks = array();
	private $locks_set_info = array();
	private $execute = FALSE;
	private $verbose = FALSE;
	private $display_sql = FALSE;
	private $message = '';
	
	public function __construct()
	{
		$this->sdb = new DB_Sql('superstatsdb');
		$this->sdb->halt_on_error = FALSE;
		$this->cmdb = new DB_Sql('cache_maintenance');
		$this->cmdb->halt_on_error = FALSE;
		
		// initialize the lock names, types and resources
		$this->getLockNamesAndTypes();
		$this->getLockResources();
	}

	/**
	 * determine if a group of locks are available
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param number $weight
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_type_weight     TRUE - the group of locks are available
	 *                                       FALSE - the group of locks are not available
	 */
	public function areLocksAvailable($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$weight=-1)
	{
		$locks_are_available = FALSE;

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts; 
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) { 
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids; 
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}

		if (count($hosts) == 0 && count($rsids) == 0) {
			throw new Exception("no hosts or rsids were specified to determine lock availability");
		}

		if (!is_array($lock_types) || count($lock_types) < 1) {
			throw new Exception("no lock types were specified to determine lock availability");
		}

		$related_lock_types = $this->getRelatedLockTypes($lock_types);

		if ($related_lock_types) {
			$related_lock_types = array_unique($related_lock_types);

			$invalid_lock_type_combinations = array_intersect($lock_types,$related_lock_types);

			if ($invalid_lock_type_combinations) {
				throw new Exception("invalid lock_type combinations found: " . implode(' ',$invalid_lock_type_combinations));
			}
		}

		// match the list of hosts and rsids
		$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

		if ($hosts_and_rsids) {
			$matched_hosts = $matched_rsids = array();
			foreach($hosts_and_rsids as $host => $rsids_on_host) {
				$matched_hosts[] = $host;
				if (count($rsids_on_host) > 0) {
					$matched_rsids = array_merge($matched_rsids,$rsids_on_host);
				}
			}
			if ($matched_hosts) $hosts = $matched_hosts;
			if ($matched_rsids) $rsids = $matched_rsids;
		} else {
			throw new Exception("no hosts and rsids were matched to determine lock availability");
		}

		// determine if the locks are available
		foreach($hosts_and_rsids as $host => $rsids) {
			foreach($lock_types as $lock_type) {

				if (count($rsids) > 0) {
					// determine if the rsid lock is available
					foreach($rsids as $rsid) {
						$lock_is_available = $this->isLockAvailable($host,$rsid,$lock_type,$locked_by,$weight);

						if (!$lock_is_available) {
							$locks_are_available = FALSE;
							if (strlen($this->message) > 0) {
								$previous_message = $this->message;
							}
							$this->message = "the $lock_type is not available for $rsid on $host";
							if (strlen($previous_message) > 0) {
								$this->message .= " - $previous_message"; 
							}
							return $locks_are_available;
						}
					}
				} else {
					// determine if the host lock is available
					$lock_is_available = $this->isLockAvailable($host,'',$lock_type,$locked_by,$weight);

					if (!$lock_is_available) {
						$locks_are_available = FALSE;
						if (!$this->message) $this->message = "the $lock_type is not available on $host";
						return $locks_are_available;
					}
				}
			}
		}

		$locks_are_available = TRUE;

		// determine if the hosts can handle the additional lock weights
		$max_host_lock_weight = MAX_HOST_LOCK_WEIGHT;

		foreach($hosts_and_rsids as $host => $rsids) {

			$previous_increased_host_weight = $increased_host_weight = $current_host_weight = 0;
			$custom_weight = $weight;

			$current_host_weight = $this->getCombinedLockWeights($host);

			if (count($rsids) < 1) {
				$rsids[] = '';  //add an empty rsid to the array so the weights will be calculated once for the host
			}

			foreach($rsids as $rsid) {
				foreach($lock_types as $lock_type) {

					if ($weight < 0) {

						$weight = $this->getLockTypeWeight($lock_type);

						if ($weight < 0) {
							throw new Exception("unable to get the lock weight for the [$lock_type] lock type");
						}
					}

					$increased_host_weight += $weight;

					if (($current_host_weight + $increased_host_weight) > $max_host_lock_weight) {
						$locks_are_available = FALSE;
						$this->message = "current combined lock weight of $current_host_weight on $host";
						if ($increased_host_weight > $weight) $this->message .= " plus the proposed added lock weight of " . ($increased_host_weight - $weight);
						$this->message .= " plus the added lock weight of $weight for $lock_type ";
						$for_rsid_on_host = "on $host";
						if ($rsid) $for_rsid_on_host = "for $rsid on $host";
						$this->message .= "$for_rsid_on_host";
						$this->message .= " would be " . ($current_host_weight + $increased_host_weight) . " which is more than the maximum allowed weight of $max_host_lock_weight";
						return $locks_are_available;
					}

					$weight = $custom_weight;
				}
			}
		}

		return $locks_are_available;
	}

	/**
	 * determines if a group of locks are set
	 *  
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $locks_are_set     TRUE - the group of locks are set 
	 *                                    FALSE - the group of locks are not set
	 */
	public function areLocksSet($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0)
	{
		$locks_are_set = FALSE;

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts; 
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) { 
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids; 
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}
		
		if (count($hosts) == 0 && count($rsids) == 0) {
			throw new Exception("no hosts or rsids were specified to determine if locks are set");
		}

		if (!is_array($lock_types) || count($lock_types) < 1) {
			throw new Exception("no lock types were specified to determine if locks are set");
		}
		
		$weight = -1;

		$frag_locks_info = $this->getLockInfo($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight,FALSE);

		$frag_locks_info_count = count($frag_locks_info);

		if ($frag_locks_info_count > 0) {
			$locks_are_set = TRUE;

			$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);
						
			$number_of_locks = 0;

			if (count($hosts_and_rsids)) {
				foreach($hosts_and_rsids as $host => $rsids) {
					if (count($rsids) == 0) {
						foreach($lock_types as $lock_type) {
							$lock_is_set = $this->isLockSet($host,'',$lock_type,$locked_by,$lock_host,$lock_id);
										
							if ($lock_is_set) {
								$number_of_locks++;
							} else {
								$locks_are_set = FALSE;
								if (strlen($this->message) < 1) $this->message = "the $lock_type is not set on $host when determining if locks are set";
								return $locks_are_set;
							}
						}
					} else {
						foreach($rsids as $rsid) {
							foreach($lock_types as $lock_type) {

								$lock_is_set = $this->isLockSet($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id);

								if ($lock_is_set) {
									$number_of_locks++;
								} else {
									$locks_are_set = FALSE;
									$this->message = "the $lock_type is not set for $rsid on $host when determining if locks are set";
									return $locks_are_set;
								}
							}
						}
					}
				}
			} else {
				throw new Exception("no hosts and rsids were matched to determine if locks are set");
			}
		} else {
			$locks_are_set = FALSE;
			if (!$this->message) {
				$this->message = "no lock information was found when determining if locks are set";
			}
			return $locks_are_set;
		}
	
		if ($number_of_locks == $frag_locks_info_count) {
			$locks_are_set = TRUE;
		} else {
			$locks_are_set = FALSE;
			$this->message = "the number of locks set ($number_of_locks) was not the same as the number of lock information records ($frag_locks_info_count) when determining if locks are set";
		}

		return $locks_are_set;
	}

	/**
	 * determines if a group of locks are expired
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $locks_are_expired     TRUE - the group of locks are expired
	 *                                        FALSE - the group of locks are not expired
	 */
	public function areLocksExpired($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0)
	{
		$locks_are_expired = FALSE;

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts; 
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) { 
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids; 
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}
		
		if (count($hosts) == 0 && count($rsids) == 0) {
			throw new Exception("no hosts or rsids were specified to determine if locks are expired");
		}

		if (!is_array($lock_types) || count($lock_types) < 1) {
			throw new Exception("no lock types were specified to determine if locks are expired");
		}

		// determine if the locks are set
		$locks_are_set = $this->areLocksSet($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight);
			
		if (!$locks_are_set) {
			throw new Exception("the locks are not set prior to determining if they are expired");
		}
		
		$weight = -1;

		$frag_locks_info = $this->getLockInfo($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight,FALSE);

		$frag_locks_info_count = count($frag_locks_info);

		if ($frag_locks_info_count > 0) {
			$locks_are_expired = TRUE;

			$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

			$number_of_locks = 0;

			if (count($hosts_and_rsids)) {
				foreach($hosts_and_rsids as $host => $rsids) {
					if (count($rsids) == 0) {
						foreach($lock_types as $lock_type) {
							$lock_is_expired = $this->isLockExpired($host,'',$lock_type);

							if ($lock_is_expired) {
								$number_of_locks++;
							} else {
								$locks_are_expired = FALSE;
								if (!$this->message) $this->message = "the [$lock_type] lock type on host [$host] is not expired";
								return $locks_are_expired;
							}
						}
					} else {
						foreach($rsids as $rsid) {
							foreach($lock_types as $lock_type) {
								$lock_is_expired = $this->isLockExpired($host,$rsid,$lock_type);

								if ($lock_is_expired) {
									$number_of_locks++;
								} else {
									$locks_are_expired = FALSE;
									$this->message = "the [$lock_type] lock type for rsid [$rsid] on host [$host] is not expired";
									return $locks_are_expired;
								}
							}
						}
					}
				}
			} else {
				throw new Exception("no hosts and rsids were matched to determine if locks are expired");
			}
		} else {
			throw new Exception("no lock information was found when determining if locks are expired");
		}
	
		if ($number_of_locks == $frag_locks_info_count) {
			$locks_are_expired = TRUE;
		} else {
			throw new Exception("the number of locks tested for expiration [$number_of_locks] were not the same as the number of lock information records [$frag_locks_info_count]");
		}

		return $locks_are_expired;
	}

	public function changeLockExpireTime($host='',$rsid='',$lock_type='',$locked_by='',$lock_host='',$lock_id=0,$expire_time="")
	{
// TODO write and test this function		
	}

	/**
	 * populates the lock_types member variable if it is empty and returns it
	 *  
	 * @throws Exception
	 * 
	 * @return array $this->lock_types     contains lock values keyed by lock type
	 */
	public function getLockTypes()
	{
		if (!is_array($this->lock_types) || count($this->lock_types) < 1) {
	
			$frag_locks_types = array();
				
			$sql = "SELECT $this->sql_comment * FROM frag_locks_types ORDER BY val";
			if ($this->display_sql) echo("\nsql [$sql]\n\n");

			if ($this->cmdb->query($sql)) {
				while ($this->cmdb->next_record()) {
					$frag_locks_types[$this->cmdb->f('type')] = $this->cmdb->f('val');
				}
			} else {
				throw new Exception("MySQL Error " . $this->cmdb->Errno . ": " . $this->cmdb->Error . " returned from sql [$sql] when getting lock types");
			}
			$this->cmdb->free();
				
			if (is_array($frag_locks_types) && count($frag_locks_types) > 0) {
				$this->lock_types = $frag_locks_types;
			}
		}
		return $this->lock_types;
	}

	/**
	 * populates the lock_names member variable if it is empty and returns it
	 * 
	 * @throws Exception
	 * 
	 * @return array $this->lock_names     contains arrays of lock information keyed by lock name
	 */
	public function getLockNames()
	{
		if (!is_array($this->lock_names) || count($this->lock_names) < 1) {

			$frag_locks_names = array();

			$sql = "SELECT $this->sql_comment * FROM frag_locks_names ORDER BY val";
			if ($this->display_sql) echo("\nsql [$sql]\n\n");

			if ($this->cmdb->query($sql)) {
				while ($this->cmdb->next_record()) {
					$frag_locks_names[$this->cmdb->f('name')] = array('val' => $this->cmdb->f('val'), 'weight' => $this->cmdb->f('weight'), 'scope' => $this->cmdb->f('scope'));
				}
			} else {
				throw new Exception("MySQL Error " . $this->cmdb->Errno . ": " . $this->cmdb->Error . " returned from sql [$sql] when getting lock names");
			}
			$this->cmdb->free();

			if (is_array($frag_locks_names) && count($frag_locks_names) > 0) {
				$this->lock_names = $frag_locks_names;
			}
		}

		return $this->lock_names;
	}

	/**
	 * populates the lock_resources member variable if it is empty and returns it
	 * 
	 * @throws Exception
	 * 
	 * @return array $this->lock_resources     contians lock resource values keyed by lock resource
	 */
	public function getLockResources()
	{
		if (!is_array($this->lock_resources) || count($this->lock_resources) < 1) {
	
			$frag_locks_resources = array();
				
			$sql = "SELECT $this->sql_comment * FROM frag_locks_resources";
			if ($this->display_sql) echo("\nsql [$sql]\n\n");

			if ($this->cmdb->query($sql)) {
				while ($this->cmdb->next_record()) {
					$frag_locks_resources[$this->cmdb->f('resource')] = $this->cmdb->f('val');
				}
			} else {
				throw new Exception("MySQL Error " . $this->cmdb->Errno . ": " . $this->cmdb->Error . " returned from sql [$sql] when getting lock types");
			}
			$this->cmdb->free();
				
			if (is_array($frag_locks_resources) && count($frag_locks_resources) > 0) {
				$this->lock_resources = $frag_locks_resources;
			}
		}

		return $this->lock_resources;
	}

	/**
	 * populates the lock_names_and_types member variable if it is empty and returns it
	 * 
	 * @return array $this->lock_names_and_types     contains arrays of lock information
	 *                                               keyed by a combinaton of lock name and lock type
	 */
	public function getLockNamesAndTypes()
	{
		if (!is_array($this->lock_names_and_types) || count($this->lock_names_and_types) < 1) {

			$lock_names_and_types = array();

			$lock_types = $this->getLockTypes();

			$lock_names = $this->getLockNames();

			if (is_array($lock_names) && count($lock_names) > 0) {
				foreach($lock_names as $name => $name_info) {
					foreach($lock_types as $type => $type_val) {
						$combined_name = $name . '-' . $type;
						$combined_value = $name_info['val'] + $type_val;
						$weight = 0;
						if ('lock' == $type) {
							$weight = $name_info['weight'];
						}
						$lock_names_and_types[$combined_name] = array('val' => $combined_value,'weight' => $weight);
					}
				}
			}

			if (is_array($lock_names_and_types) && count($lock_names_and_types) > 0) {
				$this->lock_names_and_types = $lock_names_and_types;
			}
		}

		return $this->lock_names_and_types;
	}

	/**
	 * populates the lock_names_and_types_shortcuts member variable if it is empty and returns it
	 * 
	 * @return array $this->lock_names_and_types_shortcuts     contains combined lock names and types
	 *                                                         keyed by the shortcut of the lock name and type
	 *                                                         the shortcut is the first letter of each part of the lock name and type
	 *                                                         for example:  last_minute-block shortcut is lmb
	 */
	public function getLockNamesAndTypesShortcuts()
	{
		if (!is_array($this->lock_names_and_types_shortcuts) || count($this->lock_names_and_types_shortcuts) < 1) {

			$lock_names_and_types_shortcuts = array();

			$lock_names_and_types = array_keys($this->getLockNamesAndTypes());

			foreach($lock_names_and_types as $lock_name_and_type) {

				$lock_name_and_type_parts = explode('-',$lock_name_and_type);

				$lock_name_parts = explode('_',reset($lock_name_and_type_parts));

				$lock_names_and_types_shortcut = '';
				
				foreach($lock_name_parts as $lock_name_part) {
					$lock_names_and_types_shortcut .= substr($lock_name_part,0,1);
				}
				
				$lock_names_and_types_shortcut .= substr(end($lock_name_and_type_parts),0,1);
				
				$lock_names_and_types_shortcuts[$lock_names_and_types_shortcut] = $lock_name_and_type;
			}

			if (is_array($lock_names_and_types_shortcuts) && count($lock_names_and_types_shortcuts) > 0) {
				$this->lock_names_and_types_shortcuts = $lock_names_and_types_shortcuts;
			}
		}

		return $this->lock_names_and_types_shortcuts;
	}

	/**
	 * returns the lock types for a particular lock type, or for all lock types
	 * 
	 * @param string $type
	 * 
	 * @throws Exception
	 * 
	 * @return array $lock_types     contains lock name and type information
	 *                               keyed by a combination of the lock name and type 
	 */
	public function getLockTypesForType($type='all')
	{
		$lock_types = array();
		$low_value = 0;
		$high_value = 0;

		if ($type == 'all') {
			$low_value = reset($this->lock_types);
			$high_value = end($this->lock_types) + 100;
		} else {
			if (!$this->isLockTypeValid($type)) {
				throw new Exception("the [$type] lock type is invalid when getting lock types");
			}

			$low_value = $this->lock_types[$type];
			$high_value = $low_value + 100;
		}

		if ($high_value > 0) {
			foreach($this->lock_names_and_types as $lock_name_type => $lock_name_type_info) {
				if ($lock_name_type_info['val'] > $low_value && $lock_name_type_info['val'] < $high_value) {
					$lock_types[$lock_name_type] = $lock_name_type_info;
				}
			}
		}

		return $lock_types;
	}

	/**
	 * returns the scope for a specified lock name
	 * 
	 * @param string $name
	 * 
	 * @throws Exception
	 * 
	 * @return number $scope     the scope value for the lock name 
	 */
	public function getLockScopeForName($name)
	{
		$scope = 0;

		if (!$this->isLockNameValid($name)) {
			throw new Exception("the [$name] lock name is invalid when getting the lock scope");
		}

		$names_with_info = $this->getLockNames();

		if (array_key_exists($name,$names_with_info)) {
			$scope = $names_with_info[$name]['scope'];
		} else {
			throw new Exception("the [$name] lock name is not one of the valid lock names when getting the lock scope");
		}

		return $scope;
	}

	/**
	 * returns the lock name from a complete lock type
	 * a complete lock type consists of 2 parts separated by a hyphen
	 * for example:  archive-lock, last_minute-block, snap_backup-ctl
	 * 
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return string $lock_name     the first part of the complete lock type
	 */
	public function getLockNameFromCompleteLockType($lock_type)
	{
		$lock_name = '';

		if ($this->isCompleteLockTypeValid($lock_type)) {
			$lock_type_parts = explode('-',$lock_type);

			if (count($lock_type_parts) != 2) {
				throw new Exception("the lock type [$lock_type] did not have 2 parts separated by a '-' when getting the lock name");
			}
	
			$lock_name = $lock_type_parts[0];
		} 

		return $lock_name;
	}

	/**
	 * returns the lock types for a specified lock name, or for all lock names
	 * 
	 * @param string $name
	 * 
	 * @throws Exception
	 * 
	 * @return array $lock_types     list of lock types
	 *                               a lock type contains a type and a name separated by a hyphen
	 *                               for example:  archive-lock, last_minute-block, snap_backup-ctl
	 */
	public function getLockTypesForName($name='all')
	{
		$lock_types = array();
		$low_value = 0;
		$high_value = 0;

		$names = array();
		
		$types = array_keys($this->getLockTypes());

		if ($name != 'all') {
			if (!$this->isLockNameValid($name)) {
				throw new Exception("the [$name] lock name is invalid when getting lock names");
			}
			
			$names[] = $name;
		} else {
			$names = array_keys($this->getLockNames());
		}
		
		foreach($names as $name) {
			foreach($types as $type) {
				$lock_types[] = $name . "-" . $type;
			}
		}

		return $lock_types;
	}

	/**
	 * returns the related lock types for a list of lock types
	 * 
	 * @param array $lock_types
	 * 
	 * @throws Exception
	 * 
	 * @return array $related_lock_types     list of related lock types 
	 *                                       related lock types are similar to eachother in functionality
	 *                                       for example:  locks are related to blocks and vice versa
	 */
	private function getRelatedLockTypes($lock_types)
	{
		$related_lock_types = array();
	
		if (!is_array($lock_types) || count($lock_types) < 1) {
			throw new Exception("no lock types were specified when getting related lock types");
		}
	
		foreach($lock_types as $lock_type) {
			if (!$this->isCompleteLockTypeValid($lock_type)) {
				throw new Exception("invalid lock type [$lock_type] specified when getting related lock types");
			}

			$lock_type_parts = explode('-',$lock_type);

			if (count($lock_type_parts) != 2) {
				throw new Exception("the lock type [$lock_type] did not have 2 parts separated by a '-' when getting related lock types");
			}
			
			$process_type = $lock_type_parts[0];
			$actual_type = $lock_type_parts[1];

			switch($actual_type) {
				case 'lock':
					$related_lock_type = $process_type . '-block';
					if (!in_array($related_lock_type,$lock_types))  $related_lock_types[] = $related_lock_type;
// TODO enable this when request is implemented
//					$related_lock_type = $process_type . '-request';
//					if (!in_array($related_lock_type,$lock_types))  $related_lock_types[] = $related_lock_type;
					break;	
				case 'block':
					$related_lock_type = $process_type . '-lock';
					if (!in_array($related_lock_type,$lock_types))  $related_lock_types[] = $related_lock_type;
// TODO enable this when request is implemented
//					$related_lock_type = $process_type . '-request';
//					if (!in_array($related_lock_type,$lock_types))  $related_lock_types[] = $related_lock_type;
					break;
// TODO enable this when request is implemented
//				case 'request':
//					$related_lock_type = $process_type . '-block';
//					if (!in_array($related_lock_type,$lock_types))  $related_lock_types[] = $related_lock_type;
//					break;
				default:
					// skip all other types
					break;	
			}
		}

		foreach($related_lock_types as $related_lock_type) {
			if (!$this->isCompleteLockTypeValid($related_lock_type)) {
				throw new Exception("invalid related lock type [$related_lock_type] determined for lock type [$lock_type] when getting related lock types");
			}
		}

		return $related_lock_types;
	}

	/**
	 * returns the lock type name for a specified lock type value
	 * 
	 * @param number $lock_type_value
	 * 
	 * @throws Exception
	 * 
	 * @return string $lock_type_name     for example:  the lock type name for value 101 is archive-block
	 */
	public function getLockTypeName($lock_type_value)
	{
		$lock_type_name = '';

		if ($lock_type_value > 0) {
			foreach($this->lock_names_and_types as $lock_name_type => $lock_name_type_info) {
				if ($lock_name_type_info['val'] == $lock_type_value) {
					$lock_type_name = $lock_name_type;
					break;
				}
			}
			
			if (strlen($lock_type_name) < 1) {
				throw new Exception("lock_type_value [$lock_type_value] was not found in all the defined lock types when getting the lock type name");
			}
		} else {
			throw new Exception("lock_type_value cannot be [$lock_type_value] when getting the lock type name");
		}

		return $lock_type_name;
	}

	/**
	 * return the lock type value for a specified lock name
	 * 
	 * @param string $lock_name
	 * 
	 * @throws Exception
	 * 
	 * @return number $lock_type_value     for example:  the lock type value for archive-block is 101
	 */
	private function getLockTypeValue($lock_name)
	{
		$lock_type_value = 0;

		if (strlen($lock_name) > 0) {
			if (array_key_exists($lock_name,$this->lock_names_and_types)) {
				$lock_type_value = $this->lock_names_and_types[$lock_name]['val'];
			} else {
				throw new Exception("lock_name [$lock_name] is not one of the valid lock types when getting the lock type value");
			}
		} else {
			throw new Exception("lock_name cannot be blank when getting the lock type value");
		}

		return $lock_type_value;
	}

	/**
	 * return the lock type weight for a specified lock name
	 * 
	 * @param string $lock_name
	 * 
	 * @throws Exception
	 * 
	 * @return number $lock_type_weight     for example:  the lock type weight for archive-lock is 25
	 */
	private function getLockTypeWeight($lock_name)
	{
		$lock_type_weight = -1;

		if (strlen($lock_name) > 0) {
			if (array_key_exists($lock_name,$this->lock_names_and_types)) {
				$lock_type_weight = $this->lock_names_and_types[$lock_name]['weight'];
			} else {
				throw new Exception("lock_name [$lock_name] is not one of the valid lock types when getting the lock type weight");
			}
		} else {
			throw new Exception("lock_name cannot be blank when getting the lock type weight");
		}

		return $lock_type_weight;
	}

	/**
	 * queries the frag_locks table and returns lock information based on the parameters passed in to this function
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * @param boolean $get_deprecated_locks     add information about the deprecated locks to the information returned by this function

	 * @throws Exception
	 * 
	 * @return array $lock_info 
	 */
	public function getLockInfo($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0,$weight=-1,$get_deprecated_locks=TRUE)
	{
		$lock_info = array();

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts; 
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) { 
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids; 
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}

		if (count($hosts) > 0) {
			if (count($rsids) > 0) {
				if (count($rsids) == 1 && 'ALL' == reset($rsids)) {
					// do not match the list of hosts and rsids
				} else if (count($rsids) == 1 && 'HOST_ALL' == reset($rsids)) {
					// do not match the list of hosts and rsids
				} else if (count($hosts) == 1 && count($rsids) == 1) {
					// do not match a single host and rsid to allow setting locks for an rsid on a host that it is not on
				} else {
					$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

					if (!$hosts_and_rsids) {
						throw new Exception("unable to get the list of matched hosts and rsids when getting lock info");
					}

					$hosts = array_keys($hosts_and_rsids);
					foreach($hosts_and_rsids as $host => $host_rsids) {
						$rsids = array_merge($rsids,$host_rsids);
					}
				}
			}
		}

		$hosts = array_unique($hosts);
		$rsids = array_unique($rsids);

		if ($get_deprecated_locks && count($hosts) > 0) {
			$lock_info = $this->getDeprecatedLockInfo($hosts,$lock_types);
		}

		$sql = "SELECT $this->sql_comment * FROM frag_locks";

		$hosts_sql = '';
		if (count($hosts) > 0) {
			foreach($hosts as $host) {
				if (strlen($hosts_sql) < 1) {
					$hosts_sql = "host IN ('" . $this->sdb->escape_string($host) . "'";
				} else {
					$hosts_sql .= ",'" . $this->sdb->escape_string($host) . "'";
				}
			}
			$hosts_sql .= ")";
		}

		$rsids_sql = '';
		if (count($rsids) > 0) {
			if (count($rsids) == 1 && 'ALL' == reset($rsids)) {
				$rsids_sql = "rsid LIKE '%'";
			} elseif (count($rsids) == 1 && 'HOST_ALL' == reset($rsids)) {
				// no rsid sql needed
			} else {
				foreach($rsids as $rsid) {
					if (strlen($rsids_sql) < 1) {
						$rsids_sql = "rsid IN ('" . $this->sdb->escape_string($rsid) . "'";
					} else {
						$rsids_sql .= ",'" . $this->sdb->escape_string($rsid) . "'";
					}
				}
				$rsids_sql .= ")";
			}
		} else {
			if (strlen($hosts_sql) > 0) {
				$rsids_sql = "rsid = ''";
			}
		}

		$lock_types_sql = '';
		if (count($lock_types) > 0) {

			$lock_type_values = array();

			foreach($lock_types as $lock_type) {
				$lock_type_value = $this->getLockTypeValue($lock_type);
						
				if ($lock_type_value > 0) {
					$lock_type_values[] = $lock_type_value;
				} else {
					throw new Exception("invalid lock_type_value [$lock_type_value] for lock_type [$lock_type] when getting lock info");
				}
			}
			$lock_types_sql = "type IN (" . implode(",",$lock_type_values) . ")";
		}
		
		$locked_by_sql = '';
		if (strlen($locked_by) > 0) {
			$locked_by_sql = "locked_by = '" . $this->sdb->escape_string($locked_by) . "'";
		}

		$lock_host_sql = '';
		if (strlen($lock_host) > 0) {
			$lock_host_sql = "lock_host = '" . $this->sdb->escape_string($lock_host) . "'";
		}

		$lock_id_sql = '';
		if ($lock_id > 0) {
			$lock_id_sql = "lock_id = $lock_id";
		}

		$weight_sql = '';
		if ($weight >= 0) {
			$weight_sql = "weight = $weight";
		}
		
		if (strlen($hosts_sql) > 0) {
			$sql .= " WHERE $hosts_sql";
			
			if (strlen($rsids_sql) > 0) {
				$sql .= " AND $rsids_sql";
			}

			if (strlen($lock_types_sql) > 0) {
				$sql .= " AND $lock_types_sql";
			}

			if (strlen($locked_by_sql) > 0) {
				$sql .= " AND $locked_by_sql";
			}

			if (strlen($lock_host_sql) > 0) {
				$sql .= " AND $lock_host_sql";
			}
		
			if (strlen($lock_id_sql) > 0) {
				$sql .= " AND $lock_id_sql";
			}
				
			if (strlen($weight_sql) > 0) {
				$sql .= " AND $weight_sql";
			}
		} else {
			if (strlen($rsids_sql) > 0) {
				$sql .= " WHERE $rsids_sql";
				
				if (strlen($lock_types_sql) > 0) {
					$sql .= " AND $lock_types_sql";
				}

				if (strlen($locked_by_sql) > 0) {
					$sql .= " AND $locked_by_sql";
				}

				if (strlen($lock_host_sql) > 0) {
					$sql .= " AND $lock_host_sql";
				}
			
				if (strlen($lock_id_sql) > 0) {
					$sql .= " AND $lock_id_sql";
				}
							
				if (strlen($weight_sql) > 0) {
					$sql .= " AND $weight_sql";
				}
			} else {
				if (strlen($lock_types_sql) > 0) {
					$sql .= " WHERE $lock_types_sql";

					if (strlen($locked_by_sql) > 0) {
						$sql .= " AND $locked_by_sql";
					}

					if (strlen($lock_host_sql) > 0) {
						$sql .= " AND $lock_host_sql";
					}
				
					if (strlen($lock_id_sql) > 0) {
						$sql .= " AND $lock_id_sql";
					}
								
					if (strlen($weight_sql) > 0) {
						$sql .= " AND $weight_sql";
					}
				} else {
					if (strlen($locked_by_sql) > 0) {
						$sql .= " WHERE $locked_by_sql";

						if (strlen($lock_host_sql) > 0) {
							$sql .= " AND $lock_host_sql";
						}
					
						if (strlen($lock_id_sql) > 0) {
							$sql .= " AND $lock_id_sql";
						}
									
						if (strlen($weight_sql) > 0) {
							$sql .= " AND $weight_sql";
						}
					} else {
						if (strlen($lock_host_sql) > 0) {
							$sql .= " WHERE $lock_host_sql";

							if (strlen($lock_id_sql) > 0) {
								$sql .= " AND $lock_id_sql";
							}
						} else {
							if (strlen($lock_id_sql) > 0) {
								$sql .= " WHERE $lock_id_sql";
							}
						}
									
						if (strlen($weight_sql) > 0) {
							$sql .= " AND $weight_sql";
						}
					}
				}
			}
		}
		$sql .= " ORDER BY host,rsid,type";
		
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if (!$this->sdb->query($sql)) {
			throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql [$sql] when getting lock info");
		} else {
			while ($this->sdb->next_record(MYSQL_ASSOC)) {
				$lock_info[] = $this->sdb->Record;
			}
		}
		$this->sdb->free();

		return $lock_info;
	}

	/**
	 * constructs a lock_info array based on the info passed in to the function
	 * this is useful in a dry run situation where actual queries on the table would not return the needed information
	 *  
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * @param string $expiration_date
	 * 
	 * @throws Exception
	 * 
	 * @return array $lock_info
	 */
	public function getLockInfoForDryRun($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0,$weight=-1,$expiration_date='')
	{
		$lock_info = array();

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts; 
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) { 
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids; 
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}

		if (count($hosts) > 0) {
			if (count($rsids) > 0) {
				if (count($rsids) == 1 && 'ALL' == reset($rsids)) {
					// do not match the list of hosts and rsids
				} else if (count($hosts) == 1 && count($rsids) == 1) {
					// do not match a single host and rsid to allow setting locks for an rsid on a host that it is not on
				} else {
					$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

					if (!$hosts_and_rsids) {
						throw new Exception("unable to get the list of matched hosts and rsids when getting lock info");
					}

					$hosts = array_keys($hosts_and_rsids);
					foreach($hosts_and_rsids as $host => $host_rsids) {
						$rsids = array_merge($rsids,$host_rsids);
					}
				}
			}
		}

		$hosts = array_unique($hosts);
		$rsids = array_unique($rsids);

		if (!$rsids) {
			$rsids[] = '';
		}

		if (!$lock_types) {
			$lock_types = array_keys($this->getLockTypesForType('all'));
		}

		foreach($hosts as $host) {
			foreach($rsids as $rsid) {
				foreach($lock_types as $lock_type) {
					$lock_info_record = array();
					$lock_info_record['host'] = $host;
					$lock_info_record['rsid'] = $rsid;
					
					$lock_type_value = $this->getLockTypeValue($lock_type);
					
					$lock_info_record['type'] = $lock_type_value;
					$lock_info_record['locked_by'] = $locked_by;
					$lock_info_record['lock_host'] = $lock_host;
					$lock_info_record['lock_id'] = $lock_id;
					
					if ($weight == -1) {
						$weight = $this->getLockTypeWeight($lock_type);
					}
					
					$lock_info_record['weight'] = $weight;
					
					$current_time = time();
					$start_time = date("Y-m-d H:i:s",$current_time);
					$lock_info_record['start_time'] = $start_time;
					
					if (strlen($expiration_date) < 1) {
						$expire_time_seconds = $current_time + (EXPIRE_HOURS * 60 * 60);
						$expiration_date = date("Y-m-d H:i:s",$expire_time_seconds);
					}

					$lock_info_record['expire_time'] = $expiration_date;
					$lock_info_record['modified_time'] = $start_time;
						
					$lock_info[] = $lock_info_record;
				}
			}
		}

		return $lock_info;
	}

	/**
	 * returns string representations of lock info and lock info details
	 * 
	 * @param string $host
	 * 
	 * @throws Exception
	 * 
	 * @return array $lock_info_string $lock_info_details_string $ctl_info_string $ctl_info_details_string
	 */
	public function getLockInfoStrings($host)
	{
		$lock_info_string = '';
		$lock_info_details_string = '';
		$ctl_info_string = '';
		$ctl_info_details_string = '';
		
		$host_and_rsid_lock_info = array();

		if (strlen($host) < 1) {
			throw new Exception("the host cannot be empty when getting lock info strings");
		}

		$lock_types = array_keys($this->getLockTypesForType('all'));

		$host_and_rsid_lock_info = $this->getLockInfo($host,'HOST_ALL',$lock_types);

		$lock_info = array();
		$ctl_info = array();

		foreach($host_and_rsid_lock_info as $host_and_rsid_lock_info_record) {

			$lock_type = $this->getLockTypeName($host_and_rsid_lock_info_record['type']);

			$lock_type_first_letter = strtoupper(substr($lock_type,0,1));

			if (strpos($lock_type,'-ctl') === FALSE) {
				$lock_info[$lock_type_first_letter]['locked_by'] = $host_and_rsid_lock_info_record['locked_by'];
				$lock_info[$lock_type_first_letter]['lock_host'] = $host_and_rsid_lock_info_record['lock_host'];
				$lock_info[$lock_type_first_letter]['lock_id'] = $host_and_rsid_lock_info_record['lock_id'];
			} else {
				$ctl_info[$lock_type_first_letter]['locked_by'] = $host_and_rsid_lock_info_record['locked_by'];
				$ctl_info[$lock_type_first_letter]['lock_host'] = $host_and_rsid_lock_info_record['lock_host'];
				if ($ctl_info[$lock_type_first_letter]['locked_by'] == DEPRECATED_LOCKED_BY && $host_and_rsid_lock_info_record['lock_id'] != 0) {
					$user_info = new UserInfo();
					list($user_info_ret,$user_info_ret_str,$user_info_ret_info) = $user_info->getUserInfoByCtlID($host_and_rsid_lock_info_record['lock_id']);
					if ($user_info_ret == BERT_RET_SUCCESS) {
						if (strlen($user_info_ret_info[user_name]) > 0) {
							$ctl_info[$lock_type_first_letter]['lock_id'] = $user_info_ret_info[user_name] . '-' . $host_and_rsid_lock_info_record['lock_id'];
						} else {
							$ctl_info[$lock_type_first_letter]['lock_id'] = $host_and_rsid_lock_info_record['lock_id'];
						}
					} else {
						$ctl_info[$lock_type_first_letter]['lock_id'] = $host_and_rsid_lock_info_record['lock_id'];
					}
				} else {
					$ctl_info[$lock_type_first_letter]['lock_id'] = $host_and_rsid_lock_info_record['lock_id'];
				}
			}
		}

		$loop = 0;
		while($loop < 2) {
			$loop++;
			$info_string = '';
			$info_details_string = '';
			$lock_info_combined_locks = array();
			$lock_info_to_process = array();
			
			if ($loop == 1) {
				$lock_info_to_process = $lock_info;
			} else if ($loop == 2) {
				$lock_info_to_process = $ctl_info;
			}

			if ($lock_info_to_process) {
				foreach($lock_info_to_process as $lock_type => $lock_type_info) {
					$lock_duplicate_found = FALSE;
					$unset_key = '';
					$new_key = $lock_type;

					foreach($lock_info_combined_locks as $lock_info_combined_key => $lock_info_combined_lock) {
						if ($lock_type_info['locked_by'] == $lock_info_combined_lock['locked_by'] && 
							$lock_type_info['lock_host'] == $lock_info_combined_lock['lock_host'] && 
							$lock_type_info['lock_id'] == $lock_info_combined_lock['lock_id'])
						{
							$lock_duplicate_found = TRUE;
							$unset_key = $lock_info_combined_key;
							$new_key = $lock_info_combined_key . $lock_type;
							break;
						}
					}

					if ($lock_duplicate_found) {
						unset($lock_info_combined_locks[$unset_key]);
						$lock_info_combined_locks[$new_key] = $lock_type_info;
					} else {
						$lock_info_combined_locks[$lock_type] = $lock_type_info;
					}
				}
			}

			if ($lock_info_combined_locks) {
				foreach($lock_info_combined_locks as $lock_info_combined_key => $lock_info_combined_lock) {
					$info_string .= $lock_info_combined_key;
					$info_details_string .= "($lock_info_combined_key:" . $lock_info_combined_lock['locked_by'] . ":" . $lock_info_combined_lock['lock_host'] . ":" . $lock_info_combined_lock['lock_id'] . ")";
				}
			}

			if ($loop == 1) {
				$lock_info_string = $info_string;
				$lock_info_details_string = $info_details_string;
			} else if ($loop == 2) {
				$ctl_info_string = $info_string;
				$ctl_info_details_string = $info_details_string;
			}
		}

		return array($lock_info_string,$lock_info_details_string,$ctl_info_string,$ctl_info_details_string);
	}

	/**
	 * returns an array of the lock information based on the parameters passed to the function
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * @param boolean $get_deprecated_locks
	 * 
	 * @return array $lock_info_table     results from calling getLockInfo() keyed on host
	 */
	public function getLockInfoTable($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0,$weight=-1,$get_deprecated_locks=TRUE)
	{
		$lock_info_table = $lock_info = array();

		$lock_info = $this->getLockInfo($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight,$get_deprecated_locks);

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts;
			} else {
				$hosts = array();
			}
		}

		foreach($hosts as $host) {
			$lock_info_table[$host] = array();
		}

		foreach($lock_info as $lock_info_record) {
			$lock_info_table_record = array();
			
			$lock_name_and_type = $this->getLockTypeName($lock_info_record['type']);

			$lock_name_and_type_parts = explode('-',$lock_name_and_type);
			$lock_name = reset($lock_name_and_type_parts);
			$lock_type = end($lock_name_and_type_parts);

			$lock_info_table_record['rsid'] = $lock_info_record['rsid'];
			$lock_info_table_record['locked_by'] = $lock_info_record['locked_by'];
			$lock_info_table_record['lock_host'] = $lock_info_record['lock_host'];
			$lock_info_table_record['lock_id'] = $lock_info_record['lock_id'];
			$lock_info_table_record['weight'] = $lock_info_record['weight'];
			$lock_info_table_record['start_time'] = $lock_info_record['start_time'];
			$lock_info_table_record['expire_time'] = $lock_info_record['expire_time'];
			$lock_info_table_record['modified_time'] = $lock_info_record['modified_time'];
			$lock_info_table[$lock_info_record['host']][$lock_name][$lock_type] = $lock_info_table_record;
		}

		return $lock_info_table;
	}

	/**
	 * returns lock information from the previous locking system
	 * 
	 * @param array $hosts
	 * @param array $lock_types
	 * 
	 * @throws Exception
	 * 
	 * @return array $deprecated_lock_info     lock information found in the previous locking system
	 */
	public function getDeprecatedLockInfo($hosts=array(),$lock_types=array())
	{
		$deprecated_lock_info = array();

		if (!is_array($hosts) || count($hosts) < 1) {
			throw new Exception("no hosts were specified when getting deprecated lock info");
		}

		if (!is_array($lock_types) || count($lock_types) < 1) {
			throw new Exception("no lock types were specified when getting deprecated lock info");
		}

		foreach($hosts as $host) {
			foreach($lock_types as $lock_type) {

				$lock_type_value = $this->getLockTypeValue($lock_type);

				$lock_info = array();
				$ctl_value = 0;

				switch($lock_type) {
					case 'archive-lock':
					case 'archive-block':
						$lock_info = $this->get_deprecated_extended_archive_lock_info($host);
						break;
					case 'last_minute-lock':
						case 'last_minute-block':
						$lock_info = $this->get_deprecated_extended_last_minute_lock_info($host);
						break;
					case 'frag_cleanup-lock':
					case 'frag_cleanup-block':
						$lock_info = $this->get_deprecated_extended_cleanup_lock_info($host);
						break;
					case 'vcookie_cleanup-lock':
					case 'vcookie_cleanup-block':
						$lock_info = $this->get_deprecated_extended_vcookie_cleanup_lock_info($host);
						break;
					case 'minitag-lock':
					case 'minitag-block':
						$lock_info = $this->get_deprecated_extended_minitag_lock_info($host);
						break;
					case 'archive-ctl':
						$ctl_value = $this->get_deprecated_archive_ctl_info($host);
						break;
					case 'last_minute-ctl':
						$ctl_value = $this->get_deprecated_last_minute_ctl_info($host);
						break;
					case 'frag_cleanup-ctl':
						$ctl_value = $this->get_deprecated_cleanup_ctl_info($host);
						break;
					case 'vcookie_cleanup-ctl':
						$ctl_value = $this->get_deprecated_vcookie_cleanup_ctl_info($host);
						break;
					case 'minitag-ctl':
						$ctl_value = $this->get_deprecated_minitag_ctl_info($host);
						break;
					default:
						// do not test or fail on all other lock types
						break;
				}

				if (is_array($lock_info) && count($lock_info) > 0 && '' != reset($lock_info)) {
					$deprecated_lock_info_record = array();
					$deprecated_lock_info_record['host'] = $host;
					$deprecated_lock_info_record['rsid'] = '';
					$deprecated_lock_info_record['type'] = $lock_type_value;
					$deprecated_lock_info_record['locked_by'] = DEPRECATED_LOCKED_BY;
					$deprecated_lock_info_record['lock_host'] = $lock_info[0];
					$deprecated_lock_info_record['lock_id'] = $lock_info[1];
					$deprecated_lock_info_record['weight'] = '';
					if ("0000-00-00 00:00:00" != $lock_info[2]) {
						$deprecated_lock_info_record['start_time'] = $lock_info[2];
					}
					$deprecated_lock_info_record['expire_time'] = '';
					if ("0000-00-00 00:00:00" != $lock_info[4]) {
						$deprecated_lock_info_record['modified_time'] = $lock_info[4];
					}
					$deprecated_lock_info[] = $deprecated_lock_info_record;
				} else if ($ctl_value > 0) {
					$deprecated_lock_info_record = array();
					$deprecated_lock_info_record['host'] = $host;
					$deprecated_lock_info_record['rsid'] = '';
					$deprecated_lock_info_record['type'] = $lock_type_value;
					$deprecated_lock_info_record['locked_by'] = DEPRECATED_LOCKED_BY;
					$deprecated_lock_info_record['lock_host'] = '';
					$deprecated_lock_info_record['lock_id'] = $ctl_value;
					$deprecated_lock_info_record['weight'] = '';
					$deprecated_lock_info_record['start_time'] = '';
					$deprecated_lock_info_record['expire_time'] = '';
					$deprecated_lock_info_record['modified_time'] = '';
					$deprecated_lock_info[] = $deprecated_lock_info_record;
				}
			}
		}		

		return $deprecated_lock_info;
	}

	/**
	 * returns all the current lock information from the previous locking system
	 * based on the list of in use frags
	 * 
	 * @throws Exception
	 * 
	 * @return array $all_deprecated_lock_info     
	 */
	public function getAllDeprecatedLockInfo()
	{
		$all_deprecated_lock_info = array();

		$lock_types = array_keys($this->getLockTypesForType('all'));

		$server_inventory = new ServerInventory();

		// Create the servers spec for selecting servers
		$selector_str = 'role:frag;state:inuse';
		$servers_spec = $server_inventory->create_servers_spec($selector_str);

		list($ret, $ret_str, $hosts) = $server_inventory->get_servers($servers_spec);

		if ($ret == BERT_RET_SUCCESS) {
			$all_deprecated_lock_info = $this->getDeprecatedLockInfo($hosts,$lock_types);
		} else {
			throw new Exception($ret_str);
		}

		return $all_deprecated_lock_info;
	}

	/**
	 * populates the matched_hosts_and_rsids member variable if it is empty and returns it
	 * 
	 * the matched_hosts_and_rsids member variable is populated by determining which rsids are on which hosts
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * 
	 * @throws Exception
	 * 
	 * @return array $matched_hosts_and_rsids     arrays of rsids keyed by host
	 */
	public function getMatchedHostsAndRsids(array $hosts, array $rsids)
	{
		if (is_array($this->matched_hosts_and_rsids) && count($this->matched_hosts_and_rsids) > 0 ) {
			if ($hosts == $this->hosts && $rsids == $this->rsids) {
				$this->message = "hosts and rsids were previously matched";
				return $this->matched_hosts_and_rsids;
			}
		}

		$matched_hosts_and_rsids = $matched_hosts = $matched_rsids = array();
	
		$hosts = array_unique($hosts);
		$rsids = array_unique($rsids);
	
		if (count($hosts) > 0) {  // if hosts were passed in
			if (count($rsids) > 0) {  // and rsids were passed in
				foreach($rsids as $rsid) {  // get all the hosts for each rsid
					$frags_for_rsid = $this->getFragsForRsid($rsid);

					foreach($frags_for_rsid as $frag) {
						if (in_array($frag,$hosts)) {  // if this host was passed in, save it
							$matched_hosts[$frag][] = $rsid;
							$matched_rsids[$rsid][] = $frag;
						}
					}
				}
			} else {  // if no rsids were passed in, return the hosts with no rsids
				foreach($hosts as $host) {
					$matched_hosts_and_rsids[$host] = array();
				}
				return $matched_hosts_and_rsids;
			}
		} else {  // if no hosts were passed in
			if (count($rsids) > 0) {  // if rsids were passed in
				foreach($rsids as $rsid) {  // get all the hosts for each rsid and save them
					$frags_for_rsid = $this->getFragsForRsid($rsid);

					if (count($frags_for_rsid)) {
						foreach($frags_for_rsid as $frag) {
							$matched_hosts[$frag][] = $rsid;
							$matched_rsids[$rsid][] = $frag;
						}
					} else {
						throw new Exception("rsid [$rsid] has 0 hosts");
					}
				}

				if (count($matched_hosts) < 1) {
					throw new Exception("0 hosts were found for all the rsids");
				}
			} else { // and no rsids were passed in
				throw new Exception("0 hosts and 0 rsids were specified to be matched");
			}
		}
	
		// validation
	
		// every host should be in the matched_hosts array
		foreach($hosts as $host) {
			if (!array_key_exists($host,$matched_hosts)) {
				throw new Exception("host [$host] does not have any of the specified report suites");
			}
		}

		// every matched host should be in the hosts list
		foreach($matched_hosts as $matched_host => $matched_host_info) {
			if (!in_array($matched_host,$hosts)) {
				throw new Exception("host [$matched_host] is not in the list of specified hosts");
			}
		}

		// every rsid should be in the matched_rsids array
		foreach($rsids as $rsid) {
			if (!array_key_exists($rsid,$matched_rsids)) {
				throw new Exception("report suite [$rsid] is not on any of the specified hosts");
			}
		}

		// every matched rsid should be in the rsids list
		foreach($matched_rsids as $matched_rsid => $matched_rsid_info) {
			if (!in_array($matched_rsid,$rsids)) {
				throw new Exception("report suite [$matched_rsid] is not in the list of specified report suites");
			}
		}

		// every host should be in the matched_rsids array
		foreach($matched_hosts as $matched_host => $matched_host_rsid_list) {
			$matched_host_found = FALSE;
			foreach($matched_rsids as $matched_rsid => $matched_rsid_host_list) {
				if (in_array($matched_host,$matched_rsid_host_list)) {
					$matched_host_found = TRUE;
					break;
				}
			}

			if (!$matched_host_found) {
				throw new Exception("host [$matched_host] is not in the list of hosts for the specified report suites");
			}
		}
	
		// every rsid should be in the matched_hosts array
		foreach($matched_rsids as $matched_rsid => $matched_rsid_host_list) {
			$matched_rsid_found = FALSE;
			foreach($matched_hosts as $matched_host => $matched_host_rsid_list) {
				if (in_array($matched_rsid,$matched_host_rsid_list)) {
					$matched_rsid_found = TRUE;
					break;
				}
			}
			if (!$matched_rsid_found) {
				throw new Exception("report suite [$matched_rsid] is not in list of report suites for the specified hosts");
			}
		}
	
		$matched_hosts_and_rsids = $matched_hosts;

		// save the information in the class
		$this->matched_hosts_and_rsids = $matched_hosts_and_rsids;
		$this->hosts = $hosts;
		$this->rsids = $rsids;

		return $matched_hosts_and_rsids;
	}

	/**
	 * returns the list of frags that a particular rsid is on
	 * 
	 * @param string $rsid
	 * 
	 * @throws Exception
	 * 
	 * @return array $frags_for_rsid
	 */
	public function getFragsForRsid($rsid)
	{
		if (!$rsid) {
			throw new Exception("no rsid was specified when getting frags for rsid");
		}

		$frags_for_rsid = array();
		
		$user_account = new user_account($rsid);
		
		$frag_servers_by_role = array();
		$frag_servers_by_role = $user_account->get_frag_servers_by_role();

		if (!is_array($frag_servers_by_role)) {
			throw new Exception("unable to determine the frags for rsid [$rsid]");
		}
		
		$number_of_frag_servers_by_role = count($frag_servers_by_role);
		if ($number_of_frag_servers_by_role != 5) {
			throw new Exception("the wrong number of frag servers for role [$number_of_frag_servers_by_role] were found for rsid [$rsid]");
		}

		$frags_for_rsid = array_unique(array_merge($frag_servers_by_role['combo'],$frag_servers_by_role['frag'],$frag_servers_by_role['vcookie']));

		if (!is_array($frags_for_rsid)) {
			throw new Exception("unable to get valid combo, frag, and vcookie information for rsid [$rsid]");
		}

		if (count($frags_for_rsid) == 1) {
			$main_frag = reset($frags_for_rsid);
			if (strlen($main_frag) < 1) {
				$frags_for_rsid = array();
			}
		}

		return $frags_for_rsid;
	}

	/**
	 * calculates and returns the current combined weight of a particular host
	 *  
	 * @param string $host
	 * 
	 * @throws Exception
	 * 
	 * @return number $weight     calculated by summing all of the weights for the host
	 */
	private function getCombinedLockWeights($host)
	{
		$weight = -1;

		if (strlen($host) < 1) {
			throw new Exception("host must be specified when getting combined lock weights");
		}

		$sql = "SELECT $this->sql_comment SUM(weight) AS total_weight FROM frag_locks WHERE host='" . $this->sdb->escape_string($host) . "'";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			$this->sdb->next_record();
			$weight = $this->sdb->f('total_weight');
			if (!$weight) $weight = 0;
		} else {
			throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql [$sql] when getting combined lock weights");
		}
		$this->sdb->free();

		return $weight;
	}

	/**
	 * returns the list of locks whose expiration date and time has passed
	 * 
	 * @throws Exception
	 * 
	 * @return array $expired_locks 
	 */
	public function getExpiredLocks()
	{
		$expired_locks = array();

		$sql = "SELECT $this->sql_comment * FROM frag_locks WHERE expire_time < NOW()";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			while ($this->sdb->next_record(MYSQL_ASSOC)) {
				$expired_locks[] = $this->sdb->Record;
			}
		} else {
			throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql [$sql] when getting expired locks");
		}
		$this->sdb->free();

		return $expired_locks;
	}

	/**
	 * returns the locks_set_info member variable
	 * 
	 * @return array $this->locks_set_info
	 */
	public function getLocksSetInfo()
	{
		return $this->locks_set_info;
	}

	/**
	 * returns the message member variable
	 * 
	 * @return array $this->message
	 */
	public function getMessage()
	{
		return $this->message;
	}

	/**
	 * determines if a lock type is one of the valid lock types
	 * 
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_type_is_valid     TRUE - the lock type is one of the valid types
	 *                                         FALSE - the lock type is not one of the valid types
	 */
	public function isLockTypeValid($lock_type)
	{
		$lock_type_is_valid = FALSE;
		
		if (strlen($lock_type) < 1) {
			throw new Exception("lock type must be specified when determining if a lock type is valid");
		}
		
		$lock_types = $this->getLockTypes();
		
		if (array_key_exists($lock_type,$lock_types)) {
			$lock_type_is_valid = TRUE;
		}

		return $lock_type_is_valid;
	}

	/**
	 * determines if a lock name is one of the valid lock names
	 * 
	 * @param string $lock_name
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_name_is_valid     TRUE - the lock name is one of the valid names
	 *                                         FALSE - the lock name is not one of the valid names
	 */
	public function isLockNameValid($lock_name)
	{
		$lock_name_is_valid = FALSE;
		
		if (strlen($lock_name) < 1) {
			throw new Exception("lock name must be specified when determining if a lock name is valid");
		}
		
		$lock_names = $this->getLockNames();
		
		if (array_key_exists($lock_name,$lock_names)) {
			$lock_name_is_valid = TRUE;
		}

		return $lock_name_is_valid;
	}

	/**
	 * determines if a lock type and/or a lock value is valid
	 * 
	 * @param string $lock_name
	 * @param number $lock_value
	 * 
	 * @return boolean $lock_type_is_valid     TRUE - the lock name and/or value is valid
	 *                                         FALSE - the lock name and/or valud is not valid
	 */
	public function isCompleteLockTypeValid($lock_name='',$lock_value=0)
	{
		$lock_type_is_valid = FALSE;

		if (strlen($lock_name) > 0) {
			if (array_key_exists($lock_name,$this->lock_names_and_types)) {
				if ($lock_value == 0) {
					$lock_type_is_valid = TRUE;
				} else {
					if ($lock_value == $this->lock_names_and_types[$lock_name]['val']) {
						$lock_type_is_valid = TRUE;
					}
				}
			} else {
				$lock_type_is_valid = FALSE;
			}
		} else {
			if ($lock_value > 0) {
				foreach($this->lock_names_and_types as $name => $info) {
					if (array_key_exists('val',$info)) {
						if ($info['val'] == $lock_value) {
							$lock_type_is_valid = TRUE;
							break;
						}
					}
				}
			}
		}

		return $lock_type_is_valid;
	}

	/**
	 * determines if a lock scope is valid
	 * a lock scope determines whether a lock is a host and report suite lock, or only a host lock
	 * 
	 * @param string $lock_type
	 * @param string $host
	 * @param string $rsid
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_scope_valid     TRUE - lock scope is valid 
	 *                                       FALSE - lock scope is not valid 
	 */
	public function isLockScopeValid($lock_type,$host,$rsid)
	{
		$lock_scope_valid = FALSE;

		$lock_name = $this->getLockNameFromCompleteLockType($lock_type);

		if (strlen($lock_name) > 0) {
			$scope = $this->getLockScopeForName($lock_name);

			switch ($scope) {
				case HOST_AND_REPORT_SUITE:
					if (strlen($host) < 1) {
						$lock_scope_valid = FALSE;
						$this->message = "a host must be specified with the [$lock_type] lock type because its scope is HOST_AND_REPORT_SUITE";
					} else {
						$lock_scope_valid = TRUE;
					}
					break;
				case HOST_ONLY:
					$lock_scope_valid = TRUE;

					if (strlen($host) < 1) {
						$lock_scope_valid = FALSE;
						$this->message = "a host must be specified with the [$lock_type] lock type because its scope is HOST_ONLY";
					} else {
						if (strlen($rsid) > 0) {
							$lock_scope_valid = FALSE;
							$this->message = "a report suite [$rsid] cannot be specified because the scope of the [$lock_type] lock type is HOST_ONLY";
						}
					}
					break;
				default;
					throw new Exception("unknown scope [$scope] for name [$lock_name] while validating the [$lock_type] lock type");
				break;
			}
		} else {
			$this->message = "the lock name could not be determiend for the [$lock_type] lock type on host [$host] and report suite [$rsid]";
		}

		return $lock_scope_valid;
	}

	/**
	 * determines if a particular lock is available based on the parameters passed to the function
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param number $weight
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_is_available     TRUE - the lock is available
	 *                                        FALSE - the lock is not available
	 */
	public function isLockAvailable($host,$rsid,$lock_type,$locked_by='',$weight=-1)
	{
// TODO this function should return success if a request for this lock exists for the lock_by, lock_host, lock_pid
		$lock_is_available = FALSE;
		
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine lock availability");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine lock availability");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		// determine if the deprecated lock is available for this host and lock_type
		$deprecated_lock_is_available = $this->isDeprecatedLockAvailable($host,$lock_type);

		if (!$deprecated_lock_is_available) {
			$lock_is_available = FALSE;
			$this->message = "$host has a deprecated host lock";
			return $lock_is_available;
		}

		// get the related lock types for this lock type
		$lock_types[] = $lock_type;
		
		$related_lock_types = $this->getRelatedLockTypes((array)$lock_type);

		if (!is_array($related_lock_types)) {
			throw new Exception("invalid information was returned from getRelatedLockTypes($lock_type)");
		}
		
		$related_lock_types = array_merge($related_lock_types,$lock_types);
		
		// determine if the lock types are already set for the host or the rsid
		foreach($related_lock_types as $related_lock_type) {
			
			// determine if the host lock is set
			$lock_is_set = $this->isLockSet($host,'',$related_lock_type);

			if ($lock_is_set) {
				$lock_is_available = FALSE;
				if (!$this->message) $this->message = "related lock_type ($related_lock_type) is set on $host";
				return $lock_is_available;
			}

			if (strlen($rsid) < 1) {  // host lock only
				// determine if the rsid lock is set for any rsid on this host
				$temp_locked_by = '';
				$temp_lock_host = '';
				$temp_lock_id = 0;
				$temp_weight = -1;
					
				$frag_locks_info = $this->getLockInfo($host,'ALL',$related_lock_type,$temp_locked_by,$temp_lock_host,$temp_lock_id,$temp_weight,FALSE);
				
				if ($frag_locks_info) {
					$lock_is_available = FALSE;
					if (!$this->message) $this->message = "related lock_type ($related_lock_type) is set for " . $frag_locks_info[0]['rsid'] . " on $host";
					return $lock_is_available;
				}
			} else {
				// determine if the rsid lock is set
				
				$lock_is_set = $this->isLockSet($host,$rsid,$related_lock_type);

				if ($lock_is_set) {
					$lock_is_available = FALSE;
					if (!$this->message) $this->message = "related lock_type ($related_lock_type) is set for $rsid on $host";
					return $lock_is_available;
				}
			}
		}

		// determine if the host would be above its resource limit with this additional lock - allow for wildcards in resource names
		if (strlen($locked_by) > 0) {

			foreach($this->lock_resources as $resource => $resource_limit) {

				// see if this resource is in the locked_by field
				$resource_found_in_locked_by = FALSE;
				$resource_ends_with_an_asterisk = FALSE;

				$resource_len = strlen($resource);
				$pos = strpos($resource,'*');
				if ($pos == $resource_len - 1) { // the resource ends with an *
					$resource_ends_with_an_asterisk = TRUE;
					
					$resource_without_asterisk = substr($resource,0,$resource_len-1);
	
					// see if the locked_by field has the resource at its beginning
					$pos = strpos($locked_by,$resource_without_asterisk);
					if ($pos !== FALSE && $pos === 0) {  // the locked_by field has $resource_without_asterisk at its beginning
						$resource_found_in_locked_by = TRUE;
						$resource = $resource_without_asterisk;
					}
				} else {
					if ($locked_by == $resource) {
						$resource_found_in_locked_by = TRUE;
					}
				}

				if ($resource_found_in_locked_by) {
	
					// stop if the resource limit for locked_by is 0
					if ($resource_limit == 0) {
						$lock_is_available = FALSE;
						$this->message = "the '$resource' resource has a limit of $resource_limit instances";
						return $lock_is_available;
					}
	
					$frag_locks_info = $this->getLockInfo($host,'HOST_ALL',$lock_type,'','',0,-1,FALSE);

					if ($frag_locks_info) {

						$resource_counter = 0;
						
						foreach($frag_locks_info as $frag_locks_info_record) {

							if ($resource_ends_with_an_asterisk) {
								$pos = strpos($frag_locks_info_record['locked_by'],$resource);
								if ($pos !== FALSE && $pos === 0) {  // the $frag_locks_info_record['locked_by'] field has $resource at its beginning
									$resource_counter++;
								}
							} else {
								if ($frag_locks_info_record['locked_by'] == $resource) {
									$resource_counter++;
								}
							}
						}

						if ($resource_counter >= $resource_limit) {
							$lock_is_available = FALSE;
							$this->message = "the '$resource' resource has a limit of $resource_limit instances and there are currently $resource_counter instances";
							return $lock_is_available;
						}
					}

					break;
				}
			}
		}

		// get the default weight for this lock if no weight was specified
		if ($weight < 0) {
		
			$weight = $this->getLockTypeWeight($lock_type);
		
			if ($weight < 0) {
				$lock_is_available = FALSE;
				$this->message = "unable to get the weight for the [$lock_type] lock type to determine if the lock is available";
				return $lock_is_available;
			}
		}

		if ($weight > 0) {
			// determine if the host is already at its max weight
			$current_host_weight = $this->getCombinedLockWeights($host);
	
			$max_host_lock_weight = MAX_HOST_LOCK_WEIGHT;
	
			if ($current_host_weight >= $max_host_lock_weight) {
				$lock_is_available = FALSE;
				$this->message = "current combined lock weight of $current_host_weight on $host is greater than or equal to the maximum allowed lock weight of $max_host_lock_weight";
				return $lock_is_available;
			}

			// determine if the host can handle the additional weight of this lock type
			$increased_host_weight = $current_host_weight + $weight;
			
			if ($increased_host_weight > $max_host_lock_weight) {
				$lock_is_available = FALSE;
				$this->message = "current combined lock weight of $current_host_weight on $host";
				$this->message .= " plus the added lock weight of $weight for $lock_type would be $increased_host_weight which is more than the maximum allowed weight of $max_host_lock_weight";
				return $lock_is_available;
			} else {
				$lock_is_available = TRUE;
			}
		} else {
			$lock_is_available = TRUE;
		}

		return $lock_is_available;
	}

	/**
	 * determines if a lock is available in the previous locking system
	 * 
	 * @param string $host
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $deprecated_lock_is_available     TRUE - the lock is available
	 *                                                   FALSE - the lock is not available
	 */
	private function isDeprecatedLockAvailable($host='',$lock_type='')
	{
		$deprecated_lock_is_available = FALSE;
	
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine deprecated lock availability");
		}
	
		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine deprecated lock availability");
		}

		$deprecated_lock_is_available = TRUE;
		$short_lock_type = '';

		switch($lock_type) {
			case 'archive-lock':
			case 'archive-block':
				if ($this->is_deprecated_archive_locked($host)) {
					$this->message = "$host has a deprecated archive lock";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'lock';
				break;
			case 'last_minute-lock':
			case 'last_minute-block':
				if ($this->is_deprecated_last_minute_locked($host)) {
					$this->message = "$host has a deprecated last_minute lock";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'lock';
				break;
			case 'frag_cleanup-lock':
			case 'frag_cleanup-block':
				if ($this->is_deprecated_cleanup_locked($host)) {
					$this->message = "$host has a deprecated frag_cleanup lock";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'lock';
				break;
			case 'vcookie_cleanup-lock':
			case 'vcookie_cleanup-block':
				if ($this->is_deprecated_vcookie_cleanup_locked($host)) {
					$this->message = "$host has a deprecated vcookie_cleanup lock";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'lock';
				break;
			case 'minitag-lock':
			case 'minitag-block':
				if ($this->is_deprecated_minitag_locked($host)) {
					$this->message = "$host has a deprecated minitag lock";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'lock';
				break;
			case 'archive-ctl':
				if ($this->is_deprecated_archive_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'ctl';
				break;
			case 'last_minute-ctl':
				if ($this->is_deprecated_last_minute_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'ctl';
				break;
			case 'frag_cleanup-ctl':
				if ($this->is_deprecated_cleanup_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'ctl';
				break;
			case 'vcookie_cleanup-ctl':
				if ($this->is_deprecated_vcookie_cleanup_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'ctl';
				break;
			case 'minitag-ctl':
				if ($this->is_deprecated_minitag_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_available = FALSE;
				}
				$short_lock_type = 'ctl';
				break;
			default:
				// do not test or fail on all other lock types
				break;
		}

		if (!$deprecated_lock_is_available) {
			$first_error_message = $this->message;

			$hosts = array($host);
			$lock_types = array($lock_type);

			$deprecated_lock_info = $this->getDeprecatedLockInfo($hosts,$lock_types);

			$deprecated_lock_info_count = count($deprecated_lock_info);

			if ($deprecated_lock_info_count != 1) {
				$deprecated_lock_is_available = FALSE;
				$this->message = "there are $deprecated_lock_info_count deprecated lock info records, not 1 like there should be";
				return $deprecated_lock_is_available; 
			}

			$deprecated_lock_info_record = reset($deprecated_lock_info);

			if ($short_lock_type == 'lock') {
				if (($deprecated_lock_info_record['locked_by'] == DEPRECATED_LOCKED_BY) && 
					($deprecated_lock_info_record['lock_host'] == OLD_LOCKS_HOST) && 
					($deprecated_lock_info_record['lock_id'] == OLD_LOCKS_PID)) {
					$deprecated_lock_is_available = TRUE;
					$this->message = '';
				} else {
					$deprecated_lock_is_available = FALSE;
					$this->message = $first_error_message;
				}
			} else if ($short_lock_type == 'ctl') {
				if (($deprecated_lock_info_record['locked_by'] == DEPRECATED_LOCKED_BY) &&
					($deprecated_lock_info_record['lock_id'] == FRAG_LOCKS_CTL)) {
					$deprecated_lock_is_available = TRUE;
					$this->message = '';
				} else {
					$deprecated_lock_is_available = FALSE;
					$this->message = $first_error_message;
				}
			} else {
				throw new Exception("invalid short lock type [$short_lock_type] for host [$host] when determining deprecated lock availability");
			}
		}

		return $deprecated_lock_is_available;
	}

	/**
	 * determines if a lock is currently set
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_is_set     TRUE - the lock is currently set 
	 *                                  FALSE - the lock is not currently set
	 */
	public function isLockSet($host,$rsid='',$lock_type,$locked_by='',$lock_host='',$lock_id=0)
	{
		$lock_is_set = FALSE;

		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine if a lock is set");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine if a lock is set");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		$weight = -1;

		$frag_locks_info = $this->getLockInfo($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight,FALSE);

		if ($frag_locks_info) {
			$lock_is_set = TRUE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type is set $for_rsid_on_host";
		} else {
			$lock_is_set = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type is not set $for_rsid_on_host";
		}

		return $lock_is_set;
	}

	/**
	 * determines if a lock expiration date has passed
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_is_expired     TRUE - the lock is expired
	 *                                      FALSE - the lock is not expired
	 */
	public function isLockExpired($host='',$rsid='',$lock_type='',$locked_by='',$lock_host='',$lock_id=0)
	{
		$lock_is_expired = FALSE;

		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine if a lock is expired");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine if a lock is expired");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		$weight = -1;

		$frag_locks_info = $this->getLockInfo($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight,FALSE);

		$frag_locks_info_count = count($frag_locks_info);
		
		if ($frag_locks_info_count > 1) {
			$message = "$frag_locks_info_count locks were found before determining if the [$lock_type] lock_type is expired";
			if (strlen($rsid) > 0) $message .= " for rsid [$rsid]";
			$message .= " on host [$host], when only 1 was expected";
			throw new Exception($message);
		} else if ($frag_locks_info_count == 1) {
			$lock = reset($frag_locks_info);

			$expire_time = strtotime($lock['expire_time']);
			$current_time = time();

			if ($expire_time < $current_time) {
				$lock_is_expired = TRUE;
				$this->message = "$lock_type";
				if (strlen($rsid) > 0) $this->message .= " for $rsid";
				$this->message .= " on $host expired on " . $lock['expire_time'];
			} else {
				$lock_is_expired = FALSE;
				$this->message = "$lock_type";
				if (strlen($rsid) > 0) $this->message .= " for $rsid";
				$this->message .= " on $host does not expire until " . $lock['expire_time'];
			}
		} else {
			$message = "lock_type [$lock_type] is not set";
			if (strlen($rsid) > 0) $message .= " for rsid [$rsid]";
			$message .= " on host [$host] before determining if the lock is expired";
			throw new Exception($message);
		}

		return $lock_is_expired;
	}

	/**
	 * determines if a lock will expire after a specified number of seconds
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $expire_seconds
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_is_going_to_expire     TRUE - the lock will expire after the specified number of seconds
	 *                                              FALSE - the lock will not expire after the specified number of seconds
	 */
	public function isLockGoingToExpire($host='',$rsid='',$lock_type='',$locked_by='',$lock_host='',$lock_id=0,$expire_seconds=60)
	{
		$lock_is_going_to_expire = FALSE;

		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine if a lock is going to expire");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine if a lock is going to expire");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		$weight = -1;

		$frag_locks_info = $this->getLockInfo($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight,FALSE);

		if (count($frag_locks_info) > 1) {
			$message = count($frag_locks_info) . " locks were found before determining if the $lock_type is going to expire";
			if (strlen($rsid) > 0) $message .= " for $rsid";
			$message .= " on $host, when only 1 was expected";
			throw new Exception($message);
		} else if (count($frag_locks_info) == 1) {
			$lock = reset($frag_locks_info);

			$expire_time = strtotime($lock['expire_time']);
			$current_time = time();

			$lock_is_going_to_expire_determined = TRUE;

			if ($expire_time < $current_time + $expire_seconds) {
				$lock_is_going_to_expire = TRUE;
				$this->message = "$lock_type";
				if (strlen($rsid) > 0) $this->message .= " for $rsid";
				$this->message .= " on $host is going to expire on " . date('Y-m-d g:i:s',$current_time + $expire_seconds);
			} else {
				$lock_is_going_to_expire = FALSE;
				$this->message = "$lock_type";
				if (strlen($rsid) > 0) $this->message .= " for $rsid";
				$this->message .= " on $host is not going to expire on " . date('Y-m-d g:i:s',$current_time + $expire_seconds);
			}
		} else {
			$lock_is_going_to_expire = FALSE;
			$this->message = "$lock_type is not set";
			if (strlen($rsid) > 0) $this->message .= " for $rsid";
			$this->message .= " on $host";
		}

		return $lock_is_going_to_expire;
	}

	/**
	 * determines if a lock is set in the previous locking system
	 * 
	 * @param string $host
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $deprecated_lock_is_set     TRUE - the lock is set in the previous locking system
	 *                                             FALSE - the lock is not set in the previous locking system
	 */
	public function isDeprecatedLockSet($host='',$lock_type='')
	{
		$deprecated_lock_is_set = FALSE;
	
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to determine if a deprecated lock is set");
		}
	
		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to determine if a deprecated lock is set");
		}

		switch($lock_type) {
			case 'archive-lock':
			case 'archive-block':
				if ($this->is_deprecated_archive_locked($host)) {
					$this->message = "$host has a deprecated archive lock";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'last_minute-lock':
			case 'last_minute-block':
				if ($this->is_deprecated_last_minute_locked($host)) {
					$this->message = "$host has a deprecated last_minute lock";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'frag_cleanup-lock':
			case 'frag_cleanup-block':
				if ($this->is_deprecated_cleanup_locked($host)) {
					$this->message = "$host has a deprecated frag_cleanup lock";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'vcookie_cleanup-lock':
			case 'vcookie_cleanup-block':
				if ($this->is_deprecated_vcookie_cleanup_locked($host)) {
					$this->message = "$host has a deprecated vcookie_cleanup lock";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'minitag-lock':
			case 'minitag-block':
				if ($this->is_deprecated_minitag_locked($host)) {
					$this->message = "$host has a deprecated minitag lock";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'archive-ctl':
				if ($this->is_deprecated_archive_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'last_minute-ctl':
				if ($this->is_deprecated_last_minute_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'frag_cleanup-ctl':
				if ($this->is_deprecated_cleanup_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'vcookie_cleanup-ctl':
				if ($this->is_deprecated_vcookie_cleanup_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			case 'minitag-ctl':
				if ($this->is_deprecated_minitag_ctl_set($host)) {
					$this->message = "$host has a deprecated archive ctl";
					$deprecated_lock_is_set = TRUE;
				}
				break;
			default:
				$this->message = "lock_type [$lock_type] is not one of the vaild lock types to check for a deprecated lock";
				// do not test or fail on all other lock types
				break;
		}
		return $deprecated_lock_is_set;
	}

	/**
	 * uses mysql table locking to lock the tables necessary to set or unset a lock
	 * 
	 * @param array $lock_types
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $tables_locked     TRUE - the tables were locked
	 *                                    FALSE - the tables were not locked
	 */
	public function mysqlLockFragLocksTables(array $lock_types)
	{
		$tables_locked = FALSE;
		$all_tables_to_lock = array();
		
		foreach($lock_types as $lock_type) {
			$tables_to_lock = $this->getFragLocksTablesFromType($lock_type);

			$all_tables_to_lock = array_merge($all_tables_to_lock,$tables_to_lock);
		}
		$all_tables_to_lock = array_unique($all_tables_to_lock);
		
		$all_tables_to_lock_string = '';
		
		foreach($all_tables_to_lock as $table_to_lock) {
			if (strlen($all_tables_to_lock_string) < 1) {
				$all_tables_to_lock_string = $this->sdb->escape_string($table_to_lock) . ' WRITE';
			} else {
				$all_tables_to_lock_string .= ', ' . $this->sdb->escape_string($table_to_lock) . ' WRITE';
			}
		}

		if (strlen($all_tables_to_lock_string) < 1) {
			throw new Exception("unable to determine the list of tables to lock");
		}

		$sql = "LOCK $this->sql_comment TABLES $all_tables_to_lock_string";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if ($this->sdb->query($sql)) {
				$tables_locked = TRUE;
			} else {
				throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql [$sql] when locking frag locks tables");
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$tables_locked = TRUE;
		}

		return $tables_locked;
	}

	/**
	 * uses mysql table locking to unlock the tables that were locked to set or unset a lock
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $tables_unlocked     TRUE - the tables were unlocked
	 *                                      FALSE - the tables were not unloced
	 */
	public function mysqlUnlockFragLocksTables()
	{
		$tables_unlocked = FALSE;

		$sql = "UNLOCK $this->sql_comment TABLES";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");
		
		if ($this->execute) {
			if ($this->sdb->query($sql)) {
				$tables_unlocked = TRUE;
			} else {
				throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql [$sql] when unlocking frag locks tables");
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$tables_unlocked = TRUE;
		}

		return $tables_unlocked;
	}

	/**
	 * sets the $this->execute member variable
	 * 
	 * @param boolean $execute
	 */
	public function setExecute($execute)
	{
		$this->execute = $execute;
	}

	/**
	 * sets the $this->verbose member variable
	 * 
	 * @param boolean $verbose
	 */
	public function setVerbose($verbose)
	{
		$this->verbose = $verbose;
	}

	/**
	 * sets the $this->display_sql member variable
	 * 
	 * @param boolean $display_sql
	 */
	public function setSqlDisplay($display_sql)
	{
		$this->display_sql = $display_sql;
	}

	/**
	 * sets a lock by inserting a record into the frag_locks table
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * @param string $expire_time
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_set     TRUE - the lock was set
	 *                               FALSE - the lock was not set
	 */
	public function setLock($host,$rsid,$lock_type,$locked_by='',$lock_host='',$lock_id=0,$weight=-1,$expire_time='')
	{
// TODO write a function to change an existing request to a lock if it exists
		$lock_set = FALSE;
		
		if (!is_string($host)) {
			throw new Exception("host [$host] must be a string to set the lock");
		}

		if (strlen($host) < 1) {
			throw new Exception("host cannot be empty to set the lock");
		}

		if (!is_string($lock_type)) {
			throw new Exception("lock_type [$lock_type] must be a string to set the lock");
		}

		if (!$this->isCompleteLockTypeValid($lock_type)) {
			throw new Exception("lock_type [$lock_type] is invalid to set the lock");
		}

		if (!is_string($locked_by)) {
			throw new Exception("locked_by [$locked_by] must be a string to set the lock");
		}

		if (strlen($locked_by) < 1) {
			throw new Exception("locked_by cannot be empty to set the lock");
		}
		
		if (!is_string($lock_host)) {
			throw new Exception("lock_host [$lock_host] must be a string to set the lock");
		}

		if (strlen($lock_host) < 1) {
			throw new Exception("lock_host cannot be empty to set the lock");
		}
		
		if ($lock_id < 1) {
			throw new Exception("lock_id [$lock_id] must be greater than 0 to set the lock");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		if ($weight < 0) {
			$weight = $this->getLockTypeWeight($lock_type);

			if ($weight < 0) {
				throw new Exception("unable to get the default weight for the [$lock_type] lock type prior to setting the lock for rsid [$rsid] on host [$host]");
			}
		}

		$expire_time_value = 0;
		if ($expire_time) {
			$expire_time_value = strtotime($expire_time);
			if ($expire_time_value === FALSE) {
				throw new Exception("unable to determine a valid expire time for [$expire_time] prior to setting the [$lock_type] lock type for rsid [$rsid] on host [$host]");
			}
		}

		// return success if the lock is already set
		$lock_is_set = $this->isLockSet($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id);

		if ($lock_is_set) {
			$lock_set = TRUE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type is already set $for_rsid_on_host";
			return $lock_set;
		}

		// determine if the lock is available before locking the mysql tables
		try {
			$lock_is_available = $this->isLockAvailable($host,$rsid,$lock_type,$locked_by,$weight);
		} catch (Exception $e) {
			throw $e;
		}
		
		if (!$lock_is_available) {
			$lock_set = FALSE;
			if (strlen($this->message) > 0) {
				$previous_message = $this->message;
			}
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type is not available prior to locking the tables and setting the $lock_type $for_rsid_on_host";
			if (strlen($previous_message) > 0) {
				$this->message .= " - $previous_message";
			}

			return $lock_set;
		}

		// lock the necessary tables
		$lock_type_array = array($lock_type);
		$tables_locked = $this->mysqlLockFragLocksTables($lock_type_array);

		if (!$tables_locked) {
			$lock_set = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "unable to lock the frag locks tables before setting the $lock_type $for_rsid_on_host";
			return $lock_set;
		}

		try {
			$lock_is_available = $this->isLockAvailable($host,$rsid,$lock_type,$locked_by,$weight);
		} catch (Exception $e) {

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnlockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			throw $e;
		}

		if (!$lock_is_available) {
			$lock_set = FALSE;
			if (strlen($this->message) > 0) {
				$previous_message = $this->message;
			}
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type is not available prior to setting the $lock_type $for_rsid_on_host";
			if (strlen($previous_message) > 0) {
				$this->message .= " - $previous_message";
			}

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnlockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			return $lock_set;
		}

		try {
			$lock_type_value = $this->getLockTypeValue($lock_type);
		} catch (Exception $e) {

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnlockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}
				
			throw $e;
		}

		if ($lock_type_value == 0) {

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnlockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			throw new Exception("unable to get the value for the [$lock_type] lock type before setting the lock for rsid [$rsid] on host [$host]");
		}

		$start_time = date("Y-m-d H:i:s");

		if ($expire_time_value) {
			$expire_time = date("Y-m-d H:i:s",$expire_time_value);
		} else {
			$expire_time_seconds = time() + (EXPIRE_HOURS * 60 * 60);
			$expire_time = date("Y-m-d H:i:s",$expire_time_seconds);
		}
		
		$sql = "INSERT $this->sql_comment INTO frag_locks";
		$sql .= " (host,rsid,type,locked_by,lock_host,lock_id,weight,start_time,expire_time)";
		$sql .= " VALUES ('" . $this->sdb->escape_string($host) . "','" . $this->sdb->escape_string($rsid) . "',$lock_type_value,'" . $this->sdb->escape_string($locked_by) . "','" . $this->sdb->escape_string($lock_host) . "',$lock_id,$weight,'$start_time','$expire_time')";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if (!$this->sdb->query($sql)) {

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnlockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql - $sql");
			} else {
				$lock_set = TRUE;
			}
			$this->sdb->free();
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$lock_set = TRUE;
		}				

		if ($lock_set) {
			try {
				if (!$this->setDeprecatedLock($host,$lock_type)) {
					$first_error_message = $this->message;
					$deprecated_lock_is_already_set = FALSE;
					$hosts = array($host);
					$lock_types = array($lock_type);

					$deprecated_lock_info = $this->getDeprecatedLockInfo($hosts,$lock_types);
					$deprecated_lock_info_count = count($deprecated_lock_info);

					if ($deprecated_lock_info_count != 1) {
						$deprecated_lock_is_available = FALSE;
						$this->message = "there are $deprecated_lock_info_count deprecated lock info records, not 1 like there should be";
						return $deprecated_lock_is_available;
					}
				
					$deprecated_lock_info_record = reset($deprecated_lock_info);
					$short_lock_type = '';

					switch($lock_type) {
						case 'archive-lock':
						case 'archive-block':
						case 'last_minute-lock':
						case 'last_minute-block':
						case 'frag_cleanup-lock':
						case 'frag_cleanup-block':
						case 'vcookie_cleanup-lock':
						case 'vcookie_cleanup-block':
						case 'minitag-lock':
						case 'minitag-block':
							$short_lock_type = 'lock';
							break;
						case 'archive-ctl':
						case 'last_minute-ctl':
						case 'frag_cleanup-ctl':
						case 'vcookie_cleanup-ctl':
						case 'minitag-ctl':
							$short_lock_type = 'ctl';
							break;
						default:
							// do not test or fail on all other lock types
							break;
					}

					if ($short_lock_type == 'lock') {
						if (($deprecated_lock_info_record['locked_by'] == DEPRECATED_LOCKED_BY) &&
								($deprecated_lock_info_record['lock_host'] == OLD_LOCKS_HOST) &&
								($deprecated_lock_info_record['lock_id'] == OLD_LOCKS_PID)) {
									$deprecated_lock_is_already_set = TRUE;
									$this->message = '';
								} else {
									$deprecated_lock_is_already_set = FALSE;
									$this->message = $first_error_message;
								}
					} else if ($short_lock_type == 'ctl') {
						if (($deprecated_lock_info_record['locked_by'] == DEPRECATED_LOCKED_BY) &&
								($deprecated_lock_info_record['lock_id'] == FRAG_LOCKS_CTL)) {
									$deprecated_lock_is_already_set = TRUE;
									$this->message = '';
								} else {
									$deprecated_lock_is_already_set = FALSE;
									$this->message = $first_error_message;
								}
					}
						
					if (!$deprecated_lock_is_already_set) {
						$message = "unable to set the deprecated lock type: $lock_type for host: $host";
						if (strlen($this->message) > 0) {
							$message .= " - " . $this->message;
						}
						$lock_set = FALSE;
						$this->mysqlUnlockFragLocksTables();
						$this->unsetLock($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight);
						$this->message = $message;
						return $lock_set;
					}
				}
			} catch (Exception $e) {

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnlockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				throw $e;
			}

			if (strlen($rsid)) {
				$this->my_locks[$host][$lock_type]['rsids'][] = $rsid;
			} else {
				$this->my_locks[$host][$lock_type]['host'] = TRUE;
			}

		}

		// unlock the locked tables
		$tables_unlocked = $this->mysqlUnlockFragLocksTables();

		if (!$tables_unlocked) {
			$lock_set = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			if ($this->execute) {
				$this->message = "the $lock_type was locked $for_rsid_on_host, but the frag locks tables were not unlocked";
			} else {
				$this->message = "unable to unlock the frag locks tables";
			}
		}

		return $lock_set;
	}

	/**
	 * sets a lock in the previous locking system
	 * 
	 * @param string $host
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return boolean
	 */
	public function setDeprecatedLock($host='',$lock_type='')
	{
		$deprecated_lock_set = FALSE;
	
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to set the deprecated lock");
		}
	
		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to set the deprecated lock");
		}

		$deprecated_lock_set = TRUE;

		switch($lock_type) {
			case 'archive-lock':
			case 'archive-block':
				if (!$this->acquire_deprecated_archive_lock($host)) {
					$deprecated_lock_set = FALSE;
					$this->message = "acquire_deprecated_archive_lock($host) failed";
				}
				break;
			case 'last_minute-lock':
			case 'last_minute-block':
				if (!$this->acquire_deprecated_last_minute_lock($host)) {
					$deprecated_lock_set = FALSE;
					$this->message = "acquire_deprecated_last_minute_lock($host) failed";
				}
				break;
			case 'frag_cleanup-lock':
			case 'frag_cleanup-block':
				if (!$this->acquire_deprecated_cleanup_lock($host)) {
					$deprecated_lock_set = FALSE;
					$this->message = "acquire_deprecated_cleanup_lock($host) failed";
				}
				break;
			case 'vcookie_cleanup-lock':
			case 'vcookie_cleanup-block':
				if (!$this->acquire_deprecated_vcookie_cleanup_lock($host)) {
					$deprecated_lock_set = FALSE;
					$this->message = "acquire_deprecated_vcookie_cleanup_lock($host) failed";
				}
				break;
			case 'minitag-lock':
			case 'minitag-block':
				if (!$this->acquire_deprecated_minitag_lock($host)) {
					$deprecated_lock_set = FALSE;
					$this->message = "acquire_deprecated_minitag_lock($host) failed";
				}
				break;
			case 'archive-ctl':
				if (!$this->set_deprecated_archive_ctl($host,FRAG_LOCKS_CTL)) {
					$deprecated_lock_set = FALSE;
					$this->message = "set_deprecated_archive_ctl($host,FRAG_LOCKS_CTL) failed";
				}
				break;
			case 'last_minute-ctl':
				if (!$this->set_deprecated_last_minute_ctl($host,FRAG_LOCKS_CTL)) {
					$deprecated_lock_set = FALSE;
					$this->message = "set_deprecated_last_minute_ctl($host,FRAG_LOCKS_CTL) failed";
				}
				break;
			case 'frag_cleanup-ctl':
				if (!$this->set_deprecated_cleanup_ctl($host,FRAG_LOCKS_CTL)) {
					$deprecated_lock_set = FALSE;
					$this->message = "set_deprecated_cleanup_ctl($host,FRAG_LOCKS_CTL) failed";
				}
				break;
			case 'vcookie_cleanup-ctl':
				if (!$this->set_deprecated_vcookie_cleanup_ctl($host,FRAG_LOCKS_CTL)) {
					$deprecated_lock_set = FALSE;
					$this->message = "set_deprecated_vcookie_cleanup_ctl($host,FRAG_LOCKS_CTL) failed";
				}
				break;
			case 'minitag-ctl':
				if (!$this->set_deprecated_minitag_ctl($host,FRAG_LOCKS_CTL)) {
					$deprecated_lock_set = FALSE;
					$this->message = "set_deprecated_minitag_ctl($host,FRAG_LOCKS_CTL) failed";
				}
				break;
			default:
				// do not set or fail on all other lock types
				break;
		}

		return $deprecated_lock_set;
	}

	/**
	 * sets multiple frag locks
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * @param string $expire_time
	 * @param boolean $set_available_locks
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $locks_set     TRUE - the locks were set 
	 *                                FALSE - the locks were not set
	 */
	public function setLocks($hosts,$rsids=array(),$lock_types,$locked_by='',$lock_host='',$lock_id=0,$weight=-1,$expire_time='',$set_available_locks=FALSE)
	{
		$locks_set = FALSE;
		$this->locks_set_info = array();
		
		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts;
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) {
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids;
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}
		
		if (count($hosts) == 0) {
			throw new Exception("no hosts were specified to set locks");
		}

		if(count($lock_types) == 0) {
			throw new Exception("no lock types were specified to set locks");
		}

		$locks_are_available = $this->areLocksAvailable($hosts,$rsids,$lock_types,$locked_by,$weight);

		if (!$locks_are_available) {
			$previous_message = $this->message;

			$locks_are_set = $this->areLocksSet($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight);

			if ($locks_are_set) {
				$locks_set = TRUE;
				$this->message = "the locks are already set";
				return $locks_set;
			} else {
				if (!$set_available_locks) {
					$locks_set = FALSE;
					if (strlen($previous_message) > 0) {
						$this->message = $previous_message;
					} else {
						$this->message = "the locks cannot be set because they are not available";
					}
					return $locks_set;
				}
			}
		}

		$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

		$locks_set = TRUE;
		$locks_set_info = array();
		$message = '';

		if (count($hosts_and_rsids)) {
			foreach($hosts_and_rsids as $host => $rsids) {
				if (count($rsids) == 0) {
					$rsids[] = "";
				}
				foreach($rsids as $rsid) {
					foreach($lock_types as $lock_type) {
					
						if ($set_available_locks) {

							$lock_is_available = $this->isLockAvailable($host,$rsid,$lock_type,$locked_by,$weight);

							if (!$lock_is_available) {
								continue;
							}
						}

						$lock_set = $this->setLock($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight,$expire_time);

						if ($lock_set) {
							$locks_set_info[] = array('host'=>$host,'rsid'=>$rsid,'lock_type'=>$lock_type);
						} else {
							$message = $this->message;
							$locks_set = FALSE;
							break 3;
						}
					}
				}
			}
		} else {
			$locks_set = FALSE;
			$this->message = "no hosts and rsids were matched to set locks";
			return $locks_set;
		}

		if (!$locks_set) {
			
			// remove the locks that were set because there was a failure setting a single lock
			if (count($locks_set_info) > 0) {
			
				foreach($locks_set_info as $info) {
					$host = $info['host'];
					$rsid = $info['rsid'];
					$lock_type = $info['lock_type'];
					
					$this->unsetLock($host,$rsid,$lock_type);
				}
				$locks_set_info = array();
			}
		
			$this->message = $message;
		}

		$this->locks_set_info = $locks_set_info;

		return $locks_set;
	}

	/**
	 * unsets a lock by deleting the record from the frag_locks table
	 * 
	 * @param string $host
	 * @param string $rsid
	 * @param string $lock_type
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * @param number $weight
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $lock_unset     TRUE - the lock was unset
	 *                                 FALSE - the lock was not unset
	 */
	public function unsetLock($host,$rsid,$lock_type,$locked_by='',$lock_host='',$lock_id=0,$weight=-1)
	{
		$lock_unset = FALSE;
		
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to unset the lock");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to unset the lock");
		}

		if (!$this->isCompleteLockTypeValid($lock_type)) {
			throw new Exception("lock_type [$lock_type] is an invalid lock type when unsetting the lock for rsid [$rsid] on host [$host]");
		}

		if (!$this->isLockScopeValid($lock_type,$host,$rsid)) {
			throw new Exception($this->message);
		}

		$lock_is_set = $this->isLockSet($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id);

		if (!$lock_is_set) {
			$lock_unset = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "the $lock_type lock_type is not set $for_rsid_on_host when attempting to unset the lock";
			return $lock_unset;
		}

		// lock the necessary tables
		$lock_type_array = array($lock_type);
		$tables_locked = $this->mysqlLockFragLocksTables($lock_type_array);

		if (!$tables_locked) {
			$lock_unset = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "unable to lock the frag locks tables before unsetting the $lock_type $for_rsid_on_host";
			return $lock_unset;
		}

		try {
			$frag_locks_info = $this->getLockInfo($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id,$weight,FALSE);
		} catch (Exception $e) {
			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnLockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}
			
			throw $e;
		}

		if (count($frag_locks_info) != 1) {
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "got the wrong number of lock info records (" . count($frag_locks_info) . ") when attempting to unset the $lock_type $for_rsid_on_host";
			$lock_unset = false;

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnLockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			return $lock_unset;
		}

		$frag_locks_info_record = reset($frag_locks_info);

		if (strlen($locked_by) > 0) {
			if ($locked_by != $frag_locks_info_record['locked_by']) {
				$lock_unset = FALSE;

				$for_rsid_on_host = "on $host";
				if ($rsid) $for_rsid_on_host = "for $rsid on $host";
				$this->message = "the locked_by value ($locked_by) is different than locked_by value (" . $frag_locks_info_record['locked_by'] . ") in the lock when attempting to unset the $lock_type $for_rsid_on_host";

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnLockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				return $lock_unset;
			}
		}

		if (strlen($lock_host) > 0) {
			if ($lock_host != $frag_locks_info_record['lock_host']) {
				$lock_unset = FALSE;

				$for_rsid_on_host = "on $host";
				if ($rsid) $for_rsid_on_host = "for $rsid on $host";
				$this->message = "the lock_host value ($lock_host) is different than lock_host value (" . $frag_locks_info_record['lock_host'] . ") in the lock when attempting to unset the $lock_type $for_rsid_on_host";

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnLockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				return $lock_unset;
			}
		}

		if ($lock_id > 0) {
			if ($lock_id != $frag_locks_info_record['lock_id']) {
				$lock_unset = FALSE;

				$for_rsid_on_host = "on $host";
				if ($rsid) $for_rsid_on_host = "for $rsid on $host";
				$this->message = "the lock_id value ($lock_id) is different than lock_id value (" . $frag_locks_info_record['lock_id'] . ") in the lock when attempting to unset the $lock_type $for_rsid_on_host";

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnLockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				return $lock_unset;
			}
		}

		$locked_by = $frag_locks_info_record['locked_by'];
		$lock_host = $frag_locks_info_record['lock_host'];
		$lock_id = $frag_locks_info_record['lock_id'];
		$weight = $frag_locks_info_record['weight'];
		$start_time = $frag_locks_info_record['start_time'];
		$expire_time = $frag_locks_info_record['expire_time'];
		$modified_time = $frag_locks_info_record['modified_time'];

		try {
			$lock_type_value = $this->getLockTypeValue($lock_type);
		} catch (Exception $e) {

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnLockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			throw $e;
		}

		if ($lock_type_value < 1) {
			$lock_unset = FALSE;

			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			$this->message = "invalid lock_type_value ($lock_type_value) for lock_type ($lock_type) when attempting to unset the $lock_type $for_rsid_on_host";

			// unlock the locked tables
			try {
				$tables_unlocked = $this->mysqlUnLockFragLocksTables();
			} catch (Exception $ignore_exception) {
			}

			return $lock_unset;
		}

		$sql = "DELETE $this->sql_comment FROM frag_locks";
		$sql .= " WHERE host = '" . $this->sdb->escape_string($host) . "'";
		$sql .= " AND rsid = '" . $this->sdb->escape_string($rsid) . "'";
		$sql .= " AND type = $lock_type_value";
		$sql .= " AND locked_by = '$locked_by'";
		$sql .= " AND lock_host = '$lock_host'";
		$sql .= " AND lock_id = $lock_id";
		$sql .= " AND weight = $weight";
		$sql .= " AND start_time = '$start_time'";
		$sql .= " AND expire_time = '$expire_time'";
		$sql .= " AND modified_time = '$modified_time'";
		$sql .= " LIMIT 1";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if (!$this->sdb->query($sql)) {

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnlockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}
			
				throw new Exception("MySQL Error " . $this->sdb->Errno . ": " . $this->sdb->Error . " returned from sql - $sql");
			} else {
				$lock_unset = TRUE;
			}
			$this->sdb->free();
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$lock_unset = TRUE;
		}				

		if ($lock_unset) {

			$unset_the_deprecated_lock = TRUE;
			
			// get the related lock types for this lock type
			$lock_types[] = $lock_type;
			
			$related_lock_types = $this->getRelatedLockTypes((array)$lock_type);

			if (!is_array($related_lock_types)) {
				throw new Exception("invalid information was returned from getRelatedLockTypes($lock_type)");
			}
			
			$related_lock_types = array_merge($related_lock_types,$lock_types);
			
			$rsids = '';
			
			if ($rsid) {
				$rsids = 'ALL';
			}

			// do not unset the deprecated lock unless all of the locks and related locks have been unset
			
			// determine if the lock and related locks are set for on this host
			$locked_by = '';
			$lock_host = '';
			$lock_id = 0;
			$weight = -1;

			try {
				$frag_locks_info = $this->getLockInfo($host,$rsids,$related_lock_types,$locked_by,$lock_host,$lock_id,$weight,FALSE);
			} catch (Exception $e) {

				// unlock the locked tables
				try {
					$tables_unlocked = $this->mysqlUnLockFragLocksTables();
				} catch (Exception $ignore_exception) {
				}

				throw $e;
			}

			if ($frag_locks_info) {
				$unset_the_deprecated_lock = FALSE;
			}

			if ($unset_the_deprecated_lock) {
				try {
					if (!$this->unSetDeprecatedLock($host,$lock_type)) {
						$message = $this->message;
						$this->message = "unable to unset the deprecated $lock_type on $host";
						if (strlen($message) > 0) $this->message .= " - " . $message; 
					
						$lock_unset = FALSE;
					}
				} catch (Exception $e) {

					// unlock the locked tables
					try {
						$tables_unlocked = $this->mysqlUnLockFragLocksTables();
					} catch (Exception $ignore_exception) {
					}

					throw $e;
				}
			}

			if (array_key_exists($host,$this->my_locks)) {
				if (array_key_exists($lock_type,$this->my_locks[$host])) {
					if (strlen($rsid) > 0) {
						if (array_key_exists('rsids',$this->my_locks[$host][$lock_type])) {
							$array_key = array_search($rsid,$this->my_locks[$host][$lock_type]['rsids']);
							if ($array_key !== FALSE) {
								unset($this->my_locks[$host][$lock_type]['rsids'][$array_key]);
							}
							if (count($this->my_locks[$host][$lock_type]['rsids']) == 0) {
								unset($this->my_locks[$host][$lock_type]['rsids']);
							}
						}
					} else {
						if (array_key_exists('host',$this->my_locks[$host][$lock_type])) {
							unset($this->my_locks[$host][$lock_type]['host']);
						}
					}
					if (count($this->my_locks[$host][$lock_type]) == 0) {
						unset($this->my_locks[$host][$lock_type]);
					}
					if (count($this->my_locks[$host]) == 0) {
						unset($this->my_locks[$host]);
					}
				}
			}
		}

		// unlock the locked tables
		$tables_unlocked = $this->mysqlUnLockFragLocksTables();

		if (!$tables_unlocked) {
			$lock_unset = FALSE;
			$for_rsid_on_host = "on $host";
			if ($rsid) $for_rsid_on_host = "for $rsid on $host";
			if ($this->execute) {
				$this->message = "the $lock_type was unlocked $for_rsid_on_host, but the frag locks tables were not unlocked";
			} else {
				$this->message = "unable to unlock the frag locks tables";
			}
		}

		return $lock_unset;
	}

	/**
	 * unsets a lock in the previous locking system
	 * 
	 * @param string $host
	 * @param string $lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $deprecated_lock_unset     TRUE - the lock was unset
	 *                                            FALSE - the lock was not unset
	 */
	public function unSetDeprecatedLock($host,$lock_type)
	{
		$deprecated_lock_unset = FALSE;
	
		if (strlen($host) < 1) {
			throw new Exception("host must be specified to unset the deprecated lock");
		}

		if (strlen($lock_type) < 1) {
			throw new Exception("lock_type must be specified to unset the deprecated lock");
		}

		if (!$this->isCompleteLockTypeValid($lock_type)) {
			throw new Exception("lock type [$lock_type] is invalid when attempting to unset the deprecated lock on host [$host]");
		}

		$deprecated_lock_unset = TRUE;

		if ($this->isDeprecatedLockSet($host,$lock_type)) {
			switch($lock_type) {
				case 'archive-lock':
				case 'archive-block':
					if (!$this->release_deprecated_archive_lock($host)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_archive_lock($host) failed";
					}
					break;
				case 'last_minute-lock':
				case 'last_minute-block':
					if (!$this->release_deprecated_last_minute_lock($host)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_last_minute_lock($host) failed";
					}
					break;
				case 'frag_cleanup-lock':
				case 'frag_cleanup-block':
					if (!$this->release_deprecated_cleanup_lock($host)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_cleanup_lock($host) failed";
					}
					break;
				case 'vcookie_cleanup-lock':
				case 'vcookie_cleanup-block':
					if (!$this->release_deprecated_vcookie_cleanup_lock($host)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_vcookie_cleanup_lock($host) failed";
					}
					break;
				case 'minitag-lock':
				case 'minitag-block':
					if (!$this->release_deprecated_minitag_lock($host)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_minitag_lock($host) failed";
					}
					break;
				case 'archive-ctl':
					if (!$this->release_deprecated_archive_ctl($host,FRAG_LOCKS_CTL)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_archive_ctl($host,FRAG_LOCKS_CTL) failed";
					}
					break;
				case 'last_minute-ctl':
					if (!$this->release_deprecated_last_minute_ctl($host,FRAG_LOCKS_CTL)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_last_minute_ctl($host,FRAG_LOCKS_CTL) failed";
					}
					break;
				case 'frag_cleanup-ctl':
					if (!$this->release_deprecated_cleanup_ctl($host,FRAG_LOCKS_CTL)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_cleanup_ctl($host,FRAG_LOCKS_CTL) failed";
					}
					break;
				case 'vcookie_cleanup-ctl':
					if (!$this->release_deprecated_vcookie_cleanup_ctl($host,FRAG_LOCKS_CTL)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_vcookie_cleanup_ctl($host,FRAG_LOCKS_CTL) failed";
					}
					break;
				case 'minitag-ctl':
					if (!$this->release_deprecated_minitag_ctl($host,FRAG_LOCKS_CTL)) {
						$deprecated_lock_unset = FALSE;
						$this->message = "release_deprecated_minitag_ctl($host,FRAG_LOCKS_CTL) failed";
					}
					break;
				default:
					// do not set or fail on all other lock types
					break;
			}
		} else {
			$deprecated_lock_unset = TRUE;
		}

		return $deprecated_lock_unset;
	}

	/**
	 * unsets multiple locks
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $locks_unset     TRUE - the locks were unset
	 *                                  FALSE - the locks were not unset
	 */
	public function unsetLocks($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0)
	{
		$locks_unset = FALSE;

		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts;
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) {
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids;
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}

		if (count($hosts) == 0) {
			throw new Exception("no hosts were specified to unset locks");
		}

		if(count($lock_types) == 0) {
			throw new Exception("no lock types were specified to unset locks");
		}

		foreach($lock_types as $lock_type) {
			if (!$this->isCompleteLockTypeValid($lock_type)) {
				$this->message = "lock_type [$lock_type] is invalid when unsetting locks";
				return $locks_unset;
			}
		}

		$locks_are_set = $this->areLocksSet($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id);

		if (!$locks_are_set) {
			$locks_unset = FALSE;
			if (strlen($this->message) < 1) {
				$this->message = 'the locks are not set when unsetting locks';
			}
			return $locks_unset;
		}

		$hosts_and_rsids = $this->getMatchedHostsAndRsids($hosts,$rsids);

		if (count($hosts_and_rsids)) {
			$locks_unset = TRUE;

			foreach($hosts_and_rsids as $host => $rsids) {
				if (count($rsids) == 0) {
					$rsids[] = ""; // unset the host lock
				}

				foreach($rsids as $rsid) {
					foreach($lock_types as $lock_type) {

						$lock_unset = $this->unsetLock($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id);

						if (!$lock_unset) {
							$locks_unset = FALSE;
							if (strlen($this->message) < 1) {
								$for_rsid_on_host = "on $host";
								if ($rsid) $for_rsid_on_host = "for $rsid on $host";
								$this->message = "unable to unset the $lock_type $for_rsid_on_host";
							}
							break 3;
						}
					}
				}
			}
		} else {
			$locks_unset = FALSE;
			$this->message = "no hosts and rsids were matched to unset locks";
			return $locks_unset;
		}

		return $locks_unset;
	}

	/**
	 * unsets only the locks that are set
	 * 
	 * @param array $hosts
	 * @param array $rsids
	 * @param array $lock_types
	 * @param string $locked_by
	 * @param string $lock_host
	 * @param number $lock_id
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $locks_unset     TRUE - the locks were unset
	 *                                  FALSE - the locks were not unset
	 */
	public function unsetSetLocks($hosts=array(),$rsids=array(),$lock_types=array(),$locked_by='',$lock_host='',$lock_id=0)
	{
		$locks_unset = FALSE;
	
		if (!is_array($hosts)) {
			if (strlen($hosts) > 0) {
				$hosts = (array)$hosts;
			} else {
				$hosts = array();
			}
		}
		if (!is_array($rsids)) {
			if (strlen($rsids) > 0) {
				$rsids = (array)$rsids;
			} else {
				$rsids = array();
			}
		}
		if (!is_array($lock_types)) {
			if (strlen($lock_types) > 0) {
				$lock_types = (array)$lock_types;
			} else {
				$lock_types = array();
			}
		}
	
		if (count($hosts) == 0) {
			throw new Exception("no hosts were specified to unset locks");
		}
	
		foreach($lock_types as $lock_type) {
			if (!$this->isCompleteLockTypeValid($lock_type)) {
				$this->message = "lock_type [$lock_type] is invalid when unsetting locks";
				return $locks_unset;
			}
		}
	
		$weight = -1;
	
		$frag_locks_info = $this->getLockInfo($hosts,$rsids,$lock_types,$locked_by,$lock_host,$lock_id,$weight,FALSE);
	
		if ($frag_locks_info) {
			$locks_unset = TRUE;
	
			foreach($frag_locks_info as $frag_locks_info_record) {
				$host = $frag_locks_info_record['host'];
				$rsid = $frag_locks_info_record['rsid'];
				$lock_type_name = $this->getLockTypeName($frag_locks_info_record['type']);
	
				$lock_unset = $this->unsetLock($host,$rsid,$lock_type_name,
						$frag_locks_info_record['locked_by'],
						$frag_locks_info_record['lock_host'],
						$frag_locks_info_record['lock_id'],
						$frag_locks_info_record['weight']);
	
				if (!$lock_unset) {
					$locks_unset = FALSE;
					if (strlen($this->message) > 0) {
						$previous_message = $this->message;
					}
					$for_rsid_on_host = "on $host";
					if ($rsid) $for_rsid_on_host = "for $rsid on $host";
					$this->message = "unable to unset the $lock_type_name $for_rsid_on_host";
					if ($previous_message) {
						$this->message .= " - " . $previous_message;
					}
					break;
				}
			}
		} else {
			$locks_unset = TRUE;
			$this->message = "no locks were found to unset";
			return $locks_unset;
		}
	
		return $locks_unset;
	}

	/**
	 * unsets the locks that have been set by this instantiation of the class
	 * 
	 * @return boolean $my_locks_unset     TRUE - the locks were unset
	 *                                     FALSE - the locks were not unset
	 */
	public function unsetMyLocks()
	{
		$my_locks_unset = FALSE;

		if (count($this->my_locks) > 0) {
			foreach($this->my_locks as $host => $host_info) {
				foreach($host_info as $lock_type => $lock_type_info) {
					foreach($lock_type_info as $host_or_rsids => $info) {
						switch($host_or_rsids) {
							case 'host':
								
								$lock_is_set = $this->isLockSet($host,'',$lock_type);

								if ($lock_is_set) {
									$lock_unset = $this->unsetLock($host,'',$lock_type);

									if (!$lock_unset) {
										$my_locks_unset = FALSE;
										$this->message = "the $lock_type was not unset on $host when unsetting all locks for the object";
										return $my_locks_unset;
									}
								} else {
									$my_locks_unset = FALSE;
									$this->message = "the $lock_type is not set on $host when unsetting all locks for the object";
									return $my_locks_unset;
								}
								break;
							case 'rsids':
								$hosts = array($host);
								$rsids = $info;
								$lock_types = array($lock_type);
									
								$locks_are_set = $this->areLocksSet($hosts,$rsids,$lock_types);

								if ($locks_are_set) {

									foreach($rsids as $rsid) {
										
										$lock_unset = $this->unsetLock($host,$rsid,$lock_type);

										if (!$lock_unset) {
											$locks_unset = FALSE;
											$this->message = "the $lock_type was not unset for $rsid on $host";
											return $locks_unset;
										}
									}
								} else {
									$locks_unset = FALSE;
									$this->message = "the $lock_type is not set on $host";
									if (count($info) > 0) {
										$this->message .= " for these report suites: " . implode(' ',$info);
									}
									return $locks_unset;
								}
								break;
						}
					}
				}
			}

			$locks_unset = TRUE;
			$this->message = "all locks that were set by this object have been unset";
			return $locks_unset;
		} else {
			$locks_unset = TRUE;
			$this->message = "there are no locks set by this object to unset";
			return $locks_unset;
		}

		return $locks_unset;
	}

	/**
	 * unset all locks that have expired
	 * 
	 * @throws Exception
	 * 
	 * @return boolean $expired_locks_unset     TRUE - the expired locks were unset
	 *                                          FALSE - the expired locks were not unset
	 */
	public function unsetExpiredLocks()
	{
		$expired_locks_unset = TRUE;
		
		$expired_locks = $this->getExpiredLocks();
		
		foreach($expired_locks as $expired_lock) {
			$host = $expired_lock['host'];
			$rsid = $expired_lock['rsid'];
			$type = $expired_lock['type'];

			$lock_type = $this->getLockTypeName($type);

			if (strlen($lock_type) < 1) {
				throw new Exception("unable to get the lock type name for type [$type] when unsetting expired locks");
			}

			$locked_by = $expired_lock['locked_by'];
			$lock_host = $expired_lock['lock_host'];
			$lock_id = $expired_lock['lock_id'];

			$lock_unset = $this->unsetLock($host,$rsid,$lock_type,$locked_by,$lock_host,$lock_id);

			if (!$lock_unset) {
				$expired_locks_unset = FALSE;
				$this->message = "unable to unset the expired [$lock_type] lock for rsid [$rsid] on host [$host] with $locked_by - $lock_host - $lock_id";
				break;
			}
		}

		return $expired_locks_unset;
	}

	/**
	 * The functions that will almost always be called will be handled by this function.
	 * The function call must be in the format <action>_<lock_name>_<lock_type> in lower case where:
	 *     1. <action> is one of:
	 *            getinfo                    params - host, rsid, locked_by = '', lock_host= '', lock_id = '', deprecated = true, host_only = false
	 *            isset                params - host, rsid
	 *            isavailable          params - host, rsid, weight = -1
	 *            acquire                    params - host, rsid, locked_by, lock_host, lock_id, weight = -1
	 *            release                    params - host, rsid, locked_by, lock_host, lock_id
	 *     2. <lock_names> are stored in the frag_locks_names table in cache_maintenance. At the time of writing they are:
	 *            archive
	 *            last_minute
	 *            frag_cleanup
	 *            vcookie_cleanup
	 *            minitag
	 *            snap_backup
	 *     3. <lock_types are stored in the frag_locks_types table in cache_maintenance. At the time of writing they are:
	 *            lock
	 *            block
	 *            ctl
	 *
	 *     Some example function calls:
	 *            acquire_last_minute_ctl(host, rsid, locked_by, lock_host, lock_id, weight)
	 *            release_vcookie_cleanup_lock(host, rsid, locked_by, lock_host, lock_id)
	 *            getinfo_archive_block(host, rsid)
	 *
	 *     There are two function calls that do not follow the exact format.
	 *            getinfo_<lock_name>_all(host, rsid, deprecated = true, host_only = false) gets info for all lock types for the given host and rsid
	 *            getinfo_all(host, rsid, deprecated = true, host_only = false) gets info for all lock names and all lock types for the given host and rsid
	 */
	public function __call($method, $args)
	{
		if (!$args) {// no hosts specified
			throw new Exception("no hosts specified");
		}

		$valid_actions = array('getinfo', 'isavailable', 'acquire', 'release', 'isset');
	
		$lock_name_str = '';
	
		$words = explode('_', $method);
		$action = array_splice($words, 0,1);

		if ($action) {
			$action_str = $action[0];
		} else {
			throw new Exception("$method(): action not found");
		}

		$lock_type = array_splice($words, -1);

		if ($lock_type) {
			$lock_type_str = $lock_type[0];
		} else {
			throw new Exception("$method(): lock_type not found");
		}

		if ($words) {
			$lock_name_str = implode('_', $words);
		} else {
			if (!($action_str == 'getinfo' && $lock_type_str == 'all')) {  // getinfo_all is valid
				throw new Exception("$method(): lock_name not found [$action_str] [$lock_type_str]");
			}
		}
	
		// Is action_str valid?
		if (!in_array($action_str, $valid_actions)) {
			throw new Exception("$method(): invalid action [$action_str]");
		}

		// Is lock_name_str valid?
		if ($lock_name_str && !isset($this->lock_names[$lock_name_str])) {  // lock_name_str can be empty if getinfo_all is called
			throw new Exception("$method(): [$lock_name_str] is an invalid lock name");
		}
	
		// Is lock_type_str valid?
		if (!isset($this->lock_types[$lock_type_str]) && !($action_str == 'getinfo' && $lock_type_str == 'all')) {  // getinfo_<lock_name>_all is valid
			throw new Exception("$method(): [$lock_type_str] is an invalid lock type");
		}
		
		$host = $args[0];
		$rsid = $args[1];
		
		// Handle exeptions first
		if ($lock_type_str == 'all') {

			if (strlen($lock_name_str) < 1) $lock_name_str = $lock_type_str;  // getinfo_all case

			$frag_lock_types = $this->getLockTypesForName($lock_name_str);

			$locked_by = $args[2];
			$lock_host = $args[3];
			$lock_id = $args[4];
			$weight = -1;
			if (isset($args[5])) {
				$weight = $args[5];
			}
			$deprecated = TRUE;
			if (isset($args[6])) {
				$deprecated = $args[6];
			}
			
           	return $this->getLockInfo($host, $rsid, $frag_lock_types, $locked_by, $lock_host, $lock_id, $weight, $deprecated);
		}

		$frag_lock_type = $lock_name_str . '-' . $lock_type_str;

		if ($action_str == 'getinfo') {
			// getinfo                 params - host, rsid, locked_by = '', lock_host= '', lock_id = '', deprecated = true
			$locked_by = $args[2];
			$lock_host = $args[3];
			$lock_id = $args[4];
			$weight = -1;
			if (isset($args[5])) {
				$weight = $args[5];
			}
			$deprecated = TRUE;
			if (isset($args[6])) {
				$deprecated = $args[6];
			}
           	return $this->getLockInfo($host, $rsid, $frag_lock_type, $locked_by, $lock_host, $lock_id, $weight, $deprecated);
		} else if ($action_str == 'isset') {
			// isset                   params - host, rsid
			$locked_by = $args[2];
			$lock_host = $args[3];
			$lock_id = $args[4];
			return $this->isLockSet($host, $rsid, $frag_lock_type, $locked_by, $lock_host, $lock_id);
		} else if ($action_str == 'isavailable') {
			// isavailable             params - host, rsid, locked_by = '', weight = -1
			$locked_by = '';
			if (isset($args[2])) {
				$locked_by = $args[2];
			}
			$weight = -1;
			if (isset($args[3])) {
				$weight = $args[3];
			}
			return $this->isLockAvailable($host, $rsid, $frag_lock_type, $locked_by, $weight);
		} else if ($action_str == 'acquire') {
			// acquire                 params - host, rsid, locked_by, lock_host, lock_id, weight = -1
			$locked_by = $args[2];
			$lock_host = $args[3];
			$lock_id = $args[4];
			$weight = -1;
			if (isset($args[5])) {
				$weight = $args[5];
			}
			return $this->setLock($host, $rsid, $frag_lock_type, $locked_by, $lock_host, $lock_id, $weight);
		} else if ($action_str == 'release') {
			// release                 params - host, rsid, locked_by, lock_host, lock_id
			$locked_by = $args[2];
			$lock_host = $args[3];
			$lock_id = $args[4];
			return $this->unsetLock($host, $rsid, $frag_lock_type, $locked_by, $lock_host, $lock_id);
		} else {
			throw new Exception("$method(): invalid frag lock function [$action_str]");
		}
	}

	/**
	 * returns the list of tables that need to be locked in order to set or unset a lock of $frag_lock_type
	 * 
	 * @param string $frag_lock_type
	 * 
	 * @throws Exception
	 * 
	 * @return array $tables 
	 */
	public function getFragLocksTablesFromType($frag_lock_type)
	{
		$tables = array();
	
		list($fl_name, $fl_type) = explode('-', $frag_lock_type);
		
		if (isset($this->lock_names[$fl_name]) && isset($this->lock_types[$fl_type])) {
			$tables[] = 'frag_locks';
			// Get tablenames for old frag locks
			if ($fl_name == 'archive') {
				$tables[] = 'archive_locks';
			} else if ($fl_name == 'last_minute') {
				$tables[] = 'last_minute_locks';
			} else if ($fl_name == 'frag_cleanup') {
				$tables[] = 'fragcleanup_locks';
			} else if ($fl_name == 'vcookie_cleanup') {
				$tables[] = 'vc_cleanup_locks';
			} else if ($fl_name == 'minitag') {
				$tables[] = 'minitag_locks';
			}
		} else {
			throw new Exception("invalid frag_lock_type [$frag_lock_type]");
		}

		return $tables;
	}

	/** Generic function to see if a host is locked in a table.
	 *
	 * Takes a tablename and sees if the lock is set for the member variable host in
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, lock_host, lock_pid.
	 *
	 * @param $tablename The table to search in for the lock. 
	 * @return True if a lock was found.  False if a lock was not found.
	 */ 
	private function _is_deprecated_locked_in_table($tablename, $host)
	{
		$retval = false;
		$sql = "SELECT lock_pid FROM " . $this->sdb->escape_string($tablename) . " WHERE host = '" . $this->sdb->escape_string($host) . "' AND (lock_pid > 0 OR lock_host != '')";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			if ($this->sdb->next_record()) {
				$retval = true;
			}
			$this->sdb->free();
		}
		return $retval;
	}

	public function is_deprecated_archive_locked($host) 
	{
		return $this->_is_deprecated_locked_in_table('archive_locks', $host);
	}

	public function is_deprecated_last_minute_locked($host)
	{
		return $this->_is_deprecated_locked_in_table('last_minute_locks', $host);
	}

	public function is_deprecated_cleanup_locked($host)
	{
		return $this->_is_deprecated_locked_in_table('fragcleanup_locks', $host);
	}

	public function is_deprecated_vcookie_cleanup_locked($host)
	{
		return $this->_is_deprecated_locked_in_table('vc_cleanup_locks', $host);
	}

	public function is_deprecated_minitag_locked($host)
	{
		return $this->_is_deprecated_locked_in_table('minitag_locks', $host);
	}

	/** Generic function to retrieve the current lock information for this->host in a table.
	 *
	 * @param $tablename The table to search in for the lock. 
	 * @param $host The host that the lock belongs to. 
	 * @return 
	 */ 
	private function _get_deprecated_extended_lock_info($tablename, $host)
	{
		$retval = array('', 0, '', '');
		$sql = "SELECT lock_host, lock_pid, start_time, finish_time, update_dt_tm FROM " . $this->sdb->escape_string($tablename) . " WHERE host = '" . $this->sdb->escape_string($host) . "'";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			if ($this->sdb->next_record()) {
				$retval = array($this->sdb->f('lock_host'), $this->sdb->f('lock_pid'), $this->sdb->f('start_time'), $this->sdb->f('finish_time'), $this->sdb->f('update_dt_tm'));
			}
			$this->sdb->free();
		}

		return $retval;
	}

	public function get_deprecated_extended_vcookie_cleanup_lock_info($host) 
	{
		return $this->_get_deprecated_extended_lock_info('vc_cleanup_locks', $host);
	}

	public function get_deprecated_extended_archive_lock_info($host) 
	{
		return $this->_get_deprecated_extended_lock_info('archive_locks', $host);
	}

	public function get_deprecated_extended_last_minute_lock_info($host) 
	{
		return $this->_get_deprecated_extended_lock_info('last_minute_locks', $host);
	}

	public function get_deprecated_extended_cleanup_lock_info($host) 
	{
		return $this->_get_deprecated_extended_lock_info('fragcleanup_locks', $host);
	}

	public function get_deprecated_extended_minitag_lock_info($host) 
	{
		return $this->_get_deprecated_extended_lock_info('minitag_locks', $host);
	}

	public function set_deprecated_vcookie_cleanup_lock($host, $pid, $lock_host)
	{
		return $this->_set_deprecated_lock_in_table('vc_cleanup_locks', $host, $pid, $lock_host);
	}

	public function set_deprecated_archive_lock($host, $pid, $lock_host)
	{
		return $this->_set_deprecated_lock_in_table('archive_locks', $host, $pid, $lock_host);
	}

	public function set_deprecated_last_minute_lock($host, $pid, $lock_host)
	{
		return $this->_set_deprecated_lock_in_table('last_minute_locks', $host, $pid, $lock_host);
	}

	public function set_deprecated_cleanup_lock($host, $pid, $lock_host)
	{
		return $this->_set_deprecated_lock_in_table('fragcleanup_locks', $host, $pid, $lock_host);
	}
	
	public function set_deprecated_minitag_lock($host, $pid, $lock_host)
	{
		return $this->_set_deprecated_lock_in_table('minitag_locks', $host, $pid, $lock_host);
	}

	/** Generic function to set a lock in a table.
	 *
	 * Takes a tablename and sets the lock for the a given host in 
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, lock_host, lock_pid, start_time.
	 *
	 * If $force is set to false then an existing lock will not be overridden.
	 * Otherwise an existing lock will be ignored.
	 *
	 * @param $tablename The table to set in which to set the lock. 
	 * @param $host The host that the lock belongs to. 
	 * @param $pid The pid number to use when setting the lock.
	 * @param $lock_host The host string to use when setting the lock.
	 * @param $force  Bool. Determines if it should override an existing lock.
	 * @return True if a lock was found.  False if a lock was not found.
	 */ 
	private function _set_deprecated_lock_in_table($tablename, $host, $pid, $lock_host, $force = false)
	{
		$db = &$this->sdb;

		$sql = "SELECT * FROM " . $db->escape_string($tablename) . " WHERE host = '" . $db->escape_string($host) . "'";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($db->query($sql)) {
			if (!$db->next_record()){
				$db->free();

				$sql = "INSERT INTO " . $db->escape_string($tablename) . " (host, lock_host, lock_pid, start_time) VALUES ('" . $db->escape_string($host) . "', '" . $db->escape_string($lock_host) . "', $pid, now() )";
				if ($this->display_sql) echo("\nsql [$sql]\n\n");

				if ($this->execute) {
					if ($db->query($sql)) {
						$db->free();
						return true;
					}
				} else {
					if ($this->display_sql) echo("\nsql [$sql] not executed\n\n");
					return true;
				}
			}
			$db->free();
		}

		$sql = "UPDATE " . $db->escape_string($tablename) . " set start_time = now(), lock_pid = $pid, lock_host = '" . $db->escape_string($lock_host) . "', finish_time = '' WHERE host = '" . $db->escape_string($host) . "'";
		if (!$force) $sql .= ' AND lock_pid = 0 AND lock_host = ""';
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if ($db->query($sql)) {
				if ($db->affected_rows() > 0) {
					$db->free();
					return true;
				}
				$db->free();
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			return true;
		}

		return false;
	}

	/** Generic function to clear a lock in a table.
	 *
	 * Takes a tablename and clears the lock for the given host in 
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, lock_host, lock_pid, finish_time.
	 *
	 * If ($locked_pid != 0 || $locked_host != '') then the clear is treated like a 
	 * release.  This means that that we only clear the lock if we match the 
	 * the information that it was locked with.
	 *
	 * @param $tablename The table to set in which to set the lock. 
	 * @param $host The host that the lock belongs to. 
	 * @param $locked_pid The pid number to use when releasing the lock.
	 * @param $locked_host The host string to use when releasing the lock.
	 * @return True if a lock was found.  False if a lock was not found.
	 */ 
	public function _clear_deprecated_lock_in_table($tablename, $host, $locked_pid = 0, $locked_host = '')
	{
		$retval = false;

		$sql = "UPDATE " . $this->sdb->escape_string($tablename) . " SET lock_pid = 0, lock_host = '', finish_time = now() WHERE host = '" . $this->sdb->escape_string($host) . "'";
		//if a locked_pid or locked_host was passed in then we want to treat this as a lock release meaning that we only clear the lock if we match what it was locked with.
		if ($locked_pid != 0 || $locked_host != '') {
			$release = true;
			$sql .= " AND lock_pid = $locked_pid AND lock_host = '" . $this->sdb->escape_string($locked_host) . "'";
		}
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if ($this->sdb->query($sql)) {
				if (!$release || $this->sdb->affected_rows() > 0) {
					$retval = true;
				}
				$this->sdb->free();
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$retval = true;
		}

		return $retval;
	}

	/** Releases the previously acquired vcookie_cleanup lock
	 *
	 * If a vcookie_cleanup lock was previously acquired, this function will try and release it.
	 * It uses the internally stored lock pid, lock host information.  This information 
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has 
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if it was a successful release. False if there was no lock to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_vcookie_cleanup_lock($host)
	{
		$retval = false;

		if ($host !='') {
			$retval = $this->_clear_deprecated_lock_in_table('vc_cleanup_locks', $host, OLD_LOCKS_PID, OLD_LOCKS_HOST); 
		}
		return $retval;
	}

	/** Releases the previously acquired archive lock
	 *
	 * If a archive lock was previously acquired, this function will try and release it.
	 * It uses the internally stored lock pid, lock host information.  This information 
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has 
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if it was a successful release. False if there was no lock to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_archive_lock($host)
	{
		$retval = false;

		if ($host !='') {
			$retval = $this->_clear_deprecated_lock_in_table('archive_locks', $host, OLD_LOCKS_PID, OLD_LOCKS_HOST); 
		}
		return $retval;
	}

	/** Releases the previously acquired last_minute lock
	 *
	 * If a archive lock was previously acquired, this function will try and release it.
	 * It uses the internally stored lock pid, lock host information.  This information 
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has 
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if it was a successful release. False if there was no lock to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_last_minute_lock($host)
	{
		$retval = false;

		if ($host !='') {
			$retval = $this->_clear_deprecated_lock_in_table('last_minute_locks', $host, OLD_LOCKS_PID, OLD_LOCKS_HOST); 
		}
		return $retval;
	}

	/** Releases the previously acquired frag cleanup lock
	 *
	 * If a archive lock was previously acquired, this function will try and release it.
	 * It uses the internally stored lock pid, lock host information.  This information 
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has 
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if it was a successful release. False if there was no lock to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_cleanup_lock($host)
	{
		$retval = false;

		if ($host !='') {
			$retval = $this->_clear_deprecated_lock_in_table('fragcleanup_locks', $host, OLD_LOCKS_PID, OLD_LOCKS_HOST); 
		}
		return $retval;
	}
	
	/** Releases the previously acquired minitag lock
	 *
	 * If a minitag lock was previously acquired, this function will try and release it.
	 * It uses the internally stored lock pid, lock host information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if it was a successful release. False if there was no lock to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_minitag_lock($host)
	{
		$retval = false;
	
		if ($host !='') {
			$retval = $this->_clear_deprecated_lock_in_table('minitag_locks', $host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Acquire an vcookie_cleanup lock.
	 * This looks to see if the vcookie_cleanup lock is set for the given host
	 * If not it sets the lock using the information from the parameters.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if the lock was acquired.  False if the lock could not
	 *   be acquired.
	 */
	public function acquire_deprecated_vcookie_cleanup_lock($host)
	{
		$retval = false;
		if (!$this->is_deprecated_vcookie_cleanup_locked($host)) {
			$retval = $this->set_deprecated_vcookie_cleanup_lock($host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Acquire an archive lock.
	 * This looks to see if the archive lock is set for the given host
	 * If not it sets the lock using the information from the parameters.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if the lock was acquired.  False if the lock could not
	 *   be acquired.
	 */
	public function acquire_deprecated_archive_lock($host)
	{
		$retval = false;
		if (!$this->is_deprecated_archive_locked($host)) {
			$retval = $this->set_deprecated_archive_lock($host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Acquire a last_minute lock.
	 * This looks to see if the last_minute lock is set for the given host
	 * If not it sets the lock using the information from the parameters.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if the lock was acquired.  False if the lock could not
	 *   be acquired.
	 */
	public function acquire_deprecated_last_minute_lock($host)
	{
		$retval = false;
		if (!$this->is_deprecated_last_minute_locked($host)) {
			$retval = $this->set_deprecated_last_minute_lock($host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Acquire a frag cleanup lock.
	 * This looks to see if the frag cleanup lock is set for the given host
	 * If not it sets the lock using the information from the parameters.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if the lock was acquired.  False if the lock could not
	 *   be acquired.
	 */
	public function acquire_deprecated_cleanup_lock($host)
	{
		$retval = false;
		if (!$this->is_deprecated_cleanup_locked($host)) {
			$retval = $this->set_deprecated_cleanup_lock($host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Acquire a minitag lock.
	 * This looks to see if the frag cleanup lock is set for the given host
	 * If not it sets the lock using the information from the parameters.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @return True if the lock was acquired.  False if the lock could not
	 *   be acquired.
	 */

	public function acquire_deprecated_minitag_lock($host)
	{
		$retval = false;
		if (!$this->is_deprecated_minitag_locked($host)) {
			$retval = $this->set_deprecated_minitag_lock($host, OLD_LOCKS_PID, OLD_LOCKS_HOST);
		}
		return $retval;
	}

	/** Generic function to see if the ctl flag is set for a host in a table.
	 *
	 * Takes a tablename and sees if the ctl is set for the given host in
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, ctl.
	 *
	 * @param $tablename The table to search in for the ctl flag.
	 * @param $host The host that the lock belongs to. 
	 * @return True if ctl was set.  False if ctl was not set.
	 */
	private function _is_deprecated_ctl_set_in_table($tablename, $host)
	{
		$retval = false;
		$sql = "SELECT ctl FROM " . $this->sdb->escape_string($tablename) . " WHERE host = '" . $this->sdb->escape_string($host) . "' AND ctl > 0";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			if ($this->sdb->next_record()) {
				$retval = true;
			}
			$this->sdb->free();
		}
		return $retval;
	}

	public function is_deprecated_archive_ctl_set($host)
	{
		return $this->_is_deprecated_ctl_set_in_table('archive_locks', $host);
	}

	public function is_deprecated_last_minute_ctl_set($host)
	{
		return $this->_is_deprecated_ctl_set_in_table('last_minute_locks', $host);
	}

	public function is_deprecated_cleanup_ctl_set($host)
	{
		return $this->_is_deprecated_ctl_set_in_table('fragcleanup_locks', $host);
	}

	public function is_deprecated_vcookie_cleanup_ctl_set($host)
	{
		return $this->_is_deprecated_ctl_set_in_table('vc_cleanup_locks', $host);
	}

	public function is_deprecated_minitag_ctl_set($host)
	{
		return $this->_is_deprecated_ctl_set_in_table('minitag_locks', $host);
	}

	/** Generic function to retrieve the current ctl flag information for this->host in a table.
	 *
	 * @param $tablename The table to search in for the lock.
	 * @param $host The host that the lock belongs to. 
	 * @return ctl
	 */
	private function _get_deprecated_ctl_info($tablename, $host)
	{
		$retval = 0;
		$sql = "SELECT ctl FROM " . $this->sdb->escape_string($tablename) . " WHERE host = '" . $this->sdb->escape_string($host) . "'";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->sdb->query($sql)) {
			if ($this->sdb->next_record()) {
				$retval = $this->sdb->f('ctl');
			}
			$this->sdb->free();
		}
		return $retval;
	}

	public function get_deprecated_vcookie_cleanup_ctl_info($host)
	{
		return $this->_get_deprecated_ctl_info('vc_cleanup_locks', $host);
	}

	public function get_deprecated_archive_ctl_info($host)
	{
		return $this->_get_deprecated_ctl_info('archive_locks', $host);
	}

	public function get_deprecated_last_minute_ctl_info($host)
	{
		return $this->_get_deprecated_ctl_info('last_minute_locks', $host);
	}

	public function get_deprecated_cleanup_ctl_info($host)
	{
		return $this->_get_deprecated_ctl_info('fragcleanup_locks', $host);
	}

	public function get_deprecated_minitag_ctl_info($host)
	{
		return $this->_get_deprecated_ctl_info('minitag_locks', $host);
	}

	public function set_deprecated_vcookie_cleanup_ctl($host, $value)
	{
		return $this->_set_deprecated_ctl_in_table('vc_cleanup_locks', $host, $value);
	}

	public function set_deprecated_archive_ctl($host, $value)
	{
		return $this->_set_deprecated_ctl_in_table('archive_locks', $host, $value);
	}

	public function set_deprecated_last_minute_ctl($host, $value)
	{
		return $this->_set_deprecated_ctl_in_table('last_minute_locks', $host, $value);
	}

	public function set_deprecated_cleanup_ctl($host, $value)
	{
		return $this->_set_deprecated_ctl_in_table('fragcleanup_locks', $host, $value);
	}

	public function set_deprecated_minitag_ctl($host, $value)
	{
		return $this->_set_deprecated_ctl_in_table('minitag_locks', $host, $value);
	}

	/** Generic function to set a ctl flag in a table.
	 *
	 * Takes a tablename and sets the ctl flag for the given host in
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, ctl.
	 *
	 * If $force is set to false then an existing ctl will not be overridden.
	 * Otherwise an existing ctl will be ignored.
	 *
	 * @param $tablename The table to set in which to set the lock.
	 * @param $host The host that the lock belongs to. 
	 * @param $value The value to use when setting the ctl. Usually from bert_user_info
	 * @param $force  Bool. Determines if it should override an existing ctl.
	 * @return True if a ctl was set.  False if a ctl was not set.
	 */
	private function _set_deprecated_ctl_in_table($tablename, $host, $value, $force = false)
	{
		$db = &$this->sdb;

		$sql = "SELECT * FROM " . $db->escape_string($tablename) . " WHERE host = '" . $db->escape_string($host) . "'";
		if ($this->display_sql) echo("\nsql [$sql]\n\n");
		
		if ($db->query($sql)) {
			if (!$db->next_record()){
				$db->free();

				$sql = "INSERT INTO " . $db->escape_string($tablename) . " (host, ctl) VALUES ('" . $db->escape_string($host) . "', $value)";
				if ($this->display_sql) echo("\nsql [$sql]\n\n");

				if ($this->execute) {
					if ($db->query($sql)) {
						$db->free();
						return true;
					}
				} else {
					if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
					return true;
				}
			}
			$db->free();
		}

		$sql = "UPDATE " . $db->escape_string($tablename) . " SET ctl = $value WHERE host = '" . $db->escape_string($host) . "'";
		if (!$force) $sql .= ' AND ctl = 0';
		if ($this->display_sql) echo("\nsql [$sql]\n\n");
		
		if ($this->execute) {
			if ($db->query($sql)) {
				if ($db->affected_rows() > 0) {
					$db->free();
					return true;
				}
				$db->free();
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			return true;
		}

		return false;
	}

	/** Generic function to clear a ctl in a table.
	 *
	 * Takes a tablename and clears the ctl for the given host in
	 * the given table.  The table must exist in superstatsdb.  The table must have
	 * the fields: host, ctl.
	 *
	 * If $value != 0 then the clear is treated like a release.  
	 * This means that that we only clear the ctl if the $value matches the
	 * the information that is in the ctl field.
	 *
	 * @param $tablename The table to set in which to clear the ctl flag.
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value to use when releasing the ctl flag.
	 * @return True if the ctl was cleared.  False if the ctl was not cleared.
	 */
	public function _clear_deprecated_ctl_in_table($tablename, $host, $value = 0)
	{
		$retval = false;

		$sql = "UPDATE " . $this->sdb->escape_string($tablename) . " SET ctl = 0 WHERE host = '" . $this->sdb->escape_string($host) . "'";
		//if a $value for ctl was passed in then we want to treat this as a ctl release meaning that we only clear the ctl if we match what it was set with.
		if ($value != 0) {
			$release = true;
			$sql .= " AND ctl = $value";
		}
		if ($this->display_sql) echo("\nsql [$sql]\n\n");

		if ($this->execute) {
			if ($this->sdb->query($sql)) {
				if (!$release || $this->sdb->affected_rows() > 0) {
					$retval = true;
				}
				$this->sdb->free();
			}
		} else {
			if ($this->verbose && $this->display_sql) echo("\nsql [$sql] not executed\n\n");
			$retval = true;
		}

		return $retval;
	}

	/** Releases the previously set vcookie_cleanup ctl flag
	 *
	 * If a vcookie_cleanup ctl was previously set, this function will try and release it.
	 * It uses the internally stored ctl information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value that must match when releasing the ctl flag.
	 * @return True if it was a successful release. False if there was no ctl to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_vcookie_cleanup_ctl($host, $value = 0)
	{
		$retval = false;

		if ($value != 0) {
			$retval = $this->_clear_deprecated_ctl_in_table('vc_cleanup_locks', $host, $value);
		}
		return $retval;
	}

	/** Releases the previously set archive ctl flag
	 *
	 * If a archive ctl was previously set, this function will try and release it.
	 * It uses the internally stored ctl information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value that must match when releasing the ctl flag.
	 * @return True if it was a successful release. False if there was no ctl to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_archive_ctl($host, $value = 0)
	{
		$retval = false;

		if ($value != 0) {
			$retval = $this->_clear_deprecated_ctl_in_table('archive_locks', $host, $value);
		}
		return $retval;
	}

	/** Releases the previously set last_minute ctl flag
	 *
	 * If a last_minute ctl was previously set, this function will try and release it.
	 * It uses the internally stored ctl information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value that must match when releasing the ctl flag.
	 * @return True if it was a successful release. False if there was no ctl to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_last_minute_ctl($host, $value = 0)
	{
		$retval = false;

		if ($value != 0) {
			$retval = $this->_clear_deprecated_ctl_in_table('last_minute_locks', $host, $value);
		}
		return $retval;
	}

	/** Releases the previously set frag_cleanup ctl flag
	 *
	 * If a frag_cleanup ctl was previously set, this function will try and release it.
	 * It uses the internally stored ctl information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value that must match when releasing the ctl flag.
	 * @return True if it was a successful release. False if there was no ctl to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_cleanup_ctl($host, $value = 0)
	{
		$retval = false;

		if ($value != 0) {
			$retval = $this->_clear_deprecated_ctl_in_table('fragcleanup_locks', $host, $value);
		}
		return $retval;
	}

	/** Releases the previously set minitag ctl flag
	 *
	 * If a minitag ctl was previously set, this function will try and release it.
	 * It uses the internally stored ctl information.  This information
	 * is cleared whether the release was successful or not.  This is because on success
	 * we don't need the information anymore and on failure it means someone else has
	 * grabbed the lock and we don't own it anymore.
	 *
	 * @param $host The host that the lock belongs to. 
	 * @param $value  The ctl value that must match when releasing the ctl flag.
	 * @return True if it was a successful release. False if there was no ctl to release
	 *   or someone else now owns the lock and we can't release it.
	 */
	public function release_deprecated_minitag_ctl($host, $value = 0)
	{
		$retval = false;

		if ($value != 0) {
			$retval = $this->_clear_deprecated_ctl_in_table('minitag_locks', $host, $value);
		}
		return $retval;
	}

} // end class

