<?php

/*************************************************************************
*
* ADOBE CONFIDENTIAL
* ___________________
*
*  (c) Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and may be covered by U.S. and Foreign Patents,
* patents in process, and are protected by trade secret or copyright law.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * @author Brian Saville
 * @author Robert Hickman
 * @author Matt Gould
 */

class VcClusterAdminApiException extends Exception {}

class VcClusterAdminApi {

	protected $access_token = NULL;
	protected $dry_run = false;
	
	// Variables for use in dry-run mode
	protected $progress_min_inc = 100;
	protected $progress_max_inc = 100;
	protected $job_id_counter = 0;
	protected $jobs = array();
	

	/**
	 * Creates an object to interact with the Cookie Monster Admin Web Service
	 * @link https://wiki.corp.adobe.com/display/omtrcache/Cookie+Monster+Admin+Web+Service
	 * 
	 * @param string $access_token A valid IMS access token (not used in dry-run mode)
	 * @param bool $dry_run Set to true to pretend that things are happening
	 * @param int $progress_min_inc The minimum percent a job will look to have progressed each time the progess is queried during a dry run
	 * @param int $progress_max_inc The maximum percent a job will look to have progressed each time the progess is queried during a dry run
	 */
	public function __construct($access_token, $dry_run = false, $progress_min_inc = 100, $progress_max_inc = 100) {
		if ($dry_run) {
			$this->dry_run = $dry_run;
			$this->progress_min_inc = $progress_min_inc;
			$this->progress_max_inc = $progress_max_inc;
		} else {
			$this->access_token = $access_token;
		}
	}

	private function getUrl($dc, $path, $use_secure_protocol = false, $domain_prefix="cm-admin.") {
		$port = 8080;
		if (DATA_CENTER === DATA_CENTER_DEV) {
			// Special override for integration tests 
			if (defined('DMIG_DOCKER')) {
				$dc = DATA_CENTER_DPC . ".ut1";
				$port = 1042;
			} else {
				$dc = "dev.ut1";
			}
		} else {
			// Always use PNW since this is currently the only place the API is deployed in production
			$dc = "pnw";
		}
		$domain = $domain_prefix . strtolower($dc) . ".omniture.com";
		$protocol = 'http';
		if ($use_secure_protocol) {
			$protocol = 'https';
		}
		return "$protocol://$domain:$port$path";
	}

	private function initCurl($url) {
		$ch = curl_init($url);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HTTPHEADER, array(
			"Authorization: Bearer " . $this->access_token,
			"Content-Type: application/json"
		));
		return $ch;
	}

	private function handleResponse($ch, $url, $post_data) {
		$response = curl_exec($ch);
		$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		echo "Received response $response\n";

		$decoded_response = json_decode($response, true);
		if ($decoded_response == NULL) {
			throw new VcClusterAdminApiException("There was an error decoding the response from $url. Post data: " . json_encode($post_data)
					. " Status: $status, PHP JSON Error Code: " . json_last_error() . ", Raw Response: $response");
		}
		if ($status < 200 || $status >= 300) {
			throw new VcClusterAdminApiException("The CMA API returned an error from $url.  Post data: " . json_encode($post_data)
					. " Status: $status, Error Message: {$decoded_response['errorMessage']}");
		}

		return $decoded_response;
	}

	/**
	 * Submits a copy job
	 * @link https://wiki.corp.adobe.com/display/omtrcache/Cookie+Monster+Admin+Web+Service
	 * 
	 * @param string $source_dc The datacenter of the source cluster
	 * @param string $source_cluster Source VCookie cluster where the data will be copied from.
	 * @param string $target_cluster VCookie cluster where the data will be copied to
	 * @param array(int) $userids An array of numeric userids whose associated vcookie records will be copied
	 * @param int $start_time Unix timestamp that denotes the start of a time range where vcookie records created at or after which should be copied
	 * @param int $end_time Unix timestamp that denotes the end of a time range where vcookie records created at or before should be copied
	 * @return array('id' => job id, 'success' => true/false, 'message' => error message)
	 */
	public function submitCopyJob($source_dc, $source_cluster, $target_cluster, $userids, $start_time = null, $end_time = null) {
		if ($this->dry_run) {
			$job_id = ++$this->job_id_counter;
			$this->jobs[$job_id] = 1;
			return array (
				'id' => $job_id,
				'success' => true,
				'message' => ''
			);
		}
		
		$url = $this->getUrl($source_dc, "/cma/copy");
		$ch = $this->initCurl($url);

		$post_data = array(
			"sourceCluster" => $source_cluster,
			"targetCluster" => $target_cluster,
			"reportSuiteIDs" => $userids,
		);
		if (!empty($start_time)) {
			$post_data["startDate"] = $start_time;
		}
		if (!empty($end_time)) {
			$post_data["endDate"] = $end_time;
		}
		echo "Sending POST request to $url with data: " . json_encode($post_data) . "\n";

		$options = array(
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($post_data)
		);
		curl_setopt_array($ch, $options);

		$decoded_response = $this->handleResponse($ch, $url, $post_data);
		return array(
			'success' => !empty($decoded_response['id']) ? true : false,
			'id' => $decoded_response['id'],
			'message' => $decoded_response['errorMessage']
		);
	}

	/**
	 * Get the status of a particular copy job
	 * https://wiki.corp.adobe.com/display/omtrcache/Cookie+Monster+Admin+Web+Service
	 * 
	 * @param string $source_dc The datacenter of the source cluster
	 * @param string $source_cluster Source VCookie cluster where a previous copy job was initiated
	 * @param string $job_id Job ID of previously initiated copy job
	 * 
	 * @return array('state' => State of the job, 'progress' => % done, 'message' => error message)
	 * @uses Valid states are: RUNNING, SUCCEEDED, FAILED, PREP, or KILLED
	 */
	public function getJobStatus($source_dc, $source_cluster, $job_id) {
		if ($this->dry_run) {
			if (!$this->jobs[$job_id]) {
				$progress = 100;
			} else {
				$progress = $this->jobs[$job_id];
				$progress += rand($this->progress_min_inc, $this->progress_max_inc);
				if ($progress > 100) {
					$progress = 100;
				}
				$this->jobs[$job_id] = $progress;
			}
			
			return array(
				'state' => $progress==100 ? 'SUCCEEDED' : 'RUNNING',
				'progress' => "$progress",
				'message' => ''
			);
		}
		
		$url = $this->getUrl($source_dc, "/cma/status");
		$ch = $this->initCurl($url);

		$post_data = array(
			"sourceCluster" => $source_cluster,
			"jobId" => $job_id
		);
		echo "Sending POST request to $url with data: " . json_encode($post_data) . "\n";

		$options = array(
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($post_data)
		);
		curl_setopt_array($ch, $options);

		$decoded_response = $this->handleResponse($ch, $url, $post_data);

		// TODO
		// It isn't clear from the docs if a 400 will occur if the job ID is not found
		// It isn't clear from the docs if an error message will ever accompany a 200

		return array(
			"state" => $decoded_response["jobState"],
			"progress" => ('SUCCEEDED' == $decoded_response["jobState"])?'100':($decoded_response["setupProgress"] + $decoded_response["mapProgress"] + $decoded_response["reduceProgress"] + $decoded_response["cleanupProgress"]) / 4 * 100,
			"message" => $decoded_response["errorMessage"], //TODO Is this valid for the error?
		);
	}

	/**
	 * Get the job id (if any) for each of the userids passed in
	 * https://wiki.corp.adobe.com/display/omtrcache/Cookie+Monster+Admin+Web+Service
	 * 
	 * @param string $source_dc The datacenter of the source cluster
	 * @param string $source_cluster The name of the cluster the data is moving from
	 * @param array[int] $userids An array of numeric userids for which you want to find jobs.
	 * 
	 * @return array('statuses' => array(userid => status, ...), 'message' => error message)
	 */
	public function searchForJobsByUserids($source_dc, $source_cluster, $userids) {
		if ($this->dry_run) {
			$statuses = array();
			foreach ($userids as $userid) {
				$statuses[$userid] = 1;
			}
			return array(
				"statuses" => $statuses,
				"message" => ''
			);
		}

		$url = $this->getUrl($source_dc, "/cma/jobsearch");
		$ch = $this->initCurl($url);

		$post_data = array(
			"sourceCluster" => $source_cluster,
			"reportSuiteIDs" => $userids
		);
		echo "Sending POST request to $url with data: " . json_encode($post_data) . "\n";

		$options = array(
			CURLOPT_POST => true,
			CURLOPT_POSTFIELDS => json_encode($post_data)
		);
		curl_setopt_array($ch, $options);

		$decoded_response = $this->handleResponse($ch, $url, $post_data);

		// TODO
		// It isn't clear from the docs if a 400 will occur if none of the userids are found
		// It isn't clear from the docs if an error message will ever accompany a 200

		return array(
			"statuses" => $decoded_response["jobStatus"], // key value pairs of rsid => jobId
			"message" => $decoded_response["errorMessage"]
		);
	}
}