<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// for executing a shell command
// i am hoping to run ~100 shell commands simultaneously
//  - maybe SSH and execute them on other servers, (in other datacenters)

require_once 'application.inc';
require_once 'class-ha-utilities.php';

class HA_Queue_Item extends HA_Utilities {
	var $command = null;
    var $copy_up = array();
    var $data_center;
	var $has_begun;
	var $is_complete;
	var $output_filename;
	var $pid = null;
	var $pid_filename;
	var $queue_index = 0;
    var $remote_flag;
    var $remote_server = '';
    var $remote_user = '';
	var $return_status;
	var $results_dir;
    var $custom_ps = null;
	
	function __construct($args = array()) {
		
		if( !isset( $args['command'] ) ) {
			$args['command'] = null;
		}
		$this->command( $args['command'] );
		
		if( !isset( $args['copy_up'] ) ) {
			$args['copy_up'] = array();
		}
		$this->copy_up( $args['copy_up'] );
		
		if( !isset( $args['custom_ps'] ) ) {
			$args['custom_ps'] = array();
		}
		$this->custom_ps( $args['custom_ps'] );
		
		if( !isset( $args['data_center'] ) ) {
			$args['data_center'] = null;
		}
		$this->data_center( $args['data_center'] );
		
		if( !isset( $args['queue_index'] ) ) {
			$args['queue_index'] = '';
		}
		$this->queue_index( $args['queue_index'] );
		
		if( !isset( $args['results_dir'] ) ) {
			$args['results_dir'] = null;
		}
		$this->results_dir( $args['results_dir'] );
		
		if( !isset( $args['pid_dir'] ) ) {
			$args['pid_dir'] = null;
		}
		$this->pid_dir( $args['pid_dir'] );
		
		if( !isset( $args['pid_filename'] ) ) {
			$args['pid_filename'] = 'pid-' . $this->queue_index() . '.txt';
		}
		$this->pid_filename( $args['pid_filename'] );
		
		if( !isset( $args['remote_flag'] ) ) {
			$args['remote_flag'] = false;
		}
		$this->remote_flag( $args['remote_flag'] );
		
		if( !isset( $args['remote_server'] ) ) {
			$args['remote_server'] = '';
		}
		$this->remote_server( $args['remote_server'] );
		
		if( !isset( $args['remote_user'] ) ) {
			$args['remote_user'] = '';
		}
		$this->remote_user( $args['remote_user'] );
		
		if( !isset( $args['output_filename'] ) ) {
			$args['output_filename'] = 'output-' . $this->queue_index() . '.txt';
		}
		$this->output_filename( $args['output_filename'] );
		
		$this->has_begun   = false;
		$this->is_complete = false;

        if (DATA_CENTER == DATA_CENTER_DEV) {
            $this->data_center_suffixes = array(
                DATA_CENTER_SBX      => 'sbx1',
                DATA_CENTER_DEV      => 'dev.ut1',
            );
        }
        else if (DATA_CENTER == DATA_CENTER_SAN_JOSE) {
            $this->data_center_suffixes = array(
                DATA_CENTER_SAN_JOSE => 'sj2',
                DATA_CENTER_DALLAS   => 'da2',
                DATA_CENTER_SIN      => 'sin2', 
                DATA_CENTER_LON5     => 'lon5',
            );
        }
        else {
            $this->data_center_suffixes = array();
        }
		
		parent::__construct($args);
	}

	function begin() {
        $exec_str = sprintf("%s > %s 2>&1 & echo $! >> %s", 
                $this->command(), $this->output_filename(), $this->pid_filename() );
        
        if ($this->remote_flag) {
            // copy up files
            foreach($this->copy_up as $copy_up) {
                if (file_exists($copy_up)) {
                    $scp_str = 'scp ' . $copy_up . ' ' . $this->remote_info() . ':' . $copy_up;
                    exec($scp_str);
                }
                else {
                    //$this->debug('copy up file does not exist. skipping: ' . $scp_str);
                }
            }

            $exec_str = 'ssh ' . $this->remote_info() . " '" . sprintf("%s' > %s 2>&1 & echo $! >> %s", 
                $this->command(), $this->output_filename(), $this->pid_filename() );
        }

        // http://stackoverflow.com/questions/45953/php-execute-a-background-process#45966
        exec($exec_str);
        $this->debug('exec ' . $exec_str);
        
		$this->has_begun = true;
	}
	
	function command( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->command = $new_value;
		}
		return $this->command;
	}
	
	function copy_up( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->copy_up = $new_value;
		}
		return $this->copy_up;
	}
	
	function custom_ps( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->custom_ps = $new_value;
		}
		return $this->custom_ps;
	}
	
	function data_center( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->data_center = $new_value;
		}
		return $this->data_center;
	}
	
	function is_complete() {
		if ($this->has_begun == true) {
			return !$this->is_running();
		}
		return false;
	}
	
	function is_running() {
        $custom_ps = $this->custom_ps();
		$pid = $this->pid();

		if ( empty( $pid ) && empty( $custom_ps ) ) {
			return false;
		}

		// http://stackoverflow.com/questions/45953/php-execute-a-background-process#45966
		try {
            $exec_str = ($custom_ps == null) ? "ps " . $pid : $custom_ps;
            if ($this->remote_flag) {
                $exec_str = 'ssh ' . $this->remote_info() . " '" . $exec_str . "'";
            }
            //$this->debug('monitor process: ' . $exec_str);

            $result = trim(shell_exec($exec_str));
            $result_lines = preg_split("/\n/", trim($result));
            if( ( $custom_ps == null ) && ( count($result_lines) > 1) ) {
                //$this->debug("normal process check: process still going.");
                return true;
            }
            else if ( ($custom_ps != null) && ( count($result_lines) > 0) && ( strlen($result) > 2 ) ) {
                //$this->debug("custom process check: process still going.");
                return true;
            }
		}
		catch(Exception $e) {
			//$this->debug('shell exec to get pid didn\'t work: ' . $result);
		} 
	
		return false;
	}
	
	function output() {
		if ($this->is_complete()) {
			$output = file_get_contents($this->output_filename());
			return $output;
		}
		return false;
	}
	
	function output_as_array() {
		if ($this->is_complete()) {
			$output = file($this->output_filename());
			return $output;
		}
		return array();
	}
	
	function output_filename( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->output_filename = $this->results_dir() . '/' . $new_value;
		}
		return $this->output_filename;
	}

	function pid( $new_value = null ) {
		$pid_filename = $this->pid_filename();

		if ( !empty( $new_value ) ) {
			$this->pid = $new_value;
		}
		else if ( empty($this->pid) && file_exists($pid_filename)) {

            try {
                // run cat on the main working server; the temp files are stored there.
                $exec_str = "cat " . $pid_filename;
    
                $result = trim(shell_exec($exec_str));
                //echo "pid result is " . $result . " in " . $pid_filename . "\n";
                $this->pid = $result;
            }
            catch(Exception $e) {
                $this->debug('shell exec to get pid didn\'t work: ' . $result);
                $this->pid = 0;
            } 
            
            // && file_exists( $pid_filename ) ) {
			//$this->pid = trim(file_get_contents($pid_filename));
		}
		//print_r($this->pid);
		return $this->pid;
	}
	
	function pid_dir( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->pid_dir = $new_value;
		}
		return $this->pid_dir;
	}
	
	function pid_filename( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->pid_filename = $this->pid_dir() . '/' . $new_value;
		}
		return $this->pid_filename;
	}
	
	function queue_index( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->queue_index = $new_value;
		}
		return $this->queue_index;
	}
	
	function remote_server( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->remote_server = $new_value;
		}
		return $this->remote_server;
	}
	
	function remote_user( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->remote_user = $new_value;
		}
		return $this->remote_user;
	}
	
	function remote_flag( $new_value = null ) {
		if ( ( $new_value == true ) || ( $new_value == false ) ) {
			$this->remote_flag = $new_value;
		}
        
        // remote flag FALSE is there's no remote server!
        //if (!$this->remote_server) {
        //    $this->debug("No remote flag possible for " . $this->command());
        //    return false;
        //}

		return $this->remote_flag;
	}
    
    function remote_info() {
        $remote_info = $this->remote_server();
        if (strlen($this->remote_user()) > 0) {
            $remote_info = $this->remote_user() . '@' . $this->remote_server();
        }
        
        // if no remote server, use localhost.
        if (strlen($this->remote_server()) <= 0) {
            $remote_info = $this->remote_user() . '@localhost';
        }
        
        return $remote_info;
    }
    
	function results_dir( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->results_dir = $new_value;
		}
		return $this->results_dir;
	}
	
}

?>