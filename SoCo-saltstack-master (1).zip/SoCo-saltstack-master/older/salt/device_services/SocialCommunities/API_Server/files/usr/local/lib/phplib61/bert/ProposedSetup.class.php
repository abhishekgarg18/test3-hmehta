<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * @file
 * ProposedSetup is an exploded view of a proposed setup for base or report suite handling current and future servers.
 * the implementation uses nested arrays:
 * $this->setup[USAGE][DC][ATYPE][ALLOCATION] = COUNT;
 * ALLOCATION is name for current or number for future
 *
 * @author Jack Thomasson <thomasso@adobe.com>
 *
 */

require_once 'SetupString.class.php';
require_once 'user_account.class';
require_once 'CacheServerUsage.class';
require_once 'FragServerUsage.class';
require_once 'CacheAllocationTypes.class';
require_once 'FragAllocationTypes.class';

class ProposedSetup extends SetupString implements Countable, ArrayAccess {
	const CACHE = 1;
	const FRAG = 2;
	const BOTH = 3;

	private static $span = array(self::MATCH_USAGE, self::MATCH_DC, self::MATCH_ATYPE, self::MATCH_ALLOCATION, self::MATCH_COUNT);
	const MAXKEYED = 3; // zero reference
	private $dc; ///< preferred data center for this report suite
	private $level; ///< array of ArrayIterator to navigate the nested arrays

	public static function recursive_filter_empty($a) {
		foreach ($a as $k => $v) {
			if (is_array($v))
				$a[$k] = self::recursive_filter_empty($a[$k]);
			if (empty($a[$k]))
				unset($a[$k]);
		}
		return $a;
	}

	private function get_servers_by_family(user_account $ua, $family) {
		$at = ucwords($family).'AllocationTypes';
		$at = new $at;
		$x = 'get_'.strtolower($family).'_servers_by_usage';
		$x = $ua->$x();
		if (array_key_exists(FragServerUsage::VCOOKIE, $x)) {
			$x[FragServerUsage::USER_UNIQUE] = $x[FragServerUsage::VCOOKIE];
			unset($x[FragServerUsage::VCOOKIE]);
		}
		$usage = ucwords($family).'ServerUsage';
		foreach (call_user_func($usage.'::USAGES') as $usage) # stupid PHP 5.2 compatibility
			foreach ($x[$usage] as $host) {
				$v = $at->get_allocation_type($host);
				$this->setup[$usage][substr(strrchr($host, '.'), 1)][strtolower($v[0])][$host] = 1;
			}
	}


	private function resolveWildcard(array &$match, $removed = array()) {
		if (self::RANDOM == $match[self::MATCH_DC])
			$match[self::MATCH_DC] = $removed[self::MATCH_DC] ? $removed[self::MATCH_DC] : $this->dc; // PHP 5.4: use ?:
		if (self::RANDOM == $match[self::MATCH_ATYPE]) {
			if ($match[self::MATCH_USAGE] == $removed[self::MATCH_USAGE] and $match[self::MATCH_DC] == $removed[self::MATCH_DC])
				$match[self::MATCH_ATYPE] = $removed[self::MATCH_ATYPE];
			else {
				// determine family
				foreach (self::$tracker as $family => $v)
					if (in_array($match[self::MATCH_USAGE], $v['usage']))
						break;
				// add another of best already present by usage or by family
				$match[self::MATCH_ATYPE] = (array_key_exists($match[self::MATCH_USAGE], $this->setup) and array_key_exists($match[self::MATCH_DC], $this->setup[$match[self::MATCH_USAGE]]))
					? array_shift(array_intersect(array_reverse(self::$tracker[$family]['atypes']), array_keys($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])))
					: array_shift(array_reverse(self::$tracker[$family]['atypes']));
			}
		}
	}


	/**
	 * construct a ProposedSetup from an existing base or report suite
	 * @param[in] string $BRS base or report suite
	 * @param[in] enum $family CACHE, FRAG or BOTH
	 */
	public function __construct($BRS = '', $family = self::BOTH) {
		$this->setup = array();
		if ($BRS) {
			$ua = new user_account($BRS);
			$this->dc = $ua->preferred_data_center();
			if (self::CACHE & $family)
				$this->get_servers_by_family($ua, 'cache');
			if (self::FRAG & $family)
				$this->get_servers_by_family($ua, 'frag');
		} else {
			global $localConfig;
			$this->dc = end($localConfig["data_center_hostname_suffixes"]);
		}
	}


	/**
	 * construct a ProposedSetup from a SetupString
	 * @param[in] SetupString
	 * @return ProposedSetup
	 * @throws RuntimeException if specified host listed again
	 */
	static public function withSetupString(SetupString $s) {
		$that = new ProposedSetup;
		foreach ($s as $match) {
			if ($match[self::MATCH_DROP])
				continue;
			$that->resolveWildcard($match);
			if (AdjustString::allocated($match[self::MATCH_ALLOCATION]))
				$match[self::MATCH_ALLOCATION] = 0;
			else {
				// specified host
				if (array_key_exists($match[self::MATCH_USAGE], $that->setup)
				    and array_key_exists($match[self::MATCH_DC], $that->setup[$match[self::MATCH_USAGE]])
				    and array_key_exists($match[self::MATCH_ATYPE], $that->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])
				    and array_key_exists($match[self::MATCH_ALLOCATION], $that->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]))
					throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} already present");
			}
			$that->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]] += $match[self::MATCH_COUNT];
		}
		return $that;
	}


	/**
	 * adjust setup
	 * @param[in] AdjustString $a
	 * @throws RuntimeException
	 */
	public function adjust(AdjustString $a) {
		$removed = array();
		foreach ($a as $match)
			switch ($match[self::MATCH_MODE]) {
			case '+':
				if (AdjustString::actual($match[self::MATCH_ALLOCATION])) {
					// specified host
					if (array_key_exists($match[self::MATCH_USAGE], $this->setup)
					    and array_key_exists($match[self::MATCH_DC], $this->setup[$match[self::MATCH_USAGE]])
					    and array_key_exists($match[self::MATCH_ATYPE], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])
					    and array_key_exists($match[self::MATCH_ALLOCATION], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]))
						throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} already present");
				} else {
					$this->resolveWildcard($match, $removed);
					$match[self::MATCH_ALLOCATION] = 0;
				}
				$this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]] += $match[self::MATCH_COUNT];
				break;
			case '-':
				if (self::RANDOM == $match[self::MATCH_DC])
					$match[self::MATCH_DC] = $this->dc;
				if (!array_key_exists($match[self::MATCH_USAGE], $this->setup)
				    or !array_key_exists($match[self::MATCH_DC], $this->setup[$match[self::MATCH_USAGE]]))
					throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} not present");
				if (AdjustString::actual($match[self::MATCH_ALLOCATION])) {
					if (!array_key_exists($match[self::MATCH_ATYPE], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])
					    or !array_key_exists($match[self::MATCH_ALLOCATION], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]))
						throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} not present");
					unset($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]]);
					$this->setup = self::recursive_filter_empty($this->setup);
					break;
				}
				$random = self::RANDOM == $match[self::MATCH_ATYPE];
				while ($match[self::MATCH_COUNT] > 0) {
					if (!array_key_exists($match[self::MATCH_USAGE], $this->setup)
					    or !array_key_exists($match[self::MATCH_DC], $this->setup[$match[self::MATCH_USAGE]]))
						throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} not present");
					if ($random) {
						// determine family
						foreach (self::$tracker as $family => $v)
							if (in_array($match[self::MATCH_USAGE], $v['usage']))
								break;
							// remove worst of already present iteratively
							$match[self::MATCH_ATYPE] = array_shift(array_intersect(self::$tracker[$family]['atypes'], array_keys($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])));
					}
					if (!array_key_exists($match[self::MATCH_ATYPE], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]]))
						throw new RuntimeException("{$match[self::MATCH_ATYPE]} not present");
					ksort($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]);
					$match[self::MATCH_ALLOCATION] = end(array_keys($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]));
					$removed = $match;
					if ($match[self::MATCH_COUNT] >= $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]]) {
						$match[self::MATCH_COUNT] -= $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]];
						unset($this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]]);
						$this->setup = self::recursive_filter_empty($this->setup);
						continue;
					}
					if (!array_key_exists($match[self::MATCH_ATYPE], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]])
					    or !array_key_exists($match[self::MATCH_ALLOCATION], $this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]]))
						throw new RuntimeException("{$match[self::MATCH_ALLOCATION]} not present");
					$this->setup[$match[self::MATCH_USAGE]][$match[self::MATCH_DC]][$match[self::MATCH_ATYPE]][$match[self::MATCH_ALLOCATION]] -= $match[self::MATCH_COUNT];
					$this->setup = self::recursive_filter_empty($this->setup);
					break;
				}
				break;
			}
	}


	/**
	 * construct a SetupString from a proposed setup
	 * @see FragTransposer::getProposedSetup()
	 * @param[in]	string base or report suite
	 * @return SetupString
	 * @throws SetupStringException
	 */
	public function asSetupString($BRS) {
		$pieces = array();
		$part = '';
		$usage = null;
		foreach ($this as $match) {
			$allocation = is_numeric($match[self::MATCH_ALLOCATION]) ? "${match[self::MATCH_DC]}:${match[self::MATCH_COUNT]}:${match[self::MATCH_ATYPE]}" : $match[self::MATCH_ALLOCATION];
			if ($usage == $match[self::MATCH_USAGE])
				$part .= "+$allocation";
			else {
				if ($part) $pieces[] = $part;
				$part = self::$abbrev[$match[self::MATCH_USAGE]].$allocation;
				$usage = $match[self::MATCH_USAGE];
			}
		}
		if ($part) $pieces[] = $part;
		if (!$pieces)
			throw new SetupStringException('empty proposal');
		return SetupString::withString($BRS.':'.join(',', $pieces));
	}


	/**
	 * @return array form for which this class was created to replace
	 * @warn deprecated, new code should use proper interface
	 */
	public function asArray() {
		return $this->setup;
	}


	/**
	 * disabled
	 * @throws BadMethodCallException
	 */
	protected function preg() {
		throw new BadMethodCallException('not implemented');
	}


	/**
	 * @see user_account::preferred_data_center()
	 * @return string
	 */
	public function preferred_data_center() {
		return $this->dc;
	}

	/**
	 * Countable interface
	 */
	public function count() {
		return array_sum(iterator_to_array(new RecursiveIteratorIterator(new RecursiveArrayIterator($this->setup))));
	}


	/**
	 * Iterator functions returning $matches a la preg_match
	 */
	public function rewind() {
		$this->level = array(new ArrayIterator($this->setup));
		if (!$this->level[0]->valid())
			return;
		$this->matches = array(self::$span[0] => $this->level[0]->key());
		for ($depth = 1; $depth <= self::MAXKEYED; ++$depth) {
			$this->level[$depth] = new ArrayIterator($this->level[$depth-1]->current());
			$this->matches[self::$span[$depth]] = $this->level[$depth]->key();
		}
		$this->matches[self::$span[1+self::MAXKEYED]] = $this->level[self::MAXKEYED]->current();
	}
	private static function keys(ArrayIterator $x) {
		return $x->key();
	}
	public function key() {
		return join(':', array_map('ProposedSetup::keys', $this->level));
	}
	public function next() {
		$this->level[self::MAXKEYED]->next();
		if ($this->level[self::MAXKEYED]->valid()) {
			$this->matches[self::$span[self::MAXKEYED]] = $this->level[self::MAXKEYED]->key();
			$this->matches[self::$span[1+self::MAXKEYED]] = $this->level[self::MAXKEYED]->current();
			return;
		}
		for ($depth = 1+self::MAXKEYED; --$depth >= 0; ) {
			$this->level[$depth]->next();
			if ($this->level[$depth]->valid()) {
				for (;;) {
					$this->matches[self::$span[$depth]] = $this->level[$depth]->key();
					if (++$depth > self::MAXKEYED) {
						$this->matches[self::$span[1+self::MAXKEYED]] = $this->level[self::MAXKEYED]->current();
						return;
					}
					$this->level[$depth] = new ArrayIterator($this->level[$depth-1]->current());
				}
			}
		}
	}
	public function valid() {
		return array_key_exists(self::MAXKEYED, $this->level) and $this->level[self::MAXKEYED]->valid();
	}


	/**
	 * ArrayAccess interface
	 */
	public function offsetExists($offset) {
		return $this->setup and isset($this->setup[$offset]);
	}
	public function offsetGet($offset) {
		return (array_key_exists($offset, $this->setup)) ? $this->setup[$offset] : array();
	}
	public function offsetSet($offset, $value) {
		if (null === $offset)
			$this->setup[] = $value;
		else
			$this->setup[$offset] = $value;
		$this->setup = self::recursive_filter_empty($this->setup);
	}
	public function offsetUnset($offset) {
		unset($this->setup[$offset]);
	}
}


/**
 * SELFTEST
 * Usage: php ProposedSetup.class.php
 */
if (!(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
      (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
       debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)))) {
	if (function_exists('xdebug_break')) xdebug_break();

	if (1 < count($argv))
		array_splice($argv, 0, 1);
	else
		$argv = split("\n", <<<SAMPLES
ha-testing-jkt-dev1
ha-testing-jkt-dev2
ha-testing-jkt-dev3
ha-testing-jkt-dev4
SAMPLES
			);
	$n = 0;
	foreach ($argv as $s) {
		echo "\nprocess $s\n";
		$a = new ProposedSetup($s, ++$n);
		if (!(++$n & ProposedSetup::BOTH))
			++$n;
		foreach ($a as $match)
			echo<<<EOF
USAGE={$match[ProposedSetup::MATCH_USAGE]}
ALLOC={$match[ProposedSetup::MATCH_ALLOCATION]}
DC   ={$match[ProposedSetup::MATCH_DC]}
COUNT={$match[ProposedSetup::MATCH_COUNT]}
ATYPE={$match[ProposedSetup::MATCH_ATYPE]}


EOF;
	}
	require_once 'Proposal.class.php';
	foreach ($argv as $s) {
		$s = Proposal::withString($s.':H:1,C:1');
		echo "\nprocess {$s->current()->asString()}\n";
		$a = ProposedSetup::withSetupString($s->current());
		$a->adjust(AdjustString::withString('C:+db120.ut1,H:+1'));
		$a->adjust(AdjustString::withString('C:-db120.ut1,H:-1'));
		echo var_export($a->asArray(), TRUE), "\n";
		foreach ($a as $match)
			echo<<<EOF
USAGE={$match[ProposedSetup::MATCH_USAGE]}
ALLOC={$match[ProposedSetup::MATCH_ALLOCATION]}
DC   ={$match[ProposedSetup::MATCH_DC]}
COUNT={$match[ProposedSetup::MATCH_COUNT]}
ATYPE={$match[ProposedSetup::MATCH_ATYPE]}


EOF;
	}

	foreach (array_slice($argv, -1) as $s) {
		echo "test removing from multiple atypes\n";
		$a = new ProposedSetup($s, ProposedSetup::FRAG);
		$a->adjust(AdjustString::withString('H:+ut1:1:s,+ut1:1:l,+ut1:1:h,+ut1:1:e'));
		try {
			$a->adjust(AdjustString::withString('H:-4'));
			foreach ($a as $match)
				echo<<<EOF
USAGE={$match[ProposedSetup::MATCH_USAGE]}
ALLOC={$match[ProposedSetup::MATCH_ALLOCATION]}
DC   ={$match[ProposedSetup::MATCH_DC]}
COUNT={$match[ProposedSetup::MATCH_COUNT]}
ATYPE={$match[ProposedSetup::MATCH_ATYPE]}


EOF;
		} catch(Exception $e) {
			echo 'Bad! caught '.get_class($e).": {$e->getMessage()}\n";
		}
	}

	foreach (array_slice($argv, -1) as $s) {
		$a = new ProposedSetup($s);
		var_export($a[FragServerUsage::COMBO]);
		echo "\ncount=", count($a), "\n";
		try {
			$a->adjust(AdjustString::withString('C:+db120.ut1'));
			$a->adjust(AdjustString::withString('C:+db120.ut1'));
			echo "Bad! should have thrown Exception\n";
		} catch(RuntimeException $e) {
			echo 'Good! caught '.get_class($e).": {$e->getMessage()}\n";
		} catch(Exception $e) {
			echo 'Bad! caught '.get_class($e).": {$e->getMessage()}\n";
		}
		try {
			$a->adjust(AdjustString::withString('C:-db120.ut1'));
			$a->adjust(AdjustString::withString('C:-db120.ut1'));
			echo "Bad! should have thrown Exception\n";
		} catch(RuntimeException $e) {
			echo 'Good! caught '.get_class($e).": {$e->getMessage()}\n";
		} catch(Exception $e) {
			echo 'Bad! caught '.get_class($e).": {$e->getMessage()}\n";
		}
		try {
			$a->adjust(AdjustString::withString('H:-30'));
			echo "Bad! should have thrown Exception\n";
		} catch(RuntimeException $e) {
			echo 'Good! caught '.get_class($e).": {$e->getMessage()}\n";
		} catch(Exception $e) {
			echo 'Bad! caught '.get_class($e).": {$e->getMessage()}\n";
		}
		try {
			for (;;)
				$a->adjust(AdjustString::withString('H:-?:1:s'));
		} catch(RuntimeException $e) {
			echo 'Good! caught '.get_class($e).": {$e->getMessage()}\n";
		} catch(Exception $e) {
			echo 'Bad! caught '.get_class($e).": {$e->getMessage()}\n";
		}
	}
}
?>
