<?

/**
 * Used to track the current "processing context".  For example, are we currently processing a downloadable report?
 * A dashboard reportlet? Something else? By tracking the context we're able to make decisions like whether
 * we should update last/recent report suites (this is being done in company_login.inc) and provide oberon with
 * context so it can more accurately track how various data requests are initiated.
 */
class ProcessContext
{
	// NOTE: Changing the values of these enumerations may have unintended consequences.  Some are currently being
	// used by Oberon to track where data requests are coming from. See functions that are calling
	// convertToOberonClientId().

	const SC_UI_DASHBOARD_REPORTLET = '/sc/ui/dashboard/reportlet';
	const SC_DL = '/sc/dl';
	const SC_DL_SEND = '/sc/dl/send';
	const SC_DL_DOWNLOAD = '/sc/dl/download';
	const SC_UI = '/sc/ui';

	/**
	 * @var string The current process context.
	 */
	public static $current_context;

	/**
	 * Checks to see whether $parentOrEqualContext is in fact a context that is a parent of or equal to $context.
	 * /context1 is a parent or equal context to /context1/context2
	 * /context1/context2 is a parent or equal context to /context1/context2
	 * /context1/context2 is NOT a parent or equal context to /context1
	 * /context1 is NOT a parent or equal context to /contextB
	 * /context1 is NOT a parent or equal context to /context1yetdifferent
	 * See unit tests for more examples.
	 * Trailing slashes are optional and don't make any difference in the evaluation.
	 *
	 * @param $parentOrEqualContext
	 * @param $context
	 * @return bool
	 */
	public static function isParentOrEqualContext($parentOrEqualContext, $context) {
		// Use regex names for here on.
		$pattern = $parentOrEqualContext;
		$subject = $context;

		// Just in case there are any spaces at the beginning or end.
		$subject = trim($subject);
		$pattern = trim($pattern);

		// Remove trailing slash to make matching easier.
		$pattern = rtrim($pattern, '/');

		// Escape characters that are "regexy" so they won't be interpreted as regex special characters.
		$pattern = preg_quote($pattern, '/');

		// To match, the subject must fulfill the following:
		// (1) Start with pattern.
		// (2) End immediately after pattern or end with a slash after pattern with the option of trailing characters.
		$pattern = '/^' . $pattern . '($|\/.*$)/';
		return preg_match($pattern, $subject) == 1;
	}

	/**
	 * Converts a context path (e.g., /context1/context2) to the Oberon client id
	 * format (e.g., CONTEXT1_CONTEXT2)
	 * @param $context
	 * @return string
	 */
	public static function convertToOberonClientId($context) {
		$trimmed_context = trim($context, '/ ');
		$segments = explode('/', $trimmed_context);
		$client_id = strtoupper(implode('_', $segments));
		return $client_id;
	}
}
