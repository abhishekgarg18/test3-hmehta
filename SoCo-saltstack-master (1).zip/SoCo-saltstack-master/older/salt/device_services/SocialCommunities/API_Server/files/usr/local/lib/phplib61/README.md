phplib
=======

Adobe Analytics phplib library

phplib is a set of php files that get installed on most php running servers in the analytics datacenters.

## Working with this module
This module is owned in Git by the Adobe Analytics Web UI team (AAWUI), formerly the SiteCatalyst UI team; however, it is a shared module used by many different teams and products. If you need to edit code in this repository you are encouraged to fork the repository, make and test your changes locally, then submit a pull request to the AAWUI team for anything you wish to be commited back to the main repo. The AAWUI team will review the changes and, if we accept them, will merge the code into the repository.

In order to avoid being bombarded with pull requests at the official Release Candidate Build (RBC) date, the AAWUI team has establed a <b>Merge Freeze</b> date of <b>one week before each month's RCB</b>.  We will generally require any pull requests to be submitted by the Merge Freeze date so that we have enough time to review and commit the pull requests.  For example, if RCB date for the June release is June 6, this module's Merge Freeze date would be one week earlier on May 30. The Build team requires that git modules are built by 9am on RCB day. This gives our team very little time that morning to review emergency pull requests that have come in after our freeze date and to create the branches. <b>Do not be surprised if your pull request does not get approved in time for RCB if you make a pull request on RCB Day.</b>. Any requests that do not get approved in time for RCB will have to follow the standard hot fix process.

## Best Practices
* Please provide context information around your code change.  Bug numbers, feature descriptions, and links to wiki pages with technical details are all appreciated. The more context information you can provide, the easier it will be for us to review and accept the change.
* Please identify when you expect the code changes to ship or if you have a tight merge deadline.
* Please send us requests with plenty of lead time.  Just because we have a Merge Freeze date doesn't mean you have to wait until that date to send us the request.  
* Please provide plenty of in-code comments. Comments should generally answer the question "Why?". We can generally figure out the "What?" from the code. For example, we can see that you're removing every 3rd element from the array. A comment telling us <b>*why*</b> are you doing that is invaluable. Note that boilerplate comments on every method (comments about parameters, the method name, etc.) and boilerplate comments at the head of every file (author, revision #, etc. ) don't add much value so we don't get too hung up on them.
* We strongly recommend that you create a branch per feature or branch per bug in your forked repository.  Basically, a branch per pull request.  Branching in Git is quick and painless.  Doing a branch per pull request will help make merges cleaner and help prevent merge conflicts. 
* Please make sure that your fork is up to date before you create a pull request. We may request that you resubmit your request if your code is out of date.

## Worst Practices
* Sending a large pull request after the module's Merge Freeze date. Even worse is sending a large pull request after RCB date. The AAWUI team has its own product and set of priorities that we can't simply put on hold because you submitted a massive code change after the deadline.
* Demanding instant turnaround on reviews and checkins.
* Failing to provide enough context information about your change.  Just because we own the module in Git doesn't mean we understand or know every line of code.  We certainly can't read your mind and understand what you were intending to do.
* Expecting us to coordinate the hotfix process, EU process, or other overhead for your changes. While we may own the module in Git, we aren't going to own all the overhead or QE of getting code changes pushed to production. You need to do that yourself.
* Creating a pull request from out of date code.

## Preferred Workflow
IT has requested that we minimize the amount of forks that are created on github so it is preferrable that a team would share a fork.
It is a best practice to not develop directly on the tracking branches(such as master) and to leave them looking exactly like the authoritative branches.

When working with multiple people on a fork the way that you manage your commits becomes more important. The following steps are the recommended workflow.
* Create a new branch for each feature that you are working.
* Pull the latest code into the tracking branches regularly and rebase those change into your feature branches.
* When your changes are tested and ready push your tracking branch to github and do a pull request to the authoritative repo.
* One approved your changes will appear in your repo the next time you pull from the authorititive repo and you can delete your tracking branch.

At our discretion we may ask users to fix and resubmit pull requests that have have a confusing merge history.

## Handling Bugs
If you identify a bug in the module that needs to be fixed, you are welcome to submit a bug to the AAWUI team. We will prioritize and fix bugs in the modules where appropriate; however, our priority and timeframe for fixing that bug may be very different from your priority and timeframe. If you want particular bugs to be fixed quickly, we highly recommend that you fix them yourself and submit a pull request.

If you submit a change that later proves to be buggy and affects other users of this module, the AAWUI team will ask you to fix the bug and, in severe cases, may revert your change. Just because we reviewed and merged the change doesn't mean you can walk away from that change forever. 

## Hot Fixes and Emergency Uploads

Due to the special concerns around hot fixes and emergency uploads we have a different process around changing the profile branches in git. 

Below is the recommend process
* Create your build request in helm and get manager approval
* Cherry pick your change and into the profile branch on your fork (https://www.kernel.org/pub/software/scm/git/docs/git-cherry-pick.html)
* Submit a pull request from the profile branch on your fork to the official profile branch
* Optionally include a build request number or link to mark the code as committed

The team will review the change and once we accept the change if we are provided with a build request number we will mark the code as committed in helm.

## FAQ
* <b>How often will you review pull requests?</b>  We haven't settled on a specific time frame yet (e.g. daily or weekly).  Just as we expect other teams to be reasonable in sending us pull requests in a timely manner, we expect to be reasonable about completing them in a timely manner. At the beginning we're going to "play it by ear" and see what the volume and frequency of requests is. Depending upon that volume and frequency we may establish some regular review interval.
