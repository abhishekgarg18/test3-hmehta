<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com
// This is a multi-datacenter helper class

require_once 'application.inc';


define('HA_LOG_LEVEL_DEBUG', 3);
define('HA_LOG_LEVEL_WARN',  2);
define('HA_LOG_LEVEL_ERROR', 1);
define('HA_LOG_LEVEL_NONE', 0);

define('HA_TEST_MODE_DEV', 4);
define('HA_TEST_MODE_TEST', 3);
define('HA_TEST_MODE_BETA', 2);
define('HA_TEST_MODE_PRODUCTION', 1);


class HA_Utilities {
	protected $current_datacenter;
    protected $target_data_center;
    protected $target_datacenter;
	protected $start_time;
	protected $log_level    = HA_LOG_LEVEL_NONE;
	protected $test_mode    = null;
	protected $time_zone    = null;
	protected $environment  = null;
	protected $preferred_date_format  = 'M d Y h:ia';
	protected $db_handles   = array();
	protected $errors       = array();
	protected $warnings     = array();
	protected $debugs       = array();
    protected $trie_files   = array();
    protected $user_db_handles = array();

	function __construct($args = array()) {
		
		// stuff to initialize (things without config arguments)
		$this->start_time = time();
		$this->current_datacenter();

		// configure class if any config arguments were passed in
		if (isset($args['log_level'])) {
			$this->log_level($args['log_level']);
		}
		if (isset($args['time_zone'])) {
			$this->time_zone($args['time_zone']);
		}
		if (isset($args['environment'])) {
			$this->environment($args['environment']);
		}
		if (isset($args['preferred_date_format'])) {
			$this->preferred_date_format($args['preferred_date_format']);
		}
		if (isset($args['target_data_center'])) {
			$this->target_data_center($args['target_data_center']);
			$this->target_datacenter($args['target_data_center']);
		}
		if (isset($args['target_datacenter'])) {
			$this->target_data_center($args['target_datacenter']);
			$this->target_datacenter($args['target_datacenter']);
		}
	}

    // Receives a virtual db host name suffix and returns the host with the target datacenter's suffix appended.
    // Removes any previous data center subdomain that may have existed.
    function fix_hostname($host, $target_datacenter = null) {
        global $localConfig;
        
        if ($target_datacenter === null) {
            $target_datacenter = $this->current_datacenter();
        }

        // if we're not going multidatacenter, we can use local.inc.
        if ($target_datacenter == $this->current_datacenter()) {
            return $host;
        }

        if (in_array(substr($host, strrpos($host, '.') + 1), $localConfig['data_center_db_suffix_list'])) {
            $host = substr($host, 0, strrpos($host, '.'));
        }

        return $host . '.' . $target_datacenter;
    }

	// make me some multi-datacenter database handles
	function db_handle($db_name, $data_center = NULL) {
        if (is_null($data_center)) {
            $data_center = DATA_CENTER;
        }
        //$this->debug('getting db handle for ' . $db_name . ' in ' . $data_center);
        
		if (!isset($this->db_handles[$db_name])) {
			$this->db_handles[$db_name] = array();
		}
		if (!isset($this->db_handles[$db_name][$data_center])) {
			$this->db_handles[$db_name][$data_center] = new DB_Sql($db_name);
            $this->db_handles[$db_name][$data_center]->Host = $this->fix_hostname($this->db_handles[$db_name][$data_center]->Host, $data_center);
		}
        //$this->debug_r($this->db_handles[$db_name][$data_center]);
        return $this->db_handles[$db_name][$data_center];
	}

	protected function get_trie($data_center) {
        if (empty($this->trie[$data_center])) {
            global $localConfig;
            $trie_file = '';
            if (( $data_center != $this->current_datacenter() ) && in_array($data_center, $localConfig['production_data_center_list'])) {
                $trie_file = "/home/omniture/install/share/trieconf/$data_center/usertrie_enterprise.conf";
            } else {
                $trie_file = $localConfig['usertrie_enterprise'];
            }
            $this->trie[$data_center] = trie_load($trie_file);
        }
        return $this->trie[$data_center];
	}
    
    protected function user_db_handle($username, $data_center) {
        if (is_null($data_center)) {
            $data_center = DATA_CENTER;
        }
 
        $user_trie = $this->get_trie($data_center);
        $user_host = trie_get($user_trie, $username, 'host');  
        $user_db   = trie_get($user_trie, $username, 'db');
        
        if ($user_trie && $user_host && $user_db) {
            if (!isset($this->trie_files[$data_center][$user_host . '-' . $user_db])) {
                $db = new masterdb;
                $db->Host = $this->fix_hostname($user_host, $data_center);
                $db->Database = $user_db;
                $this->trie_files[$data_center][$user_host . '-' . $user_db] = $db;
            }
                
            return $this->trie_files[$data_center][$user_host . '-' . $user_db];
        }
        
        return false;
    }

	// a way to store/output error messages; send in an email, or output to a table, or something useful
	function error($str) {
		if ($this->log_level() >= HA_LOG_LEVEL_ERROR) {
			$notice = date( $this->preferred_date_format() ) . ' ERROR: ' . $str . "\n";
			$this->errors[] = $notice;
			echo $notice;
		}
	}
	
	// a way to store/output error messages; send in an email, or output to a table, or something useful
	function warn($str) {
		if ($this->log_level() >= HA_LOG_LEVEL_WARN) {
			$notice = date( $this->preferred_date_format() ) . ' WARNING: ' . $str . "\n";
			$this->warnings[] = $notice;
			echo $notice;
		}
	}
	
	// a way to store/output debug messages; send in an email, or output to a table, or something useful
	function debug($str) {
		if ($this->log_level() >= HA_LOG_LEVEL_DEBUG) {
			$notice = date( $this->preferred_date_format() ) . ' DEBUG: ' . $str . "\n";
			$this->debugs[] = $notice;
			echo $notice;
		}
	}

	// a way to store/output debug messages; send in an email, or output to a table, or something useful
	function debug_r($obj) {
		if ($this->log_level() >= HA_LOG_LEVEL_DEBUG) {
			$notice = date( $this->preferred_date_format() ) . ' DEBUG_R: object was printed.\n';
			$this->debugs[] = $notice;
			echo $notice;
			print_r($obj);
		}
	}

	function log_level($new_log_level = null) {
		if (!($new_log_level === null)) {
			$this->log_level = $new_log_level;
		}
		return $this->log_level;
	}
	
	function preferred_date_format($new_preferred_date_format = null) {
		if (!($new_preferred_date_format === null)) {
			$this->preferred_date_format = $new_preferred_date_format;
		}
		return $this->preferred_date_format;
	}

	function environment($new_environment = null) {
		global $localConfig;
		if ($new_environment !== null) {
			$this->environment = $new_environment;
		}
		else if ($this->environment === null) {

			if ($this->current_datacenter() == DATA_CENTER_DEV) {
				$this->environment = HA_TEST_MODE_DEV;
			}
			else if (in_array(DATA_CENTER, $localConfig['production_data_center_list'])) {
				$this->environment = HA_TEST_MODE_PRODUCTION;
			}
			else if ($localConfig['beta_server'] === true) {
				$this->environment = HA_TEST_MODE_BETA;
			}
			else {
				$this->environment = HA_TEST_MODE_TEST;
			}
			
		}
		return $this->environment;
	}
	
	function current_datacenter() {
        $this->current_datacenter = DATA_CENTER;
		return DATA_CENTER;
	}
    
    function target_data_center($new_value = NULL) {
        if ( !is_null($new_value) ) {
            $this->target_data_center = $new_value;
        }
        return $this->target_data_center;
    }
    
    // for backwards compatibility
    function target_datacenter($new_value = NULL) {
        return $this->target_data_center($new_value);
    }

	function time_zone($new_time_zone = null) {
		if (!($new_time_zone === null)) {
			if ($new_time_zone != 'PST' && $new_time_zone != 'PDT') {
				$this->warn('Timezone != Pacific Time.  Synchronization problems may occur.');
			}
			$this->time_zone = $new_time_zone;
		}
		else if ($this->time_zone === null) {
			$this->time_zone = date('T');
		}
		return $this->time_zone;
	}
	
	function start_time() {
		return $this->start_time();
	}
    
    function elapsed_time() {
        return time() - $this->start_time();
    }
}