<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_FeatureAccessService extends OM_AppServiceBase {
	const CONTRIBUTION_ANALYSIS = "contributionAnalysis";
	const NUM_ACCESSIBLE_ELEMENTS = "numAccessibleElements";
	const CLICK_MAP = "clickMap";
	const EVAR_KEY = "numVariablesAllowed";
	const FREEFORM_ANALYSIS = "freeformAnalysis";

	private static $_instance = null;

	public function enabledFreeformAnalysis($user){
		$freeformAnalysis = $this->getFeatureAccessForCompanyForUser(self::FREEFORM_ANALYSIS, $user);
		$enabled = $freeformAnalysis["enabled"];
		if($enabled === true ){
			return true;
		}
		else
			return false;
	}

	public function getNumEvarsAllowed($user){
		$feature_access = $this->getFeatureAccessForCompanyForUser(self::NUM_ACCESSIBLE_ELEMENTS, $user);
		$max_evars = $feature_access["numEvarsAllowed"];
		return $max_evars;
	}

	public function getNumEventsAllowed($user){
		$feature_access = $this->getFeatureAccessForCompanyForUser(self::NUM_ACCESSIBLE_ELEMENTS, $user);
		$max_events = $feature_access["numEventsAllowed"];
		return $max_events;
	}

	public function hasClickMapV3Access($user) {
		$feature_access = $this->getFeatureAccessForCompanyForUser(self::CLICK_MAP, $user);
		$clickMapV3Access = $feature_access["clickMapV3"];
		return $clickMapV3Access;
	}

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_FeatureAccessService();
		}
		return self::$_instance;
	}

	public function getFeatureAccessForCompanyForUser($feature_type, OM_User $user) {
		// Build auth token
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getTokenForUser($user);
		return $this->getFeatureAccessForCompanyByToken($feature_type, $token);
	}

	public function getFeatureAccessForCompanyByToken($feature_type, $token) {

		$path = "/featureaccess/" . $feature_type;
		$response = $this->makeAnalyticsEndpointRequest($path, $token);
		if ($response->hasErrors()) {
			throw new Exception("Error:" . $response->getErrorMessage());
		}
		return json_decode($response->getResponse(), true);
	}

}
