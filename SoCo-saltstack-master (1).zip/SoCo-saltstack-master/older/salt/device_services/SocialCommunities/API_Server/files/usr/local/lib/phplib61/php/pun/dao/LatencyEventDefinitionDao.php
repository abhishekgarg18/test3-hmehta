<?php
require_once "pun/model/LatencyEventDefinition.php";
require_once "pun/model/LatencyEventDefinitionSelector.php";
require_once "log4php/Logger.php";

class LatencyEventDefinitionDao
{
	private $qc = '/*PowerUp Notices: LatencyEventDefinitionDao*/';
	private $tableName = 'latency_event_definition';
	private $eventNoticeJoinTableName = "latency_notice_definition";
	private $dbName = 'compassdb';
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	public function getLatencyEventDefinition($id)
	{
		$this->log->debug("Retrieving LatencyEventDefinition with id $id");
		$latencyEventDefinition = null;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_def_id,notice_def_id,username,userid,latency_threshold 
			    FROM $this->tableName  
			    WHERE event_def_id = $id";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyEventDefinition = new LatencyEventDefinition();
			$latencyEventDefinition->setEventDefId($db->f('event_def_id'));
			$latencyEventDefinition->setNoticeDefId($db->f('notice_def_id'));
			$latencyEventDefinition->setUsername($db->f('username'));
			$latencyEventDefinition->setUserid($db->f('userid'));
			$latencyEventDefinition->setLatencyThreshold($db->f('latency_threshold'));
		}
		$db->close();

		return $latencyEventDefinition;
		
	}
	
	public function getLatencyEventDefinitionsByCompanyid($companyid)
	{
		$this->log->debug("Retreiving LatencyEventDefinition with company id of $companyid");
		$eventDefs = array();
		$db =  new DB_Sql($this->dbName);
		
		$sql = "SELECT $this->qc event_def_id,notice_def_id,userid,username,latency_threshold 
			    FROM $this->tableName 
			    WHERE notice_def_id = (SELECT notice_def_id FROM latency_notice_definition WHERE companyid = $companyid);"; 
		
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record())
		{
			$eventDef = new LatencyEventDefinition();
			$eventDef->setEventDefId($db->f('event_def_id'));
			$eventDef->setNoticeDefId($db->f('notice_def_id'));
			$eventDef->setUserid($db->f('userid'));
			$eventDef->setUsername($db->f('username'));
			$eventDef->setLatencyThreshold($db->f('latency_threshold'));
			$eventDefs[] = $eventDef;
		}
		$db->close();

		return $eventDefs;
	}
	
	public function getLatencyEventDefinitions(LatencyEventDefinitionSelector $selector)
	{
		$this->log->debug("Retrieving LatencyEventDefinitions using selector");
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_def_id,notice_def_id,userid,username,latency_threshold
			    FROM $this->tableName ";  
						
		$fieldValues = $this->getPopulatedFieldsFromSelector($selector);
		if(sizeof($fieldValues) > 0)
		{
			$sql .= "\n\t\t\tWHERE ".implode(" AND ",$fieldValues);
		}
		
		$sql .= " ORDER BY username ASC";
		
		
		if ($selector->getResultCountLimit()) 
		{
			$count = $selector->getResultCountLimit();
			$start = $selector->getResultStartindex();
			$sql .= "\n\t\t\tLIMIT $start, $count";
		}
		
		$latencyEventDefs = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyEventDefinition = new LatencyEventDefinition();
			$latencyEventDefinition->setEventDefId($db->f('event_def_id'));
			$latencyEventDefinition->setNoticeDefId($db->f('notice_def_id'));
			$latencyEventDefinition->setUsername($db->f('username'));
			$latencyEventDefinition->setUserid($db->f('userid'));
			$latencyEventDefinition->setLatencyThreshold($db->f('latency_threshold'));
			$latencyEventDefs[] = $latencyEventDefinition;
		}
		$db->close();
		
		return $latencyEventDefs;
	}
	
	public function saveLatencyEventDefinition(LatencyEventDefinition $def)
	{
		$this->log->debug("Saving LatencyEventDefinition for user $def->getUsername()");
		$db =  new DB_Sql($this->dbName);
		$sql = "INSERT INTO $this->qc $this->tableName (notice_def_id,username,userid)
				VALUES (".$def->getNoticeDefId().",'".addslashes($def->getUsername())."',".$def->getUserid().")
				ON DUPLICATE KEY UPDATE event_def_id=LAST_INSERT_ID(event_def_id)";

		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		
		if($db->squery("SELECT LAST_INSERT_ID()"))
		{
			$def->setEventDefId($db->f('LAST_INSERT_ID()'));
		}
		
		$db->close();
		
		return $def;
	}
	
	/**
	 * Deletes the latency event with the given id
	 * @param int $id
	 */
	public function deleteLatencyEventDefinition($id)
	{
		$this->log->debug("Deleting LatencyEventDefinition with id of $id");
		$db =  new DB_Sql($this->dbName);
		$sql = "DELETE from $this->tableName where event_def_id = $id";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	/**
	 * Deletes all event definitions associated with the given LatencyNoticeDefinition id
	 * 
	 * @param int $noticeDefId
	 */
	public function deleteAllEventDefinitions($noticeDefId)
	{
		$this->log->debug("Deleting all LatencyEventDefinitions with LaencyNoticeDefinition with id of $noticeDefId");
		$db =  new DB_Sql($this->dbName);
		$sql = "DELETE from $this->tableName 
				WHERE notice_def_id = $noticeDefId";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	/*
	 * Builds an array of database field names and associated values. eg, (userid => 'sistr2')
	 * This is used in building where clauses dynamically.
	 * 
	 * @param LatencyEventDefinitionSelector  $selector  
	 */
	private function getPopulatedFieldsFromSelector(LatencyEventDefinitionSelector $selector)
	{
		$values = array();
		if($selector == NULL)
		{
			return $values;
		}
		
		if($selector->getDefId() != null && $selector->getDefId() > 0)
		{
			$values[] = "event_def_id = ".$selector->getDefId(); 
		}

		if($selector->getNoticeDefId() != null && $selector->getNoticeDefId() > 0)
		{
			$values[] = "notice_def_id = ".$selector->getNoticeDefId(); 
		}
		
		if($selector->getUsername() != null && strlen($selector->getUsername()) > 0)
		{
			$values[] = "username = '".addslashes($selector->getUsername())."'"; 
		}
			
		if($selector->getUserId() != null && $selector->getUserId() > 0)
		{
			$values[] = "userid = ".$selector->getUserId(); 
		}
		
		$this->log->debug("Selector field values: ".implode($values));
					
		return $values;
	}
	

}