<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

// latency data keys:
//                 'userid'
//                 'username'
//                 'host'
//                 'db'
//                 'data_center'
//                 'billing_customer_id'
//                 'sc_version'
//                 'sc_latency_minutes'
//                 'billing_customer'
//                 'latency_comments'
//                 'top100'


require_once 'application.inc';
require_once 'class-ha-utilities.php';
require_once 'latencyAPI.inc';
require_once 'LatencyHistory.class';
require_once 'ReportSuiteConfig.class';
require_once 'comments.inc';
require_once 'pun/webclient/LatencyNoticeWebClient.php';

class HA_Latency_Email_Data extends HA_Utilities {
    protected $data = array();
    protected $customers_to_skip = array();
    
	function __construct($args = array()) {
		parent::__construct($args);
        
        $this->customers_to_skip = array(
            'zzINACTIVE',
            'zzDUPLICATE',
            'OMNITURE-TESTING CUSTOMER',
            'OMNITURE-EMPLOYEE USAGE',
        );
        
        $this->latency_history = new LatencyHistory();
        $this->latency_api = new latencyAPI();

	}

    function data($new_data = false) {
		if ( $new_data !== false ) {
			$this->data = $new_data;
		}
		return $this->data;
    }
    
    static function sort_latency_data($a, $b) {
        if ( ($a['top100'] == $b['top100']) && ($a['sc_latency_minutes'] == $b['sc_latency_minutes']) ) {
            return strnatcmp($a['username'], $b['username']);
        }
        else if ($a['top100'] == $b['top100']) {
            return ($a['sc_latency_minutes'] > $b['sc_latency_minutes']) ? -1 : 1;
        }
        return ($a['top100'] > $b['top100']) ? -1 : 1;
    }
    
    static function sort_billing_customer_data($a, $b) {
        $a_num_items = count($a['items']);
        $b_num_items = count($b['items']);
        
        if ( ($a['max_latency_minutes'] == $b['max_latency_minutes']) && ($a_num_items == $b_num_items) ) {
            return strnatcmp($a['billing_customer'], $b['billing_customer']);
        }
        else if ($a['max_latency_minutes'] == $b['max_latency_minutes']) {
            return ($a_num_items > $b_num_items) ? -1 : 1;
        }
        return ($a['max_latency_minutes'] > $b['max_latency_minutes']) ? -1 : 1;
    }
    
    // raw data is stored as an unserialized php array
    function add_raw_data_file($filename) {
        if (file_exists($filename)) {
            $contents_raw = file_get_contents($filename);
            $contents = unserialize($contents_raw);
            
            if ($contents === false) {
                $this->debug("Could not unpack results for $output_file: " . $contents_raw . "\n");
                return false;
            }
            
            if (is_array($contents)) {
                $this->data = array_merge( (array)$contents, $this->data );
            }
        }
        usort($this->data, "HA_Latency_Email_Data::sort_latency_data");
        return $this->data;
    }
    
    function add_raw_data_files($filenames) {
        foreach($filenames as $filename) {
            $this->add_raw_data_file($filename);
        }
        return $this->data;
    }
    
    function top_100_data() {
        $top100 = array();
        
        foreach($this->data as $item) {
            if ($item['top100']) {
                $top100[] = $item;
            }
        }
        
        // don't limit the main table to top 100 data in dev.
        if (DATA_CENTER == DATA_CENTER_DEV) {
            return $this->data;
        }
        return $top100;
    }
    
    function billing_customer_data($includeTop100 = false) {
        $customers = array();
        
        foreach($this->data as $item) {
            
            if (($includeTop100 === false) && ($item['top100'])) {
                continue;
            }
            
            if (!(array_key_exists($item['billing_customer'], $customers))) {
                $customers[ $item['billing_customer'] ] = array(
                    'items' => array(),
                    'billing_customer' => $item['billing_customer'],
                    'max_latency_minutes' => 0,
                );
            }
            $customers[ $item['billing_customer'] ]['items'][] = $item;
            
            if ($customers[ $item['billing_customer'] ]['max_latency_minutes'] < $item['sc_latency_minutes'])  {
                $customers[ $item['billing_customer'] ]['max_latency_minutes'] = $item['sc_latency_minutes'];
            }
        }

        usort($customers, "HA_Latency_Email_Data::sort_billing_customer_data");
        return $customers;
    }
    

    function get_recent_comments($username, $start_date = null) {
        if (empty($start_date)) {
            $start_date = time() - 60*60*24;
        }
    
        $filter = new commentSearchFilter();
        $filter->startdate = date('Y-m-d H:i:s', $start_date);
        $filter->accounts = array($username);
        $filter->visibility = 1;
        
        $latency_comments = array();
        $comment_list = new comment_list();
        $comments = $comment_list->searchComments($filter);
        if (count($comments) > 0) {
            foreach($comments as $comment) {
                $comment_time = strtotime($comment['dt_time']);
                $raw_comment = $comment['comment_text'] . 
                    ' on ' . date('D, M j, Y', $comment_time) . ' at ' . date('g:ia T', $comment_time);
                $latency_comments[] = preg_replace('/,/', '&#44;', $raw_comment);
                
            }
        }
        
        return $latency_comments;
    }
    
    function get_billing_customer_name($billing_customer_id, $companydb) {
         if (!isset($this->billing_customer_cache[$billing_customer_id])) {
             // get the billing customer name
             $companysql = "select cus_name from billing_customer where id=" . $billing_customer_id . " limit 1";
             $companydb->query($companysql);

             $this->billing_customer_cache[$billing_customer_id] = '';
             if ($companydb->next_record()) {
                 $this->billing_customer_cache[$billing_customer_id] = $companydb->f('cus_name');
             }
        }
        return $this->billing_customer_cache[$billing_customer_id];
    }
    
    // figure out the data center from db host's suffix
    function find_data_center($host, $complete_suffix_list) {
        
        // DEV is dev. no cross data center stuff there.
        if (DATA_CENTER == DATA_CENTER_DEV) {
            return DATA_CENTER;
        }
        
        if (is_array($complete_suffix_list)) {
            foreach($complete_suffix_list as $s_data_center => $suffixes) {
                
                if (is_array($suffixes)) {
                    foreach($suffixes as $suffix) {
                        $pos = strrpos($host, $suffix);
                        if (($pos > 0) && ($pos + strlen($suffix)) == strlen($host)) {
                            return $s_data_center;
                        }
                    }
                }
                
                // try data center name if the suffix wasn't found.
                $pos = strrpos($host, $s_data_center);
                if (($pos > 0) && ($pos + strlen($s_data_center)) == strlen($host)) {
                   return $s_data_center;
                }
            }
        }
        else {
        }
        
        // San Jose doesn't follow the rules, so if a suffix isn't found, the server is probably  in San Jose.
        return DATA_CENTER_SAN_JOSE;
    }

    function load_trie_file($filename, $offset, $limit, $top_sc_latency_min, $sc_latency_min, $data_center_suffixes) { 
        // load up a trie file
        $td      = trie_load($filename);
        $uniques = trie_get_all_unique($td);
        $db      = new DB_SQL("masterdb");
        $companydb = new DB_SQL("companydb");
        
        // get the list of report suites
        $i = 0;
        foreach( $uniques as $location ) {
            $i++;
            if (($i <= $offset) && ($offset != 0)) {
                continue;
            }
            if (($limit != -1) && ($i > ($limit+$offset))) {
                continue;
            }
            
            $db->Host = $location["host"];
            $db->Database = $location["db"];
        
            $sql = "SELECT /" . "* SOURCE: load-user-db - mary shaw *" . "/ \n" .
                       "       u.userid, \n" .
                       "       u.username, \n" .
                       "       u.billing_customer_id, \n" .
                       "       s.axle_start, \n" .
                       "       s.axle_data, \n" .
                       "       s.workbench_sampling \n" .
                       "  FROM user u \n" .
                       "  INNER JOIN user_services s ON u.userid=s.userid \n" .
                       " WHERE u.enterprise = 1";
        
            $db->query($sql);

            // figure out the data center from the suffix
            $data_center = $this->find_data_center($location['host'], $data_center_suffixes);
        
            if ($db->Errno == 0) {
                while ($db->next_record()) {
                    
                    // todo call load data function instead. move this stuff to that function.
                    $args = array(
                        'userid' => $db->f("userid"),
                        'username' => $db->f("username"),
                        'billing_customer_id' => $db->f("billing_customer_id"),
                        'axle_start' => $db->f("axle_start"),
                        'axle_data' => $db->f("axle_data"),
                        'workbench_sampling' => $db->f("workbench_sampling"),
                        'top_sc_latency_min' => $top_sc_latency_min,
                        'sc_latency_min' => $sc_latency_min,
                        'data_center' => $data_center,
                        'host' => $location['host'],
                        'db' => $location['db'],
                    );
                    
                    // load the data, add to the final data array if 
                    // data is returned (because, in that case, latency is bad enough
                    // that it should be included in the report!)
                    $ret = $this->load_data($args, $companydb);
                    if (is_array($ret) ) {
                        $users[] = $ret;
                    }
                }
            }
        }
        return $users;
    }
    
    function load_data($args, $companydb) {
        $latency = array();

        $top_sc_latency_min = $args['top_sc_latency_min'];
        $sc_latency_min = $args['sc_latency_min'];
        $data_center = $args['data_center'];
        
        // load initial user data
        $userid = $args['userid'];
        $username = $args['username'];
        $billing_customer_id = $args['billing_customer_id'];
        $axle_start = $args["axle_start"];
        $axle_data = $args["axle_data"];
        $workbench_sampling = $args["workbench_sampling"];

        $latency_points = $this->latency_history->getHistoricalLatencyByUserid($userid, date('D, d M Y H:i:s', (time() - 60*60)), date('D, d M Y H:i:s', time()));
	$latency = array_pop($latency_points);

        //echo "latency history returned is " . $latency . "\n";
	foreach($latency as $key => $val) {
		$latency[$key] = floor($val/60);
	}
        //print_r($latency);

        if (count($latency) == 0) {
            $latency = array();
            //$this->error("No latency history for " . $rs_data['username'] . 
            //    ' from ' . date('M j, Y g:i:sa', (time()- 60*60) ) . ' to ' . date('M j, Y g:i:sa', time()) .
            //    '. Using CURRENT latency instead of 15-minutes-old latency.'
            //);
            //$latency = $this->latency_history->getCurrentLatencyByUserid($userid);

		//        echo "CURRENT latency returned is " . $latency . "\n";
		//        print_r($latency);
            
        }
        
        if (is_array($latency) && (count($latency) >= 1)) {
            $retval['data'] = array_merge($args, $latency);
        }
        
        $sc_version = '14';
        if (($axle_start != -1 && $axle_start != '0000-00-00' && $axle_start <= date('Y-m-d')) &&
                    $axle_data > 0 && $has_wb > 0) {
            $sc_version = '15';
            if (isset($latency['axle'])) {
                $sc_latency_minutes = $latency['axle'];
            }
            else {
                $this_latency = $this->latency_api->getAxleLatencyByUser($userid);
//print_r($this_latency);
                $seconds_latent = 0;
                if(is_array($this_latency)){
                    $seconds_latent = floor( max( $this_latency) / 60 );
                }
                $latency['axle'] = $seconds_latent;
                $sc_latency_minutes = $latency['axle'];
            }
            //echo "checking axle latency: " . $sc_latency_minutes . "\n";

        }
        else {
            $sc_version = '14';
            if (isset($latency['elevator'])) {
                $sc_latency_minutes = $latency['elevator'];
            }
            else {
                $this_latency = $this->latency_api->getElevatorLatencyByUser($userid);
//print_r($this_latency);
                $seconds_latent = 0;
                if (is_array($this_latency)) {
                    $seconds_latent = floor( max( $this_latency) / 60 );
                }
                $latency['elevator'] = $seconds_latent;
                $sc_latency_minutes = $latency['elevator'];
            }
        }
        
        $top100 = false;
        try {
            $web_client = new LatencyNoticeWebClient();
            $top100 = $web_client->noticeEligible($username);
        }
        catch(Exception $e) {
            //echo "ERROR loading latency notices: " . $e->getTraceAsString() . "\n";
            $top100 = false;
        }
        catch(InvalidParameterException $ie) {
            //echo "ERROR loading latency notices: " . $e->getTraceAsString() . "\n";
            $top100 = false;
        }
        
        // only include report suites with alarm-level latency
        if ($top100) {
            if ($sc_latency_minutes < $top_sc_latency_min) {
                return null;
            }
        }
        else {
            if ($sc_latency_minutes < $sc_latency_min) {
                return null;
            }
        }

                    
        // TODO skip comments at russ's request 
        $latency_comments = $this->get_recent_comments($username);
        $billing_customer = $this->get_billing_customer_name($billing_customer_id, $companydb);
        
        //echo "\n checking on user data for " . $username . "(" . $userid . ") " . $sc_latency_minutes . " min.\n";
        //echo "   billing customer is " . $billing_customer . ".\n";
        
        // skip all zzINACTIVE's!!
        if (DATA_CENTER != DATA_CENTER_DEV) {
            foreach($this->customers_to_skip as $customer_to_skip) {
                if (stripos($billing_customer, $customer_to_skip) !== false) {
                    return null;
                }
            }
        }
        
        $args['sc_version'] = $sc_version;
        $args['sc_latency_minutes'] = $sc_latency_minutes;
        $args['billing_customer'] = $billing_customer;
        $args['latency_comments'] = join('<br />', $latency_comments);
        $args['top100'] = $top100;
        
        return $args;
    }
    
    function update_latency() {
        $latencyAPI = new latencyAPI();

        foreach($this->data as $user) {
            if ($user['sc_version'] == 15) {
                $latency = $latencyAPI->getAxleLatencyByUser($userid);
                if (is_array($latency)) {
                    $latency = max($latency);
                }
                $sc_latency_minutes = floor( $latency / 60 );
            }
            else {
                $latency = $latencyAPI->getElevatorLatencyByUser($userid);
                if (is_array($latency)) {
                    $latency = max($latency);
                }
                $sc_latency_minutes = floor( $latency / 60 );
            }
        }
        return $this->data;
    }
    
    function save() {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;
        

        // delete all data 24 hours old
        $delete_sql = "DELETE FROM report_data where report_time <= DATE_SUB(NOW(), INTERVAL 5 DAYS)";
        $db->query($delete_sql);
        if ($db->Errno != 0) {

            // problems deleting old data from the table?  maybe the table doesn't exist.  create it!
            $create_sql = 'CREATE TABLE IF NOT EXISTS latency.report_data (
                report_data_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
                report_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                serialized_data text NOT NULL
            )';
            $db->query($create_sql);
            
            $this->debug('creating report data table.');
        }
        
        $add_sql = "INSERT INTO report_data SET serialized_data='" . serialize($this->data) . "'";
        $db->query($add_sql);
        
        if ($db->Errno == 0) {
            return true;
        }

        return false;
    }
    
    function get_old_data() {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;

        $load_sql = "SELECT report_time, serialized_data FROM report_data ORDER BY report_time DESC LIMIT 1";
        $db->query($load_sql);
        
        $retval = array();
        if ($db->next_record()) {
            $serialized_data = $db->f('serialized_data');
            
            $retval['data'] = unserialize($serialized_data);
            $retval['time'] = $db->f('report_time');
            
            return $retval;
        }
        
        return false;
    }
    
    function get_old_old_data() {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;

        $load_sql = "SELECT report_time, serialized_data FROM report_data ORDER BY report_time DESC LIMIT 1,1";
        $db->query($load_sql);
        
        $retval = array();
        if ($db->next_record()) {
            $serialized_data = $db->f('serialized_data');
            
            $retval['data'] = unserialize($serialized_data);
            $retval['time'] = $db->f('report_time');
            
            return $retval;
        }
        
        return false;
    }
    
    // figure out what has been dropped off the list since the last send
    function get_caught_up_data() {
        $old_data = $this->get_old_data();
        $caught_up_data = array();
        
        if (!empty($old_data['data'])) {
            $latencyAPI = new latencyAPI();
            
            foreach($old_data['data'] as $old_user) {
                $found = false;
                foreach($this->data as $new_user) {
                    if (($new_user['userid'] == $old_user['userid']) && ($new_user['username'] == $old_user['username']) && ($new_user['data_center'] == $old_user['data_center'])) {
                        $found = true;
                        break;
                    }
                }
                
                if ($found == false) {
                    $caught_up_data[] = $old_user;
                }
            }
        }
        
        return $caught_up_data;
    }
    
    // figure out what has been dropped off the list since the last send
    function get_old_caught_up_data() {
        $old_data = $this->get_old_old_data();
        $caught_up_data = array();
        
        if (!empty($old_data['data'])) {
            $latencyAPI = new latencyAPI();
            
            foreach($old_data['data'] as $old_user) {
                $found = false;
                foreach($this->data as $new_user) {
                    if (($new_user['userid'] == $old_user['userid']) && ($new_user['username'] == $old_user['username']) && ($new_user['data_center'] == $old_user['data_center'])) {
                        $found = true;
                        break;
                    }
                }
                
                if ($found == false) {
                    $caught_up_data[] = $old_user;
                }
            }
        }
        return $caught_up_data;
    }
}
