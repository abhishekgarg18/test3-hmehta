-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: db2.dev
-- Generation Time: Oct 06, 2008 at 04:37 PM
-- Server version: 5.0.27
-- PHP Version: 4.4.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `localization_stats`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `key` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `type` enum('yn','number','timestamp','text') NOT NULL,
  PRIMARY KEY  (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `stats`
--

CREATE TABLE `stats` (
  `product` varchar(50) NOT NULL,
  `version` varchar(10) NOT NULL,
  `datacenter` varchar(15) NOT NULL,
  `environment` varchar(15) NOT NULL,
  `server` varchar(255) NOT NULL,
  `locale` varchar(5) NOT NULL,
  `page` text NOT NULL,
  `view` varchar(255) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL,
  `gettext` mediumint(9) NOT NULL,
  `gettext_database` mediumint(9) NOT NULL,
  `gettext_cache` mediumint(9) NOT NULL,
  `gettext_escapechars` mediumint(9) NOT NULL,
  `gettext_htmlsafe` mediumint(9) NOT NULL,
  `getDisplayString` mediumint(9) NOT NULL,
  `getDisplayString_database` mediumint(9) NOT NULL,
  `getDisplayString_cache` mediumint(9) NOT NULL,
  `getDisplayString_escapechars` mediumint(9) NOT NULL,
  `getDisplayString_htmlsafe` mediumint(9) NOT NULL,
  `dates_getdatetime` mediumint(9) NOT NULL,
  `dates_gettext_date_format` mediumint(9) NOT NULL,
  `dates_format_locale_date` mediumint(9) NOT NULL,
  `dates_format_locale_time` mediumint(9) NOT NULL,
  KEY `product` (`product`),
  KEY `version` (`version`),
  KEY `datacenter` (`datacenter`),
  KEY `server` (`server`),
  KEY `locale` (`locale`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `timing`
--

CREATE TABLE `timing` (
  `timestamp` double unsigned NOT NULL,
  `server` varchar(200) NOT NULL,
  KEY `server` (`server`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
