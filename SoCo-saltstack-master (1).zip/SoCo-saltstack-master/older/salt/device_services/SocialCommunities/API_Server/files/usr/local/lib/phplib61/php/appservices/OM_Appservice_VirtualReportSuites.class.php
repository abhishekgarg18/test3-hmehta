<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_Appservice_VirtualReportSuites extends OM_AppServiceBase{

	private static $_instance = null;
	private static $_definitions_by_vrsid = array();
	private static $_vrs_lists_by_companyid = array();

	const VRS_PATH = "/virtualreportsuites/";
	const VRS_SERVICE_LEVEL_EXPANSIONS = "parentRsid,timezone";
	const VRS_PREFIX = "vrs_";

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_Appservice_VirtualReportSuites();
		}
		return self::$_instance;
	}

	public static function isVirtualReportSuiteId($suite_id){
		if(is_string($suite_id) && strlen($suite_id) > 0 && substr($suite_id,0,4) == OM_Appservice_VirtualReportSuites::VRS_PREFIX ){
			return true;
		}
		return false;
	}

	public static function getVrsDefinition($vrsid){
		return OM_Appservice_VirtualReportSuites::getSingleVrsFromAppservice($vrsid, explode(",",OM_Appservice_VirtualReportSuites::VRS_SERVICE_LEVEL_EXPANSIONS));
	}

	public static function getVrsParentRsid($vrsid){
		$vrs = OM_Appservice_VirtualReportSuites::getSingleVrsFromAppservice($vrsid, explode(",",OM_Appservice_VirtualReportSuites::VRS_SERVICE_LEVEL_EXPANSIONS));
		if(is_array($vrs) && $vrs['parentRsid']){
			return $vrs['parentRsid'];
		}
		return null;
	}

	public static function getAllCompanyVirtualReportSuites($company_id, $include_num_groups=false, $search=false){
		// Use cache for default params only
		if(!$include_num_groups && !$search && self::$_vrs_lists_by_companyid[$company_id]){
			return self::$_vrs_lists_by_companyid[$company_id];
		}
		$resp_array = array();
		if(!$company_id || !($company_id > 0)){
			return $resp_array;
		}
		$path = self::VRS_PATH . "?companyId=".$company_id."&limit=0";

		$expansion = "parentRsid,timezone";
		if($include_num_groups){
			$expansion .= ",numGroups";
		}
		$path .= ("&expansion=" . $expansion);

		if($search){
			$path .= "&idContains=". $search;
		}

		$response = self::makeVrsPlatformRequest($path);
		if(is_array($response) && is_array($content=$response['content'])){
			$resp_array = $content;
		}

		// Set cache
		if(!$include_num_groups && !$search){
			self::$_vrs_lists_by_companyid[$company_id] = $resp_array;
		}
		return $resp_array;
	}

	private static function getSingleVrsFromAppservice($vrsid,$expansion = array()) {
		// Check static cache if using default expansions
		if(implode(",",$expansion) == self::VRS_SERVICE_LEVEL_EXPANSIONS){
			if(self::$_definitions_by_vrsid[$vrsid]){
				return self::$_definitions_by_vrsid[$vrsid];
			}
		}

		$path = OM_Appservice_VirtualReportSuites::VRS_PATH . $vrsid;
		if (is_array($expansion) && count($expansion) > 0) {
			$path .= "?expansion=".implode(',', $expansion);
		}
		$vrs = OM_Appservice_VirtualReportSuites::makeVrsPlatformRequest($path);

		// Set static cache
		if(implode(",",$expansion) == self::VRS_SERVICE_LEVEL_EXPANSIONS){
			self::$_definitions_by_vrsid[$vrsid] = $vrs;
		}
		return $vrs;
	}

	private static function makeVrsPlatformRequest($path,$http_method=self::GET_REQUEST,$body=''){
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$vrs_instance = self::getInstance();
		// Get a service token
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();

		// Make the request
		$response = $vrs_instance->makePlatformEndpointRequest($path, $token, $http_method, $body);
		if ($response->hasErrors()) {
			throw new Exception("VirtualReportSuites service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}
}