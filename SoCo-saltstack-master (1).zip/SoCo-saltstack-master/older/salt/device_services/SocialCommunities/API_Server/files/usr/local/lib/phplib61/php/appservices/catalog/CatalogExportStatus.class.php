<?php
  /*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2016 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
  /**
   Written by saurgarg June,2016
   Represents Catalog Export Status 
  */

class CatalogExportStatus implements JsonSerializable
{

  
   private $isDataAllThere;  
   
   public function jsonSerialize() 
  	{
        if(isset($this->isDataAllThere))
          $arr['isDataAllThere']=$this->isDataAllThere;
        return $arr;
    }

    public function getIsDataAllThere()
    {
        return $this->isDataAllThere;
    }

    public function setIsDataAllThere($isDataAllThere)
    {
        $this->isDataAllThere = $isDataAllThere;
    }

       
    public function setObjectFromJson($json)
    {
        $data = json_decode($json, true);
        $this->setObjectFromArray($data);
    }

    public function setObjectFromArray($data)
    {
        foreach ($data AS $key => $value) $this->{$key} = $value;
    }

}

/* Usage Examples 
$vr=new CatalogData(); //Initialization

*/

