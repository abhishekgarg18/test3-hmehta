<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * CadenceTicker.class.php Track ticks and time to provide a trigger when interval thresholds are met
 *
 * @author  keklingl <keklingl@adobe.com>
 *
 */

class CadenceTicker {
	private $current_count;
	private $max_count;
	private $interval_count;
	private $interval_time;
	private $next_interval_count_marker;
	private $next_interval_time_marker;
	private $skip_next_count_interval;
	private $trigger_on_next_tick;

	public function __construct($max_count=0) {
		$this->current_count = 0;
		$this->max_count = $max_count;
		$this->interval_count = 1;
		$this->next_interval_count_marker = 1;
		$this->next_interval_time_marker = 0;
		$this->skip_next_count_interval = false;
		$this->trigger_on_next_tick = false;
	}

	/**
	 * Set the number of ticks before the next interval is triggered
	 *
	 * @param integer $cnt
	 */
	public function setIntervalCount($cnt) {
		$this->interval_count = $cnt;
		$this->resetIntervalCountMarker();
	}

	/**
	 * Reset the count marker for the next interval trigger
	 */
	public function resetIntervalCountMarker() {
		$this->next_interval_count_marker = $this->current_count + $this->interval_count;
	}

	/**
	 * Set the number of seconds before the next interval is triggered
	 *
	 * @param integer $seconds
	 */
	public function setIntervalTime($seconds) {
		$this->interval_time = $seconds;
		$this->resetIntervalTimeMarker();
	}

	/**
	 * Reset the time mark for the next interval
	 */
	public function resetIntervalTimeMarker() {
		$this->next_interval_time_marker = time() + $this->interval_time;
	}

	/**
	 * Set the number of ticks before the next interval is triggered based on how many count triggers are wanted
	 *
	 * @param integer $segments_max
	 */
	public function setIntervalSegmentsMax($segments_max) {
		$this->setIntervalCount(($this->max_count - $this->current_count) / $segments_max);
	}

	/**
	 * Return the current tick count
	 *
	 * @return number - The current tick count
	 */
	public function currentCount() {
		return $this->current_count;
	}

	/**
	 * Return the maximum number of ticks this cadence expects
	 *
	 * @return number - The maximum number of planned ticks
	 */
	public function maxCount() {
		return $this->max_count;
	}

	/**
	 * Force the next tick to trigger
	 */
	public function triggerOnNextTick() {
		$this->trigger_on_next_tick = true;
	}

	/**
	 * Increase by a tick and see if the next interval should be triggered
	 * 
	 * @return boolean - Next interval was triggered
	 */
	public function isNextInterval() {
		$ret_is_next_interval = false;
		$this->current_count++;
		if ($this->trigger_on_next_tick || ($this->current_count >= $this->max_count)) {
			$ret_is_next_interval = true;
			$this->trigger_on_next_tick = false;
		} else if ($this->current_count >= $this->next_interval_count_marker) {
			$this->next_interval_count_marker += $this->interval_count;
			if (!$this->skip_next_count_interval) {
				$ret_is_next_interval = true;
			}
			$this->skip_next_count_interval = false;
		} else if ((0 != $this->interval_time) && (time() >= $this->next_interval_time_marker)) {
			$ret_is_next_interval = true;
			$this->skip_next_count_interval = true;
		}

		if ($ret_is_next_interval) {
			$this->resetIntervalTimeMarker();
		}

		return $ret_is_next_interval;
	}
}
