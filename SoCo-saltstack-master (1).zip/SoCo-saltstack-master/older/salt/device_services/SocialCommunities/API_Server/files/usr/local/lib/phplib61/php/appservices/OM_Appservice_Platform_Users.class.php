<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2016 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_Appservice_Platform_Users extends OM_AppServiceBase {
	const USERS_PATH = "/users/";

	private static $_instance = null;

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_Appservice_Platform_Users();
		}
		return self::$_instance;
	}

	public static function checkSetImsAdminUserAsAnalyticsAdmin($companyid, &$loginList) {
		return; // TODO - remove this when we fix paging in admin console user management
//		$loginids = array_map(function ($ar) {return $ar['loginid'];}, $loginList); // TODO - make this php 5.2 compatible
//		try{
//			$users = self::getUsers($companyid, $loginids);
//		} catch( Exception $e ) {
//			// return if can't get ims admin status from appservice
//			return;
//		}
//
//		$appserviceUserList = $users['content'];
//		foreach($loginList as &$login) {
//			foreach($appserviceUserList as $loginFromAppService) {
//				if($login['loginid'] == $loginFromAppService['loginId']) {
//					$login['admin'] = $loginFromAppService['admin'];
//				}
//			}
//		}
	}

	public static function isImsAdminUser($companyid, $loginid) {
		try{
			$user = self::getUser($companyid, $loginid);
		} catch( Exception $e ) {
			// return false if can't get ims admin status from appservice
		}

		if($user && $user['admin'] == true) {
			return true;
		}

		return false;
	}

	public static function isImsAdminButNotAnalyticsAdmin($company, $loginid) {
		$loginDb = new companyFragDB($company);
		$sql = "SELECT admin FROM login WHERE companyid=" . $company->companyid . " AND loginid='$loginid'";
		if(!$loginDb->squery($sql))
			return false;

		$isAnalyticsAdmin = $loginDb->f('admin');
		if( $isAnalyticsAdmin ) {
			return false;
		}

		return self::isImsAdminUser($company->companyid, $loginid);
	}

	public static function getUsers($companyid, $loginids) {
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$userServiceInstance = self::getInstance();
		$path = self::USERS_PATH . "?companyId=" . $companyid . "&limit=0&expansion=admin&loginIds=" . implode(',',$loginids);
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$response = $userServiceInstance->makePlatformEndpointRequest($path, $token);
		if ($response->hasErrors()) {
			throw new Exception("UserService Error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}

	public static function getUser($companyid, $loginid) {
		require_once(PLATFORM_DIR.'/auth/OM_IMSServiceUtil.class.php'); //Required for using IMS service tokens

		$userServiceInstance = self::getInstance();
		$path = self::USERS_PATH . $loginid . "?companyId=" . $companyid . "&expansion=admin";
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$response = $userServiceInstance->makePlatformEndpointRequest($path, $token);
		if ($response->hasErrors()) {
			throw new Exception("UserService Error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}
}
