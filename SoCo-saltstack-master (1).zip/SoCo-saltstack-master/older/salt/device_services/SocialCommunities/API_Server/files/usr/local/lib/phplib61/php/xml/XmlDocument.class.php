<?
/**
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    For Support, please visit http://www.criticaldevelopment.net/xml/
*/

/**
 * The main object used in XmlDocument to form the memory structure.
 **/
require_once 'xml/XmlTag.class.php';

/**
 * @file XmlDocument.class.php
 *
 * XML Document Class (php4) - previously called XMLParser
 * Parses an XML document into an object structure much like the SimpleXML extension.
 *
 * @author Adam A. Flynn <adamaflynn@criticaldevelopment.net>
 * @copyright Copyright (c) 2006, Adam A. Flynn
 *
 * @author Brandon George <bgeorge@omniture.com>
 *
 * @version CVS: $Id$
 */
class XmlDocument
{
	/** DATA MEMBERS **/

	/**
	 * The full (absolute) path to the XML document that this object
	 * represents.
	 *
	 * @var string
	 **/
	var $_full_document_path;

    /**
     * The XML parser (used by PHP).
     *
     * @var resource
     **/
    var $_parser;

    /**
    * The root element of the XML document.
    *
    * @var object
    **/
    var $_root_element;

    /**
    * Current object depth.
    *
    * @var array
    **/
    var $_stack;
    
    /**
	 * the raw contents of the file
	 */
    var $_xml_contents;

	/** STATIC METHODS **/

	/**
	 * open - Opens an XML document from the specified full file path
	 * and returns the newly-created XmlDocument object.  If the file
	 * path is invalid, the document contents are made empty, and the
	 * file path is used for writing when the document is closed.
	 *
	 * @public
	 * @static
	 * @param string $full_document_path
	 * @return (XmlDocument) the newly created object.
	 **/
	function & open($full_document_path)
	{
		$document_contents = (file_exists($full_document_path) ? file_get_contents($full_document_path) : '');
		return new XmlDocument($document_contents, $full_document_path);
	}

	/** CONSTRUCTOR **/

    /**
     * Constructor. Loads XML string into memory.
     * Optionally stores document path (if provided).
     * @public
     * @param $xml_string
     * @param $full_document_path
     **/
    function XmlDocument($xml_string, $full_document_path = NULL)
    {
		$this->_full_document_path = $full_document_path;	// optional
		$this->_root_element = NULL;
		$this->_stack = array();
		$this->_xml_contents = $xml_string;
		$this->_parse($xml_string);
    }

	/** PUBLIC METHODS **/

	/**
	 * Indicates whether the document is empty (usually because
	 * the initial document path did not point to a valid filename).
	 *
	 * @public
	 * @return boolean whether the document is empty
	 **/
	function isEmpty()
	{
		return ($this->_root_element === NULL);
	}

	/**
	 * Gets the root element of the XML document.
	 *
	 * @public
	 * @return XmlTag the root element of the XML document
	 **/
	function & getRootElement()
	{
		return $this->_root_element;
	}

	/**
	 * Sets the root element (name and attributes).  After performing
	 * this method, subsequent XmlTag::addChild() calls can be made to
	 * construct a complete XML document from scratch.
	 *
	 * @public
	 * @param string $name
	 * @param array $attributes
	 **/
	function setRootElement($name, $attributes)
	{
		$this->_root_element = new XmlTag($name, $attributes);
	}

    /**
     * Gets the XML output of the in-memory structure from the root node
     * ($this->_root_element) - this is the entire XML document.
     *
     * @public
     * @return string
     **/
    function toString($indent="\t")
    {
        return $this->_root_element->toString($indent);
    }

	/**
	 * Writes the current document to file.
	 *
	 * If a filename is provided in the method call, it is used.  Otherwise,
	 * the filename specified at object creation time (using XmlDocument::open())
	 * is used.  If neither were provided, an error is triggered. True/false
	 * is returned depending on if the write operation was successful.
	 *
	 * @public
	 * @param string $filename
	 * @return boolean whether the write operation was successful
	 **/
	function write($filename = NULL)
	{
		// get filename to write to
		if (!$filename) {
			if (!$this->_full_document_path) {
				trigger_error('No filename specified for writing XML Document.', E_USER_ERROR);
			}

			$filename = $this->_full_document_path;
		}

		// write the XML document contents to the filename
		$file = @fopen($filename, 'w');
		if (!$file) {
			return false;
		}

		if (!@fwrite($file, $this->toString())) {
			return false;
		}
		@fclose($file);

		return true;
	}

	/**
	 * Prints out debugging information for the object.
	 *
	 * @public
	 **/
	function debug()
	{
		echo "<pre>\n";
		print_r($this);
		echo "</pre>\n";
	}

	/** EVENT HANDLERS **/

    /**
     * Event handler that gets called by PHP when the start of a tag
     * is found (should not be called manually).
     *
     * @public
     * @param resource $parser
     * @param string $name
     * @param array $attrs
     **/
    function handleStartElement($parser, $name, $attrs = array())
    {
        // check to see if tag is root-level
        if (count($this->_stack) == 0) {
            // if so, set the root node as the current tag
            $this->setRootElement($name, $attrs);

            // push the root node onto the stack
            $this->_stack = array('_root_element');
        }

        // if it isn't root level, use the stack to find the parent
        else {
            // get the name which points to the current direct parent, relative to $this
            $parent = $this->_getStackLocation();

            // add the child
            eval('$this->'.$parent.'->addChild($name, $attrs, '.count($this->_stack).');');

            // update the stack
            eval('$this->_stack[] = \'c[\\\'\' . $name . \'\\\'][\' . (count($this->'.$parent.'->c[\''.$name.'\']) - 1) . \']\';');
        }
    }

    /**
     * Event handler that gets called by PHP when the end of a tag is
     * found (should not be called manually).
     *
     * @public
     * @param resource $parser
     * @param string $name
     **/
    function handleEndElement($parser, $name)
    {
        // update stack by removing the end value from it as the parent
        array_pop($this->_stack);
    }

    /**
     * Event handler that is called by PHP when the character data within
     * a tag is found (should not be called manually).
     *
     * @public
     * @param resource $parser
     * @param string $data
     **/
    function handleCharacterData($parser, $data)
    {
        // get the reference to the current parent object
        $tag = $this->_getStackLocation();

        // assign data to it
        eval('$this->'.$tag.'->tagData .= $data;');
    }

	/** PRIVATE METHODS **/

    /**
     * Initiates and runs PHP's XML parser on the provided string of XML
     * (sets up all the options, handlers, etc. to successfully parse the
     * document; reads the document into memory).
     *
     * @private
     * @param string $xml_string
     **/
    function _parse($xml_string)
    {
        // setup the parser resource for PHP's XML parser to use
        $this->_parser = xml_parser_create();
        xml_parser_set_option($this->_parser, XML_OPTION_CASE_FOLDING, 0);	// do not convert tag/attribute names to uppercase (i.e. WORKSHEET instead of worksheet)
        xml_set_object($this->_parser, $this);

        // setup the event handlers
        xml_set_element_handler($this->_parser, 'handleStartElement', 'handleEndElement');
        xml_set_character_data_handler($this->_parser, 'handleCharacterData');

        // parse the provided XML string - handle errors if applicable
        if (!xml_parse($this->_parser, $xml_string)) {
            $this->_handleError(xml_get_error_code($this->_parser), xml_get_current_line_number($this->_parser), xml_get_current_column_number($this->_parser));
		}

        // free the parser
        xml_parser_free($this->_parser);
    }

    /**
     * Handles an XML parsing error (only called if xml_parse() fails).
     *
     * @private
     * @param int $code XML Error Code
     * @param int $line Line on which the error happened
     * @param int $col Column on which the error happened
     **/
    function _handleError($code, $line, $col)
    {
    	
    	echo 'XML Parsing Error at '.$line.':'.$col.'. Error '.$code.': '.xml_error_string($code)."\n";
    	echo "\nFull XML Contents: \n" . $this->_xml_contents . "\n";
    	
    	if ($this->_full_document_path) {
    		$document_path = $this->_full_document_path;
    	} else {
    		$document_path = "none";
    	}
    	echo "\nFull document path: " . $document_path . "\n\n";
    	
        trigger_error('error triggered');
    }

    /**
     * Gets the reference to the current direct parent.
     *
     * @private
     * @return object
     **/
    function _getStackLocation()
    {
        $return = '';

        foreach($this->_stack as $stack) {
            $return .= $stack.'->';
		}

        return rtrim($return, '->');
    }
}
