#!/usr/local/bin/php -q
<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2015 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * @file
 * LobbyTrie.class.php Simple class to do lobbytrie checking.
 *
 * @author  Matt Gould <mgould@adobe.com>
 *
 */

require_once 'trie.class';

/**
 * Simple class to do lobbytrie checking.
 *
 */
class LobbyTrie {
    private $trie;
    private $lobby_dist;
    private $ld;

    function __construct() {
        $db = new masterdb;
        $this->trie = new Trie();
        $this->lobby_dist = array();
        $this->ld = new lobby_distribution();

        $db->query("SELECT * FROM lobby_distribution");
        while($db->next_record()){
            $base = strtolower($db->f('base'));
            $this->trie->addString($base);
            $servers = explode(',',$db->f('hosts'));
            $this->lobby_dist[$base] = $servers;
        }


    }

    /**
     * Find which base a user belongs to.
     * @param string $user The report suite you want to know about.
     *
     * @return string The lobby base that the user belongs to.
     */
    function getBaseForUser($user) {
        $user = strtolower($user);
        //return $this->trie->getParent($user.'.');
        if ($this->trie->findString($user)) {
            return $user;
        } else {
            return $this->trie->getParent($user);
        }
    }

    /**
     * Get the next level children of the given base.
     * @param string $base
     *
     * @return array
     */
    function getChildBases($base) {
        $base = strtolower($base);
        return $this->trie->getChildren($base,false);
    }

    /**
     * Get the lobby servers that belong to the base.
     * @param string $base
     *
     * @return array
     */
    function getServersForBase($base) {
        return $this->lobby_dist[$base];
    }

    /**
     * Get the bases that a lobby server belongs to.
     * @param string $server
     *
     * @return array
     */
    function getBasesForServer($server) {
        //the hosts field matches when the host name is found with either a comma or a beginning or end of string around it.
        $regex = "/(^|,)$server(,|$)/";
        return $this->ld->indexes_matching_field_regex('hosts', $regex);
    }

}
