<?php

require_once 'appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php';

/**
 * The purpose of this class is to generate access tokens for the new admin services APIs.
 * The usage pattern is that you would use this class to generate an access token when you initially load up a page that needs to access the Admin Services APIs.
 * You would then expose that access token to the page as a javascript variable. This javascript variable would then be included as one of the headers on all Admin ServicesAPIs.
 * The API would verify that this request is an active access token and would also identify the current context (meaning the login company and user ID) based on the access token.
 */
class OM_AdminServicesAccessTokenGenerator extends OM_AnalyticsServicesAccessTokenGenerator {

	/**
	 * Get an access token that is tied to a specific DrTeeth ssSession. This may be an existing token if a token has already been tied to the session. Otherwise it will generate a new access token
	 * @param ssSession $session
	 * @param $companyname
	 * @param $companyid
	 * @param $loginid
	 * @return bool|string		False if a token couldn't be generated or the access token string if successful
	 */
	public function getTokenForDrTeethSession($session,$loginname,$loginid){
		$token_id = false;
		if($session instanceof adminSession){
			$session_id = $session->id; //Get the session ID for the DrTeeth.
			$companyname=""; // There is no company name, and it is not saved to the db, this is only being used to compose the salt to generate the token
			$companyid=0;
			$clientId=self::CLIENT_ID_ADMINSERVICE;
			if($session_id){
				$token_type = self::TOKENTYPE_DRTEETHSESSION;
				$token_id = $this->getExistingTokenID($token_type,$session_id);
				if(!$token_id){
					//User ID needs to be stored in the DB so that on the Java side Admin Services can determine what user the access token belongs to.
					//This information is available in the sessiondb, but isn't in a format that be accessed easily in Java
					$token_id = $this->generateTokenID($companyname .":". $loginname);
					$token_id = $this->saveTokenToDB($token_id,$token_type,$session_id,$companyid,$loginid,$clientId);
				}
				if ($token_id){
					$token_id = "ADM:".$token_id;
				}
			}
		}
		return $token_id;
	}

	public static function getTokenForCurrentUser(){
		global $admin_auth;

		if (isset($admin_auth->auth['admin_service_access_token'] )) {
			$accessToken = $admin_auth->auth['admin_service_access_token'];
			return $accessToken;
		} else {
			throw new Exception("No admin service token was found in the current session");
		}
	}



}
