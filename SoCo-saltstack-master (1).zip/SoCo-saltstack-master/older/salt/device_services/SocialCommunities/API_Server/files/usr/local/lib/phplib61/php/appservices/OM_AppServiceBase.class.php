<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property laws,
 * including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

class OM_AppServiceBase {

	const GET_REQUEST = "GET";
	const POST_REQUEST = "POST";
	const PUT_REQUEST = "PUT";
	const DELETE_REQUEST = "DELETE";

	private $endpoint_override = null;

	private function makeRequest($url, $token, $request_type = self::GET_REQUEST,$request_body = "",$is_service_token = false, $proxy_company = '', $proxy_username = '', $proxy_company_id = 0, $proxy_loginid = 0){

		//TODO: add caching to the token generator
		$token_id = 'Authorization: Bearer ';
		if(!$is_service_token){
			$token_id .= "SC:";
		}
		$token_id .= $token;

		$ch = curl_init();

		//Handle non-GET request HTTP request type
		if($request_type == self::PUT_REQUEST){
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST,$request_type);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$request_body);
		}
		else if($request_type == self::POST_REQUEST){
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$request_body);
		}
		else if($request_type == self::DELETE_REQUEST){
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST,$request_type);
		}

		//#curl_setopt($ch, CURLOPT_VERBOSE, true);
		curl_setopt($ch,CURLOPT_URL,$url);
		$headers = array();
		$headers[] = 'Content-Type:application/json';
		$headers[] = 'charset=UTF-8';
		$headers[] = 'Accept:application/json';
		$headers[] = $token_id;
		if ($proxy_company && $proxy_username) {
			$headers[] = 'proxy-company: ' . $proxy_company;
			$headers[] = 'proxy-username: ' . $proxy_username;
		}
		if ($proxy_company_id && $proxy_loginid) {
			$headers[] = 'proxy-company-id: ' . $proxy_company_id;
			$headers[] = 'proxy-userid: ' . $proxy_loginid;
		}
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_ENCODING , "gzip");
		$response = curl_exec($ch);
		$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		return new OM_AppServiceResponse($httpCode,$response);
	}

	/**
	 * Make a request to the appservices platform APIs
	 * @return OM_AppServiceResponse
	 */
	protected function makePlatformEndpointRequest($path, $token, $request_type = self::GET_REQUEST,$request_body = "", $proxy_company = '', $proxy_username = '', $proxy_company_id = 0, $proxy_loginid = 0){
		$url = $this->getEndpoint(ANALYTICS_SERVICES_PLATFORM_ENDPOINT_INTERNAL_1_0) . $path;
		return $this->makeRequest($url,  $token, $request_type,$request_body,true, $proxy_company, $proxy_username, $proxy_company_id, $proxy_loginid);
	}

	/**
	 * Make a request to the appservices analytics APIs
	 * @return OM_AppServiceResponse
	 */
	protected function makeAnalyticsEndpointRequest($path, $token, $request_type = self::GET_REQUEST,$request_body = "", $is_service_token = false, $proxy_company = '', $proxy_username = '', $proxy_company_id = 0, $proxy_loginid = 0) {
		$url = $this->getEndpoint(ANALYTICS_SERVICES_ENDPOINT_INTERNAL_1_0) . $path;
		return $this->makeRequest($url, $token, $request_type, $request_body, $is_service_token, $proxy_company, $proxy_username, $proxy_company_id, $proxy_loginid);
	}

    /**
     * Make a request to the admin analytics APIs
     * @return OM_AdminResponse
     */
    protected function makeAdminEndpointRequest($path, $token, $request_type = self::GET_REQUEST,$request_body = ""){
        $url = $this->getEndpoint(ANALYTICS_SERVICES_ADMIN_ENDPOINT_INTERNAL_1_0) . $path;
        return $this->makeRequest($url,  $token, $request_type, $request_body, true);
    }

	protected function createShare($user, $componentId, $componentType, $shareToType, $shareToId){
		$path = "/shares";

		// Build auth token
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getTokenForUser($user);

		$request_array = array();
		if($componentId){
			$request_array["componentId"] = $componentId;
		}
		if($componentType){
			$request_array["componentType"] = $componentType;
		}
		if($shareToType){
			$request_array["shareToType"] = $shareToType;
		}
		if($shareToId){
			$request_array["shareToId"] = $shareToId;
		}
		$request_json = json_encode($request_array);

		$response = $this->makeAnalyticsEndpointRequest($path,$token,self::POST_REQUEST,$request_json);
		return $response;
	}

	public function overrideEndpoint($endpointOverride) {
		$this->endpoint_override = $endpointOverride;
	}

	private function getEndpoint($endpoint) {
		if (isset($this->endpoint_override)) {
			return $this->endpoint_override;
		} else {
			return $endpoint;
		}
	}
}

class OM_AppServiceResponse{

	private $response_text;
	private $http_response_code;

	public function __construct($http_response_code,$response_text){
		$this->http_response_code = $http_response_code;
		$this->response_text = $response_text;
	}

	/**
	 * Get the actual text returned from an appservices API call
	 */
	public function getResponse(){
		return $this->response_text;
	}

	public function hasErrors(){
		if($this->http_response_code != 200 && $this->http_response_code != 204){
			return true;
		}
		return false;
	}

	public function hasForbiddenResponseCode(){
		if($this->http_response_code == 403){
			return true;
		}
		return false;
	}

	public function hasResourceNotFoundResponseCode(){
		if($this->http_response_code == 404){
			return true;
		}
		return false;
	}

	public function getErrorMessage(){
		if($this->response_text){
			$response_obj = json_decode($this->response_text);
			return $response_obj->errorDescription;
		}
	}

	public function getErrorId(){
		if($this->response_text){
			$response_obj = json_decode($this->response_text);
			return $response_obj->errorId;
		}
	}

	public function getErrorCode(){
		if($this->response_text){
			$response_obj = json_decode($this->response_text);
			return $response_obj->errorCode;
		}
	}

	public function getTotalPages(){
		$decoded_response = json_decode($this->response_text);
		if($decoded_response){
			return $decoded_response->totalPages;
		}
	}
}
