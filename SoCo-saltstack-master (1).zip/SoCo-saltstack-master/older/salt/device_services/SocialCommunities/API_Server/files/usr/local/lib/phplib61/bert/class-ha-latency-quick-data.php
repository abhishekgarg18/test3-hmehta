<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

// latency data keys:
//                 'userid'
//                 'username'
//                 'host'
//                 'db'
//                 'data_center'
//                 'billing_customer_id'
//                 'sc_version'
//                 'sc_latency_minutes'
//                 'billing_customer'
//                 'latency_comments'
//                 'top100'
//                  'migrating'

require_once 'application.inc';
require_once 'class-ha-utilities.php';
require_once 'latencyAPI.inc';
require_once 'LatencyHistory.class';
require_once 'ReportSuiteConfig.class';
require_once '/home/httpd/bin/bert/includes/comments.inc';
require_once 'pun/webclient/LatencyNoticeWebClient.php';
require_once 'reverse_userid_lookup.inc';
require_once 'DataMigration.class';

include $localConfig['ssv5']['dir'].'/api/includes/api_functions.inc';
include $localConfig['ssv5']['dir'].'/api/ha_hits.class';
include $localConfig['ssv5']['dir'].'/reports/includes/date_functions.inc';

class HA_Latency_Quick_Data extends HA_Utilities {
    protected $data = array();
    protected $customers_to_skip = array();
    protected $customer_ids_to_skip = array();
    protected $billing_customer_cache = array();
    protected $parse_failure = false;
    protected $owner_email = 'maryshaw@adobe.com';
    protected $save_data_type = 'PHP'; // could be 'PHP' or 'JSON'
    protected $sql_comment = '/* MODULE: bertlib/bert FILE: class-ha-latency-quick-data.php */';
    
	function __construct($args = array()) {
		parent::__construct($args);
        
        $this->customers_to_skip = array(
            //'zzINACTIVE',
            'zzDUPLICATE',
            'OMNITURE-TESTING CUSTOMER',
            'OMNITURE-EMPLOYEE USAGE',
        );
        $this->load_customer_ids_to_skip($this->customers_to_skip);
        $this->latency_history = new LatencyHistory();
        $this->latency_api = new latencyAPI();
        $this->dm = new DataMigration();
        
        // with data validation
        $possible_save_data_types = array('PHP', 'JSON');
        if (isset($args['save_data_type']) && in_array($args['save_data_type'], $possible_save_data_types)) {
            $this->save_data_type = $args['save_data_type'];
        }

	}
    
    function load_customer_ids_to_skip($new_customer_names = array()) {
        
        // load default list of customers to skip if nothing gets passed in
        if (count($new_customer_names) == 0) {
            $new_customer_names = $this->customers_to_skip;
        }
        
        $this->customer_ids_to_skip = array();
        $companydb = new DB_SQL("companydb");
        foreach($new_customer_names as $customer_name) {
            $companysql = 'SELECT ' . $this->sql_comment . ' id from billing_customer where cus_name="' . $customer_name . '" limit 1';
            $companydb->query($companysql);
        
            if ($companydb->next_record()) {
                $this->customer_ids_to_skip[$companydb->f('id')] = $customer_name;
            }
        }
        
        return $this->customer_ids_to_skip;
    }
    
    function get_customer_skip_status($billing_customer_id) {
        if (isset($this->customer_ids_to_skip[$billing_customer_id])) {
            return true;
        }
        return false;
    }
    
    function get_all_current_data() {
        $retval = array();
        
        // get data from the given id
        $retval['current-data'] = $this->data();
        $retval['current-top-100-data'] = $this->get_top_100_data($retval['current-data']);
        
        // get "old" data from the given id (id minus 1)
        $retval['old-data'] = $this->get_data_row_by_id( $this->get_max_id() );
        $retval['old-top-100-data'] = $this->get_top_100_data($retval['old-data']['data']);
        
        $this->debug('comparing current data with data from the email ID ' . $this->get_max_id());
        

        // find out what's caught up since the last report
        $retval['current-caught-up-data'] = $this->get_caught_up_data($retval['current-data'], $retval['old-data']['data']);
        $retval['current-top-100-caught-up-data'] = $this->get_caught_up_data($retval['current-top-100-data'], $retval['old-top-100-data']);
        
        // get "billing customer" data
        $retval['billing-customer-data'] = $this->billing_customer_data($retval['current-data']);
        $retval['billing-customer-caught-up-data'] = array();
        if (!empty($retval['current-caught-up-data'])) {
            $retval['billing-customer-caught-up-data'] = $this->billing_customer_data($retval['current-caught-up-data']);
        }

        return $retval;
    }

    function get_all_data_by_id($report_data_id = 0) {
        $retval = array();
        if ($report_data_id > 0) {
            $retval['email-id'] = $report_data_id;
            
            // get data from the given id
            $retval['current-data'] = $this->get_data_row_by_id($report_data_id);
            $retval['current-top-100-data'] = $this->get_top_100_data($retval['current-data']['data']);
            
            // get "old" data from the given id (id minus 1)
            $retval['old-data'] = $this->get_data_row_by_id($report_data_id - 1);
            $retval['old-top-100-data'] = $this->get_top_100_data($retval['old-data']['data']);
            
            // find out what's caught up since the last report
            $retval['current-caught-up-data'] = $this->get_caught_up_data($retval['current-data']['data'], $retval['old-data']['data']);
            $retval['current-top-100-caught-up-data'] = $this->get_caught_up_data($retval['current-top-100-data'], $retval['old-top-100-data']);
            
            // get "billing customer" data
            $retval['billing-customer-data'] = $this->billing_customer_data($retval['current-data']['data']);
            $retval['billing-customer-caught-up-data'] = array();
            if (!empty($retval['billing-customer-data'])) {
                $retval['billing-customer-caught-up-data'] = $this->billing_customer_data($retval['current-caught-up-data']);
            }

        }
        
        return $retval;
    }

    function data($new_data = false) {
		if ( $new_data !== false ) {
			$this->data = $new_data;
		}
		return $this->data;
    }

    function owner_email($new_owner_email = NULL) {
        if (isset($new_owner_email) && (strlen($new_owner_email) > 0)) {
            $this->owner_email = $new_owner_email;
        }
        return $this->owner_email;
    }

    function parse_failure() {
        return $this->parse_failure;
    }
    
    // data can be in either json or serialized format.
    // here we try the serialized format first; if that didn't work, we try the json format
    // if nothing worked, alert the script's owner
    function parse_raw_data($data = '') {

        // try to decode as if it were in serialized format
        $retval = @unserialize($data);
        if (($data != serialize(false)) && ($retval !== false)) {
            $this->debug("Parsed some PHP data." . $data);
            return $retval;
        }

        // try to decode as if it were in json format
        if ((strlen($data) > 0) && (is_string($data))) {
            $retval = json_decode($data, true);
            if ($retval !== false) {
                //$this->debug("Parsed some JSON data." . $data);
                $this->debug("Parsed some JSON data. " );
                $this->debug_r($retval);
                return $retval;
            }
        }

        // if the data set is truly empty, that is OK! 
        // return an empty array, and throw NO errors.
        if (is_null($data) || ($data == 'null')) {
            return array();
        }
        
        // last-ditch effort to save the data!  remove PHP errors & warnings at the front.
        $mod_data = preg_replace('/^(.*)(PHP )?Warning:(.)*line (\d+)(\s*)a\:/', 'a\:', $data);
        $mod_data_retval = @unserialize($mod_data);
        if ($mod_data_retval !== false) {
            $this->debug("removed PHP warnings to parse this data, but it parsed OK.");
            return $mod_data_retval;
        }
        else {
            $this->debug("removed PHP warnings to parse this data, but it didn't parse OK.");
            print_r($mod_data);
        }

        // record a parse error.
        // email Mary & log if the data won't parse
        $error_msg = '"Error parsing quick data results on ' . $_ENV["HOSTNAME"] . ' - ' . date('D, M j, \a\t g:iA') . ":\n" . substr($data, 128*8) . " [The rest is truncated]\n\n";
        $success = mail($this->owner_email(), 'Latency Report: Parse Error', $error_msg, "From: Latency Monitor <Adobe-Analytics-Latency-Monitor@adobe.com>\r\n");
        file_put_contents('/tmp/latency-report-error.txt', $error_msg . $data);
        $this->error($error_msg);
        $this->parse_failure = true;
        return false;
    }
    
    // sorts an array full of report suites by:
    // 1. RSID (i.e., username)
    // 2. SC latency in minutes
    // 3. top 100
    static function sort_latency_data($a, $b) {
        if ( ($a['top100'] == $b['top100']) && ($a['sc_latency_minutes'] == $b['sc_latency_minutes']) ) {
            return strnatcmp($a['username'], $b['username']);
        }
        else if ($a['top100'] == $b['top100']) {
            return ($a['sc_latency_minutes'] > $b['sc_latency_minutes']) ? -1 : 1;
        }
        
        return ($a['top100'] > $b['top100']) ? -1 : 1;
    }
    
    // sorts an array full of billing customers by:
    // 1. billing customer
    // 2. # of report suites in that billing customer
    // 2. the highest latency (in minutes) of all report suites in that billing customer
    static function sort_billing_customer_data($a, $b) {
        $a_num_items = count($a['items']);
        $b_num_items = count($b['items']);
        
        if ( ($a['max_latency_minutes'] == $b['max_latency_minutes']) && ($a_num_items == $b_num_items) ) {
            return strnatcmp($a['billing_customer'], $b['billing_customer']);
        }
        else if ($a['max_latency_minutes'] == $b['max_latency_minutes']) {
            return ($a_num_items > $b_num_items) ? -1 : 1;
        }
        
        return ($a['max_latency_minutes'] > $b['max_latency_minutes']) ? -1 : 1;
    }
    
    function add_raw_data($raw_data, $encoding_type) {
        $contents = $this->parse_raw_data($raw_data);
        
        if ($contents === false) {
            return false;
        }
        
        if (is_array($contents)) {
            $this->data = array_merge( (array)$contents, $this->data );
        }

        usort($this->data, "HA_Latency_Quick_Data::sort_latency_data");
        return $this->data;
    }
        
 
    // add data from a file to the data set we already have in here.
    // unpack it as either a serialized array or a json object
    function add_raw_data_file($filename) {
        if (file_exists($filename)) {
            $contents_raw = file_get_contents($filename);
            $contents = $this->parse_raw_data($contents_raw);
            
            if ($contents === false) {
                return false;
            }
            
            if (is_array($contents)) {
                $this->data = array_merge( (array)$contents, $this->data );
            }
        }
        usort($this->data, "HA_Latency_Quick_Data::sort_latency_data");
        return $this->data;
    }
    
    // gets & aggregates a list of raw data files
    function add_raw_data_files($filenames) {
        foreach($filenames as $filename) {
            $this->add_raw_data_file($filename);
        }
        return $this->data;
    }
    
    // aggregate the report suite data set by billing customer
    // if the $dataset argument isn't null, we'll use that instead of $this->data
    // the $includeTop100 argument will include/exclude top 100 report suites
    // creates, sorts, & returns $this->customers
    function billing_customer_data($dataset = NULL, $includeTop100 = true) {
        $customers = array();

        // use $this->data if $dataset isn't present
        if (is_null($dataset)) {
            $dataset = $this->data;
        }
        
        if (is_array($dataset)) {
            foreach($dataset as $item) {
                
                // skip non-top100 report suites if applicable
                if (($includeTop100 === false) && ($item['top100'])) {
                    continue;
                }
                
                // initialize the object for this billing customer, if we are seeing 
                //      this billing customer for the first time
                if (!(array_key_exists($item['billing_customer'], $customers))) {
                    $customers[ $item['billing_customer'] ] = array(
                        'items' => array(),
                        'billing_customer' => $item['billing_customer'],
                        'max_latency_minutes' => 0,
                        'has_migrating_accounts' => 0,
                    );
                }
                $customers[ $item['billing_customer'] ]['items'][] = $item;
                
                // keep track of the highest latency number for each customer
                if ($customers[ $item['billing_customer'] ]['max_latency_minutes'] < $item['sc_latency_minutes'])  {
                    $customers[ $item['billing_customer'] ]['max_latency_minutes'] = $item['sc_latency_minutes'];
                }
                
                // flag the customer's migration status if one (or more) migrating report suites are present
                if ($item['migrating']) {
                    $customers[ $item['billing_customer'] ]['has_migrating_accounts'] = true;
                }
            }
        }

        usort($customers, "HA_Latency_Quick_Data::sort_billing_customer_data");
        return $customers;
    }

    // returns comments  on that report suite from the past 24 hours
    function get_recent_comments($username, $start_date = NULL) {
        if (empty($start_date)) {
            $start_date = time() - 60*60*24;
        }
    
        $filter = new commentSearchFilter();
        $filter->startdate = date('Y-m-d H:i:s', $start_date);
        $filter->accounts = array($username);
        $filter->visibility = 1;
        
        $latency_comments = array();
        $comment_list = new comment_list();
        $comments = $comment_list->searchComments($filter);
        if (count($comments) > 0) {
            foreach($comments as $comment) {
                $comment_time = strtotime($comment['dt_time']);
                $raw_comment = $comment['comment_text'] . 
                    ' on ' . date('D, M j, Y', $comment_time) . ' at ' . date('g:ia T', $comment_time);
                $latency_comments[] = preg_replace('/,/', '&#44;', $raw_comment);
            }
        }
        
        return $latency_comments;
    }
    
    // get the billing customer name from the company database
    // we know the billing_customer id field
    function get_billing_customer_name($billing_customer_id, $companydb) {
        if (!isset($this->billing_customer_cache[$billing_customer_id])) {

            $companysql = "SELECT " . $this->sql_comment . " cus_name from billing_customer where id=" . $billing_customer_id . " limit 1";
            $companydb->query($companysql);
        
            $this->billing_customer_cache[$billing_customer_id] = '';
            if ($companydb->next_record()) {
                $this->billing_customer_cache[$billing_customer_id] = $companydb->f('cus_name');
            }
        }
        
        return $this->billing_customer_cache[$billing_customer_id];
    }
    
    // figure out the data center from db host's suffix
    function find_data_center($host, $complete_suffix_list) {
        
        // DEV is dev. no cross data center stuff there.
        if (DATA_CENTER == DATA_CENTER_DEV) {
            return DATA_CENTER;
        }
        
        if (is_array($complete_suffix_list)) {
            foreach($complete_suffix_list as $s_data_center => $suffixes) {
                
                if (is_array($suffixes)) {
                    foreach($suffixes as $suffix) {
                        $pos = strrpos($host, $suffix);
                        if (($pos > 0) && ($pos + strlen($suffix)) == strlen($host)) {
                            return $s_data_center;
                        }
                    }
                }
                
                // try data center name if the suffix wasn't found.
                $pos = strrpos($host, $s_data_center);
                if (($pos > 0) && ($pos + strlen($s_data_center)) == strlen($host)) {
                   return $s_data_center;
                }
            }
        }
        else {
        }
        
        // San Jose doesn't follow the rules, so if a suffix isn't found, the server is probably  in San Jose.
        return DATA_CENTER_SAN_JOSE;
    }
    
    // returns a list of all users in this data center according to parameters in $args
    function getLatentUsers($args = array()) {

        // read the args into these variables
        $max_lobby_seconds = NULL;
        $max_elevator_seconds = NULL;
        $max_export_seconds = NULL;
        $max_axle_seconds = NULL;
        $max_seconds = NULL;
        $start_time = NULL;
        $end_time = time();
        $init_end_time = $end_time;

        // here, max-seconds is lower in precendent
        // so set max-seconds to everything
        if (isset($args['max-seconds'])) {
            $max_lobby_seconds = intval($args['max-seconds']);
            $max_elevator_seconds = intval($args['max-seconds']);
            $max_export_seconds = intval($args['max-seconds']);
            $max_axle_seconds = intval($args['max-seconds']);
        }

        // set all the other max seconds arguments
        foreach($args as $key => $value) {
            switch($key) {
                case 'max-lobby-seconds':
                case 'lobby':
                    $max_lobby_seconds = intval($args[$key]);
                break;
                case 'max-elevator-seconds':
                case 'elevator':
                    $max_elevator_seconds = intval($args[$key]);
                break;
                case 'max-export-seconds':
                case 'export':
                    $max_export_seconds = intval($args[$key]);
                    $this->debug('Export seconds: ' . $args[$key]);
                break;
                case 'max-axle-seconds':
                case 'axle':
                    $max_axle_seconds = intval($args[$key]);
                break;
                case 'start-time':
                    $new_start_time = strtotime($args[$key]);
                    if ($new_start_time > 0) {
                        $start_time = $new_start_time;
                    }
                break;
                case 'end-time':
                    $new_end_time = strtotime($args[$key]);
                    if ($new_end_time > 0) {
                        $end_time = $new_end_time;
                    }
                break;
            }
        }

        // go back 19 minutes; Matthew says latency data is never more than
        // 15 minutes old, so this should be plenty of time.
        // default start time: use time range of the last 20 minutes
        if (is_null($start_time) || ($start_time >= $end_time)) {
            $start_time = $end_time - 35*60;
        }

        // build 'where' clause using any & all args provided
        $where_statements = array();
        if (!empty($max_lobby_seconds)) {
            $where_statements[] = " (lobby > $max_lobby_seconds) ";
        }
        if (!empty($max_elevator_seconds)) {
            $where_statements[] = " (elevator > $max_elevator_seconds) ";
        }
        if (!empty($max_export_seconds)) {
            $where_statements[] = " (export > $max_export_seconds) ";
        }
        if (!empty($max_axle_seconds)) {
            $where_statements[] = " (axle > $max_axle_seconds) ";
        }

        $db = new DB_SQL('latency_history');
        $db->halt_on_error = false;
        $threshold  = intval($max_threshold_seconds);
        $latents    = array();

        // latency history tables are named after the day the snapshot was taken
        $table_name = 'latency_history_' . date('Y_m_d', $end_time);
        
        // get the date stamp needed for the query
        $sql = 'select max(update_dt_tm) as stamp from ' . $table_name;
        $wheres = array(
            "(update_dt_tm >= FROM_UNIXTIME(" . $start_time . "))"
        );
        if ($end_time < $init_end_time) {
            $wheres[] = "(update_dt_tm <= FROM_UNIXTIME(" . $end_time . "))";
        }
        if (count($wheres) > 0) {
            $sql .= ' WHERE ' . join(' AND ', $wheres);
        }
        $db->query($sql);

        $update_dt_tm = date('Y-m-d H:i:s'); // to be replaced by the real timestamp from the db.
        if ($db->Errno == 0) {
            if ($db->next_record()) {
                $update_dt_tm = $db->f('stamp');
                $this->debug('latency history timestamp is changed by query ' . $update_dt_tm);
            }
        }
        $this->debug('latency history timestamp set to  ' . $update_dt_tm);

        // get all users close to any threshold; we can throw a few away later
        $sql = "SELECT " . $this->sql_comment . "\n" .
                " DISTINCT userid, update_dt_tm, lobby, elevator, export, axle \n" .
                " FROM " . $table_name . " \n" .
                " WHERE (" . join(' || ', $where_statements) . ")\n" .
                "   AND (update_dt_tm = '" . $update_dt_tm . "')\n";
        // todo add "not in billing customer id exclusion list"
        $this->debug('latency history query is ' . $sql);
                
        $db->query($sql);

        if ($db->Errno == 0) {
            while ($db->next_record()) {
                $userid = $db->f('userid');
                $key = $userid . '-' . DATA_CENTER;
                $item = array(
                    'userid'       => $userid,
                    'update_dt_tm' => $db->f('update_dt_tm'),
                    'username'     => reverse_userid_lookup($userid),
                    'elevator'     => $db->f('elevator'),
                    'axle'         => $db->f('axle'),
                    'export'     => $db->f('export'),
                    'lobby'         => $db->f('lobby'),
                );

                // skip invalid users
                if (strlen($item['username']) <= 0) {
                    continue;
                }

                // if there are duplicates, keep just the newest value
                if (isset($latents[ $key ])) {
                    if ($item['update_dt_tm'] > $latents[ $key ]['update_dt_tm']) {
                        $latents[ $key ] = $item;
                    }
                }
                else {
                    $latents[ $key ] = $item;
                }
            }
        }
        //$this->debug('found ' . count($latents) . ' latents.');

        return $latents;
    }
    
    // get all users having latency over a minimum SC latency threshold
    // top 100 customers have a different threshold
    function get_data_quick($top_latency_min, $latency_min, $latency_type = 'SC', $encode_flag = false) { 
        $db      = new DB_SQL("masterdb");
        $companydb = new DB_SQL("companydb");
        
        // quickly get an approximate list of who has normal latency
        // use the smallest threshold to start with; throw away ones that don't fit the criteria later
        $threshold_seconds = ($top_latency_min < $latency_min) ? ($latency_min*60) : ($top_latency_min*60);
        if ($latency_type == 'SC') {
            $latents = $this->getLatentUsers( array(
                'elevator' => $threshold_seconds,
                'axle' => $threshold_seconds,
                'end-time' => time(),
            ) );
        }
        else if ($latency_type == 'export') {
            $latents = $this->getLatentUsers( array(
                'export' => $threshold_seconds,
                'end-time' => time(),
            ) );
        } 
        $final_latents = array();
        
        // go through each account we caught.  throw away some, but get more data on the ones we keep.
        $i = 0;
        foreach($latents as $key => $item) {
            $userid = $item['userid'];

            $i++;
            
            // query for user data one by one because different users will live in different userdbs
            setuserdb($db, $item['username']);
            $sql = "SELECT " . $this->sql_comment . "\n" .
                       "       u.userid, \n" .
                       "       u.username, \n" .
                       "       u.billing_customer_id, \n" .
                       "       u.enterprise, \n" .
                       "       s.axle_start, \n" .
                       "       s.axle_data, \n" .
                       "       s.workbench_sampling \n" .
                       "  FROM user u \n" .
                       "  INNER JOIN user_services s ON u.userid=s.userid \n" .
                       " WHERE u.userid=" . $item['userid'] . 
                       " LIMIT 1";
            $db->query($sql);
        
            if ($db->Errno == 0) {
                while ($db->next_record()) {
                    
                    // skip non-enterprise users
                    if ($db->f('enterprise') != 1) {
                        continue;
                    }
                    
                    // skip certain predetermined customers
                    if ($this->get_customer_skip_status($db->f("billing_customer_id"))) {
                        continue;
                    }
                    
                    $get_more_user_data_args = array(
                        'userid' => $item['userid'],
                        'username' => $db->f("username"),
                        'billing_customer_id' => $db->f("billing_customer_id"),
                        'axle_start' => $db->f("axle_start"),
                        'axle_data' => $db->f("axle_data"),
                        'workbench_sampling' => $db->f("workbench_sampling"),
                        'top_latency_min' => $top_latency_min,
                        'latency_min' => $latency_min,
                        'latency_type' => $latency_type,
                        'data_center' => DATA_CENTER,
                        'host' => $db->Host,
                        'db' => $db->Database,
                        //'latency' => $latent_user,
                    ); 

                    // get more user data, add to the final data array if data is returned
                    // (if no data returned, latency isn't bad enough)
                    $user_data = $this->get_more_user_data($get_more_user_data_args, $companydb);
                    if (is_array($user_data) ) {
                        $final_latents[$userid . '-' . DATA_CENTER] = $user_data;
                    }
                }
            }
        }
        $this->data($final_latents);
        
        if ($encode_flag) {
            if ($this->save_data_type == 'JSON') {
                return json_encode($this->data);
            }
            else {
                return serialize($this->data);
            }
        }
        return $final_latents;
    }

    //	copied from date_functions.inc, so that we can adjust the timezone
    /*  NOT USED now, because this check takes too long
    function hidden_relative_date2($dayoffset=0, $timezone_offset) {
        if( $dayoffset > 0 ) return ymd_to_timestamp($dayoffset);
        // get current date/time in GMT
        $gmnow = gmdate("Y-m-d-H-i-s");
        list ($gm_y, $gm_m, $gm_d, $gm_h, $gm_i, $gm_s) = explode ("-", $gmnow);
        // get timezone offset
        $ofs_hr  = $timezone_offset;
        $ofs_min = $ofs_hr * 60;
        return mktime($gm_h, $gm_i + $ofs_min, $gm_s, $gm_m, $gm_d + $dayoffset, $gm_y);
    }
    */
    
    function get_more_user_data($args, $companydb) {
        $top_latency_min = $args['top_latency_min'];
        $latency_min = $args['latency_min'];
        $latency_type = $args['latency_type'];
        $data_center = $args['data_center'];
        $userid = $args['userid'];
        $username = $args['username'];
        $billing_customer_id = $args['billing_customer_id'];
        $axle_start = $args["axle_start"];
        $axle_data = $args["axle_data"];
        $has_wb = $args["workbench_sampling"];

        if (!isset($args['elevator'])) {
            $this_latency = $this->latency_api->getElevatorLatencyByUser($userid);
            $minutes_latent = 0;
            if (is_array($this_latency)) {
                $minutes_latent = floor( max( $this_latency) / 60 );
            }
            $args['elevator'] = $minutes_latent;
        }

        // check for version & version latency
        $sc_version = '14';
        if (($axle_start != -1 && $axle_start != '0000-00-00' && $axle_start <= date('Y-m-d')) &&
                    $axle_data > 0 && $has_wb > 0) {
            $sc_version = '15';
            
            // for v15, axle latency is SC latency
            if (isset($args['axle'])) {
                $sc_latency_minutes = $args['axle'];
            }
            else {
                $this_latency = $this->latency_api->getAxleLatencyByUser($userid);
                $minutes_latent = 0;
                if(is_array($this_latency)){
                    $minutes_latent = floor( max( $this_latency) / 60 );
                }
                $args['axle'] = $minutes_latent;
                $sc_latency_minutes = $args['axle'];
            }

        }
        else {
            $sc_latency_minutes = $args['elevator'];
        }
        
        $this_latency = $this->latency_api->getExportLatencyByUser($userid);
        $minutes_latent = 0;
        if (is_array($this_latency)) {
            $minutes_latent = floor( max( $this_latency) / 60 );
        }
        $args['export'] = $minutes_latent;

        $this_latency = $this->latency_api->getLobbyLatencyByUser($userid);
        $minutes_latent = 0;
        if (is_array($this_latency)) {
            $minutes_latent = floor( max( $this_latency) / 60 );
        }
        $args['lobby'] = $minutes_latent;

        // find out if this user is on the top 100 list
        $top100 = false;
        try {
            $web_client = new LatencyNoticeWebClient();
            $top100 = $web_client->noticeEligible($username);
        }
        catch(Exception $e) {
            $top100 = false;
        }
        catch(InvalidParameterException $ie) {
            $top100 = false;
        }
        
        // only include report suites with alarm-level latency
        // throw out all the rest by returning NULL!!
        // Top 100 customers alert 1 hour before other customers:
        // top 100: 3 hours; all others: 4 hours
        // returning NULL for OK report suites will get them off the alert list
        if ($top100) {
            if (($latency_type == 'SC') && ($sc_latency_minutes < $top_latency_min)) {
                return NULL;
            }
            else if (($latency_type == 'elevator') && ($args['elevator'] < $top_latency_min)) {
                return NULL;
            }
            else if (($latency_type == 'export') && ($args['export'] < $top_latency_min)) {
                return NULL;
            }
            else if (($latency_type == 'export') && ($args['export'] >= $top_latency_min) && ($args['elevator'] > 15)) {
                return NULL;
            }
            else if (($latency_type == 'axle') && ($args['axle'] < $top_latency_min)) {
                return NULL;
            }
        }
        else {
            if (($latency_type == 'SC') && ($sc_latency_minutes < $latency_min)) {
                return NULL;
            }
            else if (($latency_type == 'elevator') && ( $args['elevator'] < $latency_min ) ) {
                return NULL;
            }
            else if (($latency_type == 'export') && ($args['export'] < $latency_min)) {
                return NULL;
            }
            else if (($latency_type == 'export') && ($args['export'] >= $latency_min) && ($args['elevator'] > 15)) {
                return NULL;
            }
            else if (($latency_type == 'axle') && ( $args['axle'] < $latency_min ) ) {
                return NULL;
            }
        }
                    
        $billing_customer = $this->get_billing_customer_name($billing_customer_id, $companydb);
        
        // don't include comments for now, at russ's request 
        // $latency_comments = $this->get_recent_comments($username);
        
        // skip report suites with no hit data; they're not "live"
        //$ss_ymd = get_period (ymd_from_timestamp($this->hidden_relative_date2(0, $timezone_offset)), 'ym');
        //$data_object = new ha_hits_report($uname, $uid);
        //$data = $data_object->get_data($ss_ymd);
        //if (max($data) <= 100) {
        //    return NULL;
        //}
        
        $args['migrating']  = $this->get_migration_status($username);        
        $args['sc_version'] = $sc_version;
        $args['sc_latency_minutes'] = $sc_latency_minutes;
        $args['billing_customer'] = $billing_customer;
        $args['latency_comments'] = ''; //join('<br />', $latency_comments);
        $args['top100'] = $top100;
        $args['key'] = $args['userid'] . '-' . $args['data_center'];
        
        return $args;
    }
    
    // accepts either:
    //   1. an array of RSIDs
    //   2. one RSID
    // returns true if any one of those RSIDs is migrating
    function get_migration_status($rsids = NULL) {
        try {
            if (!empty($rsids)) {
                if (is_array($rsids)) {
                    foreach($rsids as $rsid) {
                        $mig = $this->dm->isMigrating($rsid, DMIG_REPORT_SUITE);
                        if ($mig) {
                            return $mig;
                        }
                    }
                }
                else if (is_string($rsids)) {
                    return $this->dm->isMigrating($rsids, DMIG_REPORT_SUITE);
                }
            }
        }
        catch(Exception $e) {
        }

        return false;
    }
    
    function save_old_data($id, $data) {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;

        // serialize latency data and put it into the database for use later (two options supported: JSON or PHP
        $add_sql = '';
        if ($this->save_data_type == 'JSON') {
            $add_sql = "UPDATE " . $this->sql_comment . " report_data SET serialized_data='" . json_encode($data) . "' WHERE report_data_id=" . $id;
        }
        else {
            $add_sql = "UPDATE " . $this->sql_comment . " report_data SET serialized_data='" . serialize($data) . "' WHERE report_data_id=" . $id;
        }

        return false;
    }
    
    // store report data in the database
    function save() {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;

        // delete all data 30 days old
        $delete_sql = "DELETE " . $this->sql_comment . " FROM report_data where report_time <= DATE_SUB(NOW(), INTERVAL 30 DAYS)";
        $db->query($delete_sql);
        if ($db->Errno != 0) {

            // problems deleting old data from the table?  maybe the table doesn't exist.  create it!
            $create_sql = 'CREATE TABLE IF NOT EXISTS " . $this->sql_comment . " latency.report_data (
                report_data_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
                report_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                serialized_data MEDIUMTEXT NOT NULL
            )';
            $db->query($create_sql);
            
            $this->debug('creating report data table.');
        }
        
        // serialize latency data and put it into the database for use later (two options supported: JSON or PHP
        $add_sql = '';
        if ($this->save_data_type == 'JSON') {
            $add_sql = "INSERT INTO " . $this->sql_comment . " report_data SET serialized_data='" . json_encode($this->data) . "'";
        }
        else {
            $add_sql = "INSERT INTO " . $this->sql_comment . " report_data SET serialized_data='" . serialize($this->data) . "'";
        }
        $db->query($add_sql);
        
        // return the ID assigned to this row as the data ID if possible
        if ($db->Errno == 0) {
            $sql = "SELECT " . $this->sql_comment . " LAST_INSERT_ID() as id";
            $db->query($sql);
            if ($db->Errno != 0) {
                $this->error('Error getting ID for latency report data: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            }
            if ($db->next_record()) {
                return intval( $db->f('id') );
            }
            return true;
        }
        else {
            $this->error('Error saving latency report data: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
        }

        return false;
    }
    
    // get the saved & encoded data from the database; parse, sort, & return
    function get_data_row_by_id($report_data_id = 0) {
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;

        $ret = array(
            'data' => NULL,
            'time' => NULL,
        );
        
        // make sure the ID we're passing into the query is a positive integer
        if ( (intval($report_data_id) <= 0) || (intval($report_data_id) != $report_data_id) ) {
            return $ret;
        }
        
        $load_sql = "SELECT " . $this->sql_comment . " report_time, serialized_data FROM report_data WHERE report_data_id=" . sprintf('%u', $report_data_id);
        //echo "get old row SQL: " . $load_sql . "\n";
        $db->query($load_sql);
        if ($db->next_record()) {
            
            // bad data is handled in parse_raw_data()
            $ret['data'] = $this->parse_raw_data( $db->f('serialized_data') );
            $ret['time'] = $db->f('report_time');
            
            if (is_array($ret['data'])) {
                usort($ret['data'], "HA_Latency_Quick_Data::sort_latency_data");
            }
        }
        
        return $ret;
    }
    
    // takes a data set, finds top 100 users, & returns the top 100 users only
    function get_top_100_data($current_data = NULL) {
        $top_100_data = array();
        
        // populate with this class's data if no data was passed as a param
        if (is_null($current_data)) {
            $current_data = $this->data();
        }
        
        foreach($current_data as $item) {
            
            // each item's unique key is "userid-data_center"
            if (!isset($item['key'])) {
                $item['key'] = $item['userid'] . '-' . $item['data_center'];
            }
            if ($item['top100']) {
                $top_100_data[ $item['key'] ] = $item;
            }
        }

        usort($top_100_data, "HA_Latency_Quick_Data::sort_latency_data");
        return $top_100_data;
    }
    
    // find out what's caught up
    // the current & old data sets will be passed in and compared
    // so you can compare apples w/ apples (now, includes top 100 customers & all customers)
    function get_caught_up_data($cur_data_set, $old_data_set) {
        $caught_up_data = array();
        if ( ( !empty($old_data_set) ) && is_array($old_data_set) ) {
            foreach($old_data_set as $old_user_key => $old_user) {
                $found = false;
                if (is_array($cur_data_set)) {
                    foreach($cur_data_set as $new_user_key => $new_user) {
                        if (($new_user['userid'] == $old_user['userid']) && 
                                ($new_user['username'] == $old_user['username']) && 
                                ($new_user['data_center'] == $old_user['data_center'])) {
                            $found = true;
                            break;
                        }
                    }
                }
                
                // each item's unique key is "userid-data_center"
                if ($found === false) {
                    if (!isset($old_user['key'])) {
                        $old_user['key'] = $old_user['userid'] . '-' . $old_user['data_center'];
                    }
                    $caught_up_data[ $old_user['key'] ] = $old_user;
                }
            }
        }

        usort($caught_up_data, "HA_Latency_Quick_Data::sort_latency_data");
        
        //$this->debug("found old data: " . count($old_data_set) . " records\n");
        //$this->debug("cur data: " . count($cur_data_set) . " records\n");
        //$this->debug("caught up data: " . count($caught_up_data) . " records\n");
        
        return $caught_up_data;
    }
    
    // returns the maximum data ID from the database
    // (used to fetch the most recent record)
    function get_max_id() {
        $id = 0;
        $db = new DB_SQL('latencydb');
        $db->halt_on_error = false;
        $sql = "SELECT " . $this->sql_comment . " report_data_id FROM report_data ORDER BY report_data_id DESC LIMIT 1;";
        $db->query($sql);
        if ($db->next_record()) {
            $id = $db->f('report_data_id');
        }
        return $id;
    }
    
}
