<?
/**
 * @file 
 * DBQuery
 *
 * Copyright 2006 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Trenton Davies <tdavies@omniture.com>
 * @version CVS: $Id: $
 **/ 


require_once 'OM_Error.class.php';
require_once 'database/ResultIterator.class.php';


/**
 * DBQuery provides a layer of security and convenience
 * around the DB_Sql family of classes. You MUST use a DB_Sql class
 * at present. 
 * 
 * DBQuery takes a string of SQL and looks for a sequence of the form
 * {parameter_name}. When given an array of parameters, it will look 
 * through that array and replace {parameter_name} with ' . mysql_escape_string($parameter_name) . '
 * 
 * In addition to the default "single-quote" escaping, DBQuery also allows you to 
 * specify an additional modifier of the form %x{parameter_name}, where 'x'
 * represents the type of modification. Modifiers are:
 * - i = cast as integer, e.g. %%i{parameter_name}
 * - f = cast as float, e.g. %%f{parameter_name}
 * - d = cast as date, requires unix timestamp, e.g. %%d{parameter_name}
 * - s = cast as string, e.g. %%s{parameter_name}
 * - n = cast as SQL. Allowed character are a-zA-Z, 1-9, _ and (), e.g. %%n{parameter_name}
 * - a = escape and implode array, turning array into comma-separated escaped values in single quotes
 * - z = serialize data
 * - v = date interval, e.g. -1 Week, 24 Hour, 3 MoNtH
 * - N = take an array and turn it into CSV with each array item cast as SQL (see lowercase n)
 * - F = take an array and turn it into CSV cast as floats (see lowercase f)
 * - I = take an array and turn it into CSV cast as ints (see lowercase i)
 * - S = take an array and turn it into CSV cast as strings (see lowercase s)
 * 
 * 
 * 
 * The most common usage will be:<br />
 * $query = new DBQuery($dbHandle, $sqlString, $arrayOfParams);<br />
 * $result = $query->execute();<br />
 * $data = $result->toArray();<br />
 * while($result->hasNext()) $data = $result->next();<br />
 * 
 * Other common methods:
 * - setQuery()<br />
 * - getQuery()<br />
 * - setDB()<br />
 *  -setParameters()<br />
 * 
 * @ingroup database
 * @author Trenton Davies
 **/
class DBQuery
{
	/**
	 * (DB_Sql) A DB_Sql database handle
	 *
	 **/
	var $_db;
	
	/**
	 * (array) Array of parameters to be escaped "into" the query string
	 *
	 **/
	var $_parameters;
	
	/**
	 * (string) A string of SQL to be executed
	 *
	 **/
	var $_query;
	
	/**
	 * (int|array) integer or array of integers represent a mysql error number.
	 *
	 **/
	var $_errorTrap = NULL;
	
	var $result_type = MYSQL_BOTH;

	/**
	 * (OM_Error) Error object if exists
	 *
	 * @see OM_Error, getError(), hasError()
	 **/
	var $_error = NULL;
	var $_errors = array();
	
	/**
	 * Constructor function.
	 *
	 * @param $db 			(DB_Sql) 	A database handle
	 * @param $sql			(string) 	A sql query with optional {param_name}
	 * 									placeholders.
	 * @param $parameters	(array)		An associative array of parameters of the form
	 * 									param_name => param_value. 
	 * @return (ResultIterator)	An iterator for manipulating the result of the query
	 **/
	function DBQuery($db=NULL, $sql=NULL, $parameters=array(), $result_type = MYSQL_BOTH)
	{
		if ($db) {
			$this->setDB($db);
		}
		if ($sql) {
			$this->setQuery($sql);
		}
		if ($parameters) {
			$this->setParameters($parameters);
		}
		
		$this->result_type = $result_type;
		
	}
	
	/**
	 * Sets the required database object on which queries will be performed
	 *
	 * @param $db
	 * @return void
	 **/
	function setDB($db)
	{
		if ($db) {
			$this->_db = $db;
		} else {
		//	trigger_error("No database handle found!",E_USER_ERROR);
		}
	}
	
	/**
	 * undocumented function
	 *
	 * @param 
	 * @return void
	 **/
	function &getDB()
	{
		return $this->_db;
	}

	/**
	 * Sets the query string to be used during prepare() and execute()
	 *
	 * @param $sql
	 * @return void
	 * @see prepare(), execute()
	 **/
	function setQuery($sql)
	{
		$this->_query = $sql;
	}
	
	/**
	 * Sets the result type (MYSQL_BOTH, MYSQL_ASSOC,...)
	 *
	 * @param $result_type
	 * @return void
	 * @see prepare(), execute()
	 **/
	function setResultType($result_type)
	{
		$this->result_type = $result_type;
	}
	
	/**
	 * Returns the prepared and escaped query string
	 *
	 * @param 
	 * @return (string)
	 **/
	function getQuery()
	{
		/** @todo TODO Need to check for existence here, and throw errors otherwise */ 
		return $this->prepare($this->_query, $this->_parameters);
	}
	
	/**
	 * Takes a list of parameters and escapes the contents into 
	 * a sql string using a simple placeholder syntax.
	 *
	 * @param $sql
	 * @return (string)
	 **/
    function prepare($sql, $parameters)
    {
        /* Parse ? in SQL (traditional prepare) */ 
        /* We'll add this later
        $indexStatement = ''; // the final prepared sql statement.
        //search for ? for index-based values in the parameter
        //i.e. 0 => $value
        if (strpos($sql,'?')!==FALSE) {
            $length = strlen($sql);
            $index = -1;
            $origSql = $sql;
            for ($i=0; $i < $length; $i++)
            { 
                if ($origSql{$i} == '?') {
                    $index++;
                    if (isset($this->_parameters[$index])) {
                        //TODO this does not escape anything!!!
                        $indexStatement .= $this->_parameters[$index];
                        //remove parameter
                        unset($this->_parameters[$index]);
                    } else {
                        $error = 'SQL statement does not contain a value for ' .
                                 'preparable index #' . ($index + 1);
                        trigger_error($error,E_USER_ERROR);
                    }
                } else {
                    $indexStatement .= $origSql{$i};
                }
            }
        }
        $statement = $indexStatement;//what we have so far
         */
        $statement = $sql;
        if ($parameters) { //only parse out the statement if there are parameters		
            $length = strlen($statement);
            $parameterStatement = ''; //what we are now going to build up
            for ($i=0; $i < $length; $i++)
            { 
                $replacement = ''; // our replacement stored here.
                //prepare statements of the form %x{param}
                if ($statement{$i} == '%' && ($i+1) < $length) {
                    //if the next is also a %, then replace the %% with %
                    if ($statement{$i+1} == '%') {
                        $replacement = '%';
                        $i++;//move the pointer up 
                    } elseif($statement{$i+1} == '{') {
                        $parameterStatement .= $statement{$i};
                        $param = NULL;
                        $i+=2;
                        while ($statement{$i}!='}' && $i < $length) {
                            $param .= $statement{$i};
                            $i++;
                        }
                        if ($statement{$i} != '}') {
                            //no closing tag so make param null
                            $param = NULL;
                        }
                        if ($parameters && array_key_exists($param,$parameters)) {
                            $replacement = $this->_escapeParameter($parameters[$param], 'l');
                        }
                    } elseif($statement{$i+1} == '\'') {
                        $parameterStatement .= $statement{$i++};
                        $parameterStatement .= $statement{$i};
                    } else {
                        $conversionChar = $statement{++$i};
                        $param = NULL;
                        //does a parameter exist inside braces?
                        //TODO this if statement is duplicated twice and could be moved to a function
                        if ($statement{$i+1} == '{' && ($i+1) < $length) {
                            $i+=2;//move to inside the brace
                            while ($statement{$i}!='}' && $i < $length) {
                                $param .= $statement{$i};
                                $i++;
                            }
                            if ($statement{$i} != '}') {
                                //no closing tag so make param null
                                $param = NULL;
                            }
                            if ($parameters && array_key_exists($param,$parameters)) {

                                $replacement = $this->_escapeParameter($parameters[$param], $conversionChar);
                            } else {
                                $this->error("DBQuery: parameter $param is undefined in query.", OM_ERROR_DB);
                                trigger_error("DBQuery: parameter $param is undefined in query.", E_USER_ERROR);
                            }
                        }
                    }
                    $parameterStatement .= $replacement;
                }
                //prepare statements of the form {param} 
                elseif ($statement{$i} == '{' && ($i+1) < $length) {
                    $param = NULL;
                    //move inside the brace
                    $old_placement = ++$i;
                    while ($statement{$i} != '}' && $i < $length) {
                        $param .= $statement{$i};
                        $i++;
                    }
                    if ($statement{$i} != '}') {
                        //no closing tag so make param null, add the brace back into the string and continue on your way
                        $param = NULL;
                        $i = $old_placement;
                        $replacement = '{';
                    }

                    if ($parameters && array_key_exists($param, $parameters)) {
                        $replacement = $this->_escapeParameter($parameters[$param]);
                    }
                    $parameterStatement .= $replacement;
                }
                //continue building up statement
                else {
                    $parameterStatement .= $statement{$i};
                }
            }
            $statement = $parameterStatement;
        }


        return $statement;
    }
	
	/**
	 * Execute the query and return the result
	 *
	 * @return (ResultIterator) 
	 **/
	function execute()
	{
		if (!$this->_db || !$this->_query) {
			trigger_error('DBQuery :: no database handle or query string set!', E_USER_ERROR);
		}
		$sql = $this->getQuery();
		$db =& $this->_db;
		//short circuit if errors during prepare
		if ($this->hasError()) { 
			return new ResultIterator($this);
		}
		//execute query
		if (!$db->query($sql, $this->_errorTrap)) {
			$this->error($db->Error, $db->Errno);
		} else {
			$this->clearError();
		}
		return new ResultIterator($this);
	}
	
	/**
	 * Frees the current database resource
	 *
	 * @return boolean
	 **/
	function free()
	{
		if ($this->_db) {
			$this->_db->free();
			return TRUE;
		} else {
			return FALSE;
		}
	}
	
	/**
	 * Adds a single attribute value to a query. The var
	 * parameter can be any database datatype and will be parsed based
	 * on the data type it represents in the query.
	 *
	 * @param $name
	 * @param $value
	 * @return void
	 **/
	function setParameter($name, $value)
	{
		$this->_parameters[$name] = $value;
	}
	
	/**
	 * Sets values for the query passed into the constructor
	 * or the setQuery method. The key values in the array must match
	 * the key names set in the query through setQuery.
	 *
	 * @param $params
	 * @return void
	 * @see setQuery(), DBQuery()
	 **/
	function setParameters($params)
	{
		$this->_parameters = $params;
	}
	
	/**
	 * Escapes parameters
	 *
	 * @param $param			the parameter
	 * @param $conversionChar	a one char identifier on how the param should be escaped
	 * @return (string) the escaped parameter
	 * @private
	 **/
	function _escapeParameter($param, $conversionChar=NULL)
	{
		switch ($conversionChar)
		{
			/* Cast to integer */
			case 'i':
				return (int)$param;
				break;
			case 'I':
				$returnArray=array();
				foreach((array)$param as $value) {
					$returnArray[] = (int)$value;
				}
				return implode(',',$returnArray);
				break;
				
			/* Cast to float */
			case 'f':
				return (float)$param;
				break;
			case 'F':
				$returnArray=array();
				foreach((array)$param as $value) {
					$returnArray[] = (float)$value;
				}
				return implode(',',$returnArray);
				break;
			
			/* DB Names, like table names */
			case 'n':
				return preg_replace('/[^a-zA-Z0-9_\(\)]/','',$param);
				break;
			case 'N':
				$returnArray = array();
				foreach ((array)$param as $p)
				{
					$returnArray[] = preg_replace('/[^a-zA-Z0-9_\(\)]/','',$p);
				}
				return implode(',',$returnArray);
				break;
			
			case 'S':
			case 'a':
				$returnArray=array();
				foreach((array)$param as $value) {
					$returnArray[] = "'".$this->_db->escape_string($value)."'";
				}
				return implode(',',$returnArray);
				break;
				
			case 'z':
				return "'".$this->_db->escape_string(serialize($param))."'";
				break;
				
			case 'v':
				$regex = '/^\s*\-?\s*\d+\s+(SECOND|MINUTE|HOUR|DAY|WEEK|MONTH|YEAR)\s*$/i';
				return preg_match($regex,$param)?$param:'0 SECOND';
				break;
				
			case 'd':
				return "'".date('Y-m-d H:i:s', $param)."'";
				break;
			case 'l':	
				return $this->_db->escape_string($param);
				break;
			/* Default. Escapes single quotes in parameter and wraps in single quotes */ 	
			case 's':
			default:
				return "'".$this->_db->escape_string($param)."'";
				break;
		}
	}
		
	/**
	 * set the error trap
	 * 
	 * This is an optional parameter to DB_Sql::query that we
	 * pass on to trap "ignore" errors
	 *
	 * @param $errorTrap
	 * @return void
	 **/
	function setErrorTrap($errorTrap)
	{
		$this->_errorTrap = $errorTrap;
	}

	/**
	 * Returns an error of type OM_Error
	 *
	 * @return	(OM_Error) An OM_Error object
	 **/
	function getError()
	{
		return $this->_error;
	}

	/**
	 * get the error message
	 *
	 * @param
	 * @return void
	 **/
	function getErrorMessage()
	{
		if (!$this->hasError()) {
			return false;
		}

		return $this->_error->getPublicErrorMessage();
	}

	/**
	 * Gets the explicit (un-localized) error message
	 *
	 * @param
	 * @return void
	 **/
	function getExplicitErrorMessage()
	{
		if (!$this->hasError()) {
			return false;
		}

		return $this->_error->getErrorMessage();
	}

	/**
	 * get the error code
	 *
	 * @return void
	 **/
	function getErrorCode()
	{
		if (!$this->hasError()) {
			return false;
		}

		return $this->_error->getErrorCode();
	}

	/**
	 * Sets an OM_Error
	 * 
	 * 'Cory Aitchison' <caitchison@adobe.com>
	 * 2010-02-25
	 * Added array so more than one error can be stored.  $this->_error always
	 * contains the last error
	 * 
	 * @param $message (string) the error message (not localized)
	 * @param $code (int) The error code
	 * @param $info (array) optional array of settings
	 * @return void
	 **/
	function error($message, $code=NULL, $info=NULL, $get_backtrace = true)
	{
		if (!$code) {
			$code = OM_ERROR_DEFAULT;
		}
		
		$error = new OM_Error(array('message'=>$message,'code'=>$code,'info'=>$info), $get_backtrace);
		$this->_errors[] = $error;
		$this->_error = $error;
	}

	function getErrors()
	{
		return $this->_errors;
	}

	function mergeErrors(array $errors)
	{
		$this->_errors = array_merge($this->_errors, $errors);
		$this->_error = $this->_errors[count($this->_errors) - 1];
	}

	/**
	 * Check to see if the object has "thrown" an error
	 *
	 * @return	(boolean)
	 **/
	function hasError()
	{
		return ($this->_error)?TRUE:FALSE;
	}

	/**
	 * Clears the error
	 *
	 * @return void
	 **/
	function clearError()
	{
		$this->_errors = array();
		$this->_error = NULL;
	}
} // END class DBQuery
