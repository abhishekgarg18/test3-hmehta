<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * VcClusterInfo.class.php Retrieve and update information regarding the vcookie_clusters_base_distribution table and individual cluster usage
 *
 * @author  Matt Gould <mgould@adobe.com>
 *
 */
require_once 'application.inc';
require_once 'common_functions.inc';
require_once 'UsertrieDB.class.php';
require_once 'trie_distribution.class';

class VcClusterInfo {

    private $mdb;
    private $utdb;
    private $dist;
    private $sqlComment;

    // Format specification for displaying Cluster Identification information
    //  Arguments will be passed in the order: cluster_id, cluster_name
    const FORMAT_CLUSTER_IDENT = '%2$s (%1$d)';
    
    public function __construct() {
        $this->sqlComment = sprintf(" /* MODULE: bertlib FILE: %s CLASS: %s */ ", basename(__FILE__), __CLASS__);
        
        $this->mdb = new masterdb();
        $this->mdb->halt_on_error = false;
        
        $this->utdb = new UsertrieDB();
        
        $this->dist = new trie_distribution();
        $this->dist->table_base = 'vcookie_clusters_base_distribution';
    }
    
    public function get_all_distribution_bases() {
        return array_keys($this->dist->get_all_data());
    }
    
    public function get_clusters_for_base($base) {
        $clusters = array();
        
        $data = $this->dist->get_index_data($base);
        if ($data['cluster_ids']) {
            foreach (explode(',', $data['cluster_ids']) as $clusterid) {
                $clusters[$clusterid] = $this->get_cluster_name($clusterid);
            }
        }
        return $clusters;
    }
    
    public function get_clusters_for_rsid($rsid) {
    	$base = $this->dist->get_matching_base($rsid);
    	return $this->get_clusters_for_base($base);
    }
    
    public function get_bases_for_cluster($clusterid) {
        if (!is_intval($clusterid)) throw new Exception("$clusterid must be an integer");
        return $this->dist->indexes_matching_field_regex('cluster_ids', "/(^|,)$clusterid(,|$)/");
    }
    
    public function get_cluster_name($clusterid) {
        if (!is_intval($clusterid)) throw new Exception("Clusterid ($clusterid) must be an integer");
        $sql = <<<SQL
            SELECT {$this->sqlComment}
                cluster_name
            FROM
                vcookie_clusters
            WHERE
                cluster_id = $clusterid
SQL;
                
        if ($this->mdb->squery($sql, 0, MYSQL_ASSOC)) {
            $name = strtolower($this->mdb->f('cluster_name'));
            $this->mdb->free();
        } else {
            throw new Exception("Could not find vcookie cluster with id: $clusterid");
        }
        
        return $name;
    }
    
    public function get_cluster_id($cluster_name) {
        $id = array_search(strtolower($cluster_name), $this->get_all_clusters());
        if ($id === false) {
            throw new Exception("Invalid vcookie cluster name: $cluster_name");
        }
        return $id;
    }
    
    
    public function get_all_clusters() {
        $clusters = array();
        $sql = <<<SQL
            SELECT {$this->sqlComment}
                cluster_id,
                cluster_name
            FROM
                vcookie_clusters
SQL;
        
        if ($this->mdb->query($sql)) {
            while ($this->mdb->next_record(MYSQL_ASSOC)) {
                $clusters[$this->mdb->f('cluster_id')] = strtolower($this->mdb->f('cluster_name'));
            }
            $this->mdb->free();
        } else {
            throw new Exception("Error querying cluster list: {$this->mdb->Error}", $this->mdb->Errno);
        }
        
        return $clusters;
    }
    
    public function get_cluster_usage($clusterid, array $filter_rsids = array()) {
        $cluster_bases = $this->get_bases_for_cluster($clusterid);
        $rsids = $this->get_rsids_on_cluster($clusterid);
        if ($filter_rsids) {
            $rsids = array_intersect($rsids, $filter_rsids);
        }
        
        $cluster_info = array();
        $cluster_info['total rsids'] = count($rsids);
        $cluster_info['assigned bases'] = array_fill_keys($cluster_bases, array());
        $cluster_info['foreign bases'] = array();
        
        $rsids_by_base = $this->classify_rsids_by_distribution_base($rsids);
        foreach ($rsids_by_base as $base => $rsids) {
            if ('^' == $base) {
                $cluster_info['unassigned rsids'] = $rsids;
            } elseif (in_array($base, $cluster_bases)) {
                $cluster_info['assigned bases'][$base] = $rsids;
            } else {
                $cluster_info['foreign bases'][$base] = $rsids; 
            }
        }
        ksort($cluster_info['assigned bases']);
        ksort($cluster_info['foreign bases']);
        
        return $cluster_info;
    }
    
    public function classify_rsids_by_distribution_base(array $rsids) {
        $classified_rsids = array();
        foreach ($rsids as $rsid) {
            $base = $this->dist->get_matching_base($rsid);
            if ($base) {
                $classified_rsids[$base][] = $rsid;
            } else {
                $classified_rsids['^'][] = $rsid;
            }
        }
        ksort($classified_rsids);
        foreach ($classified_rsids as &$base_rsids) {
            asort($base_rsids, SORT_NATURAL|SORT_FLAG_CASE);
        }
        unset ($base_rsids);
        
        return $classified_rsids;
    }
    
    public function get_rsids_on_cluster($clusterid) {
        if (!is_intval($clusterid)) throw new Exception("Clusterid ($clusterid) must be an integer");
        
        $rsids = array();
        $sql = <<<SQL
            SELECT {$this->sqlComment}
                DISTINCT v.userid as userid,
                u.username as rsid
            FROM
                vcookie_handler_info v,
                user u
            WHERE
                u.userid=v.userid
                AND
                v.cluster_id=$clusterid
SQL;
                
        if ($this->utdb->query($sql)) {
            while ($this->utdb->next_record()) {
                $rsids[$this->utdb->f('userid')] = $this->utdb->f('rsid');
            }
            $this->utdb->free();
        } else {
            throw new Exception("Error querying rsids: {$this->mdb->Error}", $this->mdb->Errno);
        }
        
        return $rsids;
        
    }
    
    function validate_cluster_ident($cluster) {
        if (!is_intval($cluster)) {
            $name = $cluster;
            $id = $this->get_cluster_id($cluster);
        } else {
            $id = $cluster;
            $name = $this->get_cluster_name($cluster);
        }
    
        return array($id, $name);
    }
    
    function add_cluster_to_distribution_base($base, $clusterid) {
        $this->invalidate_distribution();
        if (!in_array($base, $this->get_all_distribution_bases())) {
            $sql = <<<SQL
                INSERT INTO {$this->sqlComment}
                    vcookie_clusters_base_distribution
                SET
                    base = '$base',
                    cluster_ids = '$clusterid'
SQL;
        } else {
            $clusterids = array_merge(array($clusterid), array_keys($this->get_clusters_for_base($base)));
            sort($clusterids);
            $clusterids = implode(',', $clusterids);
            $sql = <<<SQL
                UPDATE {$this->sqlComment}
                    vcookie_clusters_base_distribution
                SET
                    cluster_ids = '$clusterids'
                WHERE
                    base = '$base'
SQL;
        }
        
        if (!$this->mdb->query($sql)) {
            throw new Exception("Error adding cluster $clusterid to VcBase $base: {$this->mdb->Error}", $this->mdb->Errno);
        }
        $this->mdb->free();
        
        
        $this->invalidate_distribution();
        
    }
    
    function remove_cluster_from_distribution_base($base, $clusterid) {
        $this->invalidate_distribution();
        $clusterids = array_diff(array_keys($this->get_clusters_for_base($base)), array($clusterid));
        if (!$clusterids) {
            $this->remove_distribution_base($base);
        } else {
            sort($clusterids);
            $clusterids = implode(',', $clusterids);
            $sql = <<<SQL
                UPDATE {$this->sqlComment}
                    vcookie_clusters_base_distribution
                SET
                    cluster_ids = '$clusterids'
                WHERE
                    base = '$base'
SQL;
    
            if (!$this->mdb->query($sql)) {
                throw new Exception("Error removing cluster $clusterid from VcBase $base: {$this->mdb->Error}", $this->mdb->Errno);
            }
            $this->mdb->free();
        }
    
        $this->invalidate_distribution();
    
    }
    
    function remove_distribution_base($base) {
        $sql = <<<SQL
            DELETE {$this->sqlComment}
            FROM
                vcookie_clusters_base_distribution
            WHERE
                base = '$base'
SQL;
        if (!$this->mdb->query($sql)) {
            throw new Exception("Error dropping VcBase $base: {$this->mdb->Error}", $this->mdb->Errno);
        }
        $this->mdb->free();
        
        $this->invalidate_distribution();
        
    }
    
    
    function invalidate_distribution() {
        $this->dist->last_read_time = 0;
    }
    
    static public function format_cluster_identifier($id, $name) {
        return sprintf(self::FORMAT_CLUSTER_IDENT, $id, $name);
    }
    
}


/**
 * SELFTEST
 * Usage: php VcClusterInfo.class.php
 */
if (count(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
    (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
        debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1))) == 0) {
            
    if (function_exists('xdebug_break'))
        xdebug_break();
    
    try {
        $x = new VcClusterInfo();
        var_dump($bases = $x->get_all_distribution_bases());
        var_dump($clusters = $x->get_all_clusters());
        var_dump($x->get_clusters_for_base(reset($bases)));
        var_dump($x->get_bases_for_cluster(reset(array_keys($clusters))));
        var_dump($x->get_cluster_usage(reset(array_keys($clusters))));
    } catch (Exception $e) {
        fprintf(
            STDERR,
            "caught %s%s%s\n",
            get_class($e),
            $e->getCode() ? sprintf(', code=%d', $e->getCode()) : '',
            $e->getMessage() ? sprintf(', message="%s"', $e->getMessage()) : ''
        );
        exit(1);
    }
}