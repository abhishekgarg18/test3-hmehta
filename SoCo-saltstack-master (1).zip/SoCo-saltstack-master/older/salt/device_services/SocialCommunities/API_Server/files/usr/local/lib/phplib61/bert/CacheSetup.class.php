<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * class CacheSetup - expanded representation of cache setup
 * bases: array of base names
 *   array of hosts
 *     array of usages
 *       array with atype and daemon counts
 *
 * @author  Jack Thomasson <thomasso@adobe.com>
 *
 * @version $Id: $
 */
require_once 'CacheServer.class';
require_once 'CacheServerUsage.class';
require_once 'CacheAllocationTypes.class';
require_once 'user_account.class';
require_once 'ProposedSetup.class.php';


/**
 * @class CacheSetup
 */
class CacheSetup implements Countable {

	/**
	 * organize CacheAllocationTypes and allow for random type
	 * @throws Exception
	 * @return array
	 */
	private static function FetchCacheServerATypes() {
		$atypes = array();
		$cat = new CacheAllocationTypes();
		$caps = $cat->get_capabilities_by_code();
		uasort($caps, 'CacheSetup::by_cache_units');
		$n = 0;
		foreach ($caps as $k => $v) {
			$k = strtolower($k);
			$atypes[$k]['atype'] = $k;
			$atypes[$k]['sort_order'] = ++$n;
		}
		$atypes[CacheSetup::RANDOM] = array('atype' => CacheSetup::RANDOM, 'sort_order' => ++$n); // random
		return $atypes;
	}

	/**
	 * compare function to sort by cache processing units
	 * @param array $a
	 * @param array $b
	 * @return number
	 */
	private static function by_cache_units(array $a, array $b) {
		return bccomp($a['cache_units'], $b['cache_units'], 3);
	}

	/**
	 * compare function to sort by daemon count, elevator before lobby, then by atype
	 * @param array $a
	 * @param array $b
	 * @return number
	 */
	public static function by_daemon_count(array $a, array $b) {
		if (($n = $a['elevator'] - $b['elevator']) or ($n = $a['lobby'] - $b['lobby']))
			return $n;
		static $atypes;
		if (!$atypes) $atypes = self::FetchCacheServerATypes($cat);
		return $atypes[$a['atype']]['sort_order'] - $atypes[$b['atype']]['sort_order'];
	}

	const RANDOM = '?';
	public $bases; //<! [base][usage][host] => [atype,daemons]

	/**
	 * @param[in] array of strings $bases
	 * @throws Exception
	 */
	public function __construct(array $bases=array(), $smallest_first = TRUE) {
		$cat = new CacheAllocationTypes;
		$this->bases = array();
		foreach ($bases as $base) {
			$ua = new user_account($base); // works even with cache bases
			$this->bases[$base] = $ua->get_cache_servers_by_usage();
			foreach (CacheServerUsage::USAGES() as $usage) {
				foreach ($this->bases[$base][$usage] as $k => $host) {
					unset($this->bases[$base][$usage][$k]);
					$v = $cat->get_allocation_type($host);
					$this->bases[$base][$usage][$host]['atype'] = strtolower($v[0]);
					$cs = new CacheServer($host);
					foreach (array('lobby', 'elevator', 'suite') as $daemon)
						$this->bases[$base][$usage][$host][$daemon] = $cs->get_daemon_count($daemon);
				}
				uasort($this->bases[$base][$usage], 'CacheSetup::by_daemon_count');
				if (!$smallest_first)
					$this->bases[$base][$usage] = array_reverse($this->bases[$base][$usage]);
			}
		}
	}

	public function count() {
		$n = 0;
		foreach ($this->bases as $base)
			foreach ($base as $hosts)
				$n += count($hosts);
		return $n;
	}

	/**
	 * @param[in] string $base
	 * @throws Exception
	 */
	public function add(array $bases=array(), $smallest_first = TRUE) {
		$cs = new CacheSetup($bases, $smallest_first);
		$this->bases = array_merge($this->bases, $cs->bases);
		return $this;
	}

	/**
	 * @param[in] string $base
	 * @returns ProposedSetup
	 * @throws Exception
	 */
	public function asProposedSetup($base = NULL) {
		$proposedSetup = new ProposedSetup();
		if (!$base) {
			reset($this->bases);
			list($base) = each($this->bases);
		}
		foreach ($this->bases[$base] as $usage => $host)
			foreach ($host as $host => $v)
				$proposedSetup->adjust(AdjustString::withString(AdjustString::abbreviate($usage).'+'.substr(strrchr($host, '.'), 1).":1:${v['atype']}"));
		return $proposedSetup;
	}

	/**
	 * @param[in] string $base
	 * @returns ProposedSetup
	 * @throws Exception
	 */
	public function asRealizedSetup($base = NULL) {
		$proposedSetup = new ProposedSetup();
		if (!$base) {
			reset($this->bases);
			list($base) = each($this->bases);
		}
		foreach ($this->bases[$base] as $usage => $host)
			foreach ($host as $host => $v)
				$proposedSetup->adjust(AdjustString::withString(AdjustString::abbreviate($usage)."+$host"));
		return $proposedSetup;
	}

	/**
	 * @param array $hosts
	 * @param string $leader @see asCacheSetup()
	 * @return string SetupString part
	 */
	private static function count_by_DC_then_atype(array $hosts, $leader) {
		$counts = array();
		foreach ($hosts as $k => $v) {
			$dot = strrpos($k, '.');
			++$counts[substr($k, 1+$dot)][$v['atype']];
		}
		if (!$counts)
			return null;
		asort($counts); // sort by DC
		$second = false;
		foreach ($counts as $k => $v)
			foreach ($v as $atype => $n) {
				if ($second)
					$leader .= '+';
				else
					$second = true;
				$leader .= "$k:$n:$atype";
			}
		return $leader;
	}

	/**
	 * construct a SetupString from a CacheSetup
	 * @return SetupString
	 * @throws Exception
	 */
	public function asSetupString() {
		$pieces = array();
		ksort($this->bases);
		foreach (array_keys($this->bases) as $base) {
			$parts = array();
			foreach (SetupString::USAGES() as $usage) {
				if (!($v = $this->bases[$base][$usage]))
					continue;
				uasort($v, 'CacheSetup::by_daemon_count');
				$parts[] = self::count_by_DC_then_atype($v, SetupString::abbreviate($usage));
			}
			$pieces[] = $base.':'.join(',', $parts);
		}
		return SetupString::withString(join(',', $pieces));
	}
}


/**
 * SELFTEST
 * Usage: php CacheSetup.class.php
 */
if (!(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
      (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
       debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)))) {
	if (function_exists('xdebug_break')) xdebug_break();
	define('DEBUG_MESSAGES', 1);

  // gather information for decision
  try {
	  $cs = new CacheSetup(1 < count($argv) ? array_slice($argv, 1) : array('ha-testing-jkt'));
  }
  catch (Exception $e) {
    fwrite(STDERR, $e->getCode().': '.$e->getMessage()."\n");
    exit(1);
  }
  echo var_export($cs->asProposedSetup(), TRUE), "\n";
  echo var_export($cs->asRealizedSetup(), TRUE), "\n";
  echo "\n", $cs->asSetupString()->asString().' ('.count($cs).")\n";

  $cs = new CacheSetup;
  $cs->bases['ha-testing-jkt'][CacheServerUsage::HOTEL][count($cs->bases['ha-testing-jkt'][CacheServerUsage::HOTEL]).'.'.end($localConfig["data_center_hostname_suffixes"])] = array('atype' => CacheSetup::RANDOM);
  echo $cs->asSetupString()->asString().' ('.count($cs).")\n";

  exit(0);
}
?>
