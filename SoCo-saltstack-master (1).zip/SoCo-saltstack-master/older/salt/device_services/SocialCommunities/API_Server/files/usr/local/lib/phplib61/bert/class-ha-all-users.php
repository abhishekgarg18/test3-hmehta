<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright [first year code created] Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-run-everywhere.php';

class HA_All_Users extends HA_Run_Everywhere {
    private $trie_base = '/home/omniture/install/share/trieconf/';
    private $trie_file = 'usertrie_enterprise.conf';
    private $default_server_prefix = 'eng1';
    private $data_center_suffixes;
    private $server_list = array();
    private $trie_files = array();
    
    // anything you put in $args will override the default value
	function __construct( $args = array() ) {
		parent::__construct($args);
        
        if (DATA_CENTER == DATA_CENTER_DEV) {
            $this->default_server_prefix = 'vm232';
        }

        $this->data_center_suffixes = $args['data_center_suffixes'];
        $this->remote_user          = $args['remote_user'];
        $this->crons                = $args['crons'];
        //$this->log_level(HA_LOG_LEVEL_DEBUG);
        $this->sleep_time(60);
        
        $this->start();
    }
    
    function start() {
        // todo get all users.  put trie files into the queue and start.
        $files = $this->get_trie_files();
        $users = array();
        
        foreach($files as $data_center => $filename) {
            
            //$this->debug("adding trie file to queue: " . $filename . "\n");
            if (file_exists($filename)) {

                // process trie file!
                $remote_flag = ($data_center == DATA_CENTER_DEV) ? false : true;
                
                $queue_args = array(
                    'command'       => './latencysweep.php ' . $filename,
                    
                    'log_level'     => HA_LOG_LEVEL_DEBUG,
                    'copy_up'       => array(
                        'class-ha-run-everywhere.php', 
                        'class-ha-latency-email-data.php',
                        'class-ha-utilities.php',
                        'class-ha-queue-item.php',
                        'class-ha-all-users.php',
                        'class-ha-cron-finder.php',
                        'latencysweep.php',
                    ),
                    
                    'data_center'   => $data_center,
                    'remote_user'   => $this->remote_user,
                    'remote_flag'   => $remote_flag,
                    'remote_server' => $remote_server,
                    'custom_ps'     => 'ps -u ' . $this->remote_user . ' | grep latencysweep',  // don't forget to truncate the grep to <12 chars
                );
                
                if (($data_center == DATA_CENTER_SAN_JOSE) || ($data_center == DATA_CENTER_DALLAS) || ($data_center == DATA_CENTER_DEV)) {
                    $limit = 6;
                    $loops = 5;
                    $cron_list = $this->crons->cron_servers_in($data_center);
                    $used_crons = array(
                        DATA_CENTER_SAN_JOSE => array(
                            'cron1.sj2' => 'cron1.sj2', 
                            'cron2.sj2' => 'cron2.sj2',
                            'cron3.sj2' => 'cron3.sj2', 
                            'cron4.sj2' => 'cron4.sj2',
                        ),
                        DATA_CENTER_DALLAS => array(
                            'cron1.da2' => 'cron1.da2', 
                            'cron2.da2' => 'cron2.da2',
                            'cron3.da2' => 'cron3.da2',
                            'cron10.da2' => 'cron10.da2',
                        ),
                    );
                    for($j = 0; $j < $loops; $j++) {
                        $offset = $j*$limit;
                        $limit2 = ($j == ($loops - 1) ) ? 0 : $limit;
                        $queue_args['command'] = './latencysweep.php ' . $filename . ' ' . $offset . ' ' . $limit2;
                        
                        $cron_server = $this->crons->random_cron_server($data_center);
                        if (($data_center == DATA_CENTER_SAN_JOSE) || ($data_center == DATA_CENTER_DALLAS)) {
                            $c = count($cron_list) - $j;
                        }
                        if (isset($used_crons[$data_center])) {
                            $max = 25;
                            $c = 0;
                            while (isset($used_crons[$data_center][$cron_server])) {
                                $cron_server = $this->crons->random_cron_server($data_center);
                                
                                // infinite loop control
                                $c++;
                                if ($c >= $max) {
                                    break;
                                }
                            }
                            $used_crons[$data_center][$cron_server] = $cron_server;
                        }
                        else {
                            $used_crons[$data_center] = array($cron_server);
                        }
                        
                        // try & ensure the same cron server isn't re-used.
                        $queue_args['remote_server'] = $cron_server;
                        $this->add_to_queue( $queue_args );
                    }
                }
                else {
                   $queue_args['remote_server'] = $this->crons->random_cron_server($data_center); 
                   $this->add_to_queue( $queue_args );
                }
            }
        }
        
        parent::start();
    }
    
    function get_trie_files() {
        
        if (empty($this->trie_files)) {
            global $localConfig;
    
            // in DEV
            if (DATA_CENTER == DATA_CENTER_DEV) {
                if (file_exists($this->trie_base . DATA_CENTER . '/' . $this->trie_file)) {
                    $this->trie_files[DATA_CENTER] = $this->trie_base . DATA_CENTER . '/' . $this->trie_file;
                }
            }
            
            // in San Jose (i.e., the master production datacenter)
            else if (DATA_CENTER == DATA_CENTER_SAN_JOSE) {
                foreach($this->data_center_suffixes as $data_center => $suffix) {
                    if ( in_array($data_center, $localConfig['production_data_center_list']) ) {
                        $this->trie_files[$data_center] = $this->trie_base . $data_center . '/' . $this->trie_file;
                    }
                }
            }
        }
        return $this->trie_files;
    }

}
