<?php
include ("application.inc");
require_once 'pun/services/NotificationService.php';

class NotificationServiceTest extends PHPUnit_Framework_TestCase
{
	
	public function __construct()
	{
		
	}
	
	public function testMailLatencyNotice()
	{
		$notificationService = new NotificationService();
		$notice = new LatencyNotice();
//		$notice->set
		
	}
	
	
	
}