UPDATE config_misc SET value = 'gpaulsen@adobe.com' WHERE label = 'v14_pager_contacts';
UPDATE config_misc SET value = 'gpaulsen@adobe.com,dehansen@adobe.com' WHERE label = 'v15_operations_contacts';
UPDATE config_misc SET value = 'gpaulsen@adobe.com,dehansen@adobe.com,maryshaw@adobe.com' WHERE label = 'v14_operations_contacts';



INSERT INTO latency_notice_definition (billing_customer_name,billing_customer_id,company,companyid,adobe_email,email_frequency,latency_threshold,notify_state) values('bc1',1,'funkcorp',1,'dehansen@adobe.com,gpaulsen@adobe.com',2,4,'Active');
INSERT INTO latency_notice_definition (billing_customer_name,billing_customer_id,company,companyid,adobe_email,email_frequency,latency_threshold,notify_state) values('bc2',2,'Bizco',42,'dehansen@adobe.com,gpaulsen@adobe.com',2,4,'Hold');
INSERT INTO latency_notice_definition (billing_customer_name,billing_customer_id,company,companyid,adobe_email,ha_email,email_frequency,latency_threshold,notify_state) values('Internal HA Team',0,'HA',0,'gpaulsen@adobe.com','#waitdl-ha-operations@adobe.com',2,4,'Active');

INSERT INTO latency_event_definition (notice_def_id,username,userid) values((SELECT notice_def_id FROM latency_notice_definition WHERE company = 'funkcorp' ),'bugzilla.www14',1);
INSERT INTO latency_event_definition (notice_def_id,username,userid) values((SELECT notice_def_id FROM latency_notice_definition WHERE company = 'Bizco' ),'sistr2',42);

INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'funkcorp'),1);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'funkcorp'),31);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'funkcorp'),40859);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'Bizco'),1);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'Bizco'),101);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'Bizco'),40329);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'Bizco'),76843);
INSERT INTO latency_notice_def_cust_login_id (latency_notice_def_id,cust_login_id) VALUES((SELECT notice_def_id from latency_notice_definition WHERE company = 'Bizco'),76842);




