<?php

/*************************************************************************
 * ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright [2013] Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property laws,
* including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

/**
 * Singleton class to manage the Database Audit Loggers.
 *
 */
class DBAuditLoggers {
	
	/**
	 * Static var to hold singletone instance
	 */
	private static $db_audit_loggers = NULL;
	
	/**
	 * Returns true if the singleton has been instantiated
	 */
	public static function isInit() {
		return (self::$db_audit_loggers != NULL);
	}
	
	/**
	 * Returns the singleton instance. Can be null if
	 * the instance has not been created. Caller should call 
	 * isInit() function to check if the singleton has been 
	 * instantiated.
	 */
	public static function getInstance() {
		return self::$db_audit_loggers;
	}

	/**
	 * Creates the singleton instance if not created.
	 * Then adds the given logger.
	 */
	public static function addLogger($loggerName, $logger) {
		if(self::$db_audit_loggers === NULL)
			self::$db_audit_loggers = new DBAuditLoggers();
		
		self::$db_audit_loggers->loggers[$loggerName] =  $logger; 
	}
	
	/**
	 * Array to hold all the loggers. The loggers must be concrete
	 * implementations of DatabaseAuditLoggerBase class defined in
	 * phplib/php/dbauditlogger/DatabaseAuditLoggerBase.php
	 **/
	private $loggers = NULL;
	
	private function __construct()
	{
		$this->loggers = array();
	}
	
	public function logData($query, $db='', $host='', $extraData=NULL) {
		foreach ($this->loggers as $logger) {
			$logger->log_audit_trail($query, $db, $host, $extraData);
		}
	}
}