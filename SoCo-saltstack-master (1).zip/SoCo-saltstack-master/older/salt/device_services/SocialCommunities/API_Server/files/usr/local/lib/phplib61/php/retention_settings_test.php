#!/usr/local/bin/php -q
<?

$SERVER_NAME = 'omniture';
$PHP_SELF = '/sc15';
require 'application.inc';

include_once('retention_settings.inc');

echo "starting:\n";
$rs = new RetentionSettings();

echo "getnum for DC\n";
$results = $rs->getNumReportSuitesForBillingCustomerForDC(-1, 'dev');
print_r($results);

/*
echo "get billing from rs & dc\n";
$result = $rs->searchBillingCustomerByReportSuiteName('bugzilla.www14', 'dev');
print_r($result);
*/

/*
echo "get ecc_id for billing_customer name\n";
$ecc_id = $rs->getEccIdForBillingCustomerName('Omniture-Testing Customer');
echo "eccid: $ecc_id\n";
*/

/*
echo "testing setting hold status\n";
$return_code = $rs->setHoldStatus(1, 1, 'this is a test', 'dehansen');
echo "return: $return_code\n";
$result = $rs->getHoldStatus(1);
print_r($result);

echo "DWDefault:";
$dwdefault = $rs->getDWDefaultRetentionSettings();
echo "$dwdefault\n";
echo "FragDefault:";
$fragdefault = $rs->getFragDefaultRetentionSettings();
echo "$fragdefault\n";
echo "\n";

 */

/*
echo "default retention settings billing Customer\n";
$billing_customer_id = 1;
$bcrs = $rs->getDefaultRetentionSettingsBillingCustomer($billing_customer_id);
print_r($bcrs);
echo "\n";

echo "set bc default rsetting\n";
$changed_by_user = 'dehansen';
$dw_months = 11;
$frag_months = 18;
$result = $rs->setDefaultRetentionSettingsBillingCustomer($billing_customer_id, $changed_by_user, $dw_months, $frag_months);
echo "set result: $result\n";
$bcrs = $rs->getDefaultRetentionSettingsBillingCustomer($billing_customer_id);
print_r($bcrs);
echo "\n";
*/

/*

echo "change bc default rs\n";
$dw_months = 15;
$frag_months = 30;
$result = $rs->setDefaultRetentionSettingsBillingCustomer($billing_customer_id, $changed_by_user, $dw_months, $frag_months);
echo "set result: $result\n";
$bcrs = $rs->getDefaultRetentionSettingsBillingCustomer($billing_customer_id);
print_r($bcrs);
echo "\n";

echo "get settings rs\n";
$report_suite = 'bugzilla.www14';
$result = $rs->getRetentionSettingsReportSuite($report_suite);
print_r($result);
echo "\n";

echo "set settings rs null dw 1\n";
$result = $rs->setDefaultRetentionSettingsBillingCustomer($billing_customer_id, $changed_by_user, 100, 100);
print_r($result);
echo "\n";
$result = $rs->setRetentionSettingsReportSuite($report_suite, $changed_by_user, NULL, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite);
print_r($result);
echo "\n";

*/
/*
echo "set settings rs\n";
$dw_months = 15;
$frag_months = 240;
$report_suite = 'bugzilla.www14';
$changed_by_user = 'dehansen';
$dc = 'dev';
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, $dw_months, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "set settings rs null dw 2\n";
$frag_months = 34;
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, null, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "set settings rs null frag\n";
$dw_months = 25;
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, $dw_months, null);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "change settings rs\n";
$dw_months = 30;
$frag_months = 18;
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, $dw_months, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "unset\n";
$dw_months = RetentionSettings::NOT_SET;
$frag_months = RetentionSettings::NOT_SET;
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, $dw_months, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "sistr2\n";
$report_suite2 = 'sistr2';
$dw_months = 31;
$frag_months = 19;
$result = $rs->setRetentionSettingsReportSuite($report_suite2, $dc, $changed_by_user, $dw_months, NULL);
$result = $rs->getRetentionSettingsReportSuite($report_suite2, $dc);
print_r($result);
echo "\n";

echo "change settings rs\n";
$dw_months = 30;
$frag_months = 18;
$result = $rs->setRetentionSettingsReportSuite($report_suite, $dc, $changed_by_user, $dw_months, $frag_months);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite, $dc);
print_r($result);
echo "\n";

echo "get totals \n";
$rs_list_by_dc = $rs->getAllReportSuitesForBillingCustomerByDC(-1);
foreach ($rs_list_by_dc as $dc => $users) {
	foreach ($users as $user) {
		$rs_list[] = array(
			'datacenter' => $dc,
			'username' => $user['username']);
	}
}

$results = $rs->getRetentionSettingsTotalsReportSuites($rs_list);

print_r($results);
*/
/*
echo "get reportSuites filter\n";
$result = $rs->getRetentionSettingsReportSuitesFilterBySetting(array($report_suite, $report_suite2), 30, 16);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuitesFilterBySetting(array($report_suite, $report_suite2), 31, 18);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuitesFilterBySetting(array($report_suite, $report_suite2), 31, 19);
print_r($result);
echo "\n";

echo "test not_set\n";
$result = $rs->setRetentionSettingsReportSuite($report_suite, $changed_by_user, $dw_months, RetentionSettings::NOT_SET);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuite($report_suite);
print_r($result);
echo "\n";
$result = $rs->getRetentionSettingsReportSuitesFilterBySetting(array('thisrsbetternotexist', $report_suite, $report_suite2, 'jjesquire.dev'), NULL, RetentionSettings::NOT_SET);
print_r($result);
echo "\n";
*/

echo "...done\n";


