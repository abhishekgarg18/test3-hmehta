<?php
class LatencyEventSelector
{
	private $noticeId;
	private $username;
	private $userid;
	private $company;
	private $dateStart;
	private $dateEnd;
	private $eventType;
	private $resultCountLimit;
	private $resultStartindex;
	
	public function __construct()
	{
		
	}
	public function getNoticeId()
	{
		return $this->noticeId;
	}

	public function setNoticeId($noticeId) 
	{
		$this->noticeId = $noticeId;
	}

	public function getUsername() 
	{
		return $this->username;
	}

	public function setUsername($username) 
	{
		$this->username = $username;
	}

	public function getUserid() 
	{
		return $this->userid;
	}

	public function setUserid($userid) 
	{
		$this->userid = $userid;
	}

	public function getCompany() 
	{
		return $this->company;
	}

	public function setCompany($company) 
	{
		$this->company = $company;
	}

	public function getDateStart() 
	{
		return $this->dateStart;
	}

	public function setDateStart($dateStart) 
	{
		$this->dateStart = $dateStart;
	}

	public function getDateEnd() 
	{
		return $this->dateEnd;
	}

	public function setDateEnd($dateEnd) 
	{
		$this->dateEnd = $dateEnd;
	}

	public function getResultCountLimit() 
	{
		return $this->resultCountLimit;
	}

	public function setResultCountLimit($resultCountLimit) 
	{
		$this->resultCountLimit = $resultCountLimit;
	}

	public function getResultStartindex() 
	{
		return $this->resultStartindex;
	}

	public function setResultStartindex($resultStartindex) 
	{
		$this->resultStartindex = $resultStartindex;
	}
	
	public function getEventType() 
	{
		return $this->eventType;
	}

	public function setEventType($eventType) 
	{
		$this->eventType = $eventType;
	}

}