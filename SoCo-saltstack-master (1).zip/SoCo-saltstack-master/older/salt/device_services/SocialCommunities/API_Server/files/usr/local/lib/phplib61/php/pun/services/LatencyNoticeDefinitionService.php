<?php

require_once "pun/dao/LatencyNoticeDefinitionDao.php";
require_once "pun/services/LatencyEventDefinitionService.php";
require_once "pun/dao/IdentityDao.php";
require_once "pun/services/IdentityService.php";
require_once "pun/services/ConfigService.php";
require_once "pun/dao/LatencyEventDefinitionDao.php";
require_once "pun/model/LatencyNotice.php";
require_once "pun/model/LatencyEventDefinition.php";
require_once "pun/services/Exceptions.php";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

/**
 * 
 * This class provides services dealing with LatencyNoticeDefinitions
 *
 */
class LatencyNoticeDefinitionService
{
	private $latencyNoticeDefinitionDao;
	private $eventDefDao;
	private $eventDefService;
	private $identityService;
	private $configService;
	private $log;

	/**
	 * default constructor
	 */
	public function __construct()
	{
		$this->latencyNoticeDefinitionDao = new LatencyNoticeDefinitionDao();
		$this->eventDefDao = new LatencyEventDefinitionDao();
		$this->eventDefService = new LatencyEventDefinitionService();
		$this->configService = new ConfigService();
		$this->identityService = new IdentityService();
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * retrieves a LatencyNoticeDefinition based on the record id 
	 * @param int $id
	 */
	public function getLatencyNoticeDefinition($id, $return_login_names = true)
	{
		$definition = $this->latencyNoticeDefinitionDao->getLatencyNoticeDefinition($id);
		if(isset($definition))
		{
			//TODO use the service instead of the dao
			$definition->setEventDefinitions($this->eventDefDao->getLatencyEventDefinitionsByCompanyid($definition->getLoginCompanyId()));	
		}

		if (isset($definition) && $return_login_names)
		{
			//TODO use the service instead of the dao
			$identity = new IdentityDao();
			$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
		}
		return $definition;
	}
	
	/**
	 * Retrieves a LatencyNoticeDefinition based on the given username
	 * 
	 * @param String $username
	 */
	public function getLatencyNoticeDefinitionByUsername($username, $return_login_names = true)
	{
		$userid = userid_lookup($username);
		$this->log->debug("userid for username $username is $userid");
		
		$definition = $this->latencyNoticeDefinitionDao->getLatencyNoticeDefinitionByUserid($userid);
		if(isset($definition))
		{
			//TODO use the service instead of the dao
			$definition->setEventDefinitions($this->eventDefDao->getLatencyEventDefinitionsByCompanyid($definition->getLoginCompanyId()));	
		}
		if (isset($definition) && $return_login_names)
		{
			//TODO use the service instead of the dao
			$identity = new IdentityDao();
			$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
		}
		return $definition;
	}
	
	/**
	 * Retrieves the LatencyNoticeDefinition for the given company
	 * 
	 * @param int $companyid
	 * @param boolean $return_login_names
	 */
	public function getLatencyNoticeDefinitionByCompany($companyid, $return_login_names = true)
	{
		$definition = $this->latencyNoticeDefinitionDao->getLatencyNoticeDefinitionByCompany($companyid);
		if(isset($definition))
		{
			//TODO use the service instead of the dao
			$definition->setEventDefinitions($this->eventDefDao->getLatencyEventDefinitionsByCompanyid($definition->getLoginCompanyId()));	
		}
		if (isset($definition) && $return_login_names)
		{
			//TODO use the service instead of the dao
			$identity = new IdentityDao();
			$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
		}
		return $definition;
		
	}
	
	/**
	 * Saves the given LatencyNoticeDefinition to persistent storage. this is used for new definitions only. To update existing 
	 * definitions, use the update method
	 * 
	 * @param LatencyNoticeDefinition $latencyNoticeDefinition
	 */
	public function saveLatencyNoticeDefinition(LatencyNoticeDefinition $latencyNoticeDefinition, $return_login_names = true)
	{
		if($this->latencyNoticeDefinitionDao->getLatencyNoticeDefinitionByCompany($latencyNoticeDefinition->getLoginCompanyId()))
		{
			throw new InvalidParameterException(__METHOD__, "notice Definition for company ".$latencyNoticeDefinition->getLoginCompanyName()." already exists");
		}
		
		$definition = $this->latencyNoticeDefinitionDao->saveLatencyNoticeDefinition($latencyNoticeDefinition);
		
		// delete all event defs associated with the notice def, then re-add them. This avoid having to merge the db table with the object array
		$this->eventDefService->deleteAllLatencyEventDefinitions($definition->getID());
		foreach($definition->getEventDefinitions() as $eventDef)
		{
			$eventDef->setNoticeDefId($definition->getID());
			$this->eventDefService->saveLatencyEventDefinition($eventDef);		
		}
		
		if (isset($definition) && $return_login_names)
		{
			$identity = new IdentityDao();
			$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
		}
		return $definition;
	}
	
	/**
	 * Updates the given LatencyNoticedefinition to persisten storage.
	 *  
	 * @param LatencyNoticeDefinition $noticeDef
	 * @param boolean $return_login_names
	 */
	public function updateLatencyNoticeDefinition(LatencyNoticeDefinition $noticeDef, $return_login_names = true)
	{
		$definition = $this->latencyNoticeDefinitionDao->saveLatencyNoticeDefinition($noticeDef);
		
		// delete all event defs associated with the notice def, then re-add them. This avoid having to merge the db table with the object array
		$this->eventDefService->deleteAllLatencyEventDefinitions($definition->getID());
		foreach($definition->getEventDefinitions() as $eventDef)
		{
			$eventDef->setNoticeDefId($definition->getID());
			$this->eventDefService->saveLatencyEventDefinition($eventDef);		
		}
		
		if (isset($definition) && $return_login_names)
		{
			$identity = new IdentityDao();
			$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
		}
		return $definition;
	}
	
	public function deleteLatencyNoticeDefinition($defId)
	{
		$this->eventDefService->deleteAllLatencyEventDefinitions($defId);
		$this->latencyNoticeDefinitionDao->deleteLatencyNoticeDefinition($defId);
	}
	
	/**
	 * 
	 * Retrieves all latency notice definitions that meet the criteria in the given descriptor 
	 * @param unknown_type $latencyNoticeDefinitionSelector
	 */
	public function getLatencyNoticeDefinitions(LatencyNoticeDefinitionSelector $latencyNoticeDefinitionSelector, $return_login_names = true)
	{
		// replace username,company and billingCustomer strings with the corresponding ids. this will make sure the
		// query in the DAO uses the database indexes efficiently.
		// eg... userid_lookup($latencyNoticeDefinition.getRsid()); 
		$username = $latencyNoticeDefinitionSelector->getRsid();
		if($username != NULL && strlen($username) > 0)
		{
			$userid = userid_lookup($username);
			if($userid != NULL && $userid > 0)
			{
				$latencyNoticeDefinitionSelector->setUserid($userid);
				$latencyNoticeDefinitionSelector->setRsid(NULL);
				$this->log->debug("rsid $username converted to id $userid to better use table indexes.");
			}
		}
		
		$definitions = $this->latencyNoticeDefinitionDao->getLatencyNoticeDefinitions($latencyNoticeDefinitionSelector);	
		foreach($definitions as $definition)
		{
			//TODO use the service instead of the dao
			$definition->setEventDefinitions($this->eventDefDao->getLatencyEventDefinitionsByCompanyid($definition->getLoginCompanyId()));	
		}
		
		if ($return_login_names)
		{
			$identity = new IdentityDao();
			foreach ($definitions as $definition)
			{
				//TODO use the service instead of the dao
				$definition->setCustomerLogins($identity->getLoginNamesFromIDs($definition->getCustomerLogins(), $definition->getLoginCompanyId(), $definition->getLoginCompanyName()));
			}
		}

		return $definitions;
	}
	
	/**
	 * sets the subscription of a login id. This is so that users can opt out of notifications
	 *  
	 * @param int $company_id
	 * @param int $loginId
	 * @param int (0,1) $subscribed
	 */
	public function setLoginSubscription($company_id, $loginId, $subscribed)
	{
		$this->latencyNoticeDefinitionDao->setLoginSubscription($company_id, $loginId, $subscribed);
	}
	
	public function getLoginSubscription($companyId,$loginId)
	{
		return $this->latencyNoticeDefinitionDao->getLoginSubscription($companyId,$loginId);
	}
	
	/**
	 * Validates the given LatencyNoticeDefinition
	 * 
	 * @param LatencyNoticeDefinition $latencyNoticeDefinition
	 * @throws InvalidParameterException
	 */
	public function validateDefinition(LatencyNoticeDefinition $latencyNoticeDefinition)
	{
		//must have login company name set
		if ($latencyNoticeDefinition->getLoginCompanyName() == null && $latencyNoticeDefinition->getLoginCompanyId() == null)
		{
			$this->log->debug("no login company or id set");
			throw new InvalidParameterException(__METHOD__, 'A new Notice Definition must provide either the login company name or login company id. Neither was given. ');
		}
		
		if ($latencyNoticeDefinition->getLoginCompanyId() == null)
		{
			$identity = new IdentityDao();
			$companyId = $identity->getCompanyId($latencyNoticeDefinition->getLoginCompanyName());
			$latencyNoticeDefinition->setLoginCompanyId($companyId);
		}
		
		if ($latencyNoticeDefinition->getLoginCompanyname() == null)
		{
			$identity = new IdentityDao();
			$companyname = $identity->getCompanyName($latencyNoticeDefinition->getLoginCompanyId());
			$latencyNoticeDefinition->setLoginCompanyName($companyname);
		}
		
		if($this->identityService->getCompanyId($latencyNoticeDefinition->getLoginCompanyName()) == NULL)
		{
			$this->log->info("Given login company name ".$latencyNoticeDefinition->getLoginCompanyName()." is invalid");
			throw new InvalidParameterException(__METHOD__, 'Login Company Name is invalid');
		}
		
		if($this->identityService->getCompanyName($latencyNoticeDefinition->getLoginCompanyId()) == NULL)
		{
			$this->log->info("Given login company id ".$latencyNoticeDefinition->getLoginCompanyId()." is invalid");
			throw new InvalidParameterException(__METHOD__, 'Login Company Id is invalid');
		}
		
		if ($latencyNoticeDefinition->getBillingCustomerName() == null && $latencyNoticeDefinition->getBillingCustomerId() == null)
		{
			$identity = new IdentityDao();
			$billing_customer_id = $identity->getBillingCustomerForCompanyID($latencyNoticeDefinition->getLoginCompanyId());
			if ($billing_customer_id != -1)
			{
				$latencyNoticeDefinition->setBillingCustomerId($billing_customer_id);
			}
			else
			{
				$this->log->debug("no billing customer or id set and can't find by companyid");
				throw new InvalidParameterException(__METHOD__, 'Billing Customer is invalid');
			}
		}

		if ($latencyNoticeDefinition->getBillingCustomerId() == null)
		{
			$identity = new IdentityDao();
			$bcId = $identity->getBillingCustomerId($latencyNoticeDefinition->getBillingCustomerName());
			$latencyNoticeDefinition->setBillingCustomerId($bcId);
		}
		
		if ($latencyNoticeDefinition->getBillingCustomername() == null)
		{
			$identity = new IdentityDao();
			$bcname = $identity->getBillingCustomerName($latencyNoticeDefinition->getBillingCustomerId());
			$latencyNoticeDefinition->setBillingCustomerName($bcname);
		}
		
		// Not sure right now if billing customer is a required field
//		if($this->identityService->getBillingCustomerId($latencyNoticeDefinition->getBillingCustomerName()))
//		{
//			throw new InvalidParameterException(__METHOD__, 'Billing Customer Name is invalid');
//		}
//		
//		if($this->identityService->getBillingCustomerName($latencyNoticeDefinition->getBillingCustomerId()))
//		{
//			throw new InvalidParameterException(__METHOD__, 'Billing Customer Id is invalid');
//		}
//		
		$this->validateLatencyEventDefinitions($latencyNoticeDefinition);			

		if (is_array($latencyNoticeDefinition->getCustomerLogins()))
		{
			$valid_logins = array();
			$logins = $latencyNoticeDefinition->getCustomerLogins();
			
			if ((count($logins) > 0) && (is_array($logins[0])))
			{
				//this is a work-a-round where the input is funny
				$logins = $logins[0];
			}

			foreach ($logins as $login)
			{
				if (is_numeric($login))
				{
					$valid_logins[] = intval($login);
				}
				else if (is_string($login))
				{
					//actually login name...get login id
					$identity = new IdentityDao();
					$valid_logins[] = $identity->getLoginIdFromLoginName($login, $latencyNoticeDefinition->getLoginCompanyId(), $latencyNoticeDefinition->getLoginCompanyName());
				}
			}

			$latencyNoticeDefinition->setCustomerLogins($valid_logins);
		}
		else
		{
			$latencyNoticeDefinition->setCustomerLogins(array());
		}

		if (($latencyNoticeDefinition->getAdobeEmail() != null) && is_array($latencyNoticeDefinition->getAdobeEmail()))
		{
			$latencyNoticeDefinition->setAdobeEmail(implode(',', $latencyNoticeDefinition->getAdobeEmail()));
		}

		//TODO check for valid emails

		//do same for ha emails
		
		$threshold_options = $this->configService->getLatencyThresholdOptions();
		if (! in_array($latencyNoticeDefinition->getLatencyThreshold(), $threshold_options))
		{
			$this->log->debug("invalid latency threshold passed in");
			throw new InvalidParameterException(__METHOD__, 'Threshold option in definition');
		}

		$frequency_options = $this->configService->getEmailFrequencyOptions();
		if (! in_array($latencyNoticeDefinition->getEmailFrequency(), $frequency_options))
		{
			$this->log->debug("invalid email frequency passed in");
			throw new InvalidParameterException(__METHOD__, 'Email Frequency option in definition');
		}
	
		$state_options = $this->configService->getNotificationStateOptions();
		if (! in_array($latencyNoticeDefinition->getNotifyState(), $state_options))
		{
			$this->log->debug("invalid notice state passed in");
			throw new InvalidParameterException(__METHOD__, "notice state in definition (".$latencyNoticeDefinition->getNotifyState().")");
		}
	}
	
	public function validateLatencyEventDefinitions(LatencyNoticeDefinition $noticeDef)
	{
		$companyId = $noticeDef->getLoginCompanyId();
		$companyName = $noticeDef->getLoginCompanyName();
		$eligibleUserIds = $this->configService->getEligibleUserids();

		$nilcinvalidEventDefs = array();
		$neinvalidEventDefs = array();
		$eventDefs = $noticeDef->getEventDefinitions();
		foreach($eventDefs as $eventDef)
		{
			if($eventDef->getUsername() == NULL && $eventDef->getUserid() == NULL)
			{
				throw new InvalidParameterException(__METHOD__, "Event definition has no username or user id");
				
			}
			if($eventDef->getUsername() == NULL)
			{
				$eventDef->setUsername($this->identityService->getRSNameFromRSID($eventDef->getUserid()));
				$this->log->debug("set username to".$eventDef->getUsername()." with lookup");
			}
			if($eventDef->getUserid() == NULL)
			{
				$eventDef->setUserid($this->identityService->getRSIDFromRSName($eventDef->getUsername()));
				$this->log->debug("set userid to".$eventDef->getUserid()." with lookup");
			}
			
			list($defCompanyId, $defCompanyName) = $this->identityService->getCompanyForRsid($eventDef->getUsername());
			if( ($companyName != $defCompanyName))
			{
				$nilcinvalidEventDefs[] = $eventDef->getUsername();
				$this->log->debug("username ".$eventDef->getUsername()." not in login company $companyName with id $companyId");
			}			
			if(!in_array($eventDef->getUserid(),$eligibleUserIds))
			{
				$neinvalidEventDefs[] = $eventDef->getUsername();
				$this->log->debug("username ".$eventDef->getUsername()." with id of ".$eventDef->getUserid()." not in list of eligible user ids");
			}	
		}
		
		if(sizeof($nilcinvalidEventDefs) > 0 || sizeof($neinvalidEventDefs) > 0)
		{
			$errMsg = "";
			if(sizeof($nilcinvalidEventDefs) > 0)
			{
				$errmsg .= "Report suites not in login company $companyName [".implode(",",$nilcinvalidEventDefs)."]  ";
			}
			if(sizeof($neinvalidEventDefs) > 0)
			{
				$errmsg .= "Report suites not eligible for latency monitoring [".implode(",",$neinvalidEventDefs)."]  ";
			}
			throw new InvalidParameterException(__METHOD__, $errmsg);
		}
	}
	
}
