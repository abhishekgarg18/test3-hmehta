<?php

class LatencyNoticeDefinition
{
	private $noticeDefinitionID = null;
	private $rsid = null;
	private $suiteId = null;
	private $billingCustomerId = null;
	private $billingCustomerName = null;
	private $loginCompanyId = null;
	private $loginCompanyName = null;
	private $adobeEmail = null;
	private $haEmail = null;
	private $customerLogins = null;
	private $eventDefs;
	private $emailFrequency = null;
	private $latencyThreshold = null;
	private $notifyState = null;

	public function __construct()
	{
		$this->customerLogins = array();
		$this->eventDefs = array();
	}

	public function getID() {
		return $this->noticeDefinitionID;
	}
	
	public function getRsid() 
	{
		trigger_error('Function getRsid() is deprecated', E_USER_DEPRECATED);
		return $this->rsid;
	}

	public function getSuiteId() 
	{
		trigger_error('Function getsuiteId() is deprecated', E_USER_DEPRECATED);
		return $this->suiteId;
	}

	public function getBillingCustomerId() 
	{
		return $this->billingCustomerId;
	}

	public function getBillingCustomerName() 
	{
		return $this->billingCustomerName;
	}

	public function getLoginCompanyId() 
	{
		return $this->loginCompanyId;
	}

	public function getLoginCompanyName() 
	{
		return $this->loginCompanyName;
	}

	public function setSuiteId($suiteId) 
	{
		trigger_error('Function setSuiteId() is deprecated', E_USER_DEPRECATED);
		$this->suiteId = $suiteId;
	}

	public function setBillingCustomerId($billingCustomerId) 
	{
		$this->billingCustomerId = $billingCustomerId;
	}

	public function setBillingCustomerName($billingCustomerName) 
	{
		$this->billingCustomerName = $billingCustomerName;
	}

	public function setLoginCompanyId($loginCompanyId) 
	{
		$this->loginCompanyId = $loginCompanyId;
	}

	public function setLoginCompanyName($loginCompanyName) 
	{
		$this->loginCompanyName = $loginCompanyName;
	}

	public function getAdobeEmail() 
	{
		return $this->adobeEmail;
	}

	public function setAdobeEmail($adobeEmail) 
	{
		$this->adobeEmail = $adobeEmail;
	}

	public function getHaEmail() 
	{
		return $this->haEmail;
	}
	
	public function setHaEmail($haEmail) 
	{
		$this->haEmail = $haEmail;
	}

	public function getCustomerLogins() 
	{
		return $this->customerLogins;
	}
	
	public function setCustomerLogins($customerLogins)
	{
		$this->customerLogins = $customerLogins;
	}

	public function getEmailFrequency() 
	{
		return $this->emailFrequency;
	}

	public function getLatencyThreshold() 
	{
		return $this->latencyThreshold;
	}

	public function getNotifyState() 
	{
		return $this->notifyState;
	}

	public function setID($id)
	{
		$this->noticeDefinitionID = $id;
	}

	public function setRsid($rsid) 
	{
		trigger_error('Function setRsid() is deprecated', E_USER_DEPRECATED);
		$this->rsid = $rsid;
	}

	public function addCustomerLogin($customerLogin) 
	{
		$this->customerLogins[] = $customerLogin;
	}
	
	public function getEventDefinitions()
	{
		return $this->eventDefs;
	}
	
	public function setEventDefinitions(array $eventDefs)
	{
		$this->eventDefs = $eventDefs;
	}
	
	public function addEventDefinition(LatencyEventDefinition $eventDef)
	{
		$this->eventDefs[] = $eventDef;
	}

	public function setEmailFrequency($emailFrequency) 
	{
		$this->emailFrequency = $emailFrequency;
	}

	public function setLatencyThreshold($latencyThreshold) 
	{
		$this->latencyThreshold = $latencyThreshold;
	}

	public function setNotifyState($notifyState) 
	{
		$this->notifyState = $notifyState;
	}
}
