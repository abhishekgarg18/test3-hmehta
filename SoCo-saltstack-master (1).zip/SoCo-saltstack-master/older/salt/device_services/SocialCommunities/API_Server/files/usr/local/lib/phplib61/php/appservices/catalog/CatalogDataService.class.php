<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2016 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/
require_once 'appservices/OM_AdminServicesAccessTokenGenerator.class.php';
require_once("appservices/OM_AppServiceBase.class.php");
require_once("CatalogData.class.php");

/*
* Written by drawal 06/2016
* This class provides wrapper of Catalog Data Appservices API
*/

class CatalogDataService extends OM_AppServiceBase
{
    private function getToken()
    {
        $token_generator = new OM_AdminServicesAccessTokenGenerator();
        return $token_generator->getTokenForCurrentUser();
    }

    public function getCatalogExportStatus($rsid, $startdate, $enddate)
    {
        $path = "/catalog/exportstatus?";
        if ($rsid)
            $path .= "&rsid=" . urlencode($rsid);
        if ($startdate)
            $path .= "&startdate=" . urlencode($startdate);
        if ($enddate)
            $path .= "&enddate=" . urlencode($enddate);

        $response = $this->makeAdminEndpointRequest($path, $this->getToken());
        if ($response->hasErrors()) {
            throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
        }
        return $response;
    }

    function getCatalogData($rsid, $basename, $startdate, $enddate, $filetype, $filestatus, $columns)
    {
        $path = "/catalog?";
        if ($rsid)
            $path .= "&rsid=" . urlencode($rsid);
        if ($basename)
            $path .= "&basename=" . urlencode($basename);
        if ($startdate)
            $path .= "&startdate=" . urlencode($startdate);
        if ($enddate)
            $path .= "&enddate=" . urlencode($enddate);
        if ($filetype)
            $path .= "&filetype=" . urlencode($filetype);
        if ($filestatus)
            $path .= "&filestatus=" . urlencode($filestatus);
        if ($columns)
            $path .= "&columns=" . urlencode($columns);
        $response = $this->makeAdminEndpointRequest($path, $this->getToken());
        if ($response->hasErrors()) {
            throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
        }
        return $response;
    }
}
