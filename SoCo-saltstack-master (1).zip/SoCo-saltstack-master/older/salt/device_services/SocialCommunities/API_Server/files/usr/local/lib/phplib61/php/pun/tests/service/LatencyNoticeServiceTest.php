<?php
include ("application.inc");
require_once("pun/services/LatencyNoticeService.php");
class LatencyNoticeServiceTest  extends PHPUnit_Framework_TestCase
{
	public function __construct()
	{
		
	}
	
	public function testGetLastLatencyNotice()
	{
		$service = new LatencyNoticeService();
		$latencyNotice = $service->getLastLatencyNoticeForUser("sistr2");		
	}
	
	public function testIsCurrentlyLatent()
	{
		$service = new LatencyNoticeService();
		$isLatent = $service->isCurrentlyLatent(1);		
		
	}
	
	public function testGetLastIncidentStartTime()
	{
		$service = new LatencyNoticeService();
		$startTime = $service->getLastIncidentStartTimeForUser("sistr2");
		
	}
	
	public function testGetLastIncidentEndTime()
	{
		$service = new LatencyNoticeService();
		$startTime = $service->getLastIncidentEndTimeForUser("sistr2");
		
	}
}
