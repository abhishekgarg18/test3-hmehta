<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com
// This is a multi-datacenter helper class

require_once 'application.inc';
require_once 'class-ha-utilities.php';

// this class is meant to be run once in the environment's primary data center at a scheduled interval via cron
// data will be collected via class Run_Everywhere_Remote_Service and dropped in a db table in the remote service's data center.  
// this class will wait for all remote services to finish & retrieve data from the db tables in each data center.
class Run_Everywhere_Central_Service extends HA_Utilities 
{
    // args & database fields
    protected $id;
    protected $run_name;
    protected $app_name;
    protected $start_time;
    protected $end_time;
    protected $status_code;
    protected $status_details;
    protected $error_code;
    protected $error_details;
    protected $completed_data_centers;

    // used inside the class only
    protected $row_exists = false;
    protected $listeners = array();
    
    const STATUS_IN_PROGRESS = 'inprogress';
    const STATUS_COMPLETE_OK = 'complete-OK';
    const STATUS_COMPLETE_ERROR = 'complete-ERR';
    const SERVER_PICKED_UP = 1;
    const SERVER_WAITING = 2;
    const SERVER_GAVE_UP = 3;
    
    const OUTPUT_DATA_TYPE_JSON = 'JSON';
    const OUTPUT_DATA_TYPE_PHP = 'PHP';
    
    const ERROR_RUNTIME = 'RUNTIME_ERROR';
    
    const DB_TABLE = 'run_everywhere_central_service_log';
    const DB_NAME = 'latencydb';
    const SQL_COMMENT = " /* MODULE: bertlib FILE: class-run-everywhere-central-service.php */ ";        
    const SLEEP_SECONDS = 60;
    
	// anything you put in $args will override the default value
	function __construct( $args = array() ) {
        $this->debug("Starting constructor.  First the parent constructor.");
	    parent::__construct($args);
        $this->debug("Parent constructor finished.  Checking for table.");

        if (!$this->check_for_table()) {
            $this->debug("Table does not exist.  Creating.");
            $this->create_table();
        }
        
        $this->debug("Going to load args.\n");
        $this->load_args($args);
        $this->debug("Constructor finished\n");
    }
    
    function start($args = array()) {
        $this->load_args($args);
        
        $this->save();
    }
    
    // The server is in SJ or any non-production data center.
    // there should be one client for every data center in the environment.
    function init_listeners() {
        global $localConfig;

        $this->listeners = array();
        
        // find out if this data center is in production
        if (in_array( DATA_CENTER, $localConfig['production_data_center_list'] ) ) {
            $client_data_centers = $localConfig['production_data_center_list'];
        }
        else {
            $client_data_centers = array( DATA_CENTER );
        }
        
        // create client classes with the remote data centers for picking up 
        // data as runs complete
        foreach($client_data_centers as $dc) {
            $new_client = new Run_Everywhere_Remote_Service( array(
                'app_name' => $this->app_name(),
                'run_name' => $this->run_name(),
                'target_datacenter' => $dc,
                'target_data_center' => $dc,
                'log_level' => $this->log_level(),
            ) );
            $new_client->pick_up_latest_run();
            $this->listeners[ $dc ] = $new_client;
        }
        
        return $this->listeners;
    }
    
    function wait_for_all_listeners($timeout_minutes = 60) {
        if (!is_array($this->listeners)) {
            $this->init_listeners();
        }
        
        $initial_timestamp = time();
        
        // run this loop until the timeout is reached.
        // when data is finished, loop will end via "break"
        while( time() < ( $initial_timestamp + ( $timeout_minutes * 60 ) ) ) {
            $count_completed = 0;
        
            foreach($this->listeners as $data_center => $listener) {
                $listener->refresh();
                $complete = false;
                
                if ($listener->status_code() == Run_Everywhere_Remote_Service::STATUS_COMPLETE_OK) {
                    $complete = true;
                }
                
                else if ($listener->status_code() == Run_Everywhere_Remote_Service::STATUS_COMPLETE_ERROR) {
                    $complete = true;
                }
                
                else if ($listener->status_code() == Run_Everywhere_Remote_Service::STATUS_IN_PROGRESS) {
                }
                
                if ($complete === false) {
                    $this->debug("Listener from $data_center is NOT complete.  Waiting...");
                }
                if ($complete === true) {
                    $count_completed++;
                }
            }
            
            if ($count_completed >= count($this->listeners)) {
                $this->debug("All " . $count_completed . " datacenters are done.");
                break;
            }
            else {
                // sleep for 1/2 minute... then continue until the timeout has been reached.
                sleep(30);
            }
        }
        $this->debug("Wait for all listeners - waiting loop finished.");
        
        return $this->listeners;
    }
    
    function output($listener) {
        // not sure if i want to implement this yet.
    }
    
    function finish($args = array()) {
        // set default codes for finishing properly
        $this->status_code(self::STATUS_COMPLETE_OK);
        $this->status_details('This run completed with no errors.');
        
        // overwrite default data with the args in the parameters
        $this->load_args($args);
        
        $this->save();
    }
    
    function error($args = array()) {
        // set default error code
        $this->error_code(self::ERROR_RUNTIME);
        $this->error_details('There was a problem running the server in ' . DATA_CENTER . '.');
        
        // overwrite default data with the args in the parameters
        $this->load_args($args);
        
        $this->save();
    }

    function load_args($args) {
        if (isset($args['id'])) {
			$this->id($args['id']);
		}
        if (isset($args['run_name'])) {
			$this->run_name($args['run_name']);
		}
        if (isset($args['app_name'])) {
			$this->app_name($args['app_name']);
		}
        if (isset($args['start_time'])) {
			$this->start_time($args['start_time']);
		}
        if (isset($args['end_time'])) {
			$this->end_time($args['end_time']);
		}
        if (isset($args['status_code'])) {
			$this->status_code($args['status_code']);
		}
        if (isset($args['status_details'])) {
			$this->status_details($args['status_details']);
		}
        if (isset($args['error_details'])) {
			$this->error_details($args['error_details']);
		}
        if (isset($args['completed_data_centers'])) {
			$this->completed_data_centers($args['completed_data_centers']);
		}
    }
    
	function id( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->id = $new_value;
		}
		return $this->id;
	}

	function run_name( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
            if ($new_value === 0) {
                $this->run_name = 'Run ' . date('Y-m-d H:i:s T');
            }
            else {
    			$this->run_name = $new_value;
            }
		}
		return $this->run_name;
	}

	function app_name( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->app_name = $new_value;
		}
		return $this->app_name;
	}

	function start_time( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->start_time = $new_value;
		}
		return $this->start_time;
	}

	function end_time( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->end_time = $new_value;
		}
		return $this->end_time;
	}

	function status_code( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->status_code = $new_value;
		}
		return $this->status_code;
	}

	function status_details( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->status_details = $new_value;
		}
		return $this->status_details;
	}

	function error_code( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->error_code = $new_value;
		}
		return $this->error_code;
	}

	function error_details( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->error_details = $new_value;
		}
		return $this->error_details;
	}
    
	function completed_data_centers( $new_value = NULL ) {
		if ( !is_null( $new_value ) ) {
			$this->completed_data_centers = $new_value;
		}
		return $this->completed_data_centers;
	}

    // save state in the table row.  if no row, create a new one
    function save() {
        $action = 'INSERT INTO ';
        $where = '';
        $limit = '';
        $create_flag = true;
        // update if the row already exists
        if ($row_exists) {
            $action = 'UPDATE ';
            $where = ' WHERE ID=' . intval($this->id());
            $limit = ' LIMIT 1';
            $create_flag = false;
        }
        
        $columns = array();
        if (!is_null($this->run_name())) {
            $columns[] = ' run_name= "' . addslashes($this->run_name()) . '" ';
        }
        if (!is_null($this->app_name())) {
            $columns[] = ' app_name= "' . addslashes($this->app_name()) . '" ';
        }
        if (!is_null($this->start_time())) {
            $columns[] = ' start_time= ' . intval($this->start_time()) . ' ';
        }
        if (!is_null($this->end_time())) {
            $columns[] = ' end_time= "' . intval($this->end_time()) . '" ';
        }
        if (!is_null($this->status_code())) {
            $columns[] = ' status_code= "' . addslashes($this->status_code()) . '" ';
        }
        if (!is_null($this->status_details())) {
            $columns[] = ' status_details= "' . addslashes($this->status_details()) . '" ';
        }
        if (!is_null($this->error_details())) {
            $columns[] = ' error_details= "' . addslashes($this->error_details()) . '" ';
        }
        if (!is_null($this->error_code())) {
            $columns[] = ' error_code= "' . addslashes($this->error_code()) . '" ';
        }
        if (!is_null($this->completed_data_centers())) {
            $columns[] = ' completed_data_centers= "' . addslashes($this->completed_data_centers()) . '" ';
        }
        
        $sql = $action . self::DB_TABLE . self::SQL_COMMENT .
            ' SET ' . join(' , ', $columns) . $where . $limit;
        $db = $this->db_handle( self::DB_NAME, DATA_CENTER );
        $db->halt_on_error = false;
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error checking for table ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            // TODO throw an error here
        }

        if ($create_flag === true) {
            
            // get the ID assigned to this row
            $sql = 'SELECT LAST_INSERT_ID() as id';
            $db->query($sql);
            
            if ($db->Errno != 0) {
                $this->error('Error getting ID for new everywhere server record: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            }

            if ($db->next_record()) {
                $this->id( intval( $db->f('id') ) );
            }
        }
        
        return true;
    }

    function check_for_table() {
        $table_exists = false;
        $sql = 'SHOW TABLES LIKE "' . self::DB_TABLE . '"' . self::SQL_COMMENT;
        $db = $this->db_handle( self::DB_NAME, DATA_CENTER );
        $db->halt_on_error = false;
        $db->query($sql);
        
        if ($db->Errno != 0) {
            $this->error('Error checking for table ' . self::DB_TABLE . ': ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
        }
        if ($db->next_record()) {
            $table_exists = true;
        }
        
        return $table_exists;
    }
    
    function create_table() {
        $db = $this->db_handle( self::DB_NAME, DATA_CENTER );
        $sql = 'CREATE TABLE IF NOT EXISTS ' . self::DB_TABLE . self::SQL_COMMENT . '(
            central_service_log_id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            run_name VARCHAR(20) NOT NULL,
            app_name VARCHAR(30) NOT NULL,
            start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            end_time TIMESTAMP DEFAULT 0,
            status_code VARCHAR(20),
            status_details VARCHAR(255),
            error_details VARCHAR(255),
            error_code VARCHAR(20),
            completed_data_centers VARCHAR(30)
            )';
        $sql = preg_replace('/\s+/', ' ', $sql);
        $this->debug('Creating run everywhere server table: ' . $sql);
        $db->halt_on_error = false;
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error creating run everywhere server table: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
            return false;
        }
        else {
            $this->debug('Table creation finished OK.');
        }

        return true;
    }
    
}
