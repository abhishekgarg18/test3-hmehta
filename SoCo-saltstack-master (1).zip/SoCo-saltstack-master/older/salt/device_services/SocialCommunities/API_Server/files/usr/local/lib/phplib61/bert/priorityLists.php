<?
require_once 'application.inc';

class priorityListsWeights {
	public $ownerId = NULL;
	public $listId = NULL;
	public $enabled = NULL;
	public $weight = NULL;
}

class priorityList {
	public $listId = NULL;
	public $ownerId = NULL;
	public $name = NULL;
	public $sortOrder = NULL;
	public $public = NULL;
	public $listItems = NULL;
}

class priorityListItem {
	public $listItemId = NULL;
	public $listId = NULL;
	public $priority = NULL;

	public $rsid = NULL;
	public $datacenter = NULL;
}

class priorityLists {
	protected $db;

	public function __construct(){
		$this->db = new DB_SQL('cache_maintenance');
//		$this->db->halt_on_error = false;
  		$this->db->connect_failure_force_reset = true;
	}

	private function getSqlKeyValue($list){
		$conditions = array();
		foreach($list as $key => $value){
			if($value !== NULL) $conditions[] = "`$key` = '" . mysql_escape_string($value) . "'";
		}
		return $conditions;
	}

	private function getWhereClause($list){
		return implode(' AND ', array_merge(array('1=1'), $this->getSqlKeyValue($list)));
	}

	private function getSetClause($list){
		return implode(', ', $this->getSqlKeyValue($list));
	}

	protected function getListGeneral(priorityList $list){
		$results = array();
		$this->db->query("SELECT * FROM priorityList WHERE " . $this->getWhereClause($list) . ' ORDER BY sortOrder');
		while($this->db->next_record()){
			$newList = new priorityList();
			$newList->listId = $this->db->f('listId');
			$newList->ownerId = $this->db->f('ownerId');
			$newList->sortOrder = $this->db->f('sortOrder');
			$newList->name = $this->db->f('name');
			$newList->public = $this->db->f('public');
			$results[] = $newList;
		}
		foreach($results as $key => $value){
			$itemQuery = new priorityListItem();
			$itemQuery->listId = $value->listId;
			$value->listItems = $this->getListItemsGeneral($itemQuery);
		}
		return $results;
	}

	protected function getListItemsGeneral(priorityListItem $listItem){
		$results = array();
		$this->db->query("SELECT * FROM priorityListItem WHERE " . $this->getWhereClause($listItem) . ' ORDER BY priority');
		while($this->db->next_record()){
			$newListItem = new priorityListItem();
			$newListItem->listItemId = $this->db->f('listItemId');
			$newListItem->listId = $this->db->f('listId');
			$newListItem->priority = $this->db->f('priority');
			$newListItem->rsid = $this->db->f('rsid');
			$newListItem->datacenter = $this->db->f('datacenter');
			$results[] = $newListItem;
		}
		return $results;
	}

	public function createList(priorityList $list){
		return $this->db->query("INSERT INTO priorityList SET " . $this->getSetClause($list));
	}

	public function clearList(priorityList $list){
		return $this->db->query("DELETE FROM priorityListItem WHERE listId IN(SELECT listId FROM priorityList WHERE " . $this->getWhereClause($list) . ")");
	}

	public function deleteList(priorityList $list){
		$this->clearList($list);
		return $this->db->query("DELETE FROM priorityList WHERE " . $this->getWhereClause($list));
	}

	public function updateList(priorityList $list){
		$whereList = new priorityList();
		$whereList->listId = $list->listId;
		$setList = clone $list;
		unset($setList->listItems);
		return $this->db->query("UPDATE priorityList SET " . $this->getSetClause($setList) . ' WHERE ' . $this->getWhereClause($whereList));
	}

	public function addListItem(priorityListItem $item){
		return $this->db->query("INSERT INTO priorityListItem SET " . $this->getSetClause($item));
	}

	public function deleteListItem(priorityListItem $item){
		return $this->db->query("DELETE FROM priorityListItem WHERE " . $this->getWhereClause($item));
	}

	public function updateListItem(priorityListItem $item){
		$whereItem = new priorityListItem();
		$whereItem->listItemId = $item->listItemId;
		return $this->db->query("UPDATE priorityListItem SET " . $this->getSetClause($item) . ' WHERE ' . $this->getWhereClause($whereItem));
	}

	public function getListsByOwner($ownerId){
		$whereList = new priorityList();
		$whereList->ownerId = $ownerId;
		return $this->getListGeneral($whereList);
	}

	public function getPublicLists(){
		$whereList = new priorityList();
		$whereList->public = true;
		return $this->getListGeneral($whereList);
	}

	public function getList($listId){
		$whereList = new priorityList();
		$whereList->listId = $listId;
		return $this->getListGeneral($whereList);
	}

	public function getListItem($listId, $listItemId){
		$whereList = new priorityListItem();
		$whereList->listId = $listId;
		$whereList->listItemId = $listId;
		return $this->getListItemsGeneral($whereList);
	}

	public function getOrderedLists($ownerId){
	}

}
