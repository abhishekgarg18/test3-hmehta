<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2014 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
class AppcachingAutoloader
{
	public static function autoloadAppcaching($name)
	{
		static $classes;

		if (!$classes) {
			$classes = array(
				'BlackHoleCache' => 'appcaching/BlackHoleCache.php',
				'CacheInterface' => 'appcaching/CacheInterface.class.php',
				'MemCachedCache' => 'appcaching/MemCachedCache.class.php',
				'ReportSuiteLevelCache' => 'appcaching/ReportSuiteLevelCache.class.php',
				'SessionLevelCache' => 'appcaching/SessionLevelCache.class.php',
			);
		}

		if (isset($classes[$name])) {
			require_once $classes[$name];
		}
	}
}

/*
 * Cory Aitchison <caitchis@adobe.com>
 * 11/10/2014
 *
 * Most of the Cache classes require the globals that are set up in application.inc
 */
require_once 'application.inc';
spl_autoload_register(array('AppcachingAutoloader', 'autoloadAppcaching'));