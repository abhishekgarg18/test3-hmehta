<?
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * VcClusterTransition.class.php Retrieve and update information for/from the vccookie_transition_details and related tables
 *
 * @author  keklingl <keklingl@adobe.com>
 *
 */
require_once 'common_functions.inc';
require_once 'Config.class.php';
require_once 'ReportSuiteConfig.class';
require_once 'DataMigration.class';
require_once 'VCookieTransfer.class.php';

class VcClusterTransition {
	// Valid transition states
	const MYSQL_ONLY = 'MySQL';
	const HBASE_AND_MYSQL = 'HBase-MySQL';
	const HBASE_DOING_TRANSFER = 'HBase-Tran';
	const HBASE_ONLY = 'HBase';
	const MULTI_HBASE_ONLY = 'HBase-HBase';
	const HANDLER_UNKNOWN = 'Handler Unknown';
	const VALID_TRANSFER_HANDLE = 'HM';

	const DETAIL_TABLE_NAME = 'vcookie_cluster_transition_detail';
	const COMPANY_PLAN_TABLE_NAME = 'vcookie_cluster_transition_company_plan';
	const SCHEDULE_TABLE_NAME = 'vcookie_cluster_transition_schedule';
	const MOBILE_PLAN_TABLE_NAME = 'vcookie_cluster_transition_mobile_plan';
	const BLACKLIST_TABLE_NAME = 'vcookie_cluster_black_list';

	const MIN_TRANSITION_DATE = '2015-08-01';
	const MAX_TRANSITION_DATE = '2017-02-28';
	const MAX_MOBILE_TRANSITION_DATE = '2016-06-28';

	const MIN_DAYS_ENABLED_TO_TRANSFER = 30; // From details table
	const MIN_HOURS_ENABLED_TO_TRANSFER = 4; // From VCookie Handler Info

	const ROLLUP_SCHEDULE_TAG = 'Rollups';
	const ROLLUP_DEFAULT_DATE = '2016-08-24';

	const ANY_MYSQL_SCHEDULE_TAG = 'AnyMySql';

	const FILTER_BLACKLIST = 'blacklist';
	const FILTER_MOBILE_NOT_READY = 'mobile_not_ready';
	const FILTER_ACCOUNT_UNAVAILABLE = 'user_account_unavailable';
	const FILTER_NOT_SCHEDULE_READY = 'not_schedule_ready';
	const FILTER_ALREADY_ENABLED = 'already_enabled';
	const FILTER_CYGNUS = 'cygnus_rsid';
	const FILTER_ROLLUP = 'rollup_rsid';
	const FILTER_MIGRATING = 'migrating_rsid';
	const FILTER_INCORRECT_HANDLERS = 'incorrect_handlers';
	const FILTER_ALREADY_TRANSFERRED = 'already_transferred';
	const FILTER_BEING_TRANSFERRED = 'being_transferred';
	const FILTER_NOT_ENABLED = 'not_enabled';
	const FILTER_IN_PURGE_QUEUE = 'in_purge_queue';

	const SELECT_ACTIVE = 'active';
	const SELECT_ENABLE_READY = 'enable_ready';
	const SELECT_TRANSFER_READY = 'transfer_ready';
	const SELECT_MOBILE = 'mobile';
	const SELECT_MOBILE_DELAY = 'mobile_delay';
	const SELECT_NO_PLAN = 'no_plan';
	const SELECT_ROLLUP = 'rollup';
	const SELECT_VIP_COMPANY = 'vip_company';
	const SELECT_PRIORITY = 'priority';
	const SELECT_PURGE_QUEUE = 'purge_queue';
	const SELECT_BLACKLIST = 'blacklist';
	const SELECT_ENABLED = 'enabled';
	const SELECT_TRANSFERRED = 'transferred';
	const SELECT_BEING_TRANSFERRED = 'being_transferred';
	const SELECT_NOT_ACTIVE = 'not_active';
	const SELECT_ENABLE_PAST_DUE = 'enable_past_due';
	const SELECT_STRATEGIC_CUSTOMER = 'strategic_customer';
	const SELECT_NOT_ENABLED = 'not_enabled';
	
	// Traffic types as defined in user_services
	const TRAFFIC_TYPE_WEB_BEACON        = 0; // user set to receive normal mod_stats traffic
	const TRAFFIC_TYPE_HIT_TIMESTAMP     = 1; // user set to receive hits with timestamp passed in either through mod_stats or through log files
	const TRAFFIC_TYPE_ROLLUP            = 2; // user set to be a rollup user so shouldn't get any live traffic
	const TRAFFIC_TYPE_BOTH_TIME_NONTIME = 3; // user set to allow receiving hits with or without a timestamp (i.e. traffic type 0 or 1)
	const TRAFFIC_TYPE_UNKNOWN           = 99; // Not defined in user_services

	private $min_days_enabled_to_transfer;
	private $min_hours_enabled_to_transfer;
	private $allow_auto_enable_rollups;
	private $cmdb;
	private $run;
	private $user;
	private $rollup_plan;
	private $last_find;
	private $last_schedules;
	private $last_company_plans;
	private $last_mobile_plans;
	private $last_blacklist;
	private $last_purge_queue;
	private $cached_purge_queue; // Track caching of purge queue since there might not be any entries for this DPC leaving last_purge_queue empty
	private $verbose;
	private $current_batch;

	public function __construct($run=false, $cmdb_host=NULL) {
		$this->run = $run;
		$this->cmdb = new DB_Sql('cache_maintenance');
		$this->cmdb->halt_on_error = false;
		if($cmdb_host != NULL) {
			$this->cmdb->Host = $cmdb_host;
		}
		$this->user = trim(`whoami`);
		$this->endBatch();
		$this->invalidateLastFind();
		$this->invalidateLastSchedules();
		$this->invalidateLastCompanyPlans();
		$this->invalidateLastMobilePlans();
		$this->invalidateLastBlacklist();
		$this->invalidateLastPurgeQueue();
		$this->sql_comment = ' /* MODULE: bertlib FILE: VcClusterTransition.class */ ';

		$config = new BertConfig(get_class($this));
		$this->min_days_enabled_to_transfer = $config->filter('min_days_enabled', self::MIN_DAYS_ENABLED_TO_TRANSFER, FILTER_VALIDATE_INT, array('options' => array('min_range' => 2, 'max_range' => 366)));
		$this->min_hours_enabled_to_transfer = $config->filter('min_hours_enabled', self::MIN_HOURS_ENABLED_TO_TRANSFER, FILTER_VALIDATE_INT, array('options' => array('min_range' => 2, 'max_range' => 24)));
		$this->allow_auto_enable_rollups = $config->filter('allow_auto_enable_rollups', 'no', FILTER_VALIDATE_BOOLEAN);
	}

	/**
	 * Sets flag to control showing of additional output
	 * 
	 * @param boolean $value - If true, show additional output
	 */
	public function set_verbose($value) {
		$this->verbose = $value;
	}

	/**
	 * Runs a query if in execute mode with optional display of the query
	 * 
	 * @param string $sql - The query to run
	 * @return boolean - True if query was successful or skipped
	 */
	private function run_query($sql) {
		$ret = true;
		if ($this->verbose) {
			echo "$sql\n";
		}
		if ($this->run) {
			$ret = $this->cmdb->query($sql);
		}
		return $ret;
	}

	/**
	 * Runs a query with optional display of the query
	 * 
	 * @param string $sql - The query to run
	 * @return boolean - True if query was successful
	 */
	private function run_query_always($sql) {
		if ($this->verbose) {
			echo "$sql\n";
		}
		return $this->cmdb->query($sql);
	}

	/**
	 * Creates the tables required for tracking vcookie cluster transition
	 * 
	 * @throws Exception - Error creating table or table already exists
	 */
	public function createTables() {
		$this->invalidateLastFind();
		$exception_code = BERT_RET_SUCCESS;
		$exceptions = array();

		$table_name = self::DETAIL_TABLE_NAME;
		$sql = <<<SQL
CREATE $this->sql_comment TABLE $table_name (
userid INT(10) UNSIGNED NOT NULL DEFAULT '0',
rsid VARCHAR(40) NOT NULL DEFAULT '',
ecc_id INT(11) NOT NULL DEFAULT '0',
customer_id BIGINT(20) NOT NULL DEFAULT '0',
customer_name VARCHAR(105) NOT NULL DEFAULT '',
company_id INT(10) UNSIGNED NOT NULL DEFAULT '0',
company_name VARCHAR(50) NOT NULL DEFAULT '',
vh_type ENUM('MySQL','HBase-MySQL','HBase-Tran','HBase','HBase-HBase','Handler Unknown') NOT NULL DEFAULT 'MySQL',
enabled_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
hbase_only_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
cluster_ids VARCHAR(8) NOT NULL DEFAULT '',
hits BIGINT(20) UNSIGNED NOT NULL DEFAULT '0',
mysql_bytes BIGINT(20) UNSIGNED NOT NULL DEFAULT '0',
mysql_bytes_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
on_blacklist TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
on_mobile_delay TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
is_priority_rs TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
is_vip_comp TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
is_strategic_cust TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
is_mobile TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
is_rollup TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
in_purge_queue TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
traffic_type TINYINT(3) UNSIGNED NOT NULL DEFAULT '0',
schedule_tag VARCHAR(15) NOT NULL DEFAULT '',
plan_begin_date DATE NOT NULL DEFAULT '0000-00-00',
plan_finish_date DATE NOT NULL DEFAULT '0000-00-00',
first_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
last_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
last_batch_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
PRIMARY KEY (userid),
KEY (rsid),
KEY (customer_id),
KEY (company_id),
KEY (hbase_only_ts),
KEY (last_update_ts),
KEY (last_batch_ts)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
SQL;
		if (!$this->run_query($sql)) {
			if ($this->cmdb->Errno == 1050) {
				$exceptions[] = "Could not create table because table $table_name already exists";
				if (BERT_RET_SUCCESS == $exception_code) $exception_code = BERT_TABLE_ALREADY_EXISTS;
			} else {
				$exceptions[] = "Could not create table: DB_Error={$this->cmdb->Error}  SQL=$sql";
				$exception_code = BERT_DATABASE_ACCESS_ERROR;
			}
		}

		$table_name = self::SCHEDULE_TABLE_NAME;
		$sql = <<<SQL
CREATE $this->sql_comment TABLE $table_name (
schedule_tag VARCHAR(15) NOT NULL DEFAULT '',
begin_date DATE NOT NULL DEFAULT '0000-00-00',
finish_date DATE NOT NULL DEFAULT '0000-00-00',
last_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
PRIMARY KEY (schedule_tag)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
SQL;
		if (!$this->run_query($sql)) {
			if ($this->cmdb->Errno == 1050) {
				$exceptions[] = "Could not create table because table $table_name already exists";
				if (BERT_RET_SUCCESS == $exception_code) $exception_code = BERT_TABLE_ALREADY_EXISTS;
			} else {
				$exceptions[] = "Could not create table: DB_Error={$this->cmdb->Error}  SQL=$sql";
				$exception_code = BERT_DATABASE_ACCESS_ERROR;
			}
		}

		$table_name = self::COMPANY_PLAN_TABLE_NAME;
		$sql = <<<SQL
CREATE $this->sql_comment TABLE $table_name (
company_id INT(10) UNSIGNED NOT NULL DEFAULT '0',
schedule_tag VARCHAR(15) NOT NULL DEFAULT '',
is_vip TINYINT(1) UNSIGNED NOT NULL DEFAULT '0',
company_name VARCHAR(50) NOT NULL DEFAULT '',
first_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
last_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
PRIMARY KEY (company_id),
KEY (schedule_tag),
KEY (last_update_ts)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
SQL;
		if (!$this->run_query($sql)) {
			if ($this->cmdb->Errno == 1050) {
				$exceptions[] = "Could not create table because table $table_name already exists";
				if (BERT_RET_SUCCESS == $exception_code) $exception_code = BERT_TABLE_ALREADY_EXISTS;
			} else {
				$exceptions[] = "Could not create table: DB_Error={$this->cmdb->Error}  SQL=$sql";
				$exception_code = BERT_DATABASE_ACCESS_ERROR;
			}
		}

		$table_name = self::MOBILE_PLAN_TABLE_NAME;
		$sql = <<<SQL
CREATE $this->sql_comment TABLE $table_name (
mobile_rsid VARCHAR(40) NOT NULL DEFAULT '',
enable_date DATE NOT NULL DEFAULT '0000-00-00',
first_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
last_update_ts TIMESTAMP NOT NULL DEFAULT '0000-00-00 00:00:00',
PRIMARY KEY (mobile_rsid),
KEY (last_update_ts)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
SQL;
		if (!$this->run_query($sql)) {
			if ($this->cmdb->Errno == 1050) {
				$exceptions[] = "Could not create table because table $table_name already exists";
				if (BERT_RET_SUCCESS == $exception_code) $exception_code = BERT_TABLE_ALREADY_EXISTS;
			} else {
				$exceptions[] = "Could not create table: DB_Error={$this->cmdb->Error}  SQL=$sql";
				$exception_code = BERT_DATABASE_ACCESS_ERROR;
			}
		}

		if (BERT_RET_SUCCESS != $exception_code) {
			throw new Exception(implode(';', $exceptions), $exception_code);
		}
	}

	/**
	 * Invalidates the cached entry from the last find
	 */
	private function invalidateLastFind() {
		$this->last_find = array();
	}

	/** 
	 * Returns the first entry found in the detail table
	 *  
	 * @param string $where - Where clause to use to find a matching entry
	 * @return array - First entry found matching the where clause
	 */
	private function findEntry($where) {
		$entry = array();
		$sql = "SELECT $this->sql_comment * FROM ".self::DETAIL_TABLE_NAME." WHERE $where";
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			if ($this->cmdb->next_record()) {
				$entry['userid'] = $this->cmdb->f('userid');
				$entry['rsid'] = $this->cmdb->f('rsid');
				$entry['ecc_id'] = $this->cmdb->f('ecc_id');
				$entry['customer_id'] = $this->cmdb->f('customer_id');
				$entry['customer_name'] = $this->cmdb->f('customer_name');
				$entry['company_id'] = $this->cmdb->f('company_id');
				$entry['company_name'] = $this->cmdb->f('company_name');
				$entry['vh_type'] = $this->cmdb->f('vh_type');
				$entry['enabled_ts'] = $this->cmdb->f('enabled_ts');
				$entry['hbase_only_ts'] = $this->cmdb->f('hbase_only_ts');
				$entry['cluster_ids'] = $this->cmdb->f('cluster_ids');
				$entry['hits'] = $this->cmdb->f('hits');
				$entry['mysql_bytes'] = $this->cmdb->f('mysql_bytes');
				$entry['mysql_bytes_ts'] = $this->cmdb->f('mysql_bytes_ts');
				$entry['on_blacklist'] = $this->cmdb->f('on_blacklist');
				$entry['on_mobile_delay'] = $this->cmdb->f('on_mobile_delay');
				$entry['is_priority_rs'] = $this->cmdb->f('is_priority_rs');
				$entry['is_vip_comp'] = $this->cmdb->f('is_vip_comp');
				$entry['is_strategic_cust'] = $this->cmdb->f('is_strategic_cust');
				$entry['is_mobile'] = $this->cmdb->f('is_mobile');
				$entry['is_rollup'] = $this->cmdb->f('is_rollup');
				$entry['in_purge_queue'] = $this->cmdb->f('in_purge_queue');
				$entry['traffic_type'] = $this->cmdb->f('traffic_type');
				$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
				$entry['plan_begin_date'] = $this->cmdb->f('plan_begin_date');
				$entry['plan_finish_date'] = $this->cmdb->f('plan_finish_date');
				$entry['first_update_ts'] = $this->cmdb->f('first_update_ts');
				$entry['last_update_ts'] = $this->cmdb->f('last_update_ts');
				$entry['last_batch_ts'] = $this->cmdb->f('last_batch_ts');
				$this->last_find = $entry;
			}
		}
		return $entry;
	}

	/**
	 * Returns the requested entry from the detail table
	 * 
	 * @param string $rsid - The report suite rsid matching the entry to return
	 * @return array - Requested entry from the detail table
	 */
	public function findEntryByRsid($rsid) {
		$entry = $this->last_find;
		if (!$entry || $entry['rsid'] != $rsid) {
			$entry = $this->findEntry("rsid = '$rsid'");
		}
		return $entry;
	}

	/**
	 * Returns the requested entry from the detail table
	 * 
	 * @param integer $userid - The report suite userid matching the entry to return
	 * @return array - Requested entry from the detail table
	 */
	public function findEntryByUserid($userid) {
		$entry = $this->last_find;
		if (!$entry || $entry['userid'] != $userid) {
			$entry = $this->findEntry("userid = '$userid'");
		}
		return $entry;
	}

	/**
	 * Returns the where clause that selects entries from the detail table based on the specified selectors
	 * 
	 * @param string or array $selectors - Selectors for which to generate the where clause
	 * @return string - Generated where clause
	 */
	private function detailSelectorWhereClause($selectors='') {
		$ret_where = '';
		$selectors = array_unique((array) $selectors);
		if ($selectors) {
			$separator = '';
			foreach ($selectors as $selector) {
				if ('' !== $selector) {
					switch ($selector) {
						case self::SELECT_BLACKLIST:
							$ret_where .= $separator.'on_blacklist=1';
							break;

						case self::SELECT_MOBILE:
							$ret_where .= $separator.'is_mobile=1';
							break;

						case self::SELECT_MOBILE_DELAY:
							$ret_where .= $separator.'on_mobile_delay=1';
							break;

						case self::SELECT_ROLLUP:
							$ret_where .= $separator.'is_rollup=1';
							break;

						case self::SELECT_VIP_COMPANY:
							$ret_where .= $separator.'is_vip_comp=1';
							break;

						case self::SELECT_STRATEGIC_CUSTOMER:
							$ret_where .= $separator.'is_strategic_cust=1';
							break;

						case self::SELECT_PRIORITY:
							$ret_where .= $separator.'is_priority_rs=1';
							break;

						case self::SELECT_PURGE_QUEUE:
							$ret_where .= $separator.'in_purge_queue=1';
							break;

						case self::SELECT_ENABLE_PAST_DUE:
							$ret_where .= $separator.'('
								."enabled_ts='0000-00-00 00:00:00'"
								.' AND ('
									.'('
										.'is_mobile<>1'
										." AND plan_finish_date >= '".self::MIN_TRANSITION_DATE."'"
										." AND plan_finish_date < '".date(MYSQL_DATE_FORMAT)."'"
									.') OR ('
										.'is_mobile=1'
										." AND plan_begin_date >= '".self::MIN_TRANSITION_DATE."'"
										." AND plan_begin_date < '".date(MYSQL_DATE_FORMAT)."'"
									.')'
								.'))';
							break;

						case self::SELECT_ENABLE_READY:
							$ret_where .= $separator.'('
								.'on_blacklist<>1'
								.' AND on_mobile_delay<>1'
								.' AND in_purge_queue<>1'
								." AND enabled_ts='0000-00-00 00:00:00'"
								." AND plan_begin_date >= '".self::MIN_TRANSITION_DATE."'"
								." AND plan_begin_date <= '".date(MYSQL_DATE_FORMAT)."'"
								.')';
							break;

						case self::SELECT_TRANSFER_READY:
							$ret_where .= $separator.'('
								.'on_blacklist<>1'
								.' AND on_mobile_delay<>1'
								.' AND in_purge_queue<>1'
								." AND vh_type='".self::HBASE_AND_MYSQL."'"
								." AND enabled_ts <> '0000-00-00 00:00:00'"
								.' AND enabled_ts < NOW() - INTERVAL '. $this->min_days_enabled_to_transfer . ' DAY'
								.')';
							break;

						case self::SELECT_ACTIVE:
							$ret_where .= $separator.'hits<>0';
							break;

						case self::SELECT_NOT_ACTIVE:
							$ret_where .= $separator.'hits=0';
							break;

						case self::SELECT_NO_PLAN:
							$ret_where .= $separator."schedule_tag=''";
							break;

						case self::SELECT_NOT_ENABLED:
							$ret_where .= $separator."enabled_ts='0000-00-00 00:00:00'";
							break;

						case self::SELECT_ENABLED:
							$ret_where .= $separator."enabled_ts<>'0000-00-00 00:00:00'";
							break;

						case self::SELECT_TRANSFERRED:
							$ret_where .= $separator."hbase_only_ts<>'0000-00-00 00:00:00'";
							break;

						case self::SELECT_BEING_TRANSFERRED:
							$ret_where .= $separator."vh_type='".self::HBASE_DOING_TRANSFER."'";
							break;

						default:
							throw new Exception("Invalid selector ($selector) specified in ".__METHOD__);

					}
					$separator = ' AND ';
				}
			}
		}
		return $ret_where;
	}

	/**
	 * Returns the requested entries from the detail table
	 * 
	 * @param array $rsids - List of rsids or rsid patterns for which to return detail
	 * @param boolean $include_all_details - If true, return all information in the entry otherwise just key information
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @return array - Requested entries from the detail table
	 */
	public function getMatchingEntriesByRsid($rsids, $include_all_details=false, $selectors='') {
		$all_entries = array();
		$all_rsids = array();
		$all_patterns = array();

		// Separate all entries with wildcards
		foreach ($rsids as $rsid) {
			if (false === strpos($rsid, '%')) {
				$all_rsids[] = $rsid;
			} else {
				$all_patterns[] = $rsid;
			}
		}

		// Build the SQL statement
		$sql = "SELECT $this->sql_comment * FROM ".self::DETAIL_TABLE_NAME;
		$sql_separator = ' WHERE ';

		$selector_where_clause = $this->detailSelectorWhereClause($selectors);
		if ($selector_where_clause) {
			$sql .= $sql_separator.'('.$selector_where_clause.')';
			$sql_separator = ' AND ';
		}

		// Find entries that match the rsids in the list
		$sql_begin = '(';
		$sql_end = '';
		if ($all_rsids) {
			$sql .= $sql_separator.$sql_begin."rsid in ('".implode("','", $all_rsids)."')";
			$sql_separator = ' OR ';
			$sql_begin = '';
			$sql_end = ')';
		}

		// Find entries that match any rsid patterns in the list
		foreach ($all_patterns as $pattern) {
			$sql .= $sql_separator.$sql_begin."rsid like '$pattern'";
			$sql_separator = ' OR ';
			$sql_begin = '';
			$sql_end = ')';
		}

		$sql .= $sql_end." ORDER BY rsid";
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['userid'] = $this->cmdb->f('userid');
				$entry['rsid'] = $this->cmdb->f('rsid');
				$entry['vh_type'] = $this->cmdb->f('vh_type');
				$entry['on_blacklist'] = $this->cmdb->f('on_blacklist');
				$entry['on_mobile_delay'] = $this->cmdb->f('on_mobile_delay');
				$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
				$entry['last_update_ts'] = $this->cmdb->f('last_update_ts');
				$entry['last_batch_ts'] = $this->cmdb->f('last_batch_ts');
				if ($include_all_details) {
					$entry['ecc_id'] = $this->cmdb->f('ecc_id');
					$entry['customer_id'] = $this->cmdb->f('customer_id');
					$entry['customer_name'] = $this->cmdb->f('customer_name');
					$entry['company_id'] = $this->cmdb->f('company_id');
					$entry['company_name'] = $this->cmdb->f('company_name');
					$entry['enabled_ts'] = $this->cmdb->f('enabled_ts');
					$entry['hbase_only_ts'] = $this->cmdb->f('hbase_only_ts');
					$entry['cluster_ids'] = $this->cmdb->f('cluster_ids');
					$entry['hits'] = $this->cmdb->f('hits');
					$entry['mysql_bytes'] = $this->cmdb->f('mysql_bytes');
					$entry['mysql_bytes_ts'] = $this->cmdb->f('mysql_bytes_ts');
					$entry['is_priority_rs'] = $this->cmdb->f('is_priority_rs');
					$entry['is_vip_comp'] = $this->cmdb->f('is_vip_comp');
					$entry['is_strategic_cust'] = $this->cmdb->f('is_strategic_cust');
					$entry['is_mobile'] = $this->cmdb->f('is_mobile');
					$entry['is_rollup'] = $this->cmdb->f('is_rollup');
					$entry['in_purge_queue'] = $this->cmdb->f('in_purge_queue');
					$entry['traffic_type'] = $this->cmdb->f('traffic_type');
					$entry['plan_begin_date'] = $this->cmdb->f('plan_begin_date');
					$entry['plan_finish_date'] = $this->cmdb->f('plan_finish_date');
					$entry['first_update_ts'] = $this->cmdb->f('first_update_ts');
					
				}
				$all_entries[$entry['rsid']] = $entry;
			}
			$this->cmdb->free();
		}
		return $all_entries;
	}

	/**
	 * Returns rsids from the specified list (or all rsids if empty list) that are on the blacklist
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids that are on the blacklist
	 */
	public function filterKeepBlacklisted(array $rsid_list = array()) {
		// return all Blacklist rsids if rsid_list is empty
		$blacklist_rsids = array();
		$rsid_sql = $rsid_list ? "AND rsid IN ('".implode("','", $rsid_list)."')" : '';

		// Get the blacklist info
		$table_name = self::BLACKLIST_TABLE_NAME;

		$sql = <<<SQL
SELECT $this->sql_comment
	rsid
FROM $table_name
WHERE deleted_date='0000-00-00'
	$rsid_sql
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$blacklist_rsids[] = $this->cmdb->f('rsid');
			}
			$this->cmdb->free();
		} else if ($this->cmdb->Errno) {
			throw new Exception("Error getting vcookie_cluster_black_list info. (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		return $blacklist_rsids;
	}

	/**
	 * Returns rsids from the specified list (or all rsids if empty list) that are managed mobile report suites but are not yet ready to enable
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids that are managed mobile report suites but are not yet ready to enable
	 */
	public function filterKeepMobileNotReady(array $rsid_list = array()) {
		// return all not ready mobile rsids if rsid_list is empty
		$mobile_not_ready_rsids = array();
		$rsid_sql = $rsid_list ? "AND mobile_rsid IN ('".implode("','", $rsid_list)."')" : '';

		$table_name = self::MOBILE_PLAN_TABLE_NAME;
		$min_transition_date = self::MIN_TRANSITION_DATE;
		$today = date(MYSQL_DATE_ONLY_FORMAT);

		$sql = <<<SQL
SELECT $this->sql_comment
	mobile_rsid
FROM $table_name
WHERE ((enable_date < '$min_transition_date')
 	OR (enable_date > '$today'))
 	$rsid_sql
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$mobile_not_ready_rsids[] = $this->cmdb->f('mobile_rsid');
			}
			$this->cmdb->free();
		} else if ($this->cmdb->Errno) {
			throw new Exception("Error getting mobile enable date info. (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		return $mobile_not_ready_rsids;
	}

	/**
	 * Returns hit and mysql_bytes information for rsids from the specified list (or all rsids if none specified)
	 * that match the specified selectors
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids in the detail table)
	 * @param string or array $selectors - Selectors to use as the filter (no selector returns all rsids)
	 * @return array - rsids that match the selectors
	 */
	public function getStaticTableLimitedDetails(array $rsid_list = array(), $selectors = '') {
		// return all matching rsids if rsid_list is empty
		$ret_rsids = array();
		$where_clause = '';
		$separator = 'WHERE ';
		$selector_sql = $this->detailSelectorWhereClause((array) $selectors);
		if ($selector_sql) {
			$where_clause .= $separator."$selector_sql";
			$separator = ' AND ';
		}
		if ($rsid_list) {
			$where_clause .= $separator."rsid IN ('".implode("','", $rsid_list)."')";
			$separator = ' AND ';
		}
		$table_name = self::DETAIL_TABLE_NAME;

		$sql = <<<SQL
SELECT $this->sql_comment
	rsid
	,hits
	,mysql_bytes
FROM $table_name
$where_clause
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['rsid'] = $this->cmdb->f('rsid');
				$entry['hits'] = $this->cmdb->f('hits');
				$entry['mysql_bytes'] = $this->cmdb->f('mysql_bytes');
				$ret_rsids[$entry['rsid']] = $entry;
			}
			$this->cmdb->free();
		} else if ($this->cmdb->Errno) {
			throw new Exception("Error getting filtered information from detail table. (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_rsids;
	}

	/**
	 * Returns rsids from the specified list (or all rsids if none specified) matching the specified selectors
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids matching the specified selectors
	 */
	public function filterKeepUsingStaticTableDetails(array $rsid_list = array(), $selectors = array()) {
		return array_keys($this->getStaticTableLimitedDetails($rsid_list, (array) $selectors));
	}

	/**
	 * Returns rsids from the specified list (or all rsids if none specified) that are managed mobile report suites that
	 * could be ready to enable based on the static data in the detail table
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids that are managed mobile report suites that could be ready to enable
	 */
	public function filterKeepUsingStaticTableMobileEnableReady(array $rsid_list = array()) {
		return $this->filterKeepUsingStaticTableDetails($rsid_list, array(self::SELECT_MOBILE, self::SELECT_ENABLE_READY));
	}

	/**
	 * Returns rsids from the specified list (or all rsids if none specified) that
	 * could be ready to enable based on the static data in the detail table
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids that could be ready to enable
	 */
	public function filterKeepUsingStaticTableEnableReady(array $rsid_list = array()) {
		return $this->filterKeepUsingStaticTableDetails($rsid_list, self::SELECT_ENABLE_READY);
	}

	/**
	 * Returns rsids from the specified list (or all rsids if none specified) that
	 * could be ready to transfer based on the static data in the detail table
	 * 
	 * @param array $rsids - List of rsids to filter (empty list means all rsids)
	 * @return array - rsids that could be ready to transfer
	 */
	public function filterKeepUsingStaticTableTransferReady(array $rsid_list = array()) {
		return $this->filterKeepUsingStaticTableDetails($rsid_list, self::SELECT_TRANSFER_READY);
	}

	/**
	 * Returns structure showing which of the specified rsids can be transitioned to vcookie cluster
	 * 
	 * @param array $rsids - List of rsids to check on availability
	 * @param array $ignore_test - List of tests to ignore from the acceptable list
	 * @param array $max_available_rsids - Maximum number of available rsids to return (0 means all)
	 * @return array - structure detailing which rsids can be enabled and the reason for any that can't
	 */
	public function getEnableAvailability(array $rsid_list, array $ignore_test = array(), $max_available_rsids=0) {
		// This function may pass on a thrown exception from filterKeepBlacklisted() or filterKeepMobileNotReady()
		static $valid_ignore = array(self::FILTER_MIGRATING, self::FILTER_NOT_SCHEDULE_READY, self::FILTER_ROLLUP, self::FILTER_IN_PURGE_QUEUE);

		$rtn_rsids = array();
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['description'] = "These rsids are in the blacklist";
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_MOBILE_NOT_READY]['description'] = "These mobile or custom timestamped rsids are not yet ready to be enabled";
		$rtn_rsids['remove'][self::FILTER_MOBILE_NOT_READY]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['description'] = "Unable to get user_account information";
		$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['description'] = "These rsids are not yet scheduled to be enabled";
		$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_ALREADY_ENABLED]['description'] = "These rsids are already enabled";
		$rtn_rsids['remove'][self::FILTER_ALREADY_ENABLED]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_CYGNUS]['description'] = "These rsids are cygnus rsids";
		$rtn_rsids['remove'][self::FILTER_CYGNUS]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_ROLLUP]['description'] = "These rsids are rollup rsids";
		$rtn_rsids['remove'][self::FILTER_ROLLUP]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_MIGRATING]['description'] = "These rsids are migrating";
		$rtn_rsids['remove'][self::FILTER_MIGRATING]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['description'] = "These rsids are in the data retention purge queue";
		$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['rsids'] = array();
		$rtn_rsids['keep']['available']['description'] = "These rsids are available to be enabled";
		$rtn_rsids['keep']['available']['rsids'] = array();
		
		if ($this->allow_auto_enable_rollups) { // Ignore the rollup test if rollups are allowed to be automatically enabled
			$ignore_test = array_unique(array_merge($ignore_test, array(self::FILTER_ROLLUP)));
		}

		foreach ($ignore_test as $test) {
			if (in_array($test, $valid_ignore)) {
				$rtn_rsids['remove'][$test]['description'] = "$test is not being checked";
			}
		}

		if (!$rsid_list) { // No reason to continue if there aren't any rsids to check
			return $rtn_rsids;
		}

		// Get the available schedule tags
		$available_tags = array();
		$today = strtotime(date('Y-m-d', time()));
		foreach($this->getAllSchedules() as $entry) {
			if (strtotime($entry['begin_date']) > 0 && strtotime($entry['begin_date']) <= $today) {
				$available_tags[] = $entry['schedule_tag'];
			}
		}

		// Check blacklist
		$blacklist_rsids = $this->filterKeepBlacklisted($rsid_list);
		$rsid_list = array_diff($rsid_list, $blacklist_rsids);
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['rsids'] = $blacklist_rsids;

		// Check mobile not ready
		$mobile_not_ready_rsids = $this->filterKeepMobileNotReady($rsid_list);
		$rsid_list = array_diff($rsid_list, $mobile_not_ready_rsids);
		$rtn_rsids['remove'][self::FILTER_MOBILE_NOT_READY]['rsids'] = $mobile_not_ready_rsids;

		$dm = new DataMigration();
		$cnt_available_rsids = 0;
		foreach ($rsid_list as $rsid) {
			if ($max_available_rsids && ($cnt_available_rsids >= $max_available_rsids)) {
				break;
			}
			$rsc = new ReportSuiteConfig($rsid);
			if ($rsc->error_str != '') {
				$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['rsids'][] = $rsid;
				continue;  // Could not get account information
			}

			// Make sure it is not rollup or cyg.
			if (substr($rsid, 0, 4) == 'cyg.') {
				$rtn_rsids['remove'][self::FILTER_CYGNUS]['rsids'][] = $rsid;
				continue;  // Do not enable cygnus accounts
			}

			if (!in_array(self::FILTER_ROLLUP, $ignore_test) && $rsc->is_rollup_user()) {
				$rtn_rsids['remove'][self::FILTER_ROLLUP]['rsids'][] = $rsid;
				continue;  // Do not enable rollup users
			}

			// Make sure it is not already enabled
			if ($rsc->has_hbase_vcookie_handler()) {
				$rtn_rsids['remove'][self::FILTER_ALREADY_ENABLED]['rsids'][] = $rsid;
				continue;  // This rsid is already enabled
			}

			// Check the schedule time
			if ($this->isMobileRsidWithCheck($rsc)) { // For mobile rsids begin date is handled by mobile plans table not by company plans table
				if (!$this->isScheduleReadyByMobileRsid($rsid)) {
					$rtn_rsids['remove'][self::FILTER_MOBILE_NOT_READY]['rsids'][] = $rsid;
					continue;  // Scheduled begin date has not yet arrived for this rsid
				}
			} else {
				if (!in_array(self::FILTER_NOT_SCHEDULE_READY, $ignore_test)) {
					$company_id = $rsc->get_companyid();
					$tag = $this->getScheduleTagByCompanyId($company_id);
					if (!in_array($tag, $available_tags)) {
						$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['rsids'][] = $rsid;
						continue;  // Scheduled begin date has not yet arrived for this rsid
					}
				}
			}

			// Check Data Migration
			if (!in_array(self::FILTER_MIGRATING, $ignore_test) && $dm->isMigrating($rsid)) {
				$rtn_rsids['remove'][self::FILTER_MIGRATING]['rsids'][] = $rsid;
				continue; // This rsid is being migrated
			}

			// Check data retention purge queue
			if (!in_array(self::FILTER_IN_PURGE_QUEUE, $ignore_test) && $this->isInPurgeQueue($rsid)) {
				$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['rsids'][] = $rsid;
				continue; // This rsid is in the data retention purge queue
			}

			$rtn_rsids['keep']['available']['rsids'][] = $rsid;
			$cnt_available_rsids++;
		}

		return $rtn_rsids;
	}

	/**
	 * Returns rsids that can be transitioned to vcookie cluster
	 * 
	 * @param array $rsids - List of rsids to check for availability
	 * @param array $ignore_test - List of tests to ignore from the acceptable list
	 * @return array - structure detailing which rsids can be enabled and the reason for any that can't
	 */
	public function filterKeepAvailableToEnable(array $rsid_list, array $ignore_test = array()) {
		$details = $this->getEnableAvailability($rsid_list, $ignore_test);
		return $details['keep']['available']['rsids'];
	}


	/**
	 * Returns structure showing which of the specified rsids can have data transferred from MySQL to the vccluster
	 * 
	 * @param array $rsids - List of rsids to check on availability
	 * @param array $ignore_test - List of tests to ignore from the acceptable list
	 * @return array - structure detailing which rsids can be transferred and the reason for any that can't
	 */
	public function getTransferAvailability(array $rsid_list, array $ignore_test = array(), $max_available_rsids=0) {
		// This function may pass on a thrown exception from filterKeepBlacklisted()
		static $valid_ignore = array(self::FILTER_MIGRATING, self::FILTER_NOT_SCHEDULE_READY, self::FILTER_IN_PURGE_QUEUE);

		$rtn_rsids = array();
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['description'] = "These rsids are in the blacklist";
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['description'] = "Unable to get user_account information";
		$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_ALREADY_TRANSFERRED]['description'] = "These rsids are already transferred";
		$rtn_rsids['remove'][self::FILTER_ALREADY_TRANSFERRED]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_BEING_TRANSFERRED]['description'] = "These rsids are currently being transferred";
		$rtn_rsids['remove'][self::FILTER_BEING_TRANSFERRED]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_NOT_ENABLED]['description'] = "These rsids have not yet been enabled";
		$rtn_rsids['remove'][self::FILTER_NOT_ENABLED]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_INCORRECT_HANDLERS]['description'] = "These rsids are not set up with 1 HBase and 1 MySQL handler";
		$rtn_rsids['remove'][self::FILTER_INCORRECT_HANDLERS]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['description'] = "These rsids have not yet been enabled long enough";
		$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_MIGRATING]['description'] = "These rsids are migrating";
		$rtn_rsids['remove'][self::FILTER_MIGRATING]['rsids'] = array();
		$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['description'] = "These rsids are in the data retention purge queue";
		$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['rsids'] = array();
		$rtn_rsids['keep']['available']['description'] = "These rsids are available to be transferred";
		$rtn_rsids['keep']['available']['rsids'] = array();
		
		foreach ($ignore_test as $test) {
			if (in_array($test, $valid_ignore)) {
				$rtn_rsids['remove'][$test]['description'] = "$test is not being checked";
			}
		}

		if (!$rsid_list) { // No reason to continue if there aren't any rsids to check
			return $rtn_rsids;
		}

		// Check blacklist
		$blacklist_rsids = $this->filterKeepBlacklisted($rsid_list);
		$rsid_list = array_diff($rsid_list, $blacklist_rsids);
		$rtn_rsids['remove'][self::FILTER_BLACKLIST]['rsids'] = $blacklist_rsids;

		$dm = new DataMigration();
		$cnt_available_rsids = 0;
		foreach ($rsid_list as $rsid) {
			if ($max_available_rsids && ($cnt_available_rsids >= $max_available_rsids)) {
				break;
			}
			$rsc = new ReportSuiteConfig($rsid);
			if ($rsc->error_str != '') {
				$rtn_rsids['remove'][self::FILTER_ACCOUNT_UNAVAILABLE]['rsids'][] = $rsid;
				continue;  // Could not get account information
			}

			// Make sure it is not already transferred
			$state = $this->getTransitionState($rsc);
			if (self::HBASE_ONLY == $state || self::MULTI_HBASE_ONLY == $state) {
				$rtn_rsids['remove'][self::FILTER_ALREADY_TRANSFERRED]['rsids'][] = $rsid;
				continue;  // This rsid is already transferred
			}

			if (self::HBASE_DOING_TRANSFER == $state) {
				$rtn_rsids['remove'][self::FILTER_BEING_TRANSFERRED]['rsids'][] = $rsid;
				continue;  // This rsid is currently being transferred
			}

			if (self::HBASE_AND_MYSQL != $state) {
				$rtn_rsids['remove'][self::FILTER_NOT_ENABLED]['rsids'][] = $rsid;
				continue;  // This rsid is not yet enabled
			}

			if (!in_array(self::FILTER_INCORRECT_HANDLERS, $ignore_test) && self::VALID_TRANSFER_HANDLE != $rsc->get_short_vcookie_handler_info()) {
				$rtn_rsids['remove'][self::FILTER_INCORRECT_HANDLERS]['rsids'][] = $rsid;
				continue;  // This rsid does not have the correct handler configuration
			}

			// Check the schedule time
			if (!in_array(self::FILTER_NOT_SCHEDULE_READY, $ignore_test)) {
				if (!$this->isScheduleReadyForTransfer($rsc)) {
					$rtn_rsids['remove'][self::FILTER_NOT_SCHEDULE_READY]['rsids'][] = $rsid;
					continue;  // Waiting period between being enabled and being transferred has not passed
				}
			}

			// Check Data Migration
			if (!in_array(self::FILTER_MIGRATING, $ignore_test) && $dm->isMigrating($rsid)) {
				$rtn_rsids['remove'][self::FILTER_MIGRATING]['rsids'][] = $rsid;
				continue; // This rsid is being migrated
			}

			// Check data retention purge queue
			if (!in_array(self::FILTER_IN_PURGE_QUEUE, $ignore_test) && $this->isInPurgeQueue($rsid)) {
				$rtn_rsids['remove'][self::FILTER_IN_PURGE_QUEUE]['rsids'][] = $rsid;
				continue; // This rsid is in the data retention purge queue
			}

			$rtn_rsids['keep']['available']['rsids'][] = $rsid;
			$cnt_available_rsids++;
		}

		return $rtn_rsids;
	}

	/**
	 * Returns rsids that can be transitioned to vcookie cluster
	 * 
	 * @param array $rsids - List of rsids to check for availability
	 * @param array $ignore_test - List of tests to ignore from the acceptable list
	 * @return array - structure detailing which rsids can be enabled and the reason for any that can't
	 */
	public function filterKeepAvailableToTransfer(array $rsid_list, array $ignore_test = array()) {
		$details = $this->getTransferAvailability($rsid_list, $ignore_test);
		return $details['keep']['available']['rsids'];
	}

	/**
	 * Returns transition state for a specified report suite
	 * 
	 * @param string $rsid - Rsid for which to get the transition state
	 * @throws Exception - Could not get report suite information
	 * @return string - Transition state for the report suite
	 */
	public function getTransitionStateByRsid($rsid) {
		$rsc = new ReportSuiteConfig($rsid);
		if ('' != $rsc->error_str) {
			throw new Exception("Could not get information for report suite $rsid (Error={$rsc->error_str})");
		}
		return $this->getTransitionState($rsc);
	}

	/**
	 * Returns transition state for the report suite associated with the specified ReportSuiteConfig object 
	 * 
	 * @param ReportSuiteConfig $rsc - Object with report suite for which to get the transition state
	 * @throws Exception - Could not get report suite information
	 * @return string - Transition state for the report suite
	 */
	public function getTransitionState(ReportSuiteConfig $rsc) {
		if ($rsc->has_hbase_vcookie_handler()) {
			$vctransfer = new VCookieTransfer();
			if ($rsc->has_mysql_vcookie_handler()) {
				return $vctransfer->isDumpTruckRunning($rsc->get_rsid()) ? VcClusterTransition::HBASE_DOING_TRANSFER : VcClusterTransition::HBASE_AND_MYSQL;
			} else {
				try {
					if ($vctransfer->isDumpTruckComplete($rsc->get_rsid())) {
						if ($rsc->has_multiple_hbase_vcookie_handlers()) {
							return VcClusterTransition::MULTI_HBASE_ONLY;
						} else {
							return VcClusterTransition::HBASE_ONLY;
						}
					} else {
						return VcClusterTransition::HBASE_DOING_TRANSFER;
					}
				} catch (Exception $e) {
					return VcClusterTransition::HANDLER_UNKNOWN;
				}
			}
		}
		return VcClusterTransition::MYSQL_ONLY;
	}

	/**
	 * Updates transtition state for a rsid in the detail table
	 * 
	 * @param array $rsid - Report suite transition information to update
	 * @throws Exception
	 * 		- Error updating or reading from the detail table
	 * 		- Invalid rsid
	 */
	public function updateTransitionState($rsid) {
		$this->invalidateLastFind();
		$table_name = self::DETAIL_TABLE_NAME;
		$last_update_ts = ($this->current_batch) ? $this->current_batch : date(MYSQL_DATE_FORMAT);

		// Set the vh_info, hbase_only_ts and enabled_ts timestamps as needed if not already set
		$hbase_only_ts = '';
		$enabled_ts = '';
		$vh_type = $this->getTransitionStateByRsid($rsid); // Throws exception if the rsid is not valid
		switch ($vh_type) {
			case self::HBASE_ONLY:
			case self::MULTI_HBASE_ONLY:
				$hbase_only_ts = $last_update_ts;
				// Drop through to set enabled_ts as well
				
			case self::HBASE_AND_MYSQL:
			case self::HBASE_DOING_TRANSFER:
				$enabled_ts = $last_update_ts;
				break;
		}
		if ($enabled_ts || $hbase_only_ts) {
			// Preserve the timestamp for becoming HBase only or being enabled if already set, otherwise set it to this run
			$sql = <<<SQL
SELECT $this->sql_comment
	enabled_ts
	,hbase_only_ts
FROM $table_name
WHERE rsid='$rsid'
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				if ($this->cmdb->next_record()) {
					if ($enabled_ts && ('0000-00-00 00:00:00' != $this->cmdb->f('enabled_ts'))) {
						$enabled_ts = $this->cmdb->f('enabled_ts');
					}
					if ($hbase_only_ts && ('0000-00-00 00:00:00' != $this->cmdb->f('hbase_only_ts'))) {
						$hbase_only_ts = $this->cmdb->f('hbase_only_ts');
					}
				}
			} else {
				throw new Exception("Error updating transition state for report suite $rsid. (DB_Error={$this->cmdb->Error} SQL=$sql)");
			}
		}

		$batch_sql = ($this->current_batch) ? ",last_batch_ts='$this->current_batch'" : '';
		if ($this->verbose) {
			echo "Updating transition state for $rsid as of $last_update_ts\n";
			echo ($this->current_batch) ? "last_batch_ts='{$this->current_batch}'\n" : '';
			echo "vh_type=$vh_type\n";
			echo ($enabled_ts) ? "enabled_ts=$enabled_ts\n" : '';
			echo ($hbase_only_ts) ? "hbase_only_ts=$hbase_only_ts\n" : '';
		}
		
		$sql = <<<SQL
UPDATE $this->sql_comment
	$table_name
SET
	vh_type='$vh_type'
	,enabled_ts='$enabled_ts'
	,hbase_only_ts='$hbase_only_ts'
	,last_update_ts='$last_update_ts'
	$batch_sql
WHERE
	rsid='$rsid'
SQL;
		if (!$this->run_query($sql, 0, MYSQL_ASSOC)) {
			//ToDO - Should an rsid that doesn't exist in the detail table NOT throw an error?
			if ($this->verbose) {
				echo "Error updating transition state for report suite $rsid. (DB_Error={$this->cmdb->Error} SQL=$sql)";
			}
			throw new Exception("Error updating transition state for report suite $rsid. (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
	}

	/**
	 * Returns whether or not the specified traffic type is one that can only be enabled using a mobile plan
	 * 
	 * @param integer $traffic_type - Traffic type from the user_services table
	 * @return boolean - Whether or noth the traffic type is managed
	 */
	private function isManagedTrafficType($traffic_type) {
		// Manage all traffic types except TRAFFIC_TYPE_WEB_BEACON and TRAFFIC_TYPE_ROLLUP
		return self::TRAFFIC_TYPE_WEB_BEACON != $traffic_type && self::TRAFFIC_TYPE_ROLLUP != $traffic_type;
	}

	/***
	 * Return the traffic type from user_services for the report suite associated with the specified ReportSuiteConfig object
	 * 
	 * @param ReportSuiteConfig $rsc - Object with report suite for which to get the transition state
	 * @return integer - Traffic type from user_services or TRAFFIC_TYPE_UNKNOWN
	 */
	private function getTrafficType(ReportSuiteConfig $rsc) {
		$traffic_type = $rsc->get_traffic_type();
		if ($this->isManagedTrafficType($traffic_type) && (!$this->isMobileRsid($rsc->get_rsid()))) {
			$best_enable_date = '';
			if ($traffic_type < 0) {
				$traffic_type = self::TRAFFIC_TYPE_UNKNOWN; // Stored as an unsigned value in the transition table
			} else {
				$best_enable_date = $this->getBestMobileEnableDate($rsc);
			}
			// Auto-generate a mobile plan with the best enable date but don't force all mobile plans to be re-read
			$this->updateMobilePlan($rsc->get_rsid(), $best_enable_date, false);
		}
		return $traffic_type;
	}

	/**
	 * Updates an entry in the detail table
	 * 
	 * @param array $transition_info - New values for the entry
	 * @throws Exception
	 * 		- Error updating or reading from the detail table
	 * 		- Invalid rsid
	 */
	public function updateEntry(array $transition_info) {
		$this->invalidateLastFind();
		$table_name = self::DETAIL_TABLE_NAME;
		$last_update_ts = ($this->current_batch) ? $this->current_batch : date(MYSQL_DATE_FORMAT);

		$rsc = new ReportSuiteConfig($transition_info['rsid']);
		if ('' != $rsc->error_str) {
			throw new Exception("Could not get information for report suite {$transition_info['rsid']} (Error={$rsc->error_str})");
		}

		$traffic_type = $this->getTrafficType($rsc); // Must be called before checking if mobile since it auto-generates a mobile plan when needed
		$is_vip_comp = $this->isVipCompByCompanyId($transition_info['company_id']);
		$on_blacklist = $this->isOnBlacklist($transition_info['rsid']);
		$is_mobile = $this->isMobileRsid($transition_info['rsid']);
		$on_mobile_delay = ($is_mobile && !$this->isScheduleReadyByMobileRsid($transition_info['rsid']));
		$in_purge_queue = $this->isInPurgeQueue($transition_info['rsid']);

		$this->ensureSchedules();
		$schedule_tag = $this->getScheduleTagByCompanyId($transition_info['company_id']);
		if ($transition_info['is_rollup']
				&& (!array_key_exists($schedule_tag, $this->last_schedules)
					|| ($this->last_schedules[$schedule_tag]['begin_date'] < $this->rollup_plan['begin_date'])
				)
			) {
			$schedule_tag = $this->rollup_plan['schedule_tag'];
		}

		// Set the plan begin and finish dates based on the schedule tag or mobile plan
		if ($is_mobile) {
			$enable_date = $this->getEnableDateByMobileRsid($transition_info['rsid']);
			if ($enable_date >= self::MIN_TRANSITION_DATE) {
				$schedule_tag = $this->getScheduleTagByDate($enable_date);
				$plan_begin_date = $enable_date;
				$plan_finish_date = $schedule_tag ? $this->last_schedules[$schedule_tag]['finish_date'] : self::MAX_TRANSITION_DATE;
			} else {
				$schedule_tag = '';
				$plan_begin_date = '0000-00-00';
				$plan_finish_date = '0000-00-00';
			}
		} else if (!$schedule_tag) {
			$plan_begin_date = '0000-00-00';
			$plan_finish_date = '0000-00-00';
		} else {
			$plan_begin_date = $this->last_schedules[$schedule_tag]['begin_date'];
			$plan_finish_date = $this->last_schedules[$schedule_tag]['finish_date'];
		}

		// Set the vh_info, hbase_only_ts and enabled_ts timestamps as needed if not already set
		$hbase_only_ts = '';
		$enabled_ts = '';
		$cluster_ids = '';
		$vh_type = $this->getTransitionState($rsc);
		switch ($vh_type) {
			case self::HBASE_ONLY:
			case self::MULTI_HBASE_ONLY:
				$hbase_only_ts = $last_update_ts;
				// Drop through to set enabled_ts as well
				
			case self::HBASE_AND_MYSQL:
			case self::HBASE_DOING_TRANSFER:
				$enabled_ts = $last_update_ts;
				$cluster_ids = implode(' ', $rsc->get_all_hbase_handler_clusterids());
				break;
		}
		if ($enabled_ts || $hbase_only_ts) {
			// Preserve the timestamp for becoming HBase only or being enabled if already set, otherwise set it to this run
			$sql = "SELECT $this->sql_comment enabled_ts,hbase_only_ts FROM $table_name WHERE userid='{$transition_info['userid']}'";
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				if ($this->cmdb->next_record()) {
					if ($enabled_ts && ('0000-00-00 00:00:00' != $this->cmdb->f('enabled_ts'))) {
						$enabled_ts = $this->cmdb->f('enabled_ts');
					}
					if ($hbase_only_ts && ('0000-00-00 00:00:00' != $this->cmdb->f('hbase_only_ts'))) {
						$hbase_only_ts = $this->cmdb->f('hbase_only_ts');
					}
				}
			} else {
				throw new Exception("Error updating entry for report suite {$transition_info['rsid']} ({$transition_info['userid']}) (DB_Error={$this->cmdb->Error} SQL=$sql)");
			}
		}

		$batch_sql = ($this->current_batch) ? ",last_batch_ts='{$this->current_batch}'" : '';
		if ($this->verbose) {
			echo "Updating {$transition_info['rsid']} as of $last_update_ts\n";
			echo ($this->current_batch) ? "last_batch_ts='{$this->current_batch}'\n" : '';
			echo "vh_type=$vh_type\n";
			echo ($enabled_ts) ? "enabled_ts=$enabled_ts\n" : '';
			echo ($hbase_only_ts) ? "hbase_only_ts=$hbase_only_ts\n" : '';
			echo "is_vip_comp=$is_vip_comp\n";
			echo "cluster_ids=$cluster_ids\n";
			echo "on_blacklist=$on_blacklist\n";
			echo "is_mobile=$is_mobile\n";
			echo "traffic_type=$traffic_type\n";
			echo "on_mobile_delay=$on_mobile_delay\n";
			echo "schedule_tag=$schedule_tag\n";
			echo "plan_begin_date=$plan_begin_date\n";
			echo "plan_finish_date=$plan_finish_date\n";
			echo "Other transition details: ";
			print_r($transition_info);
		}
		$customer_name = $this->cmdb->escape_string($transition_info['customer_name']);
		$company_name = $this->cmdb->escape_string($transition_info['company_name']);
		
		$sql = <<<SQL
INSERT $this->sql_comment INTO $table_name
SET userid='{$transition_info['userid']}',rsid='{$transition_info['rsid']}'
	,customer_id='{$transition_info['customer_id']}',customer_name='$customer_name',ecc_id='{$transition_info['ecc_id']}'
	,company_id='{$transition_info['company_id']}',company_name='$company_name'
	,vh_type='$vh_type',enabled_ts='$enabled_ts',hbase_only_ts='$hbase_only_ts',cluster_ids='$cluster_ids'
	,hits='{$transition_info['hits']}'
	,mysql_bytes='{$transition_info['mysql_bytes']}',mysql_bytes_ts='{$transition_info['mysql_bytes_ts']}'
	,on_blacklist='$on_blacklist',on_mobile_delay='$on_mobile_delay',is_priority_rs='{$transition_info['is_priority_rs']}'
	,is_vip_comp='$is_vip_comp',is_strategic_cust='{$transition_info['is_strategic_cust']}'
	,is_mobile='$is_mobile',is_rollup='{$transition_info['is_rollup']}'
	,in_purge_queue='$in_purge_queue',traffic_type=$traffic_type
	,schedule_tag='$schedule_tag',plan_begin_date='$plan_begin_date',plan_finish_date='$plan_finish_date'
	,first_update_ts='$last_update_ts',last_update_ts='$last_update_ts'
	$batch_sql
ON DUPLICATE KEY UPDATE
	rsid='{$transition_info['rsid']}'
	,customer_id='{$transition_info['customer_id']}',customer_name='$customer_name',ecc_id='{$transition_info['ecc_id']}'
	,company_id='{$transition_info['company_id']}',company_name='$company_name'
	,vh_type='$vh_type',enabled_ts='$enabled_ts',hbase_only_ts='$hbase_only_ts',cluster_ids='$cluster_ids'
	,hits='{$transition_info['hits']}'
	,mysql_bytes='{$transition_info['mysql_bytes']}',mysql_bytes_ts='{$transition_info['mysql_bytes_ts']}'
	,on_blacklist='$on_blacklist',on_mobile_delay='$on_mobile_delay',is_priority_rs='{$transition_info['is_priority_rs']}'
	,is_vip_comp='$is_vip_comp',is_strategic_cust='{$transition_info['is_strategic_cust']}'
	,is_mobile='$is_mobile',is_rollup='{$transition_info['is_rollup']}'
	,in_purge_queue='$in_purge_queue',traffic_type=$traffic_type
	,schedule_tag='$schedule_tag',plan_begin_date='$plan_begin_date',plan_finish_date='$plan_finish_date'
	,last_update_ts='$last_update_ts'
	$batch_sql
SQL;
		if (!$this->run_query($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error updating entry for report suite {$transition_info['rsid']} ({$transition_info['userid']}) (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
	}

	/**
	 * Sets the value to use for the batch processing timestamp
	 * 
	 * @param string $batch_ts - The batch processing timestamp or the empty string meaning current time
	 */
	public function startBatch($batch_ts='') {
		$this->current_batch = date(MYSQL_DATE_FORMAT, strtotime(($batch_ts) ? $batch_ts : now()));
	}

	/**
	 * Ends the current batch 
	 */
	public function endBatch() {
		$this->current_batch = '';
	}

	/**
	 * Return timestamp of the most recent update
	 *  
	 * @throws Exception - Error reading from the detail table
	 * @return string - Most recent last_update_ts value
	 */
	public function getLastUpdateTimestamp() {
		$ret_ts = '';
		$table_name = self::DETAIL_TABLE_NAME;

		// Get the timestamp for the last update
		$sql = "SELECT $this->sql_comment last_update_ts FROM $table_name ORDER BY 1 DESC LIMIT 1";
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			if ($this->cmdb->next_record()) {
				$ret_ts = $this->cmdb->f('last_update_ts');
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering last_update_ts information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_ts;
	}

	/**
	 * Return timestamp of the most recent batch update
	 *  
	 * @throws Exception - Error reading from the detail table
	 * @return string - Most recent last_batch_ts value
	 */
	public function getLastBatchTimestamp() {
		$ret_ts = '';
		$table_name = self::DETAIL_TABLE_NAME;

		// Get the timestamp for the last batch
		$sql = "SELECT $this->sql_comment last_batch_ts FROM $table_name ORDER BY 1 DESC LIMIT 1";
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			if ($this->cmdb->next_record()) {
				$ret_ts = $this->cmdb->f('last_batch_ts');
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering last_batch_ts information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_ts;
	}

	/**
	 * Return information about tracked report suites whose last batch update doesn't match the specified timestamp
	 * 
	 * @param string $batch_ts - Timestamp to compare against 
	 * @throws Exception - Error reading from the detail table
	 * @return Array - batch timestamp used, rsids not matching timestamp, companies with rsids not matching timestamp
	 */
	public function getTrackedRsidsMissingFromBatch($batch_ts='') {
		$ret_list = array();
		if (!$batch_ts) {
			$batch_ts = $this->getLastBatchTimestamp();
		}
		$ret_list['batch'] = $batch_ts;
		$ret_list['rsids'] = array();
		$ret_list['companies'] = array();
		$table_name = self::DETAIL_TABLE_NAME;
		
		// Get report suites not from the batch
		$sql = "SELECT $this->sql_comment rsid FROM $table_name WHERE last_batch_ts<>'$batch_ts'";
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$ret_list['rsids'][] = $this->cmdb->f('rsid');
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error getting missing rsids from batch from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		if ($ret_list['rsids']) {
			$sql = "SELECT $this->sql_comment DISTINCT company_id FROM $table_name WHERE last_batch_ts<>'$batch_ts'";
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$ret_list['companies'][] = $this->cmdb->f('company_id');
				}
				$this->cmdb->free();
			} else {
				throw new Exception("Error getting companies for missing rsids from batch from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
			}
		}
		return $ret_list;
	}

	/**
	 * Return all companies with report suites with no plans of when to be enabled
	 * 
	 * @param boolean $include_all_details - If true, return all information in the entry otherwise just key information
	 * @throws Exception - Error reading from the detail table
	 * @return Array - Companies with report suites with missing plans
	 */
	public function getAllCompaniesWithMissingPlans($include_all_details=false) {
		$ret_list = array();
		$this->ensureCompanyPlans();

		$selectors_sql = $this->detailSelectorWhereClause(self::SELECT_NO_PLAN);

		$table_name = self::DETAIL_TABLE_NAME;

		$sql = <<<SQL
SELECT $this->sql_comment
	company_id
	,company_name
	,MAX(schedule_tag) AS schedule_tag
	,MAX(is_vip_comp) AS is_vip_comp
	,COUNT(distinct customer_id) AS cust_count
	,COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(on_blacklist) AS blacklist_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE $selectors_sql
GROUP BY company_id
ORDER BY company_name
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$company_id = $this->cmdb->f('company_id');
				if (!$this->last_company_plans[$company_id]) {
					$entry = array();
					$entry['company_id'] = $company_id;
					$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
					$entry['is_vip_comp'] = $this->cmdb->f('is_vip_comp');
					$entry['company_name'] = $this->cmdb->f('company_name');
					if ($include_all_details) {
						$entry['cust_count'] = $this->cmdb->f('cust_count');
						$entry['rs_count'] = $this->cmdb->f('rs_count');
						$entry['mobile_count'] = $this->cmdb->f('mobile_count');
						$entry['blacklist_count'] = $this->cmdb->f('blacklist_count');
						$entry['total_max_hits'] = $this->cmdb->f('total_max_hits');
						$entry['total_mysql_bytes'] = $this->cmdb->f('total_mysql_bytes');
					}
					$ret_list[$entry['company_id']] = $entry;
				}
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error getting companies with report suites with missing plans (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_list;
	}

	/***
	 * Returns plan information for recorded plans with the same company name as the specified companies 
	 *  
	 * @param array $companies - list of companies by name and id for which to match plans
	 * @return array - Plan information for any matching company names
	 */
	public function getPossiblePlansMatchByCompanyName($companies) {
		$ret_list = array();

		$names_sql = '';
		$separator = '';
		foreach ($companies as $company) {
			$names_sql .= $separator.$company['company_name'];
			$separator = "','";
		}

		if ($names_sql) {
			$table_name = self::COMPANY_PLAN_TABLE_NAME;

			$sql = <<<SQL
SELECT $this->sql_comment
	*
FROM $table_name
WHERE company_name in ('$names_sql')
SQL;
			$name_check = array();
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$entry = array();
					$entry['company_id'] = $this->cmdb->f('company_id');
					$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
					$entry['is_vip'] = $this->cmdb->f('is_vip');
					$entry['company_name'] = $this->cmdb->f('company_name');
					$name_check[$entry['company_name']] = $entry;
				}
				$this->cmdb->free();
			}

			if ($name_check) {
				foreach ($companies as $company) {
					$comp_name = $company['company_name'];
					if (array_key_exists($comp_name, $name_check) && ($company['company_id'] != $name_check[$comp_name]['company_id'])) {
						$entry = array();
						$entry['company_id'] = $company['company_id'];
						$entry['matching_company_id'] = $name_check[$comp_name]['company_id'];
						$entry['schedule_tag'] = $name_check[$comp_name]['schedule_tag'];
						$entry['is_vip_comp'] = $name_check[$comp_name]['is_vip'];
						$entry['company_name'] = $comp_name;
						$ret_list[$comp_name] = $entry;
					}
				}
			}
		}
		return $ret_list;
	}

	/**
	 * Returns the daily rsid count, mobile count, hits, and mysql_bytes for report suites enabled during a given date range
	 * 
	 * @param string $start_date - Start date for the date range (inclusive)
	 * @param string $end_date - End date for the date range (inclusive)
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @throws Exception 
	 * @return array - date range, last update and batch dates, and totals found for each date in the range if any enabled that day
	 */
	public function gatherEnabledDailyTotals($start_date='today', $end_date='today', $selectors='') {
		$ret_totals = array();
		$ret_totals['start_date'] = $start_date = date(MYSQL_DATE_ONLY_FORMAT, strtotime($start_date));
		$ret_totals['end_date'] = $end_date = date(MYSQL_DATE_ONLY_FORMAT, strtotime($end_date));
		$ret_totals['last_update_ts'] = $this->getLastUpdateTimestamp();
		$ret_totals['last_batch_ts'] = $this->getLastBatchTimestamp();
		$ret_totals['totals'] = array();

		$table_name = self::DETAIL_TABLE_NAME;

		$selectors_sql = $this->detailSelectorWhereClause(array_merge((array) self::SELECT_ENABLED, (array) $selectors));
		if ($selectors_sql) {
			$selectors_sql = 'AND '.$selectors_sql;
		}

		$end_date_sql = date(MYSQL_DATE_ONLY_FORMAT, strtotime($end_date.' + 1 day'));
		
		$sql = <<<SQL
SELECT $this->sql_comment
	LEFT(enabled_ts, 10) AS date_enabled
	,COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE enabled_ts>='$start_date'
	AND enabled_ts<'$end_date_sql'
	$selectors_sql
GROUP BY 1
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['date_enabled'] =  $this->cmdb->f('date_enabled');
				$entry['rs_count'] =  $this->cmdb->f('rs_count');
				$entry['mobile_count'] =  $this->cmdb->f('mobile_count');
				$entry['total_max_hits'] =  $this->cmdb->f('total_max_hits');
				$entry['total_mysql_bytes'] =  $this->cmdb->f('total_mysql_bytes');
				$ret_totals['totals'][$entry['date_enabled']] = $entry;
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering enabled daily totals information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_totals;
	}

	/**
	 * Gather the summary totals
	 * 
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @throws Exception - Error reading from the detail table
	 * @return array - Summary totals for each vcookie handler type
	 */
	public function gatherSummaryTotals($selectors='') {
		$selector_has_blacklist = $selectors && in_array(self::SELECT_BLACKLIST, (array) $selectors);

		// Initialize the summary to guarantee the order
		foreach (array(self::MYSQL_ONLY, self::HBASE_AND_MYSQL, self::HBASE_DOING_TRANSFER, self::HBASE_ONLY, self::MULTI_HBASE_ONLY, 'Blacklist') as $type) {
			if ('Blacklist' != $type || !$selector_has_blacklist) {
				$entry = array();
				$entry['vh_type'] = $type;
				$entry['cust_count'] = 0;
				$entry['comp_count'] = 0;
				$entry['rs_count'] =  0;
				$entry['mobile_count'] =  0;
				$entry['total_max_hits'] =  0;
				$entry['total_mysql_bytes'] =  0;
				$ret_totals[$type] = $entry;
			}
		}
		$table_name = self::DETAIL_TABLE_NAME;

		$selectors_sql = $this->detailSelectorWhereClause($selectors);

		$no_blacklist_sql = $blacklist_sql = $selectors_sql ? $selectors_sql : '';
		if (!$selector_has_blacklist) { // If no selectors then always comes through here
			$blacklist_sql .= ($blacklist_sql ? ' AND ' : '').'on_blacklist=1';
			$no_blacklist_sql .= ($no_blacklist_sql ? ' AND ' : '').'on_blacklist<>1';
		}

		$sql = <<<SQL
SELECT $this->sql_comment
	vh_type
	,COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE $no_blacklist_sql
GROUP BY vh_type
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['vh_type'] =  $this->cmdb->f('vh_type');
				$entry['cust_count'] = 0;  // This value is filled in later
				$entry['comp_count'] = 0;  // This value is filled in later
				$entry['rs_count'] =  $this->cmdb->f('rs_count');
				$entry['mobile_count'] =  $this->cmdb->f('mobile_count');
				$entry['total_max_hits'] =  $this->cmdb->f('total_max_hits');
				$entry['total_mysql_bytes'] =  $this->cmdb->f('total_mysql_bytes');
				$ret_totals[$entry['vh_type']] = $entry;
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering summary totals information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		if ($ret_totals['Blacklist']) {
			$sql = <<<SQL
SELECT $this->sql_comment
	COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE $blacklist_sql
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				if ($this->cmdb->next_record()) {
					$entry = array();
					$entry['vh_type'] =  'Blacklist';
					$entry['cust_count'] = 0;  // This value is filled in later
					$entry['comp_count'] = 0;  // This value is filled in later
					$entry['rs_count'] =  $this->cmdb->f('rs_count');
					$entry['mobile_count'] =  $this->cmdb->f('mobile_count');
					$entry['total_max_hits'] =  intval($this->cmdb->f('total_max_hits'));
					$entry['total_mysql_bytes'] =  intval($this->cmdb->f('total_mysql_bytes'));
					$ret_totals[$entry['vh_type']] = $entry;
				}
				$this->cmdb->free();
			} else {
				throw new Exception("Error gathering summary blacklist totals information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
			}
		}

		$where_selectors_sql = $selectors_sql ? 'WHERE '.$selectors_sql : '';

		// Fill in company count information for blacklist and each vh_type
		$sql = <<<SQL
SELECT $this->sql_comment
	company_id
	,vh_type
	,SUM(on_blacklist) AS blacklisted_count
FROM $table_name
$where_selectors_sql
GROUP BY company_id,vh_type
ORDER BY company_id
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			$has_blacklist_rsid = false;
			$vh_types = array();
			$prev_id = $curr_id = -1;
			while ($this->cmdb->next_record()) {
				$curr_id = $this->cmdb->f('company_id');
				if ($curr_id != $prev_id) {
					if (-1 != $prev_id) {
						if ($has_blacklist_rsid) {
							$ret_totals['Blacklist']['comp_count']++;
						} else if (in_array(self::MYSQL_ONLY, $vh_types)) {
							$ret_totals[self::MYSQL_ONLY]['comp_count']++;
						} else if (in_array(self::HBASE_AND_MYSQL, $vh_types)) {
							$ret_totals[self::HBASE_AND_MYSQL]['comp_count']++;
						} else if (in_array(self::HBASE_DOING_TRANSFER, $vh_types)) {
							$ret_totals[self::HBASE_DOING_TRANSFER]['comp_count']++;
						} else if (in_array(self::HBASE_ONLY, $vh_types)) {
							$ret_totals[self::HBASE_ONLY]['comp_count']++;
						} else if (in_array(self::MULTI_HBASE_ONLY, $vh_types)) {
							$ret_totals[self::MULTI_HBASE_ONLY]['comp_count']++;
						}
					}
					$has_blacklist_rsid = false;
					$vh_types = array();
					$prev_id = $curr_id;
				}
				$has_blacklist_rsid = $ret_totals['Blacklist'] && ($has_blacklist_rsid || (0 != $this->cmdb->f('blacklisted_count')));
				$vh_types[] = $this->cmdb->f('vh_type');
			}
			$this->cmdb->free();
			if (-1 != $prev_id) {
				if ($has_blacklist_rsid) {
					$ret_totals['Blacklist']['comp_count']++;
				} else if (in_array(self::MYSQL_ONLY, $vh_types)) {
					$ret_totals[self::MYSQL_ONLY]['comp_count']++;
				} else if (in_array(self::HBASE_AND_MYSQL, $vh_types)) {
					$ret_totals[self::HBASE_AND_MYSQL]['comp_count']++;
				} else if (in_array(self::HBASE_DOING_TRANSFER, $vh_types)) {
					$ret_totals[self::HBASE_DOING_TRANSFER]['comp_count']++;
				} else if (in_array(self::HBASE_ONLY, $vh_types)) {
					$ret_totals[self::HBASE_ONLY]['comp_count']++;
				} else if (in_array(self::MULTI_HBASE_ONLY, $vh_types)) {
					$ret_totals[self::MULTI_HBASE_ONLY]['comp_count']++;
				}
			}
		} else {
			throw new Exception("Error gathering summary company counts from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		// Fill in customer count information for blacklist and each vh_type
		$sql = <<<SQL
SELECT $this->sql_comment
	customer_id
	,vh_type
	,SUM(on_blacklist) AS blacklisted_count
FROM $table_name
$where_selectors_sql
GROUP BY customer_id,vh_type
ORDER BY customer_id
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			$has_blacklist_rsid = false;
			$vh_types = array();
			$prev_id = $curr_id = -1;
			while ($this->cmdb->next_record()) {
				$curr_id = $this->cmdb->f('customer_id');
				if ($curr_id != $prev_id) {
					if (-1 != $prev_id) {
						if ($has_blacklist_rsid) {
							$ret_totals['Blacklist']['cust_count']++;
						} else if (in_array(self::MYSQL_ONLY, $vh_types)) {
							$ret_totals[self::MYSQL_ONLY]['cust_count']++;
						} else if (in_array(self::HBASE_AND_MYSQL, $vh_types)) {
							$ret_totals[self::HBASE_AND_MYSQL]['cust_count']++;
						} else if (in_array(self::HBASE_DOING_TRANSFER, $vh_types)) {
							$ret_totals[self::HBASE_DOING_TRANSFER]['cust_count']++;
						} else if (in_array(self::HBASE_ONLY, $vh_types)) {
							$ret_totals[self::HBASE_ONLY]['cust_count']++;
						} else if (in_array(self::MULTI_HBASE_ONLY, $vh_types)) {
							$ret_totals[self::MULTI_HBASE_ONLY]['cust_count']++;
						}
					}
					$has_blacklist_rsid = false;
					$vh_types = array();
					$prev_id = $curr_id;
				}
				$has_blacklist_rsid = $ret_totals['Blacklist'] && ($has_blacklist_rsid || (0 != $this->cmdb->f('blacklisted_count')));
				$vh_types[] = $this->cmdb->f('vh_type');
			}
			$this->cmdb->free();
			if (-1 != $prev_id) {
				if ($has_blacklist_rsid) {
					$ret_totals['Blacklist']['cust_count']++;
				} else if (in_array(self::MYSQL_ONLY, $vh_types)) {
					$ret_totals[self::MYSQL_ONLY]['cust_count']++;
				} else if (in_array(self::HBASE_AND_MYSQL, $vh_types)) {
					$ret_totals[self::HBASE_AND_MYSQL]['cust_count']++;
				} else if (in_array(self::HBASE_DOING_TRANSFER, $vh_types)) {
					$ret_totals[self::HBASE_DOING_TRANSFER]['cust_count']++;
				} else if (in_array(self::HBASE_ONLY, $vh_types)) {
					$ret_totals[self::HBASE_ONLY]['cust_count']++;
				} else if (in_array(self::MULTI_HBASE_ONLY, $vh_types)) {
					$ret_totals[self::MULTI_HBASE_ONLY]['cust_count']++;
				}
			}
		} else {
			throw new Exception("Error gathering summary customer counts from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		return $ret_totals;
	}

	/**
	 * Gather plan totals
	 * 
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @throws Exception - Error reading from detail table
	 * @return array - Plan totals for each used schedule
	 */
	public function gatherPlanTotals($selectors='') {
		$ret_totals = array();
		$table_name = self::DETAIL_TABLE_NAME;

		$selector_has_blacklist = ($selectors && in_array(self::SELECT_BLACKLIST, (array) $selectors));

		$selectors_sql = $this->detailSelectorWhereClause($selectors);

		$no_blacklist_sql = $blacklist_sql = $selectors_sql ? $selectors_sql : '';
		if (!$selector_has_blacklist) { // If no selectors then always comes through here
			$blacklist_sql .= ($blacklist_sql ? ' AND ' : '').'on_blacklist=1';
			$no_blacklist_sql .= ($no_blacklist_sql ? ' AND ' : '').'on_blacklist<>1';
		}

		$sql = <<<SQL
SELECT $this->sql_comment
	schedule_tag AS schedule
	,plan_begin_date
	,plan_finish_date
	,COUNT(distinct customer_id) AS cust_count
	,COUNT(distinct company_id) AS comp_count
	,COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE $no_blacklist_sql
GROUP BY schedule_tag
ORDER BY plan_begin_date,schedule_tag
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['schedule'] =  ('' == $this->cmdb->f('schedule')) ? 'No plan' : $this->cmdb->f('schedule');
				$entry['plan_begin_date'] =  $this->cmdb->f('plan_begin_date');
				$entry['plan_finish_date'] =  $this->cmdb->f('plan_finish_date');
				$entry['cust_count'] =  $this->cmdb->f('cust_count');
				$entry['comp_count'] =  $this->cmdb->f('comp_count');
				$entry['rs_count'] =  $this->cmdb->f('rs_count');
				$entry['mobile_count'] =  $this->cmdb->f('mobile_count');
				$entry['total_max_hits'] =  intval($this->cmdb->f('total_max_hits'));
				$entry['total_mysql_bytes'] =  intval($this->cmdb->f('total_mysql_bytes'));
				$ret_totals[$entry['schedule']] = $entry;
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering plan totals information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		if (!$selector_has_blacklist) {
			$sql = <<<SQL
SELECT $this->sql_comment
	COUNT(distinct customer_id) AS cust_count
	,COUNT(distinct company_id) AS comp_count
	,COUNT(*) AS rs_count
	,SUM(is_mobile) AS mobile_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM $table_name
WHERE $blacklist_sql
ORDER BY plan_begin_date,schedule_tag
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				$entry = array();
				$entry['schedule'] =  'Blacklist';
				$entry['plan_begin_date'] =  '0000-00-00';
				$entry['plan_finish_date'] =  '0000-00-00';
				if ($this->cmdb->next_record()) {
					$entry['cust_count'] =  $this->cmdb->f('cust_count');
					$entry['comp_count'] =  $this->cmdb->f('comp_count');
					$entry['rs_count'] =  $this->cmdb->f('rs_count');
					$entry['mobile_count'] =  $this->cmdb->f('mobile_count');
					$entry['total_max_hits'] =  intval($this->cmdb->f('total_max_hits'));
					$entry['total_mysql_bytes'] =  intval($this->cmdb->f('total_mysql_bytes'));
				} else {
					$entry['cust_count'] =  0;
					$entry['comp_count'] =  0;
					$entry['rs_count'] =  0;
					$entry['mobile_count'] =  0;
					$entry['total_max_hits'] =  0;
					$entry['total_mysql_bytes'] =  0;
				}
				$ret_totals[$entry['schedule']] = $entry;
				$this->cmdb->free();
			} else {
				throw new Exception("Error gathering plan blacklist totals information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
			}
		}
		return $ret_totals;
	}

	/**
	 * Return the total max hits for the entire data processing center
	 * 
	 * @return integer - total max hits for the dpc
	 */
	public function getDpcTotalMaxHits() {
		$ret_total = 0;
		$table_name = self::DETAIL_TABLE_NAME;

		$sql = <<<SQL
SELECT $this->sql_comment
	SUM(hits) AS dpc_total_max_hits
FROM $table_name
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			if ($this->cmdb->next_record()) {
				$ret_total = $this->cmdb->f('dpc_total_max_hits');
			}

		}
		return $ret_total;
	}

	/**
	 * Gather summary information from the detail table
	 * 
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @return array - last update timestamp, last batch timestamp, summary totals, and plan totals
	 */
	public function gatherSummaryInfo($selectors='') {
		$ret_summary = array();
		$ret_summary['last_update_ts'] = $this->getLastUpdateTimestamp();
		$ret_summary['last_batch_ts'] = $this->getLastBatchTimestamp();
		$ret_summary['totals'] = $this->gatherSummaryTotals($selectors);
		$ret_summary['plan_totals'] = $this->gatherPlanTotals($selectors);

		return $ret_summary;
	}

	private function selectorRsidWhereClause($selectors='', array $rsids=array()) {
		$all_rsids = array();
		$all_patterns = array();

		// Separate all rsid entries with wildcards
		foreach ($rsids as $rsid) {
			if (false === strpos($rsid, '%')) {
				$all_rsids[] = $rsid;
			} else {
				$all_patterns[] = $rsid;
			}
		}

		// Build the where clause
		$ret_clause = '';
		$sql_separator = '';
		$selector_where_clause = $this->detailSelectorWhereClause($selectors);
		if ($selector_where_clause) {
			$ret_clause .= $sql_separator.'('.$selector_where_clause.')';
			$sql_separator = ' AND ';
		}

		// Find entries that match any rsids in the list
		$sql_begin = '(';
		$sql_end = '';
		if ($all_rsids) {
			$ret_clause .= $sql_separator.$sql_begin."rsid in ('".implode("','", $all_rsids)."')";
			$sql_separator = ' OR ';
			$sql_begin = '';
			$sql_end = ')';
		}

		// Find entries that match any rsid patterns in the list
		foreach ($all_patterns as $pattern) {
			$ret_clause .= $sql_separator.$sql_begin."rsid like '$pattern'";
			$sql_separator = ' OR ';
			$sql_begin = '';
			$sql_end = ')';
		}
		$ret_clause .= $sql_end;

		return $ret_clause;
	}

	/**
	 * Gather customer information from the detail table
	 *
	 * @param array $rsids - List of rsids or rsid patterns for which to return detail
	 * @param boolean $include_all_details - If true, return additional information otherwise just customer information
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @return array - Customer information from the detail table
	 */
	public function gatherCustomerInfo($selectors='', $include_all_details=false, array $rsids=array()) {
		$ret_info = array();
		$table_name = self::DETAIL_TABLE_NAME;

		$where_clause = $this->selectorRsidWhereClause($selectors, $rsids);
		if ($where_clause) {
			$where_clause = "WHERE $where_clause";
		}

		$other_fields = '';
		if ($include_all_details) {
			$other_fields = <<<OTHER
				,cluster_ids
				,vh_type
OTHER;
		}
		
		$sql = <<<SQL
SELECT $this->sql_comment
	ecc_id
	,customer_id
	,customer_name
	,MAX(is_strategic_cust) AS is_strategic
	$other_fields
	,COUNT(*) AS rs_count
FROM
	$table_name
$where_clause
GROUP BY
	ecc_id
	$other_fields
SQL;
		if (!$this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error gathering customer information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		if ($include_all_details) {
			$cust_clusters = array();
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$ecc_id = $this->cmdb->f('ecc_id');
				$is_strategic = $this->cmdb->f('is_strategic');
				if (!array_key_exists($ecc_id, $ret_info)) {
					$entry = array();
					$entry['ecc_id'] = $ecc_id;
					$entry['customer_id'] = $this->cmdb->f('customer_id');
					$entry['customer_name'] = $this->cmdb->f('customer_name');
					$entry['is_strategic'] = $is_strategic;
					$entry['cluster_ids'] = '';
					$entry[self::MYSQL_ONLY] = 0;
					$entry[self::HBASE_AND_MYSQL] = 0;
					$entry[self::HBASE_DOING_TRANSFER] = 0;
					$entry[self::HBASE_ONLY] = 0;
					$entry[self::MULTI_HBASE_ONLY] = 0;
					$entry['rs_count'] = 0;
					$ret_info[$ecc_id] = $entry;
				}

				$ret_info[$ecc_id]['rs_count'] += $this->cmdb->f('rs_count');
				switch ($this->cmdb->f('vh_type')) {
					case self::MYSQL_ONLY:
					case self::HBASE_AND_MYSQL:
					case self::HBASE_DOING_TRANSFER:
					case self::HBASE_ONLY:
					case self::MULTI_HBASE_ONLY:
						$ret_info[$ecc_id][$this->cmdb->f('vh_type')] += $this->cmdb->f('rs_count');
						break;
				}

				if ($is_strategic) {
					$ret_info[$ecc_id]['is_strategic'] = $is_strategic;
				}

				$cust_clusters[$ecc_id][$this->cmdb->f('cluster_ids')] = '';
			}

			// Process the vcookie clusters for each customer
			foreach($cust_clusters as $ecc_id=>$info) {
				$all_clusters = array();
				foreach (array_keys($info) as $clusters) {
					if ($clusters) {
						if (strpos($clusters, ' ') === false) {
							$all_clusters[$clusters] = $clusters;
						} else {
							foreach (explode(' ', $clusters) as $single_cluster) {
								$all_clusters[$single_cluster] = $single_cluster;
							}
						}
					}
				}
				$ret_info[$ecc_id]['cluster_ids'] = implode(' ', array_keys($all_clusters));
			}
		} else {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$ret_info[$this->cmdb->f('ecc_id')] = $this->cmdb->Record;
			}
		}
		$this->cmdb->free();

		return $ret_info;
	}

	/**
	 * Gather company information from the detail table
	 *
	 * @param array $rsids - List of rsids or rsid patterns for which to return detail
	 * @param boolean $include_all_details - If true, return additional information otherwise just basic information
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @return array - Company information from the detail table
	 */
	public function gatherCompanyInfo($selectors='', $include_all_details=false, array $rsids=array()) {
		$ret_info = array();
		$table_name = self::DETAIL_TABLE_NAME;

		$where_clause = $this->selectorRsidWhereClause($selectors, $rsids);
		if ($where_clause) {
			$where_clause = "WHERE $where_clause";
		}

		$other_fields = '';
		if ($include_all_details) {
			$other_fields = <<<OTHER
				,cluster_ids
				,vh_type
OTHER;
		}
		
		$sql = <<<SQL
SELECT $this->sql_comment
	company_id
	,company_name
	,MAX(is_vip_comp) AS is_vip
	$other_fields
	,COUNT(*) AS rs_count
FROM
	$table_name
$where_clause
GROUP BY
	company_id
	$other_fields
SQL;
		if (!$this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error gathering company information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		if ($include_all_details) {
			$comp_clusters = array();
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$company_id = $this->cmdb->f('company_id');
				$is_vip = $this->cmdb->f('is_vip');
				if (!array_key_exists($company_id, $ret_info)) {
					$entry = array();
					$entry['company_id'] = $company_id;
					$entry['company_name'] = $this->cmdb->f('company_name');
					$entry['is_vip'] = $is_vip;
					$entry['cluster_ids'] = '';
					$entry[self::MYSQL_ONLY] = 0;
					$entry[self::HBASE_AND_MYSQL] = 0;
					$entry[self::HBASE_DOING_TRANSFER] = 0;
					$entry[self::HBASE_ONLY] = 0;
					$entry[self::MULTI_HBASE_ONLY] = 0;
					$entry['rs_count'] = 0;
					$ret_info[$company_id] = $entry;
				}

				$ret_info[$company_id]['rs_count'] += $this->cmdb->f('rs_count');
				switch ($this->cmdb->f('vh_type')) {
					case self::MYSQL_ONLY:
					case self::HBASE_AND_MYSQL:
					case self::HBASE_DOING_TRANSFER:
					case self::HBASE_ONLY:
					case self::MULTI_HBASE_ONLY:
						$ret_info[$company_id][$this->cmdb->f('vh_type')] += $this->cmdb->f('rs_count');
						break;
				}

				if ($is_vip) {
					$ret_info[$company_id]['is_vip'] = $is_vip;
				}

				$comp_clusters[$company_id][$this->cmdb->f('cluster_ids')] = '';
			}

			// Process the vcookie clusters for each company
			foreach($comp_clusters as $company_id=>$info) {
				$all_clusters = array();
				foreach (array_keys($info) as $clusters) {
					if ($clusters) {
						if (strpos($clusters, ' ') === false) {
							$all_clusters[$clusters] = $clusters;
						} else {
							foreach (explode(' ', $clusters) as $single_cluster) {
								$all_clusters[$single_cluster] = $single_cluster;
							}
						}
					}
				}
				$ret_info[$company_id]['cluster_ids'] = implode(' ', array_keys($all_clusters));
			}
		} else {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$ret_info[$this->cmdb->f('company_id')] = $this->cmdb->Record;
			}
		}
		$this->cmdb->free();

		return $ret_info;
	}

	/**
	 * Gather company information from the detail table
	 *
	 * @param array $rsids - List of rsids or rsid patterns for which to return detail
	 * @param boolean $include_all_details - If true, return additional information otherwise just basic information
	 * @param string or array $selectors - Selectors for which to generate the where clause 
	 * @return array - Company information from the detail table
	 */
	public function gatherVcookieClusterInfo($selectors='', $include_all_details=false, array $rsids=array()) {
		$ret_info = array();
		$table_name = self::DETAIL_TABLE_NAME;

		$where_clause = $this->selectorRsidWhereClause($selectors, $rsids);
		if ($where_clause) {
			$where_clause = "AND $where_clause";
		}

		$sql = <<<SQL
SELECT $this->sql_comment
	cluster_ids
	,COUNT(DISTINCT ecc_id) AS cust_count
	,COUNT(DISTINCT company_id) AS company_count
	,COUNT(*) AS rs_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM
	$table_name
WHERE
	cluster_ids<>''
	$where_clause
GROUP BY
	cluster_ids
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$ret_info[$this->cmdb->f('cluster_ids')] = $this->cmdb->Record;
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering vcookie cluster information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
		return $ret_info;
	}

	/**
	 * Gather company information from the detail table
	 *
	 * @param array $rsids - List of rsids or rsid patterns for which to return detail
	 * @param boolean $include_all_details - If true, return additional information otherwise just basic information
	 * @param string or array $selectors - Selectors for which to generate the where clause
	 * @return array - Company information from the detail table
	 */
	public function gatherVcookieClusterCustomerInfo($selectors='', $include_all_details=false, array $rsids=array()) {
		$ret_info = array();
		$table_name = self::DETAIL_TABLE_NAME;

		$where_clause = $this->selectorRsidWhereClause($selectors, $rsids);
		if ($where_clause) {
			$where_clause = "AND $where_clause";
		}
	
		$sql = <<<SQL
SELECT $this->sql_comment
	cluster_ids
	,ecc_id
	,customer_id
	,customer_name
	,COUNT(*) AS rs_count
	,SUM(hits) AS total_max_hits
	,SUM(mysql_bytes) AS total_mysql_bytes
FROM
	$table_name
WHERE
	cluster_ids<>''
	$where_clause
GROUP BY
	cluster_ids
	,ecc_id
ORDER BY
	cluster_ids
	,ecc_id
SQL;
		$cust_clusters = array();
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record(MYSQL_ASSOC)) {
				$ecc_id = $this->cmdb->f('ecc_id');
				if (!array_key_exists($ecc_id, $ret_info)) {
					$entry = array();
					$entry['distinct_clusters'] = '';
					$entry['ecc_id'] = $ecc_id;
					$entry['customer_id'] = $this->cmdb->f('customer_id');
					$entry['customer_name'] = $this->cmdb->f('customer_name');
					$entry['rs_count'] = 0;
					$entry['total_max_hits'] = 0;
					$entry['total_mysql_bytes'] = 0;
					$ret_info[$ecc_id] = $entry;
				}
	
				$ret_info[$ecc_id]['rs_count'] += $this->cmdb->f('rs_count');
				$ret_info[$ecc_id]['total_max_hits'] += $this->cmdb->f('total_max_hits');
				$ret_info[$ecc_id]['total_mysql_bytes'] += $this->cmdb->f('total_mysql_bytes');

				$cust_clusters[$this->cmdb->f('cluster_ids')][] = $ecc_id;
			}
			$this->cmdb->free();
		} else {
			throw new Exception("Error gathering vcookie cluster customer information from $table_name (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		//Spread into the matching single cluster list any entries with multiple clusters because of multiple hbase handlers
		$all_clusters = array();
		foreach ($cust_clusters as $clusters=>$ecc_ids) {
			if (strpos($clusters, ' ') === false) {
				$all_clusters[$clusters] = array_unique(array_merge((array) $all_clusters[$clusters], $ecc_ids));
			} else {
				foreach (explode(' ', $clusters) as $single_cluster) {
					$all_clusters[$single_cluster] = array_unique(array_merge((array) $all_clusters[$single_cluster], $ecc_ids));
				}
			}
		}

		$unique_clusters = $this->sortUniqueItems($all_clusters);

		if ($include_all_details) {
			foreach($unique_clusters as $clusters=>$ecc_ids) {
				foreach($ecc_ids as $ecc_id) {
					$ret_info[$ecc_id]['distinct_clusters'] = $clusters;
				}
			}
		} else {
			$ret_summary = array();
			foreach($unique_clusters as $clusters=>$ecc_ids) {
				$entry = array();
				$entry['distinct_clusters'] = $clusters;
				$entry['cust_count'] = 0;
				$entry['rs_count'] = 0;
				$entry['total_max_hits'] = 0;
				$entry['total_mysql_bytes'] = 0;
				$ret_summary[$clusters] = $entry;
				foreach($ecc_ids as $ecc_id) {
					//Summarize the data for all customers using clusters
					$ret_summary[$clusters]['cust_count']++;
					$ret_summary[$clusters]['rs_count'] += $ret_info[$ecc_id]['rs_count'];
					$ret_summary[$clusters]['total_max_hits'] += $ret_info[$ecc_id]['total_max_hits'];
					$ret_summary[$clusters]['total_mysql_bytes'] += $ret_info[$ecc_id]['total_mysql_bytes'];
				}
			}
			return $ret_summary;
		}
		return $ret_info;
	}

	/**
	 * Sort specified, keyed array into groups using concatenated keys when an item is in multiple subarrays
	 *  
	 * @param array $in_items - Subarrays to sort
	 * @return array - Array with newly keyed subarrays when incoming items are in multple subarrays
	 */
	private function sortUniqueItems(array $in_items) {
		$delim = ' and ';

		//Create the map and expect that everything is unique
		$ret_uniques = array();
		$map = array();
		foreach ($in_items as $key=>$items) {
			$map[] = $key;
			$ret_uniques[$key] = $items;
		}
		$max_keys = count($map);

		$next_level = array();
		for ($i=0; $i < $max_keys; $i++) {
			if ($in_items[$map[$i]]) {
				$key_i = $map[$i];
				$exploded_i = explode($delim, $key_i);
				for($j=$i+1; $j < $max_keys; $j++) {
					if ($in_items[$map[$j]]) {
						$key_j = $map[$j];
						$next_key = array_unique(array_merge($exploded_i, explode($delim, $key_j)));
						asort($next_key);
						$next_key = implode($delim, $next_key);
						$next_level[$next_key] = array_intersect($in_items[$key_i], $in_items[$key_j]);
						$ret_uniques[$key_i] = array_diff($ret_uniques[$key_i], $next_level[$next_key]);
						$ret_uniques[$key_j] = array_diff($ret_uniques[$key_j], $next_level[$next_key]);
					}
				}
			}
		}
		if ($next_level) {
			$ret_uniques += $this->sortUniqueItems($next_level);
		}

		return array_filter($ret_uniques); //Remove any uniques that have no items
	}

	/**
	 * Forces schedules to be re-read from the schedule table next time they are needed
	 */
	private function invalidateLastSchedules() {
		$this->last_schedules = array();
	}

	/**
	 * Caches all schedules from the schedule table if not already in cached
	 * 
	 * @param boolean $force_reload - If true, re-read the table even if the information was already cached
	 */
	private function ensureSchedules($force_reload=false) {
		if ($force_reload) $this->invalidateLastSchedules();

		if (!$this->last_schedules) {
			$sql = "SELECT $this->sql_comment * FROM ".self::SCHEDULE_TABLE_NAME;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$entry = array();
					$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
					$entry['begin_date'] = $this->cmdb->f('begin_date');
					$entry['finish_date'] = $this->cmdb->f('finish_date');
					$entry['last_update_ts'] = $this->cmdb->f('last_update_ts');
					$this->last_schedules[$entry['schedule_tag']] = $entry;
				}
				$this->cmdb->free();
			}

			// Set the begin date for the rollup plan based on the schedules found
			$this->rollup_plan['schedule_tag'] = array_key_exists(self::ROLLUP_SCHEDULE_TAG, $this->last_schedules)
				? self::ROLLUP_SCHEDULE_TAG
				: $this->getScheduleTagByDate(self::ROLLUP_DEFAULT_DATE);

			$this->rollup_plan['begin_date'] = $this->rollup_plan['schedule_tag']
				? $this->last_schedules[$this->rollup_plan['schedule_tag']]['begin_date']
				: self::ROLLUP_DEFAULT_DATE;
		}
	}

	/**
	 * Returns all defined schedules
	 * 
	 * @return array - All defined schedules
	 */
	public function getAllSchedules() {
		$this->ensureSchedules();
		return $this->last_schedules;
	}

	/**
	 * Returns the schedule associated with a specified date
	 * 
	 * @param string $date - Date for which schedule should be returned
	 * @return string - Schedule tag recorded for that date, if any
	 */
	public function getScheduleTagByDate($date) {
		$matching_tags = array();
		foreach($this->getAllSchedules() as $schedule) {
			if (($date >= $schedule['begin_date']) && ($date <= $schedule['finish_date'])) {
				$matching_tags[] = $schedule;
			}
		}
		if (1 == count($matching_tags)) {
			return $matching_tags[0]['schedule_tag'];
		}

		// Look for best match based on latest begin date then shortest time frame
		$ret_schedule_tag = '';
		$best_begin = '0000-00-00';
		$best_end = '9999-99-99';
		foreach($matching_tags as $schedule) {
			if ($best_begin < $schedule['begin_date']) {
				$best_begin = $schedule['begin_date'];
				$ret_schedule_tag = $schedule['schedule_tag'];
			} else if (($best_begin == $schedule['begin_date']) && ($best_end > $schedule['end_date'])) {
				$best_end = $schedule['end_date'];
				$ret_schedule_tag = $schedule['schedule_tag'];
			}
		}
		return $ret_schedule_tag;
	}

	/**
	 * Updates an entry in the schedule table
	 * 
	 * @param string $schedule_tag - Schedule to update
	 * @param date $begin_date - Scheduled begin date
	 * @param date $finish_date - Scheduled Finish date
	 * @throws Exception - Error updating the schedule table
	 */
	public function updateSchedule($schedule_tag, $begin_date, $finish_date) {
		$this->invalidateLastSchedules();

		$table_name = self::SCHEDULE_TABLE_NAME;
		$last_update_ts = date(MYSQL_DATE_FORMAT);

		$begin_date = date('Y-m-d', strtotime($begin_date));
		$finish_date = date('Y-m-d', strtotime($finish_date));

		$sql = <<<SQL
INSERT $this->sql_comment INTO $table_name
SET schedule_tag='$schedule_tag'
	,begin_date='$begin_date'
	,finish_date='$finish_date'
	,last_update_ts='$last_update_ts'
ON DUPLICATE KEY UPDATE
	schedule_tag='$schedule_tag'
	,begin_date='$begin_date'
	,finish_date='$finish_date'
	,last_update_ts='$last_update_ts'
SQL;
		if (!$this->run_query($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error updating entry for schedule $schedule_tag (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
	}

	/**
	 * Forces the company plans to be re-read from the company_plan table next time they are needed
	 */
	private function invalidateLastCompanyPlans() {
		$this->last_company_plans = array();
	}

	/**
	 * Caches all company plans from the company_plan table if not already cached
	 * 
	 * @param boolean $force_reload - If true, re-read the table even if the information was already cached
	 */
	private function ensureCompanyPlans($force_reload=false) {
		if ($force_reload) $this->invalidateLastCompanyPlans();

		if (!$this->last_company_plans) {
			$table_name = self::COMPANY_PLAN_TABLE_NAME;

			$sql = <<<SQL
SELECT $this->sql_comment
	*
FROM $table_name
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$entry = array();
					$entry['company_id'] = $this->cmdb->f('company_id');
					$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
					$entry['is_vip'] = $this->cmdb->f('is_vip');
					$entry['company_name'] = $this->cmdb->f('company_name');
					$this->last_company_plans[$entry['company_id']] = $entry;
				}
				$this->cmdb->free();
			}
		}
	}

	/**
	 * Returns all recorded company plans
	 * 
	 * @return array - All recorded company plans
	 */
	public function getAllCompanyPlans() {
		$this->ensureCompanyPlans();
		return $this->last_company_plans;
	}

	/**
	 * Return detail for all recorded company plans
	 * 
	 * @return array - detail for all recorded company plans
	 */
	public function getFullCompanyPlanEntries() {
		$ret_plans = array();

		$table_name = self::COMPANY_PLAN_TABLE_NAME;
	
		$sql = <<<SQL
SELECT $this->sql_comment
	*
FROM $table_name
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['company_id'] = $this->cmdb->f('company_id');
				$entry['schedule_tag'] = $this->cmdb->f('schedule_tag');
				$entry['is_vip'] = $this->cmdb->f('is_vip');
				$entry['company_name'] = $this->cmdb->f('company_name');
				$entry['first_update_ts'] = $this->cmdb->f('first_update_ts');
				$entry['last_update_ts'] = $this->cmdb->f('last_update_ts');
				$ret_plans[$entry['company_id']] = $entry;
			}
			$this->cmdb->free();
		}
		return $ret_plans;
	}

	/**
	 * Returns the schedule associated with a login company
	 * 
	 * @param integer $company_id - Company companyid for which schedule should be returned
	 * @return string - Schedule tag recorded for company
	 */
	public function getScheduleTagByCompanyId($company_id) {
		$this->ensureCompanyPlans();
		return (array_key_exists($company_id, $this->last_company_plans)) ? $this->last_company_plans[$company_id]['schedule_tag'] : self::ANY_MYSQL_SCHEDULE_TAG;
	}

	/**
	 * Returns the recorded vip status for the company
	 * 
	 * @param integer $company_id - Company companyid for which vip status should be returned
	 * @return boolean - Vip status recorded for company
	 */
	public function isVipCompByCompanyId($company_id) {
		$this->ensureCompanyPlans();
		return (array_key_exists($company_id, $this->last_company_plans)) ? $this->last_company_plans[$company_id]['is_vip'] : false;
	}

	/**
	 * Updates an entry in the company_plan table
	 * 
	 * @param integer $company_id - Company to update
	 * @param unknown $company_name - Company name of company being updated
	 * @param unknown $is_vip - If true, company is an important company
	 * @param unknown $schedule_tag - Schedule tag to record for the company
	 * @throws Exception - Error updating company_plan table
	 */
	public function updateCompanyPlan($company_id, $company_name, $is_vip, $schedule_tag) {
		$this->invalidateLastCompanyPlans();

		$table_name = self::COMPANY_PLAN_TABLE_NAME;
		$last_update_ts = date(MYSQL_DATE_FORMAT);

		$sql = <<<SQL
INSERT $this->sql_comment INTO $table_name
SET company_id='$company_id'
	,schedule_tag='$schedule_tag'
	,is_vip='$is_vip'
	,company_name='$company_name'
	,first_update_ts='$last_update_ts'
	,last_update_ts='$last_update_ts'
ON DUPLICATE KEY UPDATE
	company_id='$company_id'
	,schedule_tag='$schedule_tag'
	,is_vip='$is_vip'
	,company_name='$company_name'
	,last_update_ts='$last_update_ts'
SQL;
		if (!$this->run_query($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error updating entry for company plan $company_name ($company_id) (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}
	}

	/**
	 * Forces the mobile plans to be re-read from the mobile_plan table next time they are needed
	 */
	private function invalidateLastMobilePlans() {
		$this->last_mobile_plans = array();
	}

	/**
	 * Caches all mobile plans from the mobile_plan table if not already cached
	 * 
	 * @param boolean $force_reload - If true, re-read the table even if the information was already cached
	 */
	private function ensureMobilePlans($force_reload=false) {
		if ($force_reload) $this->invalidateLastMobilePlans();

		if (!$this->last_mobile_plans) {
			$table_name = self::MOBILE_PLAN_TABLE_NAME;

			$sql = <<<SQL
SELECT $this->sql_comment
	mobile_rsid
	,enable_date
FROM $table_name
ORDER BY mobile_rsid
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$entry = array();
					$entry['mobile_rsid'] = $this->cmdb->f('mobile_rsid');
					$entry['enable_date'] = $this->cmdb->f('enable_date');
					$this->last_mobile_plans[$entry['mobile_rsid']] = $entry;
				}
				$this->cmdb->free();
			}
		}
	}

	/**
	 * Returns all recorded mobile plans
	 * 
	 * @return array - All recorded mobile plans
	 */
	public function getAllMobilePlans() {
		$this->ensureMobilePlans();
		return $this->last_mobile_plans;
	}

	/**
	 * Return detail for all recorded mobile plans
	 * 
	 * @return array - detail for all recorded mobile plans
	 */
	public function getFullMobilePlanEntries() {
		$ret_plans = array();

		$table_name = self::MOBILE_PLAN_TABLE_NAME;
	
		$sql = <<<SQL
SELECT $this->sql_comment
	*
FROM $table_name
ORDER BY mobile_rsid
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['mobile_rsid'] = $this->cmdb->f('mobile_rsid');
				$entry['enable_date'] = $this->cmdb->f('enable_date');
				$entry['first_update_ts'] = $this->cmdb->f('first_update_ts');
				$entry['last_update_ts'] = $this->cmdb->f('last_update_ts');
				$ret_plans[$entry['mobile_rsid']] = $entry;
			}
			$this->cmdb->free();
		}
		return $ret_plans;
	}

	/**
	 * Returns the enable date associated with a mobile report suite
	 * 
	 * @param string $mobile_rsid - Mobile rsid for which enable date should be returned
	 * @return string - enable date recorded for the mobile report suite, if any
	 */
	public function getEnableDateByMobileRsid($mobile_rsid) {
		$this->ensureMobilePlans();
		return (array_key_exists($mobile_rsid, $this->last_mobile_plans)) ? $this->last_mobile_plans[$mobile_rsid]['enable_date'] : '';
	}

	/**
	 * Returns the mobile status for an rsid including checking the current traffic_type in user_services
	 * 
	 * @param ReportSuiteConfig - Object with report suite for which to check if mobile
	 * @return boolean - Current mobile status for the rsid
	 */
	public function isMobileRsidWithCheck(ReportSuiteConfig $rsc) {
		return $this->isMobileRsid($rsc->get_rsid()) || $this->isManagedTrafficType($rsc->get_traffic_type());
	}

	/**
	 * Returns the recorded mobile status for an rsid
	 * 
	 * @param string $rsid - Rsid for which the mobile status should be returned
	 * @return boolean - Mobile status recorded for the rsid
	 */
	public function isMobileRsid($rsid) {
		$this->ensureMobilePlans();
		return array_key_exists($rsid, $this->last_mobile_plans);
	}

	/**
	 * Returns whether or not the scheduled enable date for a mobile rsid has come
	 * 
	 * @param string $mobile_rsid - Rsid for which the schedule ready status should be returned
	 * @return boolean - Schedule ready status recorded for the rsid
	 * Note: Returns false if rsid is not a mobile rsid
	 */
	public function isScheduleReadyByMobileRsid($mobile_rsid) {
		$enable_date = $this->getEnableDateByMobileRsid($mobile_rsid);
		return (($enable_date >= self::MIN_TRANSITION_DATE) && ($enable_date <= date(MYSQL_DATE_ONLY_FORMAT)));
	}
	

	/**
	 * Returns whether or not the report suite has been enabled long enough
	 * 
	 * @param ReportSuiteConfig $rsConfig - ReportSuiteConfig object for report suite in question
	 * @return boolean - True if the report suite has been enabled long enough, False otherwise
	 * Note: Returns false if report suite's latest handler is not of type HBase
	 */
	public function isScheduleReadyForTransfer(ReportSuiteConfig $rsConfig) {		
		$vh_info = $rsConfig->get_vcookie_handler_information();
		return (VCOOKIE_HANDLER_TYPE_HBASE == $vh_info[0]['handler_type']
			&& strtotime($vh_info[0]['start_date'] . ' 23:59:59') < time() - ($this->min_hours_enabled_to_transfer*60*60));
	}

	/**
	 * Returns the best date to enable a given report suite by:
	 *   1) matching the latest date of plans for other mobile report suites from the same login company
	 *   2) using the max transition date for mobile or custom timestamped report suites if none from the same company are found
	 *    
	 * @param ReportSuiteConfig $rsc - Object with report suite for which to get the best enable date
	 * @return string - Best date to enable the given report suite
	 * NOTE: Expects that traffic_type has already been checked and that this report suite should use a mobile enable date
	 */
	private function getBestMobileEnableDate(ReportSuiteConfig $rsc) {
		$ret_best_enable_date = self::MAX_MOBILE_TRANSITION_DATE;
		$company_id = $rsc->get_companyid();
		if ($company_id) {
			$table_name = self::DETAIL_TABLE_NAME;
			
			$sql = <<<SQL
SELECT $this->sql_comment
	MAX(plan_begin_date) AS enable_date
FROM
	$table_name
WHERE
	company_id = $company_id
	AND is_mobile
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				if ($this->cmdb->next_record()) {
					$ret_best_enable_date = $this->cmdb->f('enable_date');
				}
			}
			if ('0000-00-00' == $ret_best_enable_date) {
				$ret_best_enable_date = self::MAX_MOBILE_TRANSITION_DATE;
			}
		}
		if ($this->verbose) {
			echo "Best enable date for report suite {$rsc->get_rsid()} is $ret_best_enable_date\n";
		}
		return $ret_best_enable_date;
	}

	/**
	 * Updates an entry in the mobile_plan table
	 * 
	 * @param string $mobile_rsid - Mobile report suite to update
	 * @param string $enable_date - Date report suite should be enabled to use vcookie cluster
	 * @throws Exception - Error updating mobile_plan table
	 */
	public function updateMobilePlan($mobile_rsid, $enable_date='', $force_reload=true) {
		if ($force_reload) $this->invalidateLastMobilePlans();

		if (!$enable_date) {
			$enable_date = '0000-00-00';
		}

		$table_name = self::MOBILE_PLAN_TABLE_NAME;
		$last_update_ts = date(MYSQL_DATE_FORMAT);

		$sql = <<<SQL
INSERT $this->sql_comment INTO $table_name
SET mobile_rsid='$mobile_rsid'
	,enable_date='$enable_date'
	,first_update_ts='$last_update_ts'
	,last_update_ts='$last_update_ts'
ON DUPLICATE KEY UPDATE
	mobile_rsid='$mobile_rsid'
	,enable_date='$enable_date'
	,last_update_ts='$last_update_ts'
SQL;
		if (!$this->run_query($sql, 0, MYSQL_ASSOC)) {
			throw new Exception("Error updating mobile plan entry for $mobile_rsid (DB_Error={$this->cmdb->Error} SQL=$sql)");
		}

		if (!$force_reload) {
			// Insert or update the entry in the cached list
			$this->last_mobile_plans[$mobile_rsid]['mobile_rsid'] = $mobile_rsid;
			$this->last_mobile_plans[$mobile_rsid]['enable_date'] = $enable_date;
		}
	}

	/**
	 * Forces the blacklist to be re-read from the blacklist table next time they are needed
	 */
	private function invalidateLastBlacklist() {
		$this->last_blacklist = array();
	}

	/**
	 * Caches active blacklist rsids from the blacklist table if not already cached
	 * 
	 * @param boolean $force_reload - If true, re-read the table even if the information was already cached
	 */
	private function ensureBlacklist($force_reload=false) {
		if ($force_reload) $this->invalidateLastBlacklist();

		if (!$this->last_blacklist) {
			$table_name = self::BLACKLIST_TABLE_NAME;

			$sql = <<<SQL
SELECT $this->sql_comment
	rsid
FROM $table_name
WHERE deleted_date='0000-00-00'
ORDER BY rsid
SQL;
			if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
				while ($this->cmdb->next_record()) {
					$this->last_blacklist[$this->cmdb->f('rsid')] = $this->cmdb->f('rsid');
				}
				$this->cmdb->free();
			}
		}
	}

	/**
	 * Returns all active blacklist rsids
	 * 
	 * @return array - All active blacklist rsids
	 */
	public function getAllOnBlacklist() {
		$this->ensureBlacklist();
		return $this->last_blacklist;
	}

	/**
	 * Return detail for all blacklist rsids
	 * 
	 * @return array - detail for all recorded blacklist rsids
	 */
	public function getFullBlacklistEntries() {
		$ret_blacklist = array();

		$table_name = self::BLACKLIST_TABLE_NAME;

		$sql = <<<SQL
SELECT $this->sql_comment
	*
FROM $table_name
ORDER BY rsid
SQL;
		if ($this->run_query_always($sql, 0, MYSQL_ASSOC)) {
			while ($this->cmdb->next_record()) {
				$entry = array();
				$entry['rsid'] = $this->cmdb->f('rsid');
				$entry['added_date'] = $this->cmdb->f('added_date');
				$entry['added_user'] = $this->cmdb->f('added_user');
				$entry['reason'] = $this->cmdb->f('reason');
				$entry['deleted_date'] = $this->cmdb->f('deleted_date');
				$entry['deleted_user'] = $this->cmdb->f('deleted_user');
				$ret_blacklist[$entry['rsid']] = $entry;
			}
			$this->cmdb->free();
		}
		return $ret_blacklist;
	}

	/**
	 * Returns the blacklist status for the rsid
	 * 
	 * @param string $rsid - Rsid for which the blacklist status should be returned
	 * @return boolean - Blacklist status recorded for the rsid
	 */
	public function isOnBlacklist($rsid) {
		$this->ensureBlacklist();
		return array_key_exists($rsid, $this->last_blacklist);
	}

	/**
	 * Forces the purge queue list to be re-read next time it is needed
	 */
	private function invalidateLastPurgeQueue() {
		$this->last_purge_queue = array();
		$this->cached_purge_queue = false;
	}

	/**
	 * Caches all purge queue entries for this DPC from the global_retention.purge_queue table if not already cached
	 * 
	 * @param boolean $force_reload - If true, re-read the table even if the information was already cached
	 */
	private function ensurePurgeQueue($force_reload=false) {
		if ($force_reload) $this->invalidateLastPurgeQueue();

		if (!$this->cached_purge_queue) {
			$dpc = DATA_CENTER_DPC;

			$grdb = new DB_Sql('global_retention');
			$grdb->halt_on_error = false;

			$sql = <<<SQL
SELECT $this->sql_comment
	DISTINCT username AS rsid
FROM
	purge_queue
WHERE
	datacenter='$dpc'
	AND (purge_type='frag' OR purge_type='cmonster')
SQL;
			if ($this->verbose) {
				echo "$sql\n";
			}
			if ($grdb->query($sql)) {
				while ($grdb->next_record()) {
					$this->last_purge_queue[$grdb->f('rsid')] = true;
				}
				$grdb->free();
				$this->cached_purge_queue = true;
			}
		}
	}

	/**
	 * Returns whether or not the rsid is in the data retention purge queue
	 * 
	 * @param string $rsid - Rsid for which the in purge queue status should be returned
	 * @return boolean - Whether or not the rsid is in the purge queue
	 */
	public function isInPurgeQueue($rsid) {
		$this->ensurePurgeQueue();
		return array_key_exists($rsid, $this->last_purge_queue);
	}
}
