<?
/**
 * This is a temporary logging system that will be used to log and time the
 * login process.
 * @warning THIS FILE SHOULD NOT BE REUSED FOR ANYTHING ELSE
 *
 * @author Travis Funk <travisf@omniture.com>
 * @copyright 2006 Omniture, Inc. All Rights Reserved
 * @version CVS: $Id$
 */
define('DISABLE_LOGIN_LOGGING', TRUE);

require_once 'application.inc';

/**
 * logs an entry in a database for timing of 
 * logging in to the Omniture product
 *
 * @param string $msg The text to log
 * @param string $id  A unique visitor identifier (likely company:login)
 */
function log_login ($msg, $id = '', $use_old_id = FALSE)
{
	static $db;
	static $persistent_id;
	if(DISABLE_LOGIN_LOGGING) { return; }
	if(!is_object($db)) {
		$db = new DB_Sql('loginlogdb');
	}
	if(($id && !$use_old_id) || ($id && !$persistent_id)) {
		$persistent_id = $id;
	}
	if(!trim($id) && !trim($persistent_id)) {
		$persistent_id = 'OM_CREATED:'.rand(1,100000).rand(1,100).rand(1,10000);
	}
	$table = ll_get_table_name(ll_get_date());
	list($usec, $sec) = explode(" ", microtime());
	$sql = 'INSERT INTO '.$table.' SET '.
	       'message="'.addslashes($msg).'", '.
	       'session_id="'.addslashes($persistent_id).'",'.
	       'log_time="'.date("Y-m-d H:i:s", $sec).'",'.
	       'log_time_fractional="'.($usec*100).'",'.
	       'server="'.addslashes(getenv('HOSTNAME')).'"';
	if(!$db->query($sql, 1146)) {
		if(ll_create_login_log_table($db, $table)) {
			$db->query($sql);
		}
	}
}

/**
* retrieves the table that should currently be inserted into
*
* @param int $date The date to create the new table for (format: Y-1900 m-1 d 1060502 == jun-2-2006)
*/
function ll_get_table_name ($date)
{
	
	return "login_log_".$date;
}

/**
* create the log table
*
* @param object $db    Database object
* @param string $table The name of the table to create
*/
function ll_create_login_log_table (&$db, $table)
{
	if(!$db || !$table) {
		return false;
	}
	$table_def = "CREATE TABLE ".$table." (id int unsigned not null auto_increment, 
	                                       log_time datetime,
	                                       log_time_fractional int(2) zerofill unsigned not null,
	                                       message char(255),
	                                       session_id char(255),
	                                       server char(100),          
	                                       primary key(id))";
	$db->query($table_def, 1050);
	return true;
}

/**
* retrieves current date in the correct format for creating the table
*/
function ll_get_date ()
{
	
	list($y,$m,$d) = explode('-',date("Y-m-d"));
	return sprintf("%d%02d%02d", $y-1900, $m-1, $d);
}

/**
 * gets the version of sitecatalyst based on the current URL
 */
function ll_get_sc_version ()
{
	$version = 'UNKNOWN';
	$parts = parse_url($GLOBALS['PHP_SELF']);
	$path_parts = explode('/', $parts['path']);
	if(is_array($path_parts) && count($path_parts)) {
		foreach($path_parts as $path_part)
		if(trim($path_part) != '' && strstr($path_part, '.') === FALSE) {
			$version = $path_part;
			break;
		}
	}
	return $version;
}