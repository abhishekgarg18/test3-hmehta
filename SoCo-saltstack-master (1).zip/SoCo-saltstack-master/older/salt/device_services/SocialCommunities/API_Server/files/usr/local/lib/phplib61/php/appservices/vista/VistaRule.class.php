<?php
  /*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2016 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
  /**
   Written by saurgarg Jan,2016
   Represents VISTA RULE as an entity
  */

   class VistaRule implements JsonSerializable
   {

    private $id;

    private $rsid;

    private $vistaRuleDescription;

    private $code;

    private $heapSize;

    private $compilationDate; 

    private $modifyingUser;

    private $enabled;

    private $enabledASI;

    private $enabledDiscover;

    private $enabledDataWarehouse;

    public function getId(){return $this->id;}
    public function setId($id){$this->id=$id;}

    public function getRsid(){return $this->rsid;}
    public function setRsid($rsid){$this->rsid=$rsid;}

    public function getVistaRuleDescription(){return $this->vistaRuleDescription;}
    public function setVistaRuleDescription($vistaRuleDescription){$this->vistaRuleDescription=$vistaRuleDescription;}

    public function getCode(){return $this->code;}
    public function setCode($code){$this->code=$code;}

    public function getHeapSize(){return $this->heapSize;}
    public function setHeapSize($heapSize){$this->heapSize=$heapSize;}

    public function getCompilationDate(){return $this->compilationDate;}
    public function setCompilationDate($compilationDate){$this->compilationDate=$compilationDate;}

    public function getModifyingUser(){return $this->modifyingUser;}
    public function setModifyingUser($modifyingUser){$this->modifyingUser=$modifyingUser;}

    public function getEnabled(){return $this->enabled;}
    public function setEnabled($enabled){$this->enabled=$enabled;}

    public function getEnabledASI(){return $this->enabledASI;}
    public function setEnabledASI($enabledASI){$this->enabledASI=$enabledASI;}

    public function getEnabledDiscover(){return $this->enabledDiscover;}
    public function setEnabledDiscover($enabledDiscover){$this->enabledDiscover=$enabledDiscover;}

    public function getEnabledDataWarehouse(){return $this->enabledDataWarehouse;}
    public function setEnabledDataWarehouse($enabledDataWarehouse){$this->enabledDataWarehouse=$enabledDataWarehouse;}

  	public function jsonSerialize() 
  	{
        
        if(isset($this->id))
          $arr['id']=$this->id;
        if(isset($this->rsid))
          $arr['rsid']=$this->rsid;
        if(isset($this->vistaRuleDescription))
          $arr['vistaRuleDescription']=$this->vistaRuleDescription;
        if(isset($this->code))
          $arr['code']=base64_encode($this->code);
        if($this->heapSize)
          $arr['heapSize']=$this->heapSize;
        if(isset($this->enabled))
          $arr['enabled']=$this->enabled;
        if(isset($this->enabledASI))
          $arr['enabledASI']=$this->enabledASI;
        if(isset($this->enabledDiscover))
          $arr['enabledDiscover']=$this->enabledDiscover;
        if(isset($this->enabledDataWarehouse))
          $arr['enabledDataWarehouse']=$this->enabledDataWarehouse;
        return $arr;
    }

    public function setObjectFromJson($json) 
    {
        $data = json_decode($json, true);
        $this->setObjectFromArray($data);        
    }

    public function setObjectFromArray($data) 
    {
        foreach ($data AS $key => $value) $this->{$key} = $value;
        $this->code=base64_decode($this->code);
    }

}

/* Usage Examples 
$vr=new VistaRule(); //Initialization
$vr->setHeapSize(1000); //Setting attribute
$vr->setCode("int main(){return 0;}"); //Setting code
$vr->setEnabled(TRUE); 
$vr->setEnabledASI(FALSE);
//Encoding Vista Rule to json(2 steps)
$json=json_encode($vr); 
echo $json;
//$jsonWithoutNull=preg_replace('/,\s*"[^"]+":null|"[^"]+":null,?/', '', $json);

//Converting a Json to Vista Rule object
//$vr->setObjectFromJson($jsonWithoutNull);

//echo $jsonWithoutNull;
*/

