<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2016 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once 'appservices/OM_AdminServicesAccessTokenGenerator.class.php';
require_once("appservices/OM_AppServiceBase.class.php");
require_once ("VistaRule.class.php");


/*
* Written by saurgarg 02/2016
* This class provides wrapper of Vista Rule Appservices API
*/
class VistaRuleService extends  OM_AppServiceBase {

	const MOVE_UP = 'up';
	const MOVE_DOWN = 'down';

	private function getToken()
	{
		$token_generator = new OM_AdminServicesAccessTokenGenerator();
		return $token_generator->getTokenForCurrentUser();
	}

	public function getVistaRulesByRsid($rsid)
   	{
   		$path = "/reportsuites/".urlencode($rsid)."/vista";
		$response = $this->makeAdminEndpointRequest($path, $this->getToken());
		if ($response->hasErrors()) {
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
   	}


	public function getVistaRuleByGuid($rsid,$guid)
   	{
	    $path = "/reportsuites/".urlencode($rsid)."/vista/".urlencode($guid);
		$response = $this->makeAdminEndpointRequest($path, $this->getToken());
		if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
   	}

    public function deleteVistaRuleByGuid($rsid,$guid)
    {
	    $path = "/reportsuites/".urlencode($rsid)."/vista/".urlencode($guid);
		$response = $this->makeAdminEndpointRequest($path, $this->getToken(), self::DELETE_REQUEST);
	    if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
    }

    public function updateVistaRuleByGuid($rsid,$guid,$json)
    {
	    $path = "/reportsuites/".urlencode($rsid)."/vista/".urlencode($guid);
		$response = $this->makeAdminEndpointRequest($path, $this->getToken(), self::PUT_REQUEST,$json);
		if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
    }

    public function createVistaRule($rsid,$json)
    {
	    $path = "/reportsuites/".urlencode($rsid)."/vista/";
		$response = $this->makeAdminEndpointRequest($path, $this->getToken(), self::POST_REQUEST,$json);
		if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
    }   

    public function getVistaRuleOrderByRsid($rsid)
    {
	    $path = "/reportsuites/".urlencode($rsid)."/vista/order";
		$response = $this->makeAdminEndpointRequest($path, $this->getToken());
		if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
    }

    public function setVistaRuleOrderByRsid($rsid,$json)
    {
	    $path = "/reportsuites/".urlencode($rsid)."/vista/order";
		$response = $this->makeAdminEndpointRequest($path, $this->getToken(), self::PUT_REQUEST,$json);
		if ($response->hasErrors()) 
		{
			throw new Exception($response->getErrorMessage() . " ErrorId: " . $response->getErrorId());
		}
	    return $response;
    }

    public function moveVistaRuleByGuid($rsid,$guid,$direction,$relativeOffset=1)
    {
    	$originalOrder=json_decode($this->getVistaRuleOrderByRsid($rsid)->getResponse(),true);
    	if($direction===self::MOVE_UP)
    	{
    		
    		for($i=$relativeOffset;$i<$originalOrder['totalElements'];++$i)
			{
				if($originalOrder['content'][$i]['id']===$guid)
				{	
					if(($i-$relativeOffset)<0)
					{
						throw new Exception("Invalid relativeOffset specified");
					}
					$temp=$originalOrder['content'][$i-$relativeOffset]['id'];
					$originalOrder['content'][$i-$relativeOffset]['id']=$originalOrder['content'][$i]['id'];
					$originalOrder['content'][$i]['id']=$temp;
					$inputJson=json_encode($originalOrder['content']);
		    		return $this->setVistaRuleOrderByRsid($rsid,$inputJson);
				}
			}
    	}
    	else if($direction===self::MOVE_DOWN)
    	{
    		
			for($i=0;$i<$originalOrder['totalElements']-$relativeOffset;++$i)
			{
				if($originalOrder['content'][$i]['id']===$guid)
				{
					if(($i+$relativeOffset)>=($originalOrder['totalElements']))
					{
						throw new Exception("Invalid relativeOffset specified");
					}
					$temp=$originalOrder['content'][$i+$relativeOffset]['id'];
					$originalOrder['content'][$i+$relativeOffset]['id']=$guid;
					$originalOrder['content'][$i]['id']=$temp;
					$inputJson=json_encode($originalOrder['content']);
					return $this->setVistaRuleOrderByRsid($rsid,$inputJson);	
				}
			}
    	}
    	else
    	{
    		throw new Exception("Invalid direction specified. Can be either MOVE_UP or MOVE_DOWN.");
    	}
    	
    }

    function copyRulesArraytoTarget($targetRsid,$rulesArray)
	{
		$rulesArray = array_values($rulesArray);
		for($i=0;$i<count($rulesArray);$i++)
		{
			$vr=new VistaRule();
			$vr->setVistaRuleDescription($rulesArray[$i]['vistaRuleDescription']);
			$vr->setCode(base64_decode($rulesArray[$i]['code']));
			$vr->setHeapSize($rulesArray[$i]['heapSize']);
			$vr->setEnabledASI($rulesArray[$i]['enabledASI']);
			$vr->setEnabledDiscover($rulesArray[$i]['enabledDiscover']);
			$vr->setEnabledDataWarehouse($rulesArray[$i]['enabledDataWarehouse']);
			$vr->setEnabled($rulesArray[$i]['enabled']);
			$inputJson=json_encode($vr);
			$this->createVistaRule($targetRsid,$inputJson);
			//log_report_suite_event("VISTA Rule `" . $vr->vistaRuleDescription . "` copied from RSID " . $from_user, $to_user, $admin_auth->auth['uname'], 0, 0, 10);
		}
	}

	function moveRulesArraytoTarget($sourceRsid,$targetRsid,$rulesArray)
	{
		$rulesArray = array_values($rulesArray);
		for($i=0;$i<count($rulesArray);$i++)
			{
				$vr=new VistaRule();
				$vr->rsid=$targetRsid;
				$inputJson=json_encode($vr);
				$this->updateVistaRuleByGuid($sourceRsid,$rulesArray[$i]['id'],$inputJson);
			}
	}


}
