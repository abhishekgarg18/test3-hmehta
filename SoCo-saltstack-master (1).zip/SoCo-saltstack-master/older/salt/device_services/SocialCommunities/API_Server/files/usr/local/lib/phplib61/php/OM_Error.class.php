<?
/**
 * @file 
 * OM_Error Class
 *
 * Copyright 2006 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Trenton Davies <tdavies@omniture.com>
 *
 * @version CVS: $Id: //depot/application_platform/trunk/bin/OM_Error.class.php#5 $
 **/ 



/**
 * Default Error
 **/ 
define('OM_ERROR_DEFAULT', 1);
/**
 * Any DB Error
 **/ 
define('OM_ERROR_DB', 2);
/**
 * Any error resulting from invalid input 
 */ 
define('OM_ERROR_INPUT', 4);
/**
 * Error resulting from invalid privileges or authentication. 
 */ 
define('OM_ERROR_PRIV', 8);
/**
 * Error resulting from an invalid type of request 
 */ 
define('OM_ERROR_INVALID', 16);

/**
 * Error resulting from an internal process failure
 */
define('OM_ERROR_INTERNAL', 32);

/**
 * Error resulting from environmental issues, such as files or pipes not being available
 */ 
define('OM_ERROR_ENVIRONMENT', 64);

/**
 * Base Omniture Error Object
 *
 * @author Trenton Davies
 **/
class OM_Error
{
	/**
	 * (mixed) An Error Code
	 *
	 **/
	var $code;
	
	/**
	 * (array) Backtrace Debug Data
	 *
	 **/
	var $backtrace;
	
	/**
	 * (string) The explicit error message.
	 * 
	 * Should never be client-facing.
	 **/
	var $message;
	
	/**
	 * (array) User Info (optional) 
	 */ 
	var $info=NULL;
	
	/**
	 * Constructor
	 * Takes an array of parameters, namely:
	 * - code: the Error Code associated with the error.
	 * - message: Th error message (not public facing)
	 *
	 * @param $params	(array)	An array of configuration parameters.
	 * @return void
	 **/
	function OM_Error($params=array(), $get_backtrace = true)
	{
		foreach ($params as $key => $val) {
			$this->$key = $val;
		}
		// generate a backtrace
		if (
			function_exists('debug_backtrace') &&
			$get_backtrace
		) {
			$this->backtrace = debug_backtrace();
		}
		
		// extended behavior
		$this->error();
	}
	
	/**
	 * Checks to see whether an object is of the OM_Error class.
	 * 
	 * May be called statically. 
	 * 
	 * @param $object
	 * @return boolean
	 **/
	function isError($object)
	{
		if (is_a($object, 'OM_Error')) {
			return TRUE;
		} else {
			return FALSE;
		}
	}
		
	/**
	 * Stub method for any extended behaviors
	 *
	 **/
	function error()
	{
	}
	
	/**
	 * Takes an existing OM_ERROR_* constant
	 * and maps it to a localized, public-facing
	 * error message.
	 * 
	 * @see getErrorMessage()
	 *
	 * @param $code
	 * @return string The message
	 **/
	function mapCodeToPublicErrorMessage($code=OM_ERROR_DEFAULT)
	{
		$_codeToErrorMap = array(
			OM_ERROR_DEFAULT  =>  OM_L10n::getString('lib://an-error-occurred-1', 'An error occurred.'),
			OM_ERROR_DB       =>  OM_L10n::getString('lib://encountered-a-database-error', 'Encountered a database error.'),
			OM_ERROR_INPUT    =>  OM_L10n::getString('lib://invalid-input', 'Invalid input.'),
			OM_ERROR_PRIV     =>  OM_L10n::getString('lib://invalid-privileges', 'Invalid privileges.'),
			OM_ERROR_INVALID  =>  OM_L10n::getString('lib://invalid-request', 'Invalid request.'),
			);
		return $_codeToErrorMap[$code];
	}
	
	/**
	 * Get the localized public facing error message based off the error code.
	 *
	 * @return int the error message
	 **/
	function getPublicErrorMessage()
	{
		return $this->mapCodeToPublicErrorMessage($this->code);
	}
	/**
	 * Sets the explicit error message
	 * 
	 * @see message
	 *
	 * @param $message
	 * @return void
	 **/
	function setErrorMessage($message)
	{
		$this->message = $message;
	}
	
	/**
	 * Sets the error code used to generate 
	 * the client-facing error message. 
	 * 
	 * Default is OM_ERROR_DEFAULT
	 * 
	 * @see mapCodeToPublicErrorMessage
	 *
	 * @param $code
	 * @return void
	 **/
	function setErrorCode($code=OM_ERROR_DEFAULT)
	{
		$this->code = $code;
	}
	
	/**
	 * Returns the explicit error message.
	 * This should not be used to generate client-facing errors.
	 * Use OM_Object::getErrorMessage instead.
	 * 
	 * @see OM_Object::getErrorMessage, setErrorMessage
	 *
	 * @return string The explicit error message
	 **/
	function getErrorMessage()
	{
		return $this->message;
	}
	
	/**
	 * Get the error code
	 *
	 * @return int The error code
	 **/
	function getErrorCode()
	{
		return $this->code;
	}
	
	/** Get the user info */
	function getInfo() {
		return $this->info;
	}
	
} // END class OM_Error
