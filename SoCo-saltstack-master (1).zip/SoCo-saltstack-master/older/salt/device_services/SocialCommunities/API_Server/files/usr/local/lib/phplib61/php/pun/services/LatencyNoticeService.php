<?php
require_once("pun/dao/LatencyNoticeDao.php");
require_once("pun/model/LatencyEvent.php");
require_once("pun/model/LatencyNotice.php");
require_once("pun/services/LatencyEventService.php");
require_once("pun/services/LatencyNoticeDefinitionService.php");
require_once("pun/services/NotificationService.php");
require_once("log4php/Logger.php");
require_once("reverse_userid_lookup.inc");
L4P_Logger::configure('pun/LogConfig.xml');

/**
 * The NotificationService class provides utility services for LatencyNotice objects.
 * This class is an abstraction layer class. CRUD operations and any intermediate processing for LatencyNotices should
 * be done via this service.  
 *
 */
class LatencyNoticeService
{
	private $latencyNoticeDao;
	private $latencyEventService;
	private $latencyNoticeDefService;
	private $log;
	
	/**
	 * 
	 * default constructor
	 */
	public function __construct()
	{
		$this->latencyNoticeDao = new LatencyNoticeDao();
		$this->latencyEventService = new LatencyEventService();
		$this->latencyNoticeDefService = new LatencyNoticeDefinitionService();
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * retrieves a LatencyNotice based on given id 
	 * @param int $id
	 */
	public function getLatencyNotice($id)
	{
		$latencyNotice = $this->latencyNoticeDao->getLatencyNotice($id);
		if($latencyNotice != null)
		{
			$latencyNotice->setLatencyEvents($this->latencyEventService->getLatencyEventsByNoticeId($latencyNotice->getID()));
			$noticeDef = $this->latencyNoticeDefService->getLatencyNoticeDefinition($latencyNotice->getDefId());
			
			$notificationService = new NotificationService();
			$emailText = $notificationService->getFinishedEmailText($latencyNotice,$noticeDef->getEmailFrequency());
			$latencyNotice->setEmailText($emailText);
			$latencyNotice->setSubject($notificationService->getEmailSubjectText($latencyNotice));
		}
		
		return $latencyNotice;
	}
	
	/**
	 * 
	 * Saves the given latency notice and the associated latency events
	 * 
	 * @param LatencyNotice $latencyNotice
	 */
	public function saveLatencyNotice(LatencyNotice $latencyNotice)
	{
		$notice = $this->latencyNoticeDao->saveLatencyNotice($latencyNotice);
		$events = $latencyNotice->getLatencyEvents();
		$eventService = new LatencyEventService();
		foreach($events as $event)
		{
			$event->setNoticeId($notice->getID());
			$eventService->saveLatencyEvent($event);
		} 
		return $notice;
	}
	
	/**
	 * Deletes the given latency notice and all associated latency events
	 * 
	 * @param int $noticeId
	 */
	public function deleteLatencyNotice($noticeId)
	{
		$this->latencyNoticeDao->deleteLatencyNotice($noticeId);
		$this->latencyEventService->deleteLatencyEvents($noticeId);
	}
	
	/**
	 * 
	 * Retrieves all historical LatencyNotices associated with the given rsid 
	 * @param LatencyNoticeSelector $latencyNoticeSelector The selector with search criteria
	 */
	public function getLatencyNotices($latencyNoticeSelector)
	{
		// replace username,company and billingCustomer strings with the corresponding ids. this will make sure the
		// query in the DAO uses the database indexes efficiently.
		// eg... userid_lookup($latencyNotice.getRsid()); 
		$notices = $this->latencyNoticeDao->getLatencyNotices($latencyNoticeSelector);
		foreach($notices as $notice)
		{
			$notice->setLatencyEvents($this->latencyEventService->getLatencyEventsByNoticeId($notice->getID()));
		}
		return $notices;	
	}
	
	/**
	 * Gets the timestamp of the last notification send for the given rsid
	 * 
	 * @param String $username
	 */
	public function getLastLatencyNoticeForUser($username)
	{
		$userid = userid_lookup($username);
		$this->log->debug("userid for username $username is $userid");
		$notice = $this->latencyNoticeDao->getLastLatencyNoticeForUser($userid);
		if(isset($notice))
		{
			$notice->setLatencyEvents($this->latencyEventService->getLatencyEventsByNoticeId($notice->getID()));
		}
		return $notice;	
		
	}
	
	/**
	 * Retrieves the last latencyNotice, if there is one, for the given company
	 * 
	 * @param int $companyid
	 */
	public function getLastLatencyNotice($companyid)
	{
		$notice =  $this->latencyNoticeDao->getLastLatencyNotice($companyid);	
		if(isset($notice))
		{
			$notice->setLatencyEvents($this->latencyEventService->getLatencyEventsByNoticeId($notice->getID()));
		}
		return $notice;
	}
	
	/** determines if the given company has any reports suites that are currently latent.
	 * 
	 * 
	 * @param int $companyid
	 */
	public function isCurrentlyLatent($companyid)
	{
		$notice = $this->getLastLatencyNotice($companyid);
		if(isset($notice))
		{
			$notice->setLatencyEvents($this->latencyEventService->getLatencyEventsByNoticeId($notice->getID()));
		}
		return isset($notice) && (sizeof($notice->getEventsByType(1)) > 0 || sizeof($notice->getEventsByType(2)) > 0);
	}
	
	/**
	 * Retrieves the last incident start time, if there is one, for the given company.
	 * 
	 * @param int $companyid
	 */
	public function getLastIncidentStartTime($companyid)
	{
		$notice = $this->latencyNoticeDao->getLastIncidentStartNotice($companyid);	
		return isset($notice) ? $notice->getSentTime() : NULL;
	}
	
	/**
	 * Retrieves the last incident end time, if there is one, for the given company id
	 * 
	 * @param int $companyid
	 */
	public function getLastIncidentEndTime($companyid)
	{
		$notice = $this->latencyNoticeDao->getLastIncidentEndNotice($companyid);	
		return isset($notice) ? $notice->getSentTime() : NULL;
	}
	
	
	// These last methods probably belong in the LatencyEventService
	/**
	 * determines if the given rsid is currently in a latent state 
	 * @param string $username
	 */
	public function isUserCurrentlyLatent($username)
	{
		$event = $this->latencyEventService->getMostRecentLatencyEvent($username);
		return (isset($event) && $event->getEventType() < 3) ? true : false ; // even type < 3 is latent
	}
	
	/**
	 * Gets the time of the last notification of type 1 (new latency)
	 * @param string $username
	 * @return time string or NULL if there is no last incident.
	 */
	public function getLastIncidentStartTimeForUser($username)
	{
		$event = $this->latencyEventService->getMostRecentLatencyEvent($username, 1); // type 1 is Newly Latent
		return isset($event) ? $event->getEventTime() : NULL ;
	}

	/**
	 * Gets the time of the last notification of type 3 (no longer latent)
	 * @param string $username
	 * @return time string or NULL if there is no last incident
	 */
	public function getLastIncidentEndTimeForUser($username)
	{
		$event = $this->latencyEventService->getMostRecentLatencyEvent($username, 3); // type 3 is No Longer Latent
		return isset($event) ? $event->getEventTime() : NULL ;
	}
}
