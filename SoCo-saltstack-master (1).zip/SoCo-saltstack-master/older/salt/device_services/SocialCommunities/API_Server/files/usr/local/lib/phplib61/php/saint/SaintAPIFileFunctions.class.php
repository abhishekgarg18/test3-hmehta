<?php

require_once("application.inc");
require_once("account_superstats.class");
require_once(SC_DIR . "/reports/includes/object_functions.inc");
require_once("ftp.class");
require_once("hostname.inc");
require_once 'error_utils.inc';
require_once SAINT_PROCESS_DIR . '/includes/file/SaintTabFileParser.class.php';
require_once SAINT_PROCESS_DIR . '/includes/file/SaintTabFileWriter.class.php';

class SaintAPIFileFunctions
{
	const SEGMENT_BASE_PATH = '/nfs/saintapi/segments';

	private $nfs_path = '/nfs/saintapi/';
	private $error_array = array();
	private $row_parse_buffer = array();

	function commitImportFile($job_id)
	{
		if($this->canAddSegment($job_id) && $this->checkImportPages($job_id))
		{
			$db = new DB_Sql("masterdb");
			$sql = "update saint_api_files set status_code = 1 where api_id = $job_id and file_type = 'upload'";
			$db->squery($sql);
		}

	}

	function checkImportPages($job_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select segment from saint_api_files f join saint_api_file_segments s on f.file_id = s.file_id and f.file_type = 'upload' and f.api_id = $job_id order by segment";
		$db->query($sql);

		$count = 0;
		while($db->next_record())
		{
			$segment = $db->f('segment');

			if($segment != $count)
			{
				$this->add_error(sprintf(OM_L10n::getString('lib://missing-segment-count','Missing Segment %s.'), $count));
				return false;
			}
			$count++;
		}

		if($count == 1)
		{
			$this->add_error(OM_L10n::getString('lib://no-data-segments-in-job','No data segments in Job.'));
			return false;
		}
		return true;
	}

	function writeHeaders($header, $path, $filename, $file_header, $enclosed_by = '', $delimited_by = "\t", $terminated_by = "\n")
	{
		$fullpath = $path . $filename;
		$fh = @fopen($fullpath, 'w');
		if (!$fh) {
			// There was a problem opening this file!
			$host = get_hostname();
			$this->add_error(OM_L10n::getString('lib://an-error-was-encountered','An error was encountered. Please try again.'));
			DispatchMsg("SAINT_WEB_API", "writeHeaders($header, $path, $filename, $file_header, )\nfopen($fullpath, 'w'): failed to open stream: Permission denied on server $host", "$host: SAINT API: writeHeaders permission denied.");
			return false;
		}
		$count = 0;

		fwrite($fh, $file_header);

		foreach ($header as $k => $v)
		{
			$count++;
			$item = $enclosed_by . $v . $enclosed_by;
			if ($count < count($header))
			{
				$item = $item . $delimited_by;
			}
			else
			{
				$item = $item . $terminated_by;
			}
			fwrite($fh, $item);
		}
		fclose($fh);
		return true;
	}

	static function addFileRecord($job_id, $local_filename, $local_file_path, $file_type, $status_code = 0)
	{
		$full_path = $local_file_path . $local_filename;

		$host = get_hostname();

		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_files set api_id = $job_id, filename = '$local_filename', file_path = '$local_file_path', file_type = '$file_type', status_code = $status_code, hostname = '$host', date_recieved = now()";

		$db->squery($sql);
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			return $db->f('id');
		}
		else
		{
			return false;
		}
	}

	static function createFileRecord($job_id, $local_filename, $local_file_path, $file_type, $status_code = 0)
	{
		$host = get_hostname();

		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_files set api_id = $job_id, file_path = '$local_file_path', file_type = '$file_type', status_code = $status_code, hostname = '$host', date_recieved = now()";

		$db->squery($sql);
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			$file_id = $db->f('id');

			$filename = $job_id . "_" . $file_id . "_" . $local_filename;

			$sql = "update saint_api_files set filename = $filename where file_id = $file_id";
			$db->squery($sql);

			return $file_id;
		}
		else
		{
			return false;
		}
	}

	function getImportFileID($job_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select file_id from saint_api_files where api_id = $job_id and file_type = 'upload'";
		$db->squery($sql);
		$file_id = $db->f('file_id');
		return $file_id;
	}

	function saveFileHeader($job_id, $segment, $header, $file_path, $report_suites)
	{
		//TODO:Query to check if file can recieve more pages. Is main file > status 0?
		$file_header = $this->get_header($report_suites);
		$file_name = $job_id . "_" . $segment . "_SaintImportSegment.tab";
		$this->writeHeaders($header, $file_path, $file_name, $file_header);
		$this->addFileSegmentRecord($this->getImportFileID($job_id), 0, $file_path, $file_name,  get_hostname());
	}

	private function canAddSegment($job_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select status_code from saint_api_files where api_id = $job_id and file_type = 'upload'";
		$db->squery($sql);
		$c = $db->f('status_code');

		if($c == 0)
		{
			return true;
		}
		$this->add_error(OM_L10n::getString('lib://cannot-commit-a-committed-job','Cannot commit a job that has already been committed.'));
		return false;
	}

	function saveFileSegment($job_id, $segment, $rows, $file_path, $host = 0)
	{
		//TODO:Hostname not populating from web-server.
		if($this->canAddSegment($job_id))
		{
			$file_name = $job_id . "_" . $segment . "_SaintImportSegment.tab";

			if ($this->writeFileSegment($rows, $file_path, $file_name)) {
				$this->addFileSegmentRecord($this->getImportFileID($job_id), $segment, $file_path, $file_name, "NFS");
			} else {
				// There was a problem opening this file!
				$host_name = get_hostname();
				$this->add_error(OM_L10n::getString('lib://unable-to-save-file-segment','Unable to save the file segment. Please try again later.'));
				DispatchMsg("SAINT_WEB_API", "saveFileSegment($job_id, $segment, ...)\nwriteFileSegment(\$rows, $path, $filename, ...)\nfopen({$path}$filename, 'w'): failed to open stream: Permission denied on server $host_name", "$host_name: SAINT API: writeFileSegment permission denied.");
			}
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://cannot-add-data-page-to-import-request','Cannot add a data page to a commited Import Request.'));
		}
	}

	function writeFileSegment($rows, $path, $filename, $enclosed_by = '"', $delimited_by = "\t", $terminated_by = "\n")
	{
		//TODO:Update Database.
		//TODO:" Handlers.
		$fullpath = $path . $filename;
		$fh = @fopen($fullpath, 'w');
		if (!$fh) {
			// There was a problem opening this file!
			return false;
		}
		// Rows
		foreach($rows as $k => $v)
		{
			foreach($v as $sk => $sv)
			{
				$count = 0;
				$s = count($sv);
				foreach($sv as $ssk => $ssv)
				{
					$count++;
					$ssv = str_replace('"', '""', $ssv);

					$enclose_exclude = array('','~autogen~','~none~','~hash~','~empty~','~deletekey~','::unspecified::','::uniques_exceeded::','~uniques exceeded~');

					$enclose = true;
					foreach($enclose_exclude as $ek => $ev)
					{
						if($ssv == $ev)
						{
							$enclose = false;
						}
					}

					if($enclose)
					{
						$item = $enclosed_by . $ssv . $enclosed_by;
					}
					else
					{
						$item = $ssv;
					}
					if($count < count($sv))
					{
						$item = $item . $delimited_by;
					}
					else
					{
						$item = $item . $terminated_by;
					}

					fwrite($fh, $item);
				}
			}
		}
		fclose($fh);
		return true;
	}

	public function addFileSegmentRecord($file_id, $segment, $file_path, $file_name, $host)
	{
		$db = new DB_Sql("masterdb");

		$sql = "insert into saint_api_file_segments set
		file_id = $file_id,
		segment = $segment,
		hostname = '$host',
		filename = '$file_name',
		file_path = '$file_path',
		file_size = '$file_size',
		date_recieved = NOW()
		on duplicate key update hostname = '$host', file_path = '$file_path', date_recieved = NOW()";

		$db->squery($sql);
		if($db->affected_rows() > 0)
		{
			$sql = "select LAST_INSERT_ID() id from dual";
			$db->squery($sql);
			return $db->f('id');
		}
		else
		{
			return false;
		}
	}

	function add_error($error_string)
	{
		// Adds an error to the errors array.
		$this->error_array[] = $error_string;
	}

	function buildFileList($file_id)
	{
		$filenames = array();

		$db = new DB_Sql("masterdb");
		$sql = "select filename from saint_api_file_segments where file_id = $file_id order by segment";

		$db->query($sql);
		while($db->next_record())
		{
			$filename = $db->f('filename');
			$filenames[] = $filename;
		}
		return $filenames;

	}

	function buildFile($file, $file_id, $local_host)
	{

		$filenames = $this->buildFileList($file_id);

		$write_file = $this->nfs_path . $file;
		$this->assembleParts($filenames, $write_file);

		return $this->updateFileStatus($file_id, $file_name, 2, get_hostname(), $this->nfs_path);

	}

	static function updateFileStatus($file_id, $file_name, $status_code, $host, $path)
	{
		$file = $path . $file_name;
		$fsize = filesize($file);

		$db = new DB_Sql("masterdb");
		$sql = "update saint_api_files set status_code = $status_code, hostname = '$host', file_path = '$path', file_size = $fsize where file_id = $file_id";

		$db->query($sql);

		if($fsize)
		{
			return true;
		}
	}

	static function updateFileStatusOnly($file_id, $status_code)
	{
		$db = new DB_Sql("masterdb");
		$sql = "update saint_api_files set status_code = $status_code where file_id = $file_id";
		$db->query($sql);
	}

	function assembleParts($filenames, $file)
	{
		$write_file = $this->nfs_path . $file;

		$fh = @fopen($write_file, 'w');
		if (!$fh) {
			// There was a problem opening this file!
			$host = get_hostname();
			$this->add_error(OM_L10n::getString('lib://unable-to-assemble-parts','Unable to assemble parts. Please try again.'));
			DispatchMsg("SAINT_WEB_API", "assembleParts(\$filenames, $file)\nfopen($write_file, 'w'): failed to open stream: Permission denied on server $host", "$host: SAINT API: assembleParts permission denied.");
			return;
		}

		foreach ($filenames as $k => $f)
		{
			$read_file = $this->nfs_path . $f;
			$handle = @fopen($read_file, "rb");
			if ($handle)
			{
				while (!feof($handle))
				{
					$buffer .= fgets($handle, 4096);
				}
				fclose($handle);
				fwrite($fh, $buffer);
				unset($buffer);
			} else {
				// There was a problem opening this file!
				fclose($fh);
				$host = get_hostname();
				$this->add_error(OM_L10n::getString('lib://still-missing-parts','Still missing parts. Please try again.'));
				DispatchMsg("SAINT_WEB_API", "assembleParts(\$filenames, $file)\nfopen($read_file, 'rb'): failed to open stream on server $host", "$host: SAINT API: assembleParts could not open a read file.");
				return false;
			}
		}
		fclose($fh);
		return true;
	}

	function writeParts($filenames, $path)
	{
		$fh = @fopen($path, 'w');
		if (!$fh) {
			// There was a problem opening this file!
			$host = get_hostname();
			$this->add_error(OM_L10n::getString('lib://unable-to-assemble-parts','Unable to assemble parts. Please try again.'));
			DispatchMsg("SAINT_WEB_API", "writeParts(\$filenames, $path)\nfopen($path, 'w'): failed to open stream: Permission denied on server $host", "$host: SAINT API: writeParts permission denied.");
			return;
		}

		foreach ($filenames as $k => $f)
		{
			$read_file = $this->nfs_path . $f;
			$handle = @fopen($read_file, "rb");
			if ($handle)
			{
				while (!feof($handle))
				{
					$buffer .= fgets($handle, 4096);
				}
				fclose($handle);
				fwrite($fh, $buffer);
				unset($buffer);
			} else {
				// There was a problem opening this file!
				fclose($fh);
				$host = get_hostname();
				$this->add_error(OM_L10n::getString('lib://still-missing-parts','Still missing parts. Please try again.'));
				DispatchMsg("SAINT_WEB_API", "writeParts(\$filenames, $path)\nfopen($read_file, 'rb'): failed to open stream on server $host", "$host: SAINT API: writeParts could not open a read file.");
				return false;
			}
		}
		fclose($fh);
		return true;
	}

	function get_errors()
	{
		return $this->error_array;
	}

	function get_last_error_string()
	{
		return $this->error_array[(count($this->error_array)-1)];
	}

	function run_command($command, &$message)
	{
		exec($command, $output, $result);

		$message = implode('\n', $output);
		return $result;
	}

	function get_header($report_suite_array)
	{
		$rsids = implode('*', $report_suite_array);
		$date = date( 'Y/m/d H:i:s',mktime(date('H'),date('i'),date('s'),date('m'),date('d'),date('Y')) );
		$header = "## SC	SiteCatalyst SAINT Import File	v:2.1	\n";
		$header .= "## SC	'## SC' indicates a SiteCatalyst pre-process header. Please do not remove these lines.		\n";
		$header .= "## SC	D:$date	RS:$rsids\n";
		return $header;
	}

	function enter_utf_8_mode() {
		$this->orig_locale = setlocale( LC_CTYPE, 0);
		$loc = $this->orig_locale.'.UTF-8';//"en_US.UTF-8";
		$this->orig_env_locale = getenv('LANG');
		$loc = setlocale( LC_CTYPE, $loc);
		if ($loc != 'C' && $loc != 'c' && $loc != $this->orig_locale.'.UTF-8') {
			$loc = "en_US.UTF-8";
			$loc = setlocale( LC_CTYPE, $loc);
		}
		putenv("LANG=$loc");
		if ($GLOBALS['loki']['dev_template'])
		echo "Curr local: {$this->orig_locale} New local: $loc<br>";
	}

	function exit_utf_8_mode() {
		setlocale( LC_CTYPE, $this->orig_locale);
		putenv("LANG={$this->orig_env_locale}");
		if ($GLOBALS['loki']['dev_template'])
		echo "Restored locale: {$this->orig_locale}<br>\n";
	}

	function check_for_version($buf, &$version)
	{
		if (strpos($buf, '## SC') === 0) {
			//print "found SC tag\n";
			$pos = strpos($buf, "\tv:");
			//print "pos: $pos\n";
			if ($pos !== false) {
				//print "found ver tag\n";
				$version = (substr($buf, $pos+3)) + 0;
				//print "Version found: $version\n";
			}
			return true;
		}
		else {
			return false;
		}
	}

	function get_non_quoted_row_data($buf)
	{
		$row_data = explode("\t", $buf);
		// clean up data

		//print_r($row_data);
		foreach ($row_data as $i => $p) {
			if ($i == 0) { // the key is always the first element
				// cleanup data (allow whitespace in front of keys,
				// but not behind. matches what the rest of the system allows
				$row_data[$i] = rtrim($p);
			}
			else {
				// all other values are trimmed completely
				$row_data[$i] = trim($p);
			}
		}
		return $row_data;
	}

	function getQuotedRowData($buf, $ending, &$fp) {
		$row_data = array();
		$inQ = false;
		$currInd = 0;
		$row_data[$currInd] = '';
		//	echo "<pre>";
		do {
			$row = explode("\t", $buf);
			//print_r($row);
			foreach ($row as $i => $cell) {
				$len = strlen($cell);
				if ($len == 1) {
					if ($cell == '"') {
						$inQ = $inQ ? false : true; // Toggle
						$cell = '';
					}
				} else if ($len == 0) {
				} else if ($inQ) {
					// We are in a quoted cell
					if ($this->hasEndQuote($cell, $len, $inQ)) {
						$inQ = false;
						$cell = substr($cell, 0, -1);
					}
					// Convert double quotes
					$cell = str_replace('""', '"', $cell);
				} else if ($cell{0} == '"') {
					if (!$this->hasEndQuote($cell, $len, $inQ)) {
						$inQ = true;
					}
					$cell = substr($cell, 1, $inQ ? $len : -1);
					// Convert double quotes
					$cell = str_replace('""', '"', $cell);
				} else {
					$cell = $currInd == 0 ? rtrim($cell) : trim($mm);
				}
				// If we are in a quoted cell, append the cell to the previous data
				if ($inQ) {
					$row_data[$currInd] = $row_data[$currInd] . $cell . "\t";
				} else {
					// Move on to the next cell
					$row_data[$currInd++] .= $cell;
					$row_data[$currInd] = ''; // If we just finished, we will remove this index
				}
			}
			if ($inQ && !feof($fp)) {
				$row_data[$currInd] .= $ending;
				$buf = fgets($fp, 4096);
				$len = strlen($buf);
				$ending = ($len > 2 && $buf[$len-2] == "\r" ? $buf[$len-2] : '') . ($len > 1 ? $buf[$len-1] : '');
				$buf = rtrim($buf);
				//echo "Line:$buf " . str_replace(array("\t", "\n", "\r"), array("\\t", "\\n", "\\r"), $ending) . "<br>";
			} else {
				$inQ = false;
			}
		} while ($inQ);
		if (empty($row_data[$currInd])) unset($row_data[$currInd]);
		return $row_data;
	}

	function hasEndQuote($buf, $len, $inQ) {
		$c = $inQ ? 0 : 1;
		$cnt = 0;
		for ($i = $len-1; $i >= $c; $i--) {
			if ($buf{$i} == '"') {
				$cnt++;
			} else {
				break;
			}
		} // for
		return ($cnt > 0 && ($cnt & 1) == 1);
	}

	function readSaintExportFile($file_id, $segment_id)
	{
		$db = new DB_Sql("masterdb");
		$sql = "select filename, file_path from saint_api_file_segments where file_id = $file_id and segment = $segment_id";
		$db->squery($sql);

		$file_name = $db->f('filename');
		$file_path = $db->f('file_path');
		if (substr($file_path,-1) == '/') {
			$segment_file_name = $file_path . $file_name;
		} else {
			$segment_file_name = $file_path . '/' . $file_name;
		}
		$data = $this->parseSaintFile($segment_file_name);
		return $data;
	}

	public function parseSaintFile($filename, $segment_file = false, $segment_rows = -1, $file_id = '', $file_path = '', $export_file_name = '')
	{
		$rows_per_page = $segment_rows <= 0 ? 20000 : $segment_rows;
		$this->row_parse_buffer = array();

		$parser = new SaintTabFileParser($filename);
		$parser->setNumRowsToEmit($rows_per_page)
		       ->setCallbackOptions(array('file_id' => $file_id, 'file_path' => $file_path, 'file_base' => $export_file_name));
		if ($segment_file) {
			$parser->setRowEmitCallback(array($this, 'segmentSaintFileCallback'));
		} else {
			$parser->setRowEmitCallback(array($this, 'parseSaintFileCallback'));
		}

		try {
			if (!$parser->parse()) {
				$this->add_error(sprintf('Unable to parse file %s for file_id %s', $filename, $file_id));
				return false;
			}
		} catch (Exception $e) {
			$message = sprintf("segmentSaintFileCallback() caught error on file_id=%s, filename=%s, host=%s, exception=%s", $file_id, $filename, get_hostname(), $e->__toString());
			$this->add_error($message);
			return false;
		}	

		if (!$segment_file) {
			return $this->row_parse_buffer;
		} 
		return true;
	}

	public function parseSaintFileCallback(SaintTabFileParser $parser, array $header, array $rows) {
		if (is_array($this->row_parse_buffer) && count($this->row_parse_buffer) > 0) {
			$this->row_parse_buffer = array_merge($this->row_parse_buffer, $rows);
		} else {
			$this->row_parse_buffer = array_merge(array($header), $rows);
		}
	}

	public function segmentSaintFileCallback(SaintTabFileParser $parser, array $header, array $rows) {
		$options = $parser->getCallbackOptions();
		$filename = sprintf("%s_%s_%s",
			$options['file_id'],
			$parser->getPageNumber(),
			$options['file_base']
		);
		$fullpath = sprintf("%s/%s", $options['file_path'], $filename);
		$userid = '0';
		$rel_id = '0';

		$writer = new SaintTabFileWriter($fullpath);
		$writer->setQuoted(true); // we always produced quoted files because they are deterministally parsable
		$writer->writeHeaders($header, $userid, $rel_id);
		$writer->writeRows($rows);
		$writer->close();

		$this->addFileSegmentRecord($options['file_id'], $parser->getPageNumber(), $options['file_path'], $filename, get_hostname());
	}
}
