<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property laws,
 * including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

class SkmsWebApiClient {
	// Version Constants
	const CLIENT_TYPE = "php5.curl";
	const CLIENT_VERSION = "1.3";
	
	// Protected Properties
	protected $ch;
	protected $client_hostname = '';
	protected $client_script = '';
	protected $client_username = '';
	protected $debug = false;
	protected $error_message = '';
	protected $passkey = '';
	protected $request_timeout = 25;
	protected $response_arr = null;
	protected $response_header = '';
	protected $response_str = '';
	protected $skms_csrf_token = null;
	protected $skms_domain = 'api.skms.adobe.com';
	protected $skms_session_storage_file = null;
	protected $skms_session_id = null;
	protected $status = false;
	protected $trusted_cert_file_path = "";
	protected $username = '';
	protected $verify_ssl_chain = true;

	
	//---------------//
	//   CONSTRUCT   //
	//---------------//
	/**
	 * This is the construct method. It can be passed the username, passkey, and skms_domain settings.
	 * @param string $username The username to use to login to the SKMS Web API
	 * @param string $passkey The passkey to use to login to the SKMS Web API
	 * @param string $skms_domain The hostname of the SKMS that will be accessed
	 */
	public function __construct($username, $passkey, $skms_domain = null) {
		$this->username = $username;
		$this->passkey = $passkey;
		if(!is_null($this->skms_domain)) {
			$this->skms_domain = $skms_domain;
		}
		
		// Set Tracking Info
		$this->client_script = ( isset($_SERVER['PHP_SELF']) ? $_SERVER['PHP_SELF'] : __FILE__ );
		$this->client_hostname = ( isset($_SERVER['HOSTNAME']) ? $_SERVER['HOSTNAME'] : '' );
		$this->client_username = ( isset($_SERVER['USER']) ? $_SERVER['USER'] : '' );
		
		// Try to enable session optimization
		if(trim($username) != '') {
			$home_dir = ( isset($_SERVER['HOME']) && trim($_SERVER['HOME']) != '' ? trim($_SERVER['HOME']) . '/' : '/home/' . $this->client_username . '/' );
			if(!file_exists($home_dir)) {
				return;
			}
			$skms_dir = $home_dir . '.skms/';
			if(!file_exists($skms_dir)) {
				if(!mkdir($skms_dir)) {
					return;
				}
				if(!file_exists($skms_dir)) {
					return;
				}
				if(!chmod($skms_dir, 0700)) {
					return;
				}
			}
			$this->enableSkmsSessionOptimization($skms_dir . 'sess_' . trim($username) . '.json');
		}
	}
	
	//---------------------------//
	//   CONFIGURATION METHODS   //
	//---------------------------//
	/**
	 * Enables the debug mode which will return debug information with all messages.
	 */
	public function enableDebugMode() {
		$this->debug = true;
	}
	/**
	 * Disables the debug mode which will return debug information with all messages.
	 */
	public function disableDebugMode() {
		$this->debug = false;
	}
	/**
	 * Returns the current request timeout setting
	 * @return int
	 */
	public function getRequestTimeout() {
		return $this->request_timeout;
	}
	/**
	 * Sets the request timeout setting
	 * @param int $timeout
	 */
	public function setRequestTimeout($timeout) {
		if(is_int($timeout) && $timeout > 0) {
			$this->request_timeout = $timeout;
		}
	}
	/**
	 * Enables Skms Session Optimization by storing session information in a local file that will be reused in future requests.
	 * @param string $skms_session_storage_file The path to the file where session information should be stored.
	 */
	public function enableSkmsSessionOptimization($skms_session_storage_file) {
		// Try to load file
		if(file_exists($skms_session_storage_file)) {
			$file_contents = file_get_contents($skms_session_storage_file);
			if($file_contents !== false) {
				$session_info = json_decode($file_contents, true);
				if(is_array($session_info) && isset($session_info['skms_session_id']) && trim($session_info['skms_session_id']) != "") {
					$this->setSkmsSessionId($session_info['skms_session_id']);
				}
				if(is_array($session_info) && isset($session_info['skms_csrf_token']) && trim($session_info['skms_csrf_token']) != "") {
					$this->setSkmsCsrfToken($session_info['skms_csrf_token']);
				}
			}
		}
		$this->skms_session_storage_file = $skms_session_storage_file;
	}
	/**
	 * Returns the SKMS session id returned from the last request. Returns false if there is no session id.
	 * @return string|bool The session_id or bool false
	 */
	public function getSkmsSessionId() {
		return ( !is_null($this->skms_session_id) ? $this->skms_session_id : false );
	}
	/**
	 * Sets the SKMS session id
	 * @param string The SKMS session id
	 */
	public function setSkmsSessionId($skms_session_id) {
		if(trim($skms_session_id) != "") {
			$this->skms_session_id = $skms_session_id;
		}
	}
	/**
	 * Returns the latest SKMS CSRF Token. Returns false if there is no CSRF token.
	 * @return string|bool The CSRF token or bool false
	 */
	public function getSkmsCsrfToken() {
		return ( !is_null($this->skms_csrf_token) ? $this->skms_csrf_token : false );
	}
	/**
	 * Sets the SKMS CSRF Token
	 * @param string The CSRF Token
	 */
	public function setSkmsCsrfToken($skms_csrf_token) {
		$this->skms_csrf_token = $skms_csrf_token;
	}
	/**
	 * Sets the path to the CA file to use for SSL peer/chain verification
	 * @param string $trusted_cert_file_path
	 */
	public function setTrustedCertFilePath($trusted_cert_file_path) {
		if(trim($trusted_cert_file_path) != "") {
			$this->trusted_cert_file_path = $trusted_cert_file_path;
		} else {
			$this->trusted_cert_file_path = "";
		}
	}
	/**
	 * Enables SSL Chain Verification
	 */
	public function enableSslChainVerification() {
		$this->verify_ssl_chain = true;
	}
	/**
	 * Disables SSL Chain Verification
	 */
	public function disableSslChainVerification() {
		$this->verify_ssl_chain = false;
	}
	
	//---------------------//
	//   REQUEST METHODS   //
	//---------------------//
	/**
	 * Sends a request based on the passed in request_method, resource_name, and param_array
	 * @param string $object_name The name of the object to access via the API. 
	 * @param string $resource_name The name of the method to access via the API.
	 * @param array $method_params An associative array of key/value pairs that represent parameters that will be passed to the method
	 * @return bool True on success, false on error.
	 */
	public function sendRequest($object_name, $method_name, $method_params = null) {
		// Reset Properties
		$this->error_message = '';
		$this->response_header = '';
		$this->response_str = '';
		$this->response_arr = null;
		
		// Make sure Var Array is an array
		if(!is_array($method_params)) {
			$method_params = Array();
		}
		
		// Check to see if debug flag should be passed
		if($this->debug) {
			$method_params['_debug'] = true;
		}
		
		// Tracking Data
		$method_params['_client_type'] = SkmsWebApiClient::CLIENT_TYPE;
		$method_params['_client_ver'] = SkmsWebApiClient::CLIENT_VERSION;
		$method_params['_client_script'] = $this->client_script;
		$method_params['_client_hostname'] = $this->client_hostname;
		$method_params['_client_username'] = $this->client_username;
		
		// Username and Passkey
		if(trim($this->username) != "" && trim($this->passkey) != "") {
			$method_params['_username'] = $this->username;
			$method_params['_passkey'] = $this->passkey;
		}
		
		$method_params['_object'] = $object_name;
		$method_params['_method'] = $method_name;
		
		// Set URL
		$this->ch = curl_init("https://" . $this->skms_domain . "/web_api/");
		
		// Add Session Cookie (if applicable)
		if(!is_null($this->skms_session_id) && trim($this->skms_session_id) != "") {
			$cookie_name = 'SkmsSID';
			if(preg_match('/\.dev\.skms/i', $this->skms_domain)) {
				$cookie_name = 'dev_' . $cookie_name;
			}
			curl_setopt($this->ch, CURLOPT_COOKIE, $cookie_name . "=" . urlencode($this->skms_session_id) . ";");
		}
		// Add CSRF token to param array (if applicable)
		if(!is_null($this->skms_csrf_token) && trim($this->skms_csrf_token) != "") {
			$method_params['csrf_token'] = $this->skms_csrf_token;
		}
		
		// Configure Settings for POST 
		curl_setopt($this->ch, CURLOPT_POST, true);
		curl_setopt($this->ch, CURLOPT_POSTFIELDS, $this->convertParametersToPostFields($method_params));
		curl_setopt($this->ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($this->ch, CURLOPT_HEADER, true);
		if(trim($this->trusted_cert_file_path) != "") {
			curl_setopt($this->ch, CURLOPT_CAINFO, $this->trusted_cert_file_path);
		}
		curl_setopt($this->ch, CURLOPT_SSL_VERIFYPEER, $this->verify_ssl_chain);
		curl_setopt($this->ch, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt($this->ch, CURLOPT_TIMEOUT, $this->request_timeout);
		$response_str = curl_exec($this->ch);
		
		// Separate header from body
		$header_len = curl_getinfo($this->ch, CURLINFO_HEADER_SIZE);
		$this->response_header = substr($response_str, 0, $header_len);
		$this->response_str = substr($response_str, $header_len);
		
		// Pull Out Session Cookie and CSRF Token from header
		if(preg_match_all('/Set-Cookie: (?:dev_)?SkmsSID=([^;]+);/', $this->response_header, $sid_matches)) {
			if(isset($sid_matches[1]) && is_array($sid_matches[1]) && count($sid_matches[1]) > 0) {
				$this->skms_session_id = $sid_matches[1][count($sid_matches[1]) - 1];
			} else {
				$this->skms_session_id = null;
			}
		} else {
			// Don't reset if the cookie wasn't passed
		}
		if(preg_match_all('/Set-Cookie: (?:dev_)?csrf_token=([^;]+);/', $this->response_header, $csrf_matches)) {
			if(isset($csrf_matches[1]) && is_array($csrf_matches[1]) && count($csrf_matches[1]) > 0) {
				$this->skms_csrf_token = $csrf_matches[1][count($csrf_matches[1]) - 1];
			} else {
				$this->skms_csrf_token = null;
			}
		} else {
			// Don't reset if the cookie wasn't passed
		}
		
		// Check for session storage
		if(!is_null($this->skms_session_storage_file)) {
			// Check if File Exists
			if(!file_exists($this->skms_session_storage_file)) {
				$populate_session_file = touch($this->skms_session_storage_file);
				if($populate_session_file) {
					$populate_session_file = chmod($this->skms_session_storage_file, 0600);
				}
			} else {
				$populate_session_file = true;
			}
			
			if($populate_session_file) {
				// Populate File
				$session_info = Array(
					'skms_session_id' => $this->skms_session_id,
					'skms_csrf_token' => $this->skms_csrf_token,
				);
				$session_info_str = json_encode($session_info);
				if($session_info_str !== false) {
					file_put_contents($this->skms_session_storage_file, $session_info_str);
				}
			}
		}
		
		// Check for CURL Error
		$error_number = curl_errno($this->ch);
		if($error_number > 0) {
			// CURL Error
			$this->error_message = 'CURL reported error #' . $error_number . ' - ' . curl_error($this->ch);
			curl_close($this->ch);
			return false;
		}
		
		// Check Response Status
		$response_arr = $this->getResponseArray();
		if($response_arr === false) {
			$this->error_message = 'Unable to JSON decode the response string.';
			return false;
		}
		if(is_array($response_arr) && isset($response_arr['status']) && trim($response_arr['status']) != "") {
			$status = $response_arr['status'];
		} else {
			if(!is_array($response_arr)) {
				$response_arr = Array();
			}
			$status = 'unknown';
		}
		if(strtolower($status) == "success") {
			curl_close($this->ch);
			return true;
		} else {
			// Pull out error messages
			$error_message_arr = $this->getErrorMessageArray();
			if(count($error_message_arr) > 1) {
				$this->error_message = "The API returned " . count($error_message_arr) . " error messages:\n";
				foreach($error_message_arr as $array_key => $error_message) {
					$this->error_message .= ($array_key + 1) . '. ' . $error_message['message'] . "\n";
				}
			} else if(count($error_message_arr) == 1) {
				$this->error_message = $error_message_arr[0]['message'];
			} else {
				$this->error_message = 'The status was returned as "' . $status . '" but no errors were in the messages array.';
			}
			curl_close($this->ch);
			return false;
		}
	}
	/**
	 * Returns the response header of the last request.
	 * @return string
	 */
	public function getResponseHeader() {
		return $this->response_header;
	}
	/**
	 * Returns the response string of the last request.
	 * @return string
	 */
	public function getResponseString() {
		return $this->response_str;
	}
	/**
	 * Returns an associative array that was created by decoding the returned JSON. If the JSON could not be decoded, false will be returned.
	 * @return array|bool The decoded array or bool false
	 */
	public function getResponseArray() {
		if(is_null($this->response_arr)) {
			$response_str = $this->getResponseString();
			$this->response_arr = json_decode($response_str, true);
			if(is_null($this->response_arr)) {
				return false;
			}
		}
		return $this->response_arr;
	}
	/**
	 * Returns the 'status' field from the response if it can be found. Otherwise, a blank string is returned.
	 * @return string|bool The status string or bool false
	 */
	public function getResponseStatus() {
		$response_arr = $this->getResponseArray();
		if(is_array($response_arr) && isset($response_arr['status'])) {
			return $response_arr['status'];
		} else {
			return "";
		}
	}
	/**
	 * Returns the 'data' array from the response if it can be found. Otherwise, an empty array is returned.
	 * @return array
	 */
	public function getDataArray() {
		$response_arr = $this->getResponseArray();
		if(is_array($response_arr) && isset($response_arr['data'])) {
			return $response_arr['data'];
		} else {
			return Array();
		}
	}
	/**
	 * Returns the 'error_type' field from the response if it can be found. Otherwise, false is returned.
	 * @return string|bool The error_type string or bool false
	 */
	public function getErrorType() {
		$response_arr = $this->getResponseArray();
		if(is_array($response_arr) && isset($response_arr['error_type'])) {
			return $response_arr['error_type'];
		} else {
			return false;
		}
	}
	/**
	 * Returns the error message from the last request. Will be an empty string if there was no error.
	 * @return string
	 */
	public function getErrorMessage() {
		return $this->error_message;
	}
	/**
	 * Returns an array of messages based on the passed in type. If a blank string is passed in, all message are returned.
	 * @param string $type
	 * @return array
	 */
	public function getMessageArrayByType($type = '') {
		$ret_arr = Array();
		$response_arr = $this->getResponseArray();
		if(is_array($response_arr) && isset($response_arr['messages']) && is_array($response_arr['messages']) && count($response_arr['messages']) > 0) {
			foreach($response_arr['messages'] as $message) {
				if(trim($type) == "" || strtolower(@$message['type']) == strtolower($type)) {
					$ret_arr[] = $message;
				}
			}
		}
		return $ret_arr;
	}
	/**
	 * Returns an array of messages where type=error
	 * @return array
	 */
	public function getErrorMessageArray() {
		return $this->getMessageArrayByType('error');
	}
	/**
	 * Returns an array of all messages
	 * @return array
	 */
	public function getAllMessageArray() {
		return $this->getMessageArrayByType();
	}
	
	//----------------------//
	//   INTERNAL METHODS   //
	//----------------------//
	/**
	 * JSON encodes an associative array and URL encodes it with the correct URL arg name
	 * @param array $param_array This associative array contains key/value pairs that will be JSON encoded
	 * @return string
	 * @access protected
	 */
	protected function convertParametersToPostFields($param_array) {
		$json_str = json_encode($param_array);
		// @todo Check for json encode error
		$ret_str = urlencode('_parameters') . '=' . urlencode($json_str);
		return $ret_str;
	}
}
$options = getopt("h", array("skms_user_id:", "skms_passkey:", "file_name:", "help::"));

if (isset($options['help']) || isset($options['h'])) {
	echo "\nUsage:\n\t--skms_user_id <skms user id>\n\t--skms_passkey <skms pass key, obtained from skms>\n\t--file_name <write output to this file>\n";
	exit;
}

if (!$options['skms_user_id']) {
	throw new Exception("Must pass a valid skms_user_id");
}
if (!$options['skms_passkey']) {
	throw new Exception("Must pass a valid skms_passkey");
}

//get adobe ips
$api = new SkmsWebApiClient($options['skms_user_id'], $options['skms_passkey'], 'api.skms.adobe.com');
$api->disableSslChainVerification();
$param_arr = Array(
	'include_ipv6' => false,
);
$adobe_blocks = array();

if($api->sendRequest('IpBlockDao', 'getTopLevelAdobeIpBlocks', $param_arr) == true) {
	$response_arr = $api->getResponseArray();
	if(isset($response_arr['data']['adobe_ip_blocks']) && is_array($response_arr['data']['adobe_ip_blocks'])) {
		foreach($response_arr['data']['adobe_ip_blocks'] as $adobe_ip_block) {
			$adobe_blocks[] = $adobe_ip_block['name'];
		}
	} else {
		throw new Exception("No Adobe IP Blocks were returned from skms");
	}
} else {
	throw new Exception("Invalid response from skms when requesting adobe IP blocks:\nSTATUS: " . $api->getResponseStatus() . "\nTYPE: " . $api->getErrorType() . "\nMESSAGE: " . $api->getErrorMessage() . "\n");
}

//get amazon ips
$api = new SkmsWebApiClient($options['skms_user_id'], $options['skms_passkey'], 'api.skms.adobe.com');
$api->disableSslChainVerification();
$amazon_blocks = array();
if($api->sendRequest('IpAddressDao', 'getAmazonIpAddresses') == true) {
	$response_arr = $api->getResponseArray();
	if(isset($response_arr['data']['amazon_ips']) && is_array($response_arr['data']['amazon_ips'])) {
		foreach($response_arr['data']['amazon_ips'] as $amazon_ip) {
			//these are individual addresses, not blocks, so create the cidr notation.
			$amazon_blocks[] = $amazon_ip . "/32";
		}
	} else {
		throw new Exception("No amazon IP Blocks were returned from skms");
	}
} else {
	throw new Exception("Invalid response from skms when requesting amazon IP blocks:\nSTATUS: " . $api->getResponseStatus() . "\nTYPE: " . $api->getErrorType() . "\nMESSAGE: " . $api->getErrorMessage() . "\n");
}

//get egress ips
$api = new SkmsWebApiClient($options['skms_user_id'], $options['skms_passkey'], 'api.skms.adobe.com');
$api->disableSslChainVerification();
$egress_blocks = array();
if($api->sendRequest('IpAddressDao', 'getEgressIpAddresses') == true) {
	$response_arr = $api->getResponseArray();
	if(isset($response_arr['data']['egress_ips']) && is_array($response_arr['data']['egress_ips'])) {
		foreach($response_arr['data']['egress_ips'] as $egress_ip) {
			//these are individual addresses, not blocks, so create the cidr notation.
			$egress_blocks[] = $egress_ip. "/32";
		}
	} else {
		throw new Exception("No egress IP Blocks were returned from skms");
	}
} else {
	throw new Exception("Invalid response from skms when requesting egress IP blocks:\nSTATUS: " . $api->getResponseStatus() . "\nTYPE: " . $api->getErrorType() . "\nMESSAGE: " . $api->getErrorMessage() . "\n");
}

$combined = array();
foreach ($egress_blocks as $cidr) {
	list ($net, $mask) = explode ('/', $cidr); 
	$combined[ip2long($net)] = $cidr;
}
foreach ($amazon_blocks as $cidr) {
	list ($net, $mask) = explode ('/', $cidr); 
	$combined[ip2long($net)] = $cidr;
}
foreach ($adobe_blocks as $cidr) {
	list ($net, $mask) = explode ('/', $cidr); 
	$combined[ip2long($net)] = $cidr;
}
ksort($combined);
$output = implode("\n", array_values($combined));
if ($options['file_name']) {
	file_put_contents($options['file_name'], $output);
} else {
	echo $output;
}

?>