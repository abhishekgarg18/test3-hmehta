<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * ___________________
 *
 *  Copyright 2015 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * FragReplacer.class.php Update all database pointers to replace one frag with another without moving any data.
 * Primarily used when replacing a frag server using rsync.
 *
 * @author Matt Gould <mgould@adobe.com>
 *        
 */
require_once 'application.inc';
require_once 'UsertrieDB.class.php';
require_once 'new_frag_host_distribution.class';
require_once 'new_frag_host_distribution_update.class';
require_once 'reverse_userid_lookup.inc';

class FragReplacer
{

    private $old_frag;

    private $new_frag;

    private $require_frag_status;

    private $execute;

    private $sql_comment;

    function __construct($old_frag, $new_frag, $execute = false)
    {
        if (!$old_frag || !$new_frag) {
            throw new Exception("You must specify both an old frag and a new frag");
        }
        
        $this->old_frag = $old_frag;
        $this->new_frag = $new_frag;
        
        $this->execute = $execute;
        
        $this->sql_comment = sprintf(" /* MODULE: bertlib FILE: %s CLASS: %s */ ", basename(__FILE__), __CLASS__);
    }

    function setExecute()
    {
        $this->execute = true;
    }

    function setDryRun()
    {
        $this->execute = false;
    }

    function updateTables()
    {
        $utdb = new UsertrieDB();
        $cmdb = new DB_Sql('cache_maintenance');
        $cmdb->halt_on_error = false;
        $mdb = new masterdb();
        $mdb->halt_on_error = false;
        $main_rsids = array();
        $updates = array('old_frag' => $this->old_frag, 'new_frag' => $this->new_frag, 'warnings' => []);
        
        // Updating fields in banner_config
        $banner_config_values = array(
            array(
                'frag',
                'host',
                'db'
            ),
            array(
                'archive',
                'archive_host',
                'archive_db'
            ),
            array(
                'unique_tables',
                'unique_table_host',
                'unique_table_db'
            ),
            array(
                'saint',
                'saint_host',
                'saint_db'
            )
        );
        foreach ($banner_config_values as $type) {
            list ($name, $host_field, $db_field) = $type;
            $sql = <<<SQL
                SELECT $this->sql_comment
                    u.username AS rsid,
                    b.$db_field AS db
                FROM
                    user u,
                    banner_config b
                WHERE
                    u.userid = b.userid
                    AND
                    b.$host_field = '$this->old_frag'
SQL;
            $utdb->query($sql);
            while ($utdb->next_record()) {
                $updates['rsids'][$utdb->f('rsid')][$name][] = $utdb->f('db');
                if ('host' == $host_field) {
                    $main_rsids[$utdb->f('rsid')] = $utdb->f('db');
                }
            }
            
            if ($this->execute) {
                $sql = <<<SQL
                    UPDATE $this->sql_comment
                        banner_config
                    SET
                        $host_field = '$this->new_frag'
                    WHERE
                        $host_field = '$this->old_frag'
SQL;
               $utdb->query($sql);
            }
        }
        
        // Updating other tables in user db
        $other_tables = array(
            array(
                'frag',
                'user_frag_list'
            ),
            array(
                'archive',
                'user_archive_list'
            ),
            array(
                'high_unique',
                'user_high_uniques_list'
            ),
            array(
                'frag_table_dist',
                'frag_table_dist'
            ),
            array(
                'unique_tables',
                'user_unique_table_list'
            ),
            array(
                'cache_frag_list',
                'user_cache_frag_list'
            )
        );
        foreach ($other_tables as $table_info) {
            list ($name, $table) = $table_info;
            $sql = <<<SQL
                SELECT $this->sql_comment
                    u.username AS rsid,
                    t.db AS db
                FROM
                    user u,
                    $table t
                WHERE
                    u.userid = t.userid
                    AND
                    t.host = '$this->old_frag'
                GROUP BY
                    u.username,
                    t.db
SQL;
            $utdb->query($sql);
            while ($utdb->next_record()) {
                $updates['rsids'][$utdb->f('rsid')][$name][] = $utdb->f('db');
            }
            
            if ($this->execute) {
                $sql = <<<SQL
                    UPDATE $this->sql_comment
                        $table
                    SET
                        host = '$this->new_frag'
                    WHERE
                        host = '$this->old_frag'
SQL;
                $utdb->query($sql);
            }
        }
        
        // Update vcookie_migration tables
        $sql = <<<SQL
            SELECT $this->sql_comment
                userid,
                db
            FROM
                vcookie_migration_tablename_details
            WHERE
                host = '$this->old_frag'
            GROUP BY
                userid,
                db
SQL;
        if (! $cmdb->query($sql)) {
            $updates['warnings'][] = "Could not check vcookie_migration_tablename_details table: " . $cmdb->Error;
        }
        while ($cmdb->next_record()) {
            $updates['rsids'][reverse_userid_lookup($cmdb->f('userid'))]['vcookie_migration'][] = $cmdb->f('db');
        }
        
        if ($this->execute) {
            $sql = <<<SQL
                UPDATE $this->sql_comment
                    vcookie_migration_tablename_details
                SET
                    host = '$this->new_frag'
                WHERE
                    host = '$this->old_frag'
SQL;
            if (! $cmdb->query($sql)) {
                $updates['warnings'][] = "Could not update vcookie_migration_tablename_details table: " . $cmdb->Error;
            }
        }
        
        // Replace frag in frag host automation exceptions
        $sql = <<<SQL
            SELECT $this->sql_comment
                user,
                comment,
                reason_text
            FROM
                frag_host_automation_exceptions f,
                automation_exception_reasons a
            WHERE
                f.reason_id = a.reason_id
                AND
                frag_host = '$this->old_frag'
SQL;
        if (! $cmdb->query($sql)) {
            $updates['warnings'][] = "Could not check frag_host_automation_exceptions table: " . $cmdb->Error;
        }
        $updates['automation_exception'] = $cmdb->next_record(MYSQL_ASSOC) ? $cmdb->Record : array();
        
        if ($this->execute) {
            $sql = <<<SQL
                UPDATE $this->sql_comment
                    frag_host_automation_exceptions
                SET
                    frag_host = '$this->new_frag'
                WHERE
                    frag_host = '$this->old_frag'
SQL;
            if (! $cmdb->query($sql)) {
                $updates['warnings'][] = "Could not update frag_host_automation_exceptions table: " . $cmdb->Error;
            }
        }
        
        // Update frag_movement table
        if ($this->execute) {
            $values = array();
            foreach ($main_rsids as $rsid => $db) {
                $userid = userid_lookup($rsid);
                $values[] = "($userid, '$rsid', '$this->old_frag', '$db', '$this->new_frag', '$db', now(), now())";
            }
            if ($values) {
                $values_string = implode(',', $values);
                $sql = <<<SQL
                    INSERT INTO 
                        frag_movement
                        (
                            userid,
                            username,
                            old_host,
                            old_db,
                            new_host,
                            new_db,
                            move_begun,
                            move_finished
                        )
                    VALUES
                        $values_string
SQL;
                if (! $mdb->query($sql)) {
                    $updates['warnings'][] = "Could not insert frag moves into frag_movement table: " . $mdb->Error;
                }
            }
        }
        
        // Update new_frag_host_distribution
        $fd = new new_frag_host_distribution();
        $frag_bases = $fd->get_bases_for_host($this->old_frag);
        $updates['frag_bases'] = $frag_bases;
        
        if ($this->execute) {
            $fdu = new new_frag_host_distribution_update();
            $fdu->replace_host('', $this->old_frag, $this->new_frag);
        }
        
        // Update load_distribution
        $sql = <<<SQL
            SELECT $this->sql_comment
                COUNT(*) AS c
            FROM
                load_distribution
            WHERE
                host = '$this->old_frag'
SQL;
        if (! $mdb->squery($sql)) {
            $updates['warnings'][] = "Could not check load_distribution table: " . $mdb->Error;
        }
        $updates['load_distribution'] = ($mdb->f('c') > 0);
        
        if ($this->execute) {
            // If the old frag has any entries in load_distribution delete any existing entries for new_frag to allow for the subsequent updates
            if ($updates['load_distribution']) {
                $sql = <<<SQL
                    DELETE $this->sql_comment
                    FROM
                        load_distribution
                    WHERE
                        host = '$this->new_frag'
SQL;
                if (! $mdb->query($sql)) {
                    $updates['warnings'][] = "Could not update load_distribution table: " . $mdb->Error;
                }
            }
            
            // Replace load_distribution entries for old_frag with new_frag
            $sql = <<<SQL
                UPDATE $this->sql_comment
                    load_distribution
                SET
                    host = '$this->new_frag'
                WHERE
                    host = '$this->old_frag'
SQL;
            if (! $mdb->query($sql)) {
                $updates['warnings'][] = "Could not update load_distribution table: " . $mdb->Error;
            }
        }
        
        // Add hardware comments
        if ($this->execute) {
            foreach (array(
                $this->old_frag,
                $this->new_frag
            ) as $frag_host) {
                $comment = array(
                    'comment_text' => "Replaced $this->old_frag with $this->new_frag using " . __CLASS__,
                    'dt_time' => date("Y-m-d H:i:s"),
                    'by_user' => __CLASS__,
                    'sticky' => false,
                    'comment_type' => 'server',
                    'commenting_on' => $frag_host
                );
                
                $hc = new hardware_comment($comment);
                $hc->set_property('server_list', $frag_host);
                $hc->build_base_and_account_list_from_frag($frag_host);
                $hc->visibility = 0;
                $hc->save();
            }
        }
        
        return $updates;
    }
 
    public function formatUpdateString(array $updates) {
        $ret = '';
        
        if ($updates['rsids']) {
        	$rsid_strings = [];
        	foreach ($updates['rsids'] as $rsid => $types) {
        		$rsid_strings[] = sprintf('%s (%s)', $rsid, implode(',', array_keys($types)));
        	}
            $ret .= sprintf(
                "Report suites moved from %s to %s (%d):\n    %s\n",
                $updates['old_frag'],
                $updates['new_frag'],
                count($updates['rsids']),
                implode("\n   ", $rsid_strings)
            );
        }
            
        if ($updates['frag_bases']) {
            $ret .= sprintf(
                "Frag Distribution bases where %s was replaced with %s (%d): %s\n",
                $updates['old_frag'],
                $updates['new_frag'],
                count($updates['frag_bases']),
                implode(' ', $updates['frag_bases'])
            );
        }
        
        if ($updates['load_distribution']) {
            $ret .= "Load distribution entries for {$updates['old_frag']} were replaced with {$updates['new_frag']}\n";
        }
        
        if ($updates['automation_exception']) {
            $ret .= "The Frag Host Automation exception for {$updates['old_frag']} was replaced with {$updates['new_frag']}\n";
        }
        
        if (!$ret) { 
            $ret = "Nothing was updated while replacing {$updates['old_frag']} with {$updates['new_frag']}\n";
        }
        return $ret;
    }
}

