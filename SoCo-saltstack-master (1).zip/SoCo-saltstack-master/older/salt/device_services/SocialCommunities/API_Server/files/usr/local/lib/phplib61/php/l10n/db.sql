-- MySQL dump 8.22
--
-- Host: dw1.dev    Database: localization
---------------------------------------------------------
-- Server version	3.23.51

--
-- Table structure for table 'de_DE_images'
--

CREATE TABLE de_DE_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'de_DE_text'
--

CREATE TABLE de_DE_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'de_DE_times'
--

CREATE TABLE de_DE_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'en_US_images'
--

CREATE TABLE en_US_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'en_US_text'
--

CREATE TABLE en_US_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'en_US_times'
--

CREATE TABLE en_US_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'fr_FR_images'
--

CREATE TABLE fr_FR_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'fr_FR_text'
--

CREATE TABLE fr_FR_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'fr_FR_times'
--

CREATE TABLE fr_FR_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'garbage_images'
--

CREATE TABLE garbage_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'garbage_text'
--

CREATE TABLE garbage_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'garbage_times'
--

CREATE TABLE garbage_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'image_alternate_text'
--

CREATE TABLE image_alternate_text (
  image_token char(100) NOT NULL default '',
  text_token int(10) unsigned NOT NULL default '0',
  UNIQUE KEY image_token (image_token,text_token)
) TYPE=MyISAM;

--
-- Table structure for table 'image_inline_text'
--

CREATE TABLE image_inline_text (
  image_token char(100) NOT NULL default '',
  text_token int(10) unsigned NOT NULL default '0',
  UNIQUE KEY image_token (image_token,text_token)
) TYPE=MyISAM;

--
-- Table structure for table 'jp_JP_images'
--

CREATE TABLE jp_JP_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'jp_JP_text'
--

CREATE TABLE jp_JP_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'jp_JP_times'
--

CREATE TABLE jp_JP_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'locale_numbers'
--

CREATE TABLE locale_numbers (
  locale varchar(25) NOT NULL default '',
  thousands_separator tinytext NOT NULL,
  decimal_separator tinytext NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'locales'
--

CREATE TABLE locales (
  locale varchar(25) NOT NULL default '',
  description varchar(25) NOT NULL default '',
  tlds varchar(100) default NULL,
  host_extentions varchar(100) default NULL,
  fake_locale tinyint(4) NOT NULL default '1',
  localized_description varchar(200) NOT NULL default '',
  multibyte tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (locale)
) TYPE=MyISAM;

--
-- Table structure for table 'mark_dates_images'
--

CREATE TABLE mark_dates_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'mark_dates_text'
--

CREATE TABLE mark_dates_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'mark_dates_times'
--

CREATE TABLE mark_dates_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'missing_images'
--

CREATE TABLE missing_images (
  page_hash int(10) unsigned NOT NULL default '0',
  image_token char(100) NOT NULL default '',
  KEY page_hash (page_hash,image_token)
) TYPE=MyISAM;

--
-- Table structure for table 'no_images_images'
--

CREATE TABLE no_images_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'no_images_text'
--

CREATE TABLE no_images_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'no_images_times'
--

CREATE TABLE no_images_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'page_text'
--

CREATE TABLE page_text (
  page_hash int(10) unsigned NOT NULL default '0',
  text_token int(10) unsigned NOT NULL default '0',
  KEY page_hash (page_hash)
) TYPE=MyISAM;

--
-- Table structure for table 'pages'
--

CREATE TABLE pages (
  hash int(10) unsigned NOT NULL default '0',
  page text NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'uppercase_images'
--

CREATE TABLE uppercase_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'uppercase_text'
--

CREATE TABLE uppercase_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'uppercase_times'
--

CREATE TABLE uppercase_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'w_images'
--

CREATE TABLE w_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'w_text'
--

CREATE TABLE w_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL
) TYPE=MyISAM;

--
-- Table structure for table 'w_times'
--

CREATE TABLE w_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_CN_images'
--

CREATE TABLE zh_CN_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_CN_text'
--

CREATE TABLE zh_CN_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_CN_times'
--

CREATE TABLE zh_CN_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_TW_images'
--

CREATE TABLE zh_TW_images (
  token char(100) NOT NULL default '',
  file_type char(10) NOT NULL default '',
  height int(11) NOT NULL default '0',
  width int(11) NOT NULL default '0',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (token)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_TW_text'
--

CREATE TABLE zh_TW_text (
  token int(10) unsigned NOT NULL default '0',
  text text NOT NULL,
  last_updated timestamp(14) NOT NULL,
  KEY token (token)
) TYPE=MyISAM;

--
-- Table structure for table 'zh_TW_times'
--

CREATE TABLE zh_TW_times (
  hash int(10) unsigned NOT NULL default '0',
  format varchar(50) NOT NULL default '',
  last_updated timestamp(14) NOT NULL,
  PRIMARY KEY  (hash)
) TYPE=MyISAM;

