<?php
require_once "latencyAPI.inc";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

class LatencyService
{
	private $latencyApi;
	private $log;
	
	public function __construct()
	{
		$this->latencyApi = new latencyAPI();
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * Calculates latency for either v.14 or v.15 (axle) in seconds for the given userid depending on if the userid is configured for v.14 or v.15
	 * @param int $userid
	 */
	public function getLatency($userid,$isV15)
	{
		$this->log->info("determining latency for $userid");
		$latency = null;
		// determine if this is a v15 or v14 rsid
		if($isV15)
		{
			// axle latency includes elevator and export latency values when it is appropriate. This call should include all axle latency
			$axleLatencyData = $this->latencyApi->getAxleLatencyByUser($userid,FALSE);
			$latency = round(max($axleLatencyData)/60,0);
			
			$this->log->info("v.15 Latency for $userid is $latency minutes"); 
		}
		else
		{
			$elevatorLatencyData = $this->latencyApi->getElevatorLatencyByUser($userid);
			$elevatorLatency = round(max($elevatorLatencyData)/60,0);
			$latency = $elevatorLatency; // I am told that elevator latency alone will ALWAYS reflect true latecny. 
			$this->log->info("v.14 Latency for $userid is $latency minutes"); 
		}
		
		return $latency; 
					
	}
	
}
