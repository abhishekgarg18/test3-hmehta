<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-run-everywhere.php';

class HA_All_Latents extends HA_Run_Everywhere {
    private $default_server_prefix = 'eng1';
    private $data_center_suffixes;
    private $server_list = array();
    private $trie_files = array();
    
    // anything you put in $args will override the default value
	function __construct( $args = array() ) {
		parent::__construct($args);
        
        if (DATA_CENTER == DATA_CENTER_DEV) {
            $this->default_server_prefix = 'vm232';
        }

        $this->data_center_suffixes = $args['data_center_suffixes'];
        $this->remote_user = $args['remote_user'];
        $this->crons = $args['crons'];
        $this->log_level(HA_LOG_LEVEL_DEBUG);
        $this->sleep_time(60);
        
        $this->start();
    }
    
    function start() {
	global $localConfig;

        foreach($localConfig['production_data_center_list'] as $data_center) {
            // skip PNW for now
            if ($data_center == DATA_CENTER_PNW) {
                continue;
            }
            
            $remote_flag = ($data_center == DATA_CENTER_DEV) ? false : true;
            
            $queue_args = array(
                'command' => './ha-quicklatency.php ',
                
                'log_level' => HA_LOG_LEVEL_DEBUG,
                'copy_up' => array(
                    'class-ha-run-everywhere.php', 
                    'class-ha-latency-quick-data.php',
                    'class-ha-utilities.php',
                    'class-ha-queue-item.php',
                    'class-ha-all-latents.php',
                    'class-ha-cron-finder.php',
                    'ha-quicklatency.php',
                ),
                
                'data_center' => $data_center,
                'remote_user' => $this->remote_user,
                'remote_flag' => $remote_flag,
                'remote_server' => $remote_server,
                'custom_ps' => 'ps -u ' . $this->remote_user . ' | grep quicklat',  // don't forget to truncate the grep to <12 chars
            );
            
            $queue_args['remote_server'] = $this->crons->random_cron_server($data_center); 
            $this->add_to_queue( $queue_args );
        }
        
        parent::start();
    }
    
}
