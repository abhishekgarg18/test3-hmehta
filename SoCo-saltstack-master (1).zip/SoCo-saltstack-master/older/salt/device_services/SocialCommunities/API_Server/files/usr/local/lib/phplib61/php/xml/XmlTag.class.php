<?
/**
 * @file XmlTag.class.php
 *
 * XML Tag Object (php4)
 * This object stores all of the direct children of itself in the $children array. They are also stored by
 * type as arrays. So, if, for example, this tag had 2 <font> tags as children, there would be a class member
 * called $font created as an array. $font[0] would be the first font tag, and $font[1] would be the second.
 *
 * To loop through all of the direct children of this object, the $children member should be used.
 *
 * To loop through all of the direct children of a specific tag for this object, it is probably easier
 * to use the arrays of the specific tag names, as explained above.
 *
 * @author Adam A. Flynn <adamaflynn@phppal.com>
 * @copyright Copyright (c) 2005, Adam A. Flynn
 *
 * @author Brandon George <bgeorge@omniture.com>
 *
 * @version CVS: $Id$
 */
class XmlTag
{
	/** DATA MEMBERS **/

    /**
     * Array with the attributes of this XML tag.
     *
     * @var array
     **/
    var $tagAttrs;

    /**
     * The name of the tag.
     *
     * @var string
     **/
    var $tagName;

    /**
     * The data the tag contains.
     *
     * So, if the tag doesn't contain child tags, and just contains a string, it would go here.
     *
     * @var string
     **/
    var $tagData;

    /**
     * The number of parents this XML object has (number of levels from this tag to the root tag).
     *
     * Used presently only to set the number of tabs when outputting XML.
     *
     * @var int
     **/
    var $tagParents;

    /**
     * Array of references (indexed by tagname of the child tag) to the objects of all direct children of this XML object.
     * ('c' is for 'children' - normally, a more explicit name would be used, but this data member will be referenced repeatedly
     * by clients using this object).
     *
     * @var array
     **/
    var $c;

	/** CONSTRUCTOR **/

    /**
     * Constructor.  Sets up all the default values.
     *
     * @public
     * @param string $name
     * @param array $attrs
     * @param int $parents
     **/
    function XmlTag($name, $attrs = array(), $parents = 0)
    {
        // cache tag attributes
        $this->tagAttrs = $attrs;

        // cache tag name
        $this->tagName = $name;

        // cache the number of parents
        $this->tagParents = $parents;

        // initialize the types for tag children and tag data
        $this->c = array();
        $this->tagData = '';
    }

	/** PUBLIC METHODS **/

	/**
	 * Gets the name of the XML tag.
	 *
	 * @public
	 * @return (string) tag name
	 **/
	function & getTagName()
	{
		return $this->tagName;
	}

	/**
	 * Gets the data for the XML tag.
	 *
	 * @public
	 * @return (string) tag data
	 **/
	function & getTagData()
	{
		return $this->tagData;
	}

	/**
	 * Gets the value of a specified attribute on the XML tag.
	 *
	 * @public
	 * @param $key (string) attribute name
	 * @return (string) attribute value
	 **/
	function getTagAttribute($key)
	{
		return $this->tagAttrs[$key];
	}

	/**
	 * Set an attribute (key-value pair) on the XML tag.  This
	 * can be a new or existing attribute.
	 *
	 * @public
	 * @param $key (string) attribute name
	 * @param $value (string) attribute value
	 **/
	function setTagAttribute($key, $value)
	{
		$this->tagAttrs[$key] = $value;
	}

	/**
	 * Remove an attribute from the XML tag.
	 *
	 * @public
	 * @param $key (string) attribute name
	 **/
	function removeTagAttribute($key)
	{
		unset($this->tagAttrs[$key]);
	}

    /**
     * Adds a direct child to this object.
     *
     * @public
     * @param string $name
     * @param array $attrs
     * @param int $parents
     * @param int $insertion_point
     * @return XmlTag reference to the added child
     **/
    function & addChild($name, $attrs, $parents, $insertion_point = NULL)
    {
        // if there is no array already set for the tag name being added,
        // create an empty array for it
        if(!isset($this->c[$name])) {
        	$this->c[$name] = array();
		}

        // If the tag has the same name as a member in XmlTag, or somehow the
        // array wasn't properly created, output a more informative error than
        // PHP otherwise would.
        if(!is_array($this->c[$name]))
        {
            trigger_error('You have used a reserved name as the name of an XML tag. Please consult the documentation (http://www.thousandmonkeys.net/xml_doc.php) and rename the tag named '.$name.' to something other than a reserved name.', E_USER_ERROR);
            return NULL;
        }

        // add a new child object to the children array
        $child = new XmlTag($name, $attrs, $parents);
        if ($insertion_point !== NULL) {
			array_splice($this->c[$name], (int)$insertion_point, 0, array(&$child));
		} else {
        	$this->c[$name][] =& $child;	// no insertion point specified - push it onto the back
		}

		return $child;
    }

	/**
	 * Removes a child from this object (by tagname and index).
	 *
	 * @public
	 * @param string $child_tagname
	 * @param int @child_index
	 **/
    function removeChild($child_tagname, $child_index)
    {
		if ($child_index === NULL) {
			return;
		}

		array_splice($this->c[$child_tagname], (int)$child_index, 1);
	}

	/**
	 * Indicates whether this object has any children.  A filter
	 * (child tagname) may be supplied to ask whether this object
	 * has any children of that specific tagname.
	 *
	 * @public
	 * @param string $child_tagname
	 * @return boolean whether this object has any children
	 **/
	function hasChildren($child_tagname = NULL)
	{
		// no child tagname specified - check to see if the object has any children at all
		if (!$child_tagname) {
			return (count($this->c) > 0);
		}

		// otherwise, check the specific child tagname
		return (isset($this->c[$child_tagname]) && count($this->c[$child_tagname]) > 0);
	}

    /**
     * Returns the string of the XML document which would be generated from this object.
     *
     * This function works recursively, so it gets the XML of itself and all of its children, which
     * in turn gets the XML of all their children, which in turn gets the XML of all thier children,
     * and so on. So, if you call toString from the document root object, it will return a string for
     * the XML of the entire document.
     *
     * This function does not, however, return a DTD or an XML version/encoding tag. That should be
     * handled by XmlDocument::toString()
     *
     * @public
     * @return string
     **/
    function toString($indent="\t")
    {
        // start a new line, indent by the number indicated in $this->parents, add a <, and add the name of the tag
        $out = "\n".str_repeat($indent, $this->tagParents).'<'.$this->tagName;

        // for each attribute, add attr="value"
        foreach($this->tagAttrs as $attr => $value) {
        	$out .= ' '.$attr.'="'.htmlspecialchars($value, ENT_COMPAT).'"';
		}

        // if there are no children and the data is blank, end it off with a />
        if(empty($this->c) && $this->_isBlank($this->tagData)) {
        	$out .= " />";
		}

        // otherwise...
        else {
            // if there are children
            if(!empty($this->c)) {
                // close off the start tag
                $out .= '>';

                // for each child, call the toString function (this will ensure that all children are added recursively)
                foreach($this->c as $child_tagname => $children) {
					foreach ($children as $child) {
	                	$out .= $child->toString($indent);
					}
				}

                // add the newline and indentation to go along with the close tag
                $out .= "\n".str_repeat($indent, $this->tagParents);
            }

            // if there is data, close off the start tag and add the data
            elseif (!$this->_isBlank($this->tagData)) {
            	$out .= '>'.htmlspecialchars($this->tagData, ENT_NOQUOTES);
			}

            // add the end tag
            $out .= '</'.$this->tagName.'>';
        }

        // return the final output
        return $out;
    }

    function _isBlank($value)
    {
		return (empty($value) && (string)$value !== '0');
	}
}
