<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright [first year code created] Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-run-everywhere.php';

class HA_Cron_Finder extends HA_Run_Everywhere {
    private $default_server_prefix = 'eng1';
    private $data_center_suffixes;
    private $server_list = array();
    
    // anything you put in $args will override the default value
	function __construct( $args = array() ) {
		parent::__construct($args);
        
        if (DATA_CENTER == DATA_CENTER_DEV) {
            $this->default_server_prefix = 'vm232';
            $this->server_list[DATA_CENTER] = array('vm232.dev.ut1');
        }

        $this->data_center_suffixes = $args['data_center_suffixes'];
        $this->remote_user          = $args['remote_user'];
        $this->log_level(HA_LOG_LEVEL_ERROR);
        
        // servers we really DON'T want to use
        $this->exclude_servers = array(
            'cron3.oak1',
            'cron4.lon5',
        );
        
        if (DATA_CENTER != DATA_CENTER_DEV) {
            foreach($this->data_center_suffixes as $data_center => $suffix) {
    
                $remote_flag = ($data_center == DATA_CENTER) ? false : true;            
                $this->add_to_queue( array(
                    'command' => '/home/httpd/bin/sql group ' . $suffix . '-cron',
                    'remote_user' => $args['remote_user'],
                    'data_center' => $data_center,
                    'remote_flag' => true,
                    'remote_server' => $this->default_server_prefix . '.' . $suffix,
                ) );
            }
            
            // add oak1 to san jose cron list
            $this->add_to_queue( array(
                'command' => '/home/httpd/bin/sql group oak1-cron',
                'data_center' => DATA_CENTER_SAN_JOSE,
                'remote_flag' => false,
            ) );
            
            
            $this->start();
            foreach($this->queue() as $item) {
                
                // don't put an error message in the server list :)
                $output = trim($item->output());
                $matches = array();
                preg_match('/No such file/', $output, $matches);
                
                if (count($matches) == 0) {
                    if (isset($this->server_list[$item->data_center()])) {
                        $this->server_list[$item->data_center()] = array_merge($this->server_list[$item->data_center()], preg_split('/\s+/', $output));
                    }
                    else {
                        $this->server_list[$item->data_center()] = preg_split('/\s+/', $output);
                    }
                }
            }
            
            // todo: look for a better way than a foreach
            // remove bad cron servers
            foreach($this->exclude_servers as $exclude_server) {
                foreach($this->server_list as $data_center => $dc_servers) {
                    foreach($dc_servers as $key => $server) {
                        if ($server == $exclude_server) {
                            // remove it!
                            // todo: check for problems in the "foreach" when unsetting an iterated item
                            unset($this->server_list[$data_center][$key]);
                        }
                        
                        // todo: remove items that aren't formed correctly (xxx.xxx)
                    }
                }
            }
        }
    }
    
    function cron_server_list() {
        return $this->server_list;
    }
    
    function cron_servers_in($data_center) {
        if (isset($this->server_list) && is_array($this->server_list[$data_center])) {
            return $this->server_list[$data_center];
        }
        
        // if we couldn't find a cron, find an eng server.
        return array($this->eng_server($data_center));
    }
    
    function random_cron_server($data_center) {
        if (isset($this->server_list) && is_array($this->server_list[$data_center])) {
            $randi = mt_rand(0, count($this->server_list[$data_center]) - 1);
            return $this->server_list[$data_center][$randi];
        }
        
        // if we couldn't find a cron, find an eng server.
        return $this->eng_server($data_center);
    }
    
    function eng_server($data_center) {
        $this->default_server_prefix . '.' . $this->data_center_suffixes[$data_center];
    }
}