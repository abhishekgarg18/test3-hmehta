<?php

require_once 'application.inc';
require_once 'CacheAlertModel.inc';

require_once 'lobby_distribution.class';
require_once 'elevator_dist.inc';
require_once 'suite_dist.inc';

class CacheAlerts {
	function CacheAlerts(){

	}
	
	static private $te;
	static function initialize(){
		self::$te = new TrieEntry();
	}

	static function get_cache_alerts($type='') {
		$db = new DB_Sql('latencydb');

		$sql = "SELECT * FROM cache_alerts";
		if (strlen($type)) {
			$sql .= " where problem_type='" . $type . "'";
			$sql .= " ORDER BY severity DESC, acknowledged";
		}
        $sql .= " LIMIT 100";
		$db->query($sql);

		$entries = array();
		$i = 0;
		

		while ($db->next_record()) {
			$host = $db->f('host');
			$problem_type = $db->f('problem_type');
			$severity = $db->f('severity');
			$alert_time = $db->f('alert_time');
			$problem_details = $db->f('problem_details');
			$acknowledged = $db->f('acknowledged');
			$acknowledged_by = $db->f('acknowledged_by');
			$acknowledge_reset_time = $db->f('acknowledge_reset_time');
			$comments = $db->f('comments');

			$entry = array(
			"host" => $host,
			"severity" => $severity,
			"alert_time" => $alert_time,
			"problem_details" => $problem_details,
			"acknowledged" => $acknowledged,
			"acknowledged_by" => $acknowledged_by,
			"acknowledge_reset_time" => $acknowledge_reset_time,
			"comments" => $comments,
			"problem_type" => $problem_type);
			
			$wholeEntry = CacheAlerts::getWholeEntry($entry);
			$entries[$i++] = CacheAlertModel::getInstance($wholeEntry);
		}
		$db->free();

		return $entries;
	}
	
	static function get_cache_alerts_without_base($type='') {
		$db = new DB_Sql('latencydb');

		$sql = "SELECT * FROM cache_alerts";
		if (strlen($type)) {
			$sql .= " where problem_type='" . $type . "'";
		}
        $sql .= " LIMIT 100";
		$db->query($sql);

		$entries = array();
		$i = 0;

		while ($db->next_record()) {
			$host = $db->f('host');
			$problem_type = $db->f('problem_type');
			$severity = $db->f('severity');
			$alert_time = $db->f('alert_time');
			$problem_details = $db->f('problem_details');
			$acknowledged = $db->f('acknowledged');
			$acknowledged_by = $db->f('acknowledged_by');
			$acknowledge_reset_time = $db->f('acknowledge_reset_time');
			$comments = $db->f('comments');

			$entry = array(
			"host" => $host,
			"severity" => $severity,
			"alert_time" => $alert_time,
			"problem_details" => $problem_details,
			"acknowledged" => $acknowledged,
			"acknowledged_by" => $acknowledged_by,
			"acknowledge_reset_time" => $acknowledge_reset_time,
			"comments" => $comments,
			"problem_type" => $problem_type);
			
			$entries[$i++] = CacheAlertModel::getInstance($entry);
		}
		$db->free();

		return $entries;
	}
	
	static private function getWholeEntry($entry){
		try{
			$problem_type = $entry["problem_type"];
			$host = $entry["host"];
			$triestring = '';
			$lobbytrie = self::$te->get_lobby_trie_entries($host);
			if($lobbytrie) {
				$triestring = 'Lobby: ' . implode(', ', (array)$lobbytrie);
			}
			$elevatortrie = self::$te->get_elevator_trie_entries($host);
			if($elevatortrie) {
				if($triestring != '')  $triestring .= ' ';
				$triestring .= 'Elevator: ' . implode(', ', (array)$elevatortrie);
			}
			$suitetrie = self::$te->get_suite_trie_entries($host);
			if($suitetrie) {
				if($triestring != '')  $triestring .= ' ';
				$triestring .= 'Suite: ' . implode(', ', (array)$suitetrie);
			}
				
			$othertrie = self::$te->check_latency_dependencies($host);
			foreach ((array)$othertrie as $server){
				$dependent_servers[$server] = true;
			}

			$desc = '';
			$trie = '';
			if (strpos($problem_type, 'lobby') === 0 && $lobbytrie){
				$trie = $lobbytrie;
				$desc =  implode(', ', (array)$lobbytrie);
			} else if (strpos($problem_type, 'elevator') === 0 && $elevatortrie){
				$trie = $elevatortrie;
				$desc =  implode(', ', (array)$elevatortrie);
			} else if (strpos($problem_type, 'suite') === 0 && $suitetrie){
				$trie = $suitetrie;
				$desc =  implode(', ',(array)$suitetrie);
			} else if ($othertrie) {
				$trie = $othertrie;
				$desc = implode(', ', (array)$trie);
			} else {
				$desc = 'No base found.';
			}
				
			$entry["trie"] = $trie;
			$entry["desc"] = $desc;
			$entry["triestring"] = $triestring;
		}catch(Exception $e){
			throw $e;
		}
		return $entry;
	}
	
	static function get_unique_cache_alert($host, $p_type){
		$db = new DB_Sql('latencydb');
		
		$sql = "select * from cache_alerts";
		$sql .= " where problem_type = '" . $p_type . "'";
		$sql .= " and host = '" . $host . "'"; 
        $sql .= " LIMIT 100";
		
		$db->query($sql);
		
		if ($db->next_record()) {
			$host = $db->f('host');
			$problem_type = $db->f('problem_type');
			$severity = $db->f('severity');
			$alert_time = $db->f('alert_time');
			$problem_details = $db->f('problem_details');
			$acknowledged = $db->f('acknowledged');
			$acknowledged_by = $db->f('acknowledged_by');
			$acknowledge_reset_time = $db->f('acknowledge_reset_time');
			$comments = $db->f('comments');
		
			$entry = array(
					"host" => $host,
					"severity" => $severity,
					"alert_time" => $alert_time,
					"problem_details" => $problem_details,
					"acknowledged" => $acknowledged,
					"acknowledged_by" => $acknowledged_by,
					"acknowledge_reset_time" => $acknowledge_reset_time,
					"comments" => $comments,
					"problem_type" => $problem_type);
			
			$cam = CacheAlertModel::getInstance(CacheAlerts::getWholeEntry($entry));
			
		}
		$db->free();
		
		return $cam;
	}
	
	static function get_cache_alerts_by_hostlist($hostlist) {
		$db = new DB_Sql('latencydb');
	
		$sql = "SELECT * FROM cache_alerts WHERE ";
		$item_count=0;
		foreach ($hostlist as $hostname=>$val){
			if ($item_count++ != 0) {
				$sql .= " OR ";
			}
		
			$sql .= "(host='" . $hostname . "')";
		}
        $sql .= " LIMIT 100";
		
		$db->query($sql);
	
		$entries = array();
		$i = 0;
	
		while ($db->next_record()) {
			$host = $db->f('host');
			$problem_type = $db->f('problem_type');
			$severity = $db->f('severity');
			$alert_time = $db->f('alert_time');
			$problem_details = $db->f('problem_details');
			$acknowledged = $db->f('acknowledged');
			$acknowledged_by = $db->f('acknowledged_by');
			$acknowledge_reset_time = $db->f('acknowledge_reset_time');
			$comments = $db->f('comments');
	
			$entry = array(
				"host" => $host,
				"severity" => $severity,
				"alert_time" => $alert_time,
				"problem_details" => $problem_details,
				"acknowledged" => $acknowledged,
				"acknowledged_by" => $acknowledged_by,
				"acknowledge_reset_time" => $acknowledge_reset_time,
				"comments" => $comments,
				"problem_type" => $problem_type);
				
			$cam = CacheAlertModel::getInstance($entry);
			$entries[$i++] = $cam;
		}
		$db->free();
	
		return $entries;
	}

	static function get_alert_types() {
		$db = new DB_Sql('latencydb');

		$sql = "SELECT problem_type FROM cache_alert_limits ORDER BY warning_level";
		$db->query($sql);

		$p_types = array();

		while ($db->next_record()) {
			$p_types[] = $db->f('problem_type');
		}

		$db->free();

		return $p_types;
	}

	static function get_alert_type_last_update($type) {
		$db = new DB_Sql('latencydb');

		$sql = "SELECT last_update FROM cache_alerts_update_latency WHERE problem_type = '$type'";
		$db->query($sql);

		$time = NULL;

		if ($db->next_record()) {
			$time = $db->f('last_update');
		}

		$db->free();

		return $time;
	}


	static function acknowledge_record ($problem_type, $host_list, $r_time, $uName) {
		if (!$host_list)	return false;

		$retVal = false;	// Default to false return value

		$db = new DB_Sql('latencydb');

		{
			//  OK to lock record
			$reset_time = date("Y-m-d H:i:s", time() + (3600 * $r_time));
			$sql = "UPDATE cache_alerts SET acknowledged='1', acknowledged_by='$uName', acknowledge_reset_time='$reset_time' WHERE (";

			$item_count=0;
			foreach ($host_list as $host_item=>$val) {
				if ($item_count++ != 0) {
					$sql .= " OR ";
				}

				$sql .= "(host='" . $host_item . "')";
			}

			$sql .= ") and problem_type = '" . $problem_type. "'";
			$db->query ($sql);
			if (!$db->Errno)
			$retVal = true;
		}

		$db->free();
		return $retVal;
	}

	// Find those hosts which share a base with the input host
	static function get_host_list($host, $problem_type) {
		$records = CacheAlerts::get_cache_alerts_without_base($problem_type);

		$source_trie = self::$te->get_trie_entries($host, $problem_type);
		$host_list[$host] = 1;

		if (is_array($records) && (count($records)>0)) {
			$rcd_count=0;
			foreach($records as $record) {
				$target_host = $record->getHost();
				$rcd_count++;

				if ($target_host != $host){
					$target_trie = self::$te->get_trie_entries($target_host, $problem_type);
					if (is_array($target_trie) && (count($target_trie)>0)) {
						$match_found = false;
						$source_count=0;
						foreach($source_trie as $source_base) {
							// echo("<p>target_base[$base_count]=$target_base</p>");
							$source_count++;

							$targ_count=0;
							foreach($target_trie as $target_base) {
								// echo("<p>source_base[$source_count]=$source_base</p>");
								$targ_count++;

								if ($source_base == $target_base) {
									$match_found = true;
									// echo("<p>Adding $target_host to list</p>");
									$host_list[$target_host]=1;
									break;
								}
							}

							if ($match_found)
							break;
						}
					}
				}
			}
		}

		return $host_list;
	}
}
CacheAlerts::initialize();

class TrieEntry{
	private $ld = null;
	private $ed_by_host = array();
	private $sd_by_host = array();
	private $totalDependencies = array();
	
	function TrieEntry()
	{
		// init the lobby data
		$this->ld = new lobby_distribution();
		$this->ld->get_all_data();
		
		// init the elecvator data
		$ed = new elevator_distribution();
		$ed->get_elevator_distribution();
		foreach($ed->elevator_dist as $base => $loc) {
			$this->ed_by_host[$loc[0]][$base] = true;
		}
		foreach($ed->elevator_sub_dist as $base => $modarr) {
			foreach($modarr as $mod => $loc) {
				$this->ed_by_host[$loc[0]][$base] = true;
			}
		}
		
		// init the suite data
		$sd = new suite_distribution();
		$sd->get_suite_distribution();
		foreach($sd->suite_dist as $base => $loc) {
			$this->sd_by_host[$loc[0]][$base] = true;
		}
		foreach($sd->suite_sub_dist as $base => $modarr) {
			foreach($modarr as $mod => $loc) {
				$this->sd_by_host[$loc[0]][$base] = true;
			}
		}
		
		// init the dependencies
		$db = new DB_Sql('latencydb');
			
		$sql = "SELECT server, depends_on FROM stage2_latency_dependencies WHERE depends_on = '$host'";
		$db->query($sql);

		while ($db->next_record()) {
			$this->totalDependencies[$db->f('depends_on')][] = $db->f('server');
		}
		$db->free();
	}
	
	//sort lobby distribution by host
	function get_lobby_trie_entries($h)
	{
		return $this->ld->get_bases_for_host($h);
	}


	//sort elevator distribution by host
	function get_elevator_trie_entries($h)
	{
		if (is_array($this->ed_by_host[$h])) {
			$entries = $this->ed_by_host[$h];

			$entries_array = array();
			uksort($entries, 'strnatcasecmp');
			foreach ($entries as $k=>$v) {
				$entries_array[] = $k;
			}
		} else {
			$entries_array = array();
		}
		return $entries_array;
	}


	//sort suite distribution by host
	function get_suite_trie_entries($h)
	{
		if (is_array($this->sd_by_host[$h])) {
			$entries = $this->sd_by_host[$h];

			$entrie_array = array();
			uksort($entries, 'strnatcasecmp');
			foreach ($entries as $k=>$v) {
				$entries_array[] = $k;
			}
		} else {
			$entrie_array = false;
		}
		return $entries_array;
	}

	function get_trie_entries($host, $problem_type)
	{
		$hosttrie = array();
		// echo("<p>get_trie_entries($host, $problem_type)</p>");
		if (stripos($problem_type, 'Lobby') === 0) {
			// echo("<p>Searching lobby for $problem_type</p>");
			$hosttrie = $this->get_lobby_trie_entries($host);
		} else if (stripos($problem_type, 'Elevator') === 0) {
			// echo("<p>Searching elevator for $problem_type</p>");
			$hosttrie = $this->get_elevator_trie_entries($host);
		} else 	if (stripos($problem_type, 'Suite') === 0) {
			// echo("<p>Searching suite for $problem_type</p>");
			$hosttrie = $this->get_suite_trie_entries($host);
		}

		return $hosttrie;
	}

	function check_latency_dependencies($host){
		global $dependent_servers;
		$servers = $this->totalDependencies[$host];
		
		foreach ((array) $servers as $server){
			$trie = array_merge((array)$trie,$this->get_lobby_trie_entries($server));
		}
		if(!$trie) {
			foreach ((array) $servers as $server){
				$trie = array_merge((array)$trie,$this->get_elevator_trie_entries($server));
			}
		}
		foreach ((array)$trie as $server){
			$dependent_servers[$server] = true;
		}
		return $trie;
	}
}

?>