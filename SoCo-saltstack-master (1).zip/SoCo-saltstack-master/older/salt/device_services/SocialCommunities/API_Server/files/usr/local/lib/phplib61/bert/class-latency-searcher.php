<?php

/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright [first year code created] Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// mary shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-run-everywhere.php';
require_once 'LatencyHistory.class';
require_once 'DataMigration.class';
require_once 'class-compass-lists.php';

class Latency_Searcher extends HA_Utilities {
    protected $ecc_id_list       = array();
    protected $billing_customer_name_list = array();
    protected $companyid_list    = array();
    protected $login_company_name_list = array();
    protected $username_list     = array();
    protected $userid_list       = array();
    protected $thresholds        = array();
    protected $exclude_customers = array();
    protected $latency_history_timestamps = array();
    protected $current_table_names = array();
    
    protected $output_format = self::FORMAT_PHP;
    protected $serp_offset = 0;
    protected $serp_limit = 10;
    protected $user_list_chunk_size = 60; // should be 600
    protected $exclude_migrating_accounts = null;
    protected $latency_history            = null;
    protected $serp_data                  = array();
    protected $multi_data_center = false;
    protected $sql_comment = '/* MODULE: bertlib/bert FILE: class-latency-searcher.php */';
    protected $minimum_threshold_minutes = NULL;

    const EVERYONE = 'everyone';
    const TOP_100  = 'top100';
    const LOBBY = 'lobby';
    const ELEVATOR = 'elevator';
    const EXPORT = 'export';
    const AXLE = 'axle';
    const SITE_CATALYST = 'site_catalyst';
    const FORMAT_PHP = 'php';
    const FORMAT_CSV = 'csv';
    const FORMAT_JSON = 'json';
    
    // anything you put in $args will override the default value
	function __construct( $args = array() ) {
		parent::__construct($args);

        $this->latency_types = array(
            self::LOBBY,
            self::ELEVATOR,
            self::EXPORT,
            self::AXLE,
            self::SITE_CATALYST,
        );
        
        $this->latency_groups = array(
            self::TOP_100,
            self::EVERYONE,
        );
        
        $this->load_args($args);
        $this->latency_history = new LatencyHistory();
    }
    
    function load_args( $args = array() ) {
		if( isset( $args['ecc_id_list'] ) && is_array( $args['ecc_id_list'] ) ) {
			$this->ecc_id_list( $args['ecc_id_list'] );
		}
		if( isset( $args['billing_customer_name_list'] ) && is_array( $args['billing_customer_name_list'] ) ) {
			$this->billing_customer_name_list( $args['billing_customer_name_list'] );
		}
		if( isset( $args['companyid_list'] ) && is_array( $args['companyid_list'] ) ) {
			$this->companyid_list( $args['companyid_list'] );
		}
		if( isset( $args['login_company_name_list'] ) && is_array( $args['login_company_name_list'] ) ) {
			$this->login_company_name_list( $args['login_company_name_list'] );
		}
		if( isset( $args['username_list'] ) && is_array( $args['username_list'] ) ) {
			$this->username_list( $args['username_list'] );
		}
		if( isset( $args['userid_list'] ) && is_array( $args['userid_list'] ) ) {
			$this->userid_list( $args['userid_list'] );
		}
        
        // remember! threshold is in SECONDS
        if (is_array($this->latency_types)) {
            foreach($this->latency_types as $latency_type) {
                if (is_array($this->latency_groups)) {
                    foreach($this->latency_groups as $latency_group) {
                        $key = 'threshold-' . $latency_type . '-' . $latency_group;
                        if (array_key_exists($key, $args)) {
                            $this->set_latency_threshold($latency_type, $latency_group, $args[$key]);
                        }
                    }
                }
            }
        }
		if( isset( $args['output_format'] ) ) {
			$this->output_format( $args['output_format'] );
		}
		if( isset( $args['exclude_migrating_accounts'] ) ) {
			$this->exclude_migrating_accounts( $args['exclude_migrating_accounts'] );
		}
        if( isset( $args['exclude_these_customers'] ) && is_array( $args['exclude_these_customers'] ) ) {
            $this->exclude_customers( $args['exclude_these_customers'] );
        }
        if( isset( $args['multi_data_center'] ) ) {
            $this->multi_data_center( $args['multi_data_center'] );
        }
        if( isset( $args['serp_offset'] ) ) {
            $this->serp_offset( $args['serp_offset'] );
        }
        if( isset( $args['serp_limit'] ) ) {
            $this->serp_limit( $args['serp_limit'] );
        }
        if( isset( $args['user_list_chunk_size'] ) ) {
            $this->user_list_chunk_size( $args['user_list_chunk_size'] );
        }
        if( isset( $args['latency_history_timestamps'] ) ) {
            $this->latency_history_timestamps( $args['latency_history_timestamps'] );
        }
    }
    
    function build_latency_history_query($user_list, $data_center) {
        // get the where clause stuff
        $threshold_statements = array();
        foreach($this->latency_types as $latency_type) {
            foreach($this->latency_groups as $latency_group) {
                $threshold = $this->latency_threshold($latency_type, $latency_group, false);
                if ($threshold) {
                    $threshold = intval($threshold);
                    switch($latency_type) {
                        case self::SITE_CATALYST:
                            if ( ( !isset( $threshold_statements[ self::ELEVATOR ] ) ) || ($threshold < $threshold_statements[ self::ELEVATOR ] ) ) {
                                $threshold_statements[ self::ELEVATOR ] = " (elevator > $threshold) ";
                            }
                            break;
                        default:
                            if ( ( !isset( $threshold_statements[ $latency_type ] ) ) || ($threshold < $threshold_statements[ $latency_type ] ) ) {
                                $threshold_statements[ $latency_type ] = " (" . $latency_type . " > $threshold) ";
                            }
                    }
                }
            }
        }
        
        // latency history tables are named after the day the snapshot was taken
        $table_name = $this->current_table_name($data_center);
        $timestamp = $this->latency_history_timestamp($data_center);

        $threshold_clause = '';
        if (count($threshold_statements)) {
            $threshold_clause = 'AND (' . join(' || ', $threshold_statements) . ')';
        }
        
        $userid_clause = '';
        if (count($user_list) > 0) {
            $userid_clause = 'AND (userid in (' . join(',', array_keys($user_list) ) . ') )';
        }

        // get all users close to any threshold; we can throw a few away later
        $sql = "SELECT " . $this->sql_comment . "\n" .
                " DISTINCT userid, update_dt_tm, lobby, elevator, export, axle \n" .
                " FROM " . $table_name . " \n" .
                " WHERE (update_dt_tm = '" . $timestamp . "')\n" .
                "   " . $threshold_clause . "\n" .
                "   " . $userid_clause . "\n";
        return $sql;
    }
    
    function current_table_name($data_center) {
        if (empty($this->current_table_names[$data_center])) {
            // latency history tables are named after the day the snapshot was taken
            $table_name = 'latency_history_' . date('Y_m_d');
            $yesterday_table_name = 'latency_history_' . date('Y_m_d', (time() - 24*60*60));
            
            // make sure a record exists in this table.  if no records, go back a day.
            $db = $this->db_handle('latency_history', $data_center);
            $db->halt_on_error = false;
            $sql = 'SHOW TABLES LIKE "' . $table_name . '"';
            $db->query($sql);
    
            if ($db->Errno == 0) {
                if ($db->next_record()) {
                    $this->current_table_names[$data_center] = $table_name;
                    return $table_name;
                }
            }
            
            // if today's table name is not found, use yesterday's (may be neceessary for correct reporting at 12:01 Pacific Time)
            $this->current_table_names[$data_center] = $yesterday_table_name;
        }
        return $this->current_table_names[$data_center];
    }
    
    function search_user_list(&$search_results, $user_list, $data_center = NULL) {
        if (is_null($data_center)) {
            $data_center = $this->target_data_center();
        }
        
        // first do a really loose search in the latency history tableS
        $sql = $this->build_latency_history_query($user_list, $data_center);
        $db = $this->db_handle('latency_history', $data_center);
        $db->query($sql);
        while( $db->next_record()) {
            $userid = $db->f('userid');
            $key = $user_list[$userid]['username'] . '-' . $data_center;
            $user_list[$userid]['lobby'] = $db->f('lobby');
            $user_list[$userid]['elevator'] = $db->f('elevator');
            $user_list[$userid]['export'] = $db->f('export');
            $user_list[$userid]['export_latency_minutes'] = round($db->f('export')/60);
            $user_list[$userid]['axle'] = $db->f('axle');
            $this->add_report_suite_data($search_results, $user_list[$userid], $data_center);
            //$search_results[$key] = $user_list[$userid];
        }
        return true;
    }
    
    function search( $args = NULL ) {
        if ( is_array($args) && ( !( empty($args) ) ) ) {
            //echo "searching with loaded args:"; print_r($args);
            $this->load_args($args);
        }

        // get the list of users to check, chunked by data center        
        $data_center_user_lists = $this->get_starting_user_list();
        //print_r($data_center_user_lists);
        foreach($data_center_user_lists as $data_center => $data_center_user_list) {
            
            // chunk the users belonging to this data center
            $chunked_user_list = array_chunk( $data_center_user_list, $this->user_list_chunk_size(), true );

            foreach($chunked_user_list as $user_list) {
                $this->search_user_list($this->serp_data, $user_list, $data_center);
            }
        }
        
        return true;
    }
    
    function results($format = self::FORMAT_JSON) {
    
        if (empty($format)) {
            $format = $this->output_format();
        }
        
        // return the search results
        // in the requested format
        
        if (count($this->serp_data) == 0) {
            return false;
        }
        
        switch($format) {
            case self::FORMAT_PHP:
                return serialize($this->serp_data);
                break;
            case self::FORMAT_JSON:
                return json_encode($this->serp_data);
                break;
            //case self::FORMAT_CSV:
                /* todo: format for CSV */
                //break;
        }
    }
    
    
    // report suite data will be used to fill in a search results page (or email)
    function add_report_suite_data(&$search_results, $rs_data, $data_center) {
        $include = false;
        $key = $rs_data['username'] . '-' . $data_center;
        
        /* START exclude report suites based on additional criteria (not related to latency) */

        // do we need to exclude it because it is a test account?
        $customers_to_exclude = $this->exclude_customers();
        if (is_array($customers_to_exclude) && (!empty($customers_to_exclude))) {
            
            if (in_array($rs_data['billing_customer_name'], $customers_to_exclude)) {
               return $include;
            }
        }
        
        // do we need to exclude it because it is migrating?
        // not until we have multi-data-center support for data migration.

        /* END exclude report suites based on criteria not related to latency */

        /* START exclude report suites based on latency data */
        // get version and top100
        $rs_data['sc_version'] = $this->get_sc_version($rs_data, $data_center);
        $rs_data['top100']     = $this->get_top_100_status($rs_data, $data_center);
        
        $latency_group = self::EVERYONE;       
        if ($rs_data['top100']) {
            $latency_group = self::TOP_100;
        }
        
        // lobby latency minutes
        $lobby_threshold = $this->latency_threshold(self::LOBBY, $latency_group);
        if (($rs_data['lobby'] >= $lobby_threshold) && ($lobby_threshold > 0)) {
            $include = true;
        }
        
        // elevator latency minutes
        $elevator_threshold = $this->latency_threshold(self::ELEVATOR, $latency_group);
        if (($rs_data['elevator'] >= $elevator_threshold) && ($elevator_threshold > 0)) {
            $include = true;
        }
        
        // export latency minutes
        $export_threshold = $this->latency_threshold(self::EXPORT, $latency_group);
        if (($rs_data['export'] >= $export_threshold) && ($export_threshold > 0)) {
            $include = true;
        }
        
        // axle latency minutes
        $axle_threshold = $this->latency_threshold(self::AXLE, $latency_group);
        if (($rs_data['axle'] >= $axle_threshold) && ($axle_threshold > 0)) {
            $include = true;
        }

        // SC latency minutes
        $sc_threshold = $this->latency_threshold(self::SITE_CATALYST, $latency_group);
        if ($rs_data['sc_version'] == '15') {
            $rs_data['sc_latency_seconds'] = $rs_data['axle'];
            if (($rs_data['axle'] >= $sc_threshold) && ($sc_threshold > 0)) {
                $include = true;
            }
        }
        else { // v14
            $rs_data['sc_latency_seconds'] = $rs_data['elevator'];
            if (($rs_data['elevator'] >= $sc_threshold) && ($sc_threshold > 0)) {
                $include = true;
            }
        }
        $rs_data['sc_latency_minutes'] = round( $rs_data['sc_latency_seconds'] / 60 );
        
        /* END exclude report suites based on latency data */

        if ($include) {
            $search_results[$key] = $rs_data;
        }
        
        return $include;
    }
    
    function add_serp_data($key, $data) {
        $this->serp_data[$key] = $data;
    }
    
    function get_starting_user_list() {
        $starting_user_list = array();
        // 1. break the user list up into smaller lists by data center
        // 3. chunk the user lists in each data center (between 500 & 1000 is best)
        
        // collect all of the report suites belonging to any listed ECC ID
        if ( count( $this->ecc_id_list() ) ) {
            $this->add_report_suites_for_ecc_id_list( $starting_user_list, $this->ecc_id_list() );
        }
        
        // collect all of the report suites belonging to any listed billing customer name
        if ( count( $this->billing_customer_name_list() ) ) {
            $this->add_report_suites_for_billing_customer_name_list( $starting_user_list, $this->billing_customer_name_list() );
        }
        
        // collect all of the report suites belonging to any listed company ID
        if ( count( $this->companyid_list() ) ) {
            $this->add_report_suites_for_companyid_list($starting_user_list, $this->companyid_list() );
        }
        
        // collect all of the report suites belonging to any listed company name
        if ( count( $this->login_company_name_list() ) ) {
            $this->add_report_suites_for_login_company_name_list($starting_user_list, $this->login_company_name_list() );
        }
        
        // collect all of the report suites belonging to any listed username
        if ( count( $this->username_list() ) ) {
            $this->add_report_suites_for_username_list($starting_user_list, $this->username_list() );
        }
        
        // collect all of the report suites belonging to any listed userid
        if ( count( $this->userid_list() ) ) {
            $this->add_report_suites_for_userid_list($starting_user_list, $this->userid_list() );
        }
        
        return $starting_user_list;
    }
    
    function latency_history_timestamp($data_center = DATA_CENTER) {
        if (!isset($this->latency_history_timestamps[$data_center])) {
            $this->latency_history_timestamps[$data_center] = $this->get_latency_history_timestamp($data_center);
        }
        return $this->latency_history_timestamps[$data_center];
    }
    
    protected function get_latency_history_timestamp($data_center = DATA_CENTER) {
        $db = $this->db_handle('latency_history', $data_center);
        $db->halt_on_error = false;
        $table_name = $this->current_table_name($data_center);
        $sql = "SELECT " . $this->sql_comment . "\n" .
            ' max(update_dt_tm) as stamp from ' . $table_name;
        $db->query($sql);

        if ($db->Errno == 0) {
            if ($db->next_record()) {
                $update_dt_tm = $db->f('stamp');
                return $update_dt_tm;
            }
        }
        return NULL;
    }
    
    protected function latency_history_timestamps( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->latency_history_timestamps = $new_value;
		}
		return $this->latency_history_timestamps;
	}

	// get a list of all report suites for a specific billing customer ECC ID
    // user_list is passed by reference!!
	function add_report_suites_for_ecc_id_list(&$user_list, $ecc_id_array) {
        $cnt = count($ecc_id_array);
	
		// don't search on an empty array
		if ($cnt == 0) {
			return 0;
		}
	
        $ecc_id_str = join(',', $ecc_id_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            $db->halt_on_error = false;

            $billing_customers    = array();
            $billing_customer_ids = array();

            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    DISTINCT billing_customer_id, ecc_id, billing_customer_name\n" .
                   "FROM \n" .
                   "    company_billing_customer\n"  .
                   "WHERE \n" .
                   "    ecc_id IN (" . $ecc_id_str . ")\n" .
                   "LIMIT " . $cnt . "\n";
            $db->query($sql);
            while ($db->next_record()) {
                $billing_customer_id = $db->f('billing_customer_id');
                $billing_customer_ids[$billing_customer_id] = $billing_customer_id;
                $billing_customers[$billing_customer_id] = array(
                    'billing_customer_id' => $billing_customer_id,
                    'ecc_id' => $db->f('ecc_id'),
                    'billing_customer_name' => $db->f('billing_customer_name'),
                );
            }
            
            // don't continue this loop if no billing customers were found
            if (count($billing_customer_ids) <= 0) {
                continue;
            }

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $billing_customer_str = join(',', $billing_customer_ids);
                
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    DISTINCT userid, billing_customer_id, companyid, \n" .
                   "    username\n" .
                   "FROM \n" .
                   "    user_company_billing_customer\n" .
                   "WHERE \n" .
                   "    billing_customer_id IN (" . addslashes($billing_customer_str) . ")\n";
            $db->query($sql);
            
            while ($db->next_record()) {
                $username = $db->f("username");
                $userid   = $db->f("userid");
                $billing_customer_id = $db->f('billing_customer_id');
                
                if (!array_key_exists($userid, $user_list[$data_center])) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $billing_customer_id;
                $user_list[$data_center][$userid]['companyid'] = $db->f('companyid');
                $user_list[$data_center][$userid]['ecc_id'] = $billing_customers[$billing_customer_id]['ecc_id'];
                $user_list[$data_center][$userid]['data_center'] = $data_center;
                $user_list[$data_center][$userid]['billing_customer_name'] = $billing_customers[$billing_customer_id]['billing_customer_name'];
            }
        }
	}

	// get a list of all report suites for a specific billing customer ECC ID
    // user_list is passed by reference!!
	function add_report_suites_for_billing_customer_name_list(&$user_list, $billing_customer_name_array) {
        $cnt = count($billing_customer_name_array);
	
		// don't search on an empty array
		if ($cnt == 0) {
			return 0;
		}
	
        $billing_customer_name_str = join("','", $billing_customer_name_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            $db->halt_on_error = false;

            $billing_customers    = array();
            $billing_customer_ids = array();

            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    billing_customer_id, ecc_id, billing_customer_name, companyid, company_name \n" .
                   "FROM \n" .
                   "    company_billing_customer\n"  .
                   "WHERE \n" .
                   "    billing_customer_name IN ('" . $billing_customer_name_str . "')\n" .
                   "LIMIT " . $cnt . "\n";
            $db->query($sql);
            while ($db->next_record()) {
                $billing_customer_id = $db->f('billing_customer_id');
                $billing_customer_ids[$billing_customer_id] = $billing_customer_id;
                $billing_customers[$billing_customer_id] = array(
                    'billing_customer_id' => $billing_customer_id,
                    'ecc_id' => $db->f('ecc_id'),
                    'billing_customer_name' => $db->f('billing_customer_name'),
                    'login_company_id' => $db->f('companyid'),
                    'login_company_name' => $db->f('company_name'),
                );
            }
            
            // don't continue this loop if no billing customers were found
            if (count($billing_customer_ids) <= 0) {
                continue;
            }

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $billing_customer_str = join(',', $billing_customer_ids);
                
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    DISTINCT userid, billing_customer_id, companyid, \n" .
                   "    username\n" .
                   "FROM \n" .
                   "    user_company_billing_customer\n" .
                   "WHERE \n" .
                   "    billing_customer_id IN (" . addslashes($billing_customer_str) . ")\n";
            $db->query($sql);
            while ($db->next_record()) {
                $username = $db->f("username");
                $userid   = $db->f("userid");
                $billing_customer_id = $db->f('billing_customer_id');
                
                if (!array_key_exists($userid, $user_list[$data_center])) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $billing_customer_id;
                $user_list[$data_center][$userid]['companyid'] = $db->f('companyid');
                $user_list[$data_center][$userid]['ecc_id'] = $billing_customers[$billing_customer_id]['ecc_id'];
                $user_list[$data_center][$userid]['billing_customer_name'] = $billing_customers[$billing_customer_id]['billing_customer_name'];
                $user_list[$data_center][$userid]['data_center'] = $data_center;
            }
        }
	}

	// get a list of all report suites for a specific billing customer ECC ID
    // user_list is passed by reference!!
	function add_report_suites_for_login_company_name_list(&$user_list, $login_company_name_array) {
        $cnt = count($login_company_name_array);
        
		// don't search on an empty array
		if ($cnt == 0) {
			return 0;
		}
	
        $login_company_name_str = join("','", $login_company_name_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            //$db->halt_on_error = false;
            $login_companies = array();
            $company_ids = array();

            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    billing_customer_id, ecc_id, billing_customer_name, companyid, company_name \n" .
                   "FROM \n" .
                   "    company_billing_customer\n"  .
                   "WHERE \n" .
                   "    company_name IN ('" . $login_company_name_str . "')\n" .
                   "LIMIT " . $cnt . "\n";

            $db->query($sql);
            while ($db->next_record()) {
                $company_id = $db->f('companyid');
                $company_ids[$company_id] = $company_id;
                $login_companies[$company_id] = array(
                    'billing_customer_id' => $billing_customer_id,
                    'ecc_id' => $db->f('ecc_id'),
                    'billing_customer_name' => $db->f('billing_customer_name'),
                    'login_company_id' => $company_id,
                    'login_company_name' => $db->f('company_name'),
                );
            }
            
            // don't continue this loop if no companies were found
            if (count($company_ids) <= 0) {
                continue;
            }

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $login_company_str = join(',', $company_ids);
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    DISTINCT userid, billing_customer_id, companyid, \n" .
                   "    username\n" .
                   "FROM \n" .
                   "    user_company_billing_customer\n" .
                   "WHERE \n" .
                   "    companyid IN (" . addslashes($login_company_str) . ")\n";
            
            $db->query($sql);
            while ($db->next_record()) {
                $username = $db->f("username");
                $userid   = $db->f("userid");
                $login_company_id = $db->f('companyid');
                
                if (!array_key_exists($userid, $user_list[$data_center])) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $billing_customer_id;
                $user_list[$data_center][$userid]['companyid'] = $login_company_id;
                $user_list[$data_center][$userid]['ecc_id'] = $login_companies[$login_company_id]['ecc_id'];
                $user_list[$data_center][$userid]['billing_customer_name'] = $login_companies[$login_company_id]['billing_customer_name'];
                $user_list[$data_center][$userid]['data_center'] = $data_center;
            }
        }
	}
	
	// get a list of all report suites for a specific company ID
	function add_report_suites_for_companyid_list(&$user_list, $companyid_array) {

		// don't search on an empty array
		if (count($companyid_array) == 0) {
			return;
		}

        $companyid_str = join(',', $companyid_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            $db->halt_on_error = false;
			//if ($db->Errno) {
			//	continue;
			//}

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   "    DISTINCT userid, billing_customer_id, companyid, \n" .
                   "    username\n" .
                   "FROM \n" .
                   "    user_company_billing_customer\n" .
                   "WHERE \n" .
                   "    companyid IN (" . addslashes($companyid_str) . ")\n";
            $db->query($sql);

            while ($db->next_record()) {
                $userid   = $db->f("userid");
                $username = $db->f("username");
                
                if (!array_key_exists($userid, $user_list) && (!is_array($userid))) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $db->f('billing_customer_id');
                $user_list[$data_center][$userid]['companyid'] = $db->f('companyid');
                $user_list[$data_center][$userid]['data_center'] = $data_center;
            }
		
        }
	}

	
	// add to list of all report suites
	function add_report_suites_for_username_list(&$user_list, $username_array) {

		// don't search on an empty array
		if (count($username_array) == 0) {
			return;
		}

        $username_str = join("','", $username_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            $db->halt_on_error = false;
			//if ($db->Errno) {
			//	continue;
			//}

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   " DISTINCT userid, billing_customer_id, companyid, \n" .
                   " username\n" .
                   "FROM \n" .
                   " user_company_billing_customer\n" .
                   "WHERE \n" .
                   " username IN ('" . $username_str . "')\n";
            $db->query($sql);

            while ($db->next_record()) {
                $userid   = $db->f("userid");
                $username = $db->f("username");
                
                if (!array_key_exists($userid, $user_list) && (!is_array($userid))) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $db->f('billing_customer_id');
                $user_list[$data_center][$userid]['companyid'] = $db->f('companyid');
                $user_list[$data_center][$userid]['data_center'] = $data_center;
            }
		
        }
	}

	// add to list of all report suites
	function add_report_suites_for_userid_list(&$user_list, $userid_array) {
		// don't search on an empty array
		if (count($username_array) == 0) {
			return;
		}

        $userid_str = join("','", $userid_array);

		foreach($this->get_data_center_list() as $data_center) {
            $db = $this->db_handle( 'misc_metrics', $data_center );
            $db->halt_on_error = false;
			//if ($db->Errno) {
			//	continue;
			//}

            if (!array_key_exists($data_center, $user_list)) {
                $user_list[$data_center] = array();
            }
            
            $sql = "SELECT " . $this->sql_comment . "\n" .
                   " DISTINCT userid, billing_customer_id, companyid, \n" .
                   " username\n" .
                   "FROM \n" .
                   " user_company_billing_customer\n" .
                   "WHERE \n" .
                   " userid IN ('" . $userid_str . "')\n";
            $db->query($sql);

            while ($db->next_record()) {
                $userid   = $db->f("userid");
                $username = $db->f("username");
                
                if (!array_key_exists($userid, $user_list) && (!is_array($userid))) {
                    $user_list[$data_center][$userid] = array();
                }
                
                $user_list[$data_center][$userid]['username'] = $username;
                $user_list[$data_center][$userid]['userid'] = $userid;
                $user_list[$data_center][$userid]['billing_customer_id'] = $db->f('billing_customer_id');
                $user_list[$data_center][$userid]['companyid'] = $db->f('companyid');
                $user_list[$data_center][$userid]['data_center'] = $data_center;
            }
		
        }
    }
    
    // get the billing customer name
    function get_billing_customer_name($billing_customer_id) {
        $billing_customer = '';
        $companysql       = "SELECT " . $this->sql_comment . "\n" .
                   " cus_name from billing_customer where id=" . $billing_customer_id . " limit 1";
        $companydb->query($companysql);
    
        if ($companydb->next_record()) {
            $billing_customer = $companydb->f('cus_name');
        }
        
        return $billing_customer;
    }
    
    // get the SiteCatalyst version (14 or 15)
    function get_sc_version($user_data, $data_center) {
        $sql = "SELECT " . $this->sql_comment . "\n" .
                   " axle_start, axle_data, workbench_sampling \n" .
                   "FROM user_services \n" .
                   "WHERE user_services.userid=" . intval($user_data['userid']) . " LIMIT 1\n";
        $db = $this->user_db_handle($user_data['username'], $data_center);
        $db->query($sql);
        
        if( $db->next_record()) {
            $axle_start = $db->f('axle_start');
            $axle_data = $db->f('axle_data');
            $has_wb = $db->f('workbench_sampling');
        }
        
        $sc_version = '14';
        if (($axle_start != -1 && $axle_start != '0000-00-00' && $axle_start <= date('Y-m-d')) &&
                    $axle_data > 0 && $has_wb > 0) {
            $sc_version = '15';
        }

        return $sc_version;
    }
    
    function get_top_100_status($username) {
        $compass_lists = new Compass_Lists();
        $top100 = $compass_lists->is_priority_report_suite($username);
        return $top100;
    }
    
    function set_latency_threshold($latency_type, $latency_group, $value) {
        if (!is_array($this->thresholds[$latency_type])) {
            $this->thresholds[$latency_type] = array();
        }
        $new_value = intval($value);
        $this->thresholds[$latency_type][$latency_group] = $new_value;
        
        if (is_null($this->minimum_threshold_minutes) || ($value < $this->minimum_threshold_minutes)) {
            $this->minimum_threshold_minutes = $value;
        }
    }
    
    function latency_threshold($latency_type, $latency_group, $use_default = true) {
        if (!empty($this->thresholds[$latency_type]) && (!empty($this->thresholds[$latency_type][$latency_group]))) {
            return $this->thresholds[$latency_type][$latency_group];
        }
        
        if ($use_default) {
            // default to 3 hours for top 100 & SC latency
            if (($latency_type == self::SITE_CATALYST) && ($latency_group == self::TOP_100)) {
                return 3*60*60;
            }
            
            // always default to 4 hours
            return 4*60*60;
        }
        
        // if not found, and don't use default, return null because this threshold was not set
        return NULL;
    }
    
    function latency_thresholds() {
        return $this->thresholds;
    }
    
    function minimum_threshold() {
        return $this->minimum_threshold_minutes;
    }

    // returns the list of data centers to include in the search
    function get_data_center_list() {
        
        // if we're in production and/or the current data center is inside the 
        //    prod dc list (a possibility for qe??), return that if multi_data_center is flagged
        if ( $this->multi_data_center() ) {
            global $localConfig;
            $prod_dcs = $localConfig['production_data_center_list'];
            if (array_search(DATA_CENTER, $prod_dcs) !== false) {
                return $prod_dcs;
            }
        }
        
        // if the target data center is set (in parent class constructor),
        // use that
        $target_data_center = $this->target_data_center();
        if (!empty($target_data_center)) {
            return array($target_data_center);
        }
        
        // otherwise, use just this data center    
        return array(DATA_CENTER);
    }
    
	function ecc_id_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->ecc_id_list = $new_value;
		}
		return $this->ecc_id_list;
	}
	function billing_customer_name_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->billing_customer_name_list = $new_value;
		}
		return $this->billing_customer_name_list;
	}
	function login_company_name_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->login_company_name_list = $new_value;
		}
		return $this->login_company_name_list;
	}
	function companyid_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->companyid_list = $new_value;
		}
		return $this->companyid_list;
	}
	function userid_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->userid_list = $new_value;
		}
		return $this->userid_list;
	}
	function username_list( $new_value = null ) {
		if ( !empty( $new_value ) && is_array( $new_value ) ) {
			$this->username_list = $new_value;
		}
		return $this->username_list;
	}
  	function output_format( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->output_format = $new_value;
		}
		return $this->output_format;
	}
  	function exclude_customers( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->exclude_customers = $new_value;
		}
		return $this->exclude_customers;
	}
  	function exclude_migrating_accounts( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->exclude_migrating_accounts = $new_value;
		}
		return $this->exclude_migrating_accounts;
	}
  	function multi_data_center( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->multi_data_center = $new_value;
		}
		return $this->multi_data_center;
	}
  	function serp_offset( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->serp_offset = $new_value;
		}
		return $this->serp_offset;
	}
  	function serp_limit( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->serp_limit = $new_value;
		}
		return $this->serp_limit;
	}
    
    function user_list_chunk_size( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->user_list_chunk_size = $new_value;
		}
		return $this->user_list_chunk_size;
	}

}
