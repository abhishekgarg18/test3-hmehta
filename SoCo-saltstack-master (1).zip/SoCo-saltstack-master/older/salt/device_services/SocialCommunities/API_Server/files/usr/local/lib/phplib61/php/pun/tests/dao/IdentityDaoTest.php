<?php

include 'application.inc';

require_once 'pun/dao/IdentityDao.php';

class IdentityDaoTest extends PHPUnit_Framework_TestCase
{
	private $identity_dao;

	public function __construct()
	{
		$this->identity_dao = new IdentityDao();
	}

	public function test_getLogins()
	{
		$logins = $this->identity_dao->getLoginsForRsid('bugzilla.www14');

		//print_r($logins);
		$this->assertType('array', $logins);
		$this->assertTrue(count($logins) > 0);
	}
	
	public function test_isLoginInCompany()
	{
		$this->assertTrue($this->identity_dao->isLoginInCompany(39606, 1, 'funkcorp'));
	}

	public function test_getLoginsFromIDs()
	{
		$logins = $this->identity_dao->getLoginsFromIDs(array(40654, 40656, 39710, 130), 1, 'funkcorp');

		//print_r($logins);
		$this->assertType('array', $logins);
		$this->assertTrue(count($logins) > 0);
	}

	public function test_suiteNamefromid()
	{
		$id = $this->identity_dao->getSuiteNameFromSuiteID(2659380);

		$this->assertTrue($id != null);
	}

	public function test_suiteidFromName()
	{
		$this->assertTrue($this->identity_dao->getSuiteIDFromSuiteName('bugzilla.www14') != null);
		$this->assertTrue($this->identity_dao->getSuiteIDFromSuiteName('sistr2') != null);
	}

	public function test_getCompany()
	{
		list($cid, $c) = $this->identity_dao->getCompanyForRsid('bugzilla.www14');
		$this->assertTrue($cid != 0);
	}

	public function test_getBC()
	{
		list($bcid, $b) = $this->identity_dao->getBillingCustomerForRsid('bugzilla.www14');
		$this->assertTrue($bcid != 0);
	}

	public function test_isv15()
	{
		$this->assertFalse($this->identity_dao->rsIsV15('bugzilla.www14'));
		$this->assertTrue($this->identity_dao->rsIsV15('sistr2'));
	}

	public function test_getLoginIDFromName()
	{
		$loginID = $this->identity_dao->getLoginIdFromLoginName('tfunk', 1, 'funkcorp');

		$this->assertTrue($loginID > 0);
	}

	public function test_getInfoForSistr2()
	{
		$rsid = 'sistr2';
		$id = $this->identity_dao->getSuiteIDFromSuiteName($rsid);
		$this->assertTrue(isset($id));
		list($cid, $c) = $this->identity_dao->getCompanyForRsid($rsid);
		$this->assertTrue($cid != 0);
		list($bcid, $b) = $this->identity_dao->getBillingCustomerForRsid($rsid);
		$this->assertTrue($bcid != 0);

		echo "$rsid - bc: $bcid, $b - lc: $cid, $c\n";
	}
}

