<?php

//models
require_once 'pun/model/LatencyNoticeDefinition.php';
require_once 'pun/model/LatencyNoticeDefinitionSelector.php';
require_once 'pun/model/LatencyNotice.php';
require_once 'pun/model/LatencyNoticeSelector.php';
require_once 'pun/model/Login.php';
require_once 'pun/model/LoginSelector.php';

//service
require_once 'pun/services/LatencyNoticeDefinitionService.php';
require_once 'pun/services/LatencyNoticeService.php';
require_once 'pun/services/ConfigService.php';
require_once 'pun/services/Exceptions.php';

//utility
require_once "log4php/Logger.php";

L4P_Logger::configure('pun/LogConfig.xml');


class LatencyNoticeWebClient
{
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);		
	}

	/*
	 * tests whether there exists a noticeDefinition for a given rs
	 *
	 * NOTE: stubbed out
	 */
	public function noticeDefinitionExistsForReportSuite($rsid)
	{
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->setRsid($rsid);

		$defs = $this->getNoticeDefinitions($selector);
		if (count($defs) > 0)
			return true;
		return false;
	}
	
	public function noticeDefinitionExistsForCompany($companyid)
	{
		$notice_service = new LatencyNoticeService();
		$selector = new LatencyNoticeDefinitionSelector();
		$selector->setLoginCompany($companyid);
		$defs = $this->getNoticeDefinitions($selector);
		return (count($defs) > 0) ? true : false;
	}

	/*
	 * tests whether rs is eligible for notices
	 * i.e. part of top 100 on the list of rs eligible
	 *
	 */
	public function noticeEligible($rsid)
	{
		$configService = new ConfigService();
		
		return $configService->isUsernameEligible($rsid);
	}

	public function getNoticeDefinition($id)
	{
		if (! is_numeric($id)) {
			throw new InvalidParameterException(__METHOD__, 'id');
		}

		$int_id = intval($id);

		$notice_definitions = new LatencyNoticeDefinitionService();

		return $notice_definitions->getLatencyNoticeDefinition($int_id);
	}	
	
	public function getNoticeDefinitions($selector)
	{
		if (! (is_object($selector) && (get_class($selector) == 'LatencyNoticeDefinitionSelector')))
		{
			throw new InvalidParameterException(__METHOD__, 'selector');
		}

		$notice_definitions = new LatencyNoticeDefinitionService();
		///TODO validate selector?
		return $notice_definitions->getLatencyNoticeDefinitions($selector);
	}
	
	public function createNoticeDefinition($notice_definition)
	{
		if (! (is_object($notice_definition) && (get_class($notice_definition) == 'LatencyNoticeDefinition')))
		{
			throw new InvalidParameterException(__METHOD__, 'notice_definition');
		}

		$notice_definitions = new LatencyNoticeDefinitionService();
		$notice_definitions->validateDefinition($notice_definition);
		return $notice_definitions->saveLatencyNoticeDefinition($notice_definition);
	}
	
	public function updateNoticeDefinition($notice_definition)
	{
		if (! (is_object($notice_definition) && (get_class($notice_definition) == 'LatencyNoticeDefinition')))
		{
			throw new InvalidParameterException(__METHOD__, 'notice_definition');
		}
		
		///TODO validate definition

		$notice_definitions = new LatencyNoticeDefinitionService();
		$notice_definitions->validateDefinition($notice_definition);
		return $notice_definitions->updateLatencyNoticeDefinition($notice_definition);
	}
	
	public function setNoticeDefinitionState($notice_definition_id, $state)
	{
		$nd = $this->getNoticeDefinition($notice_definition_id);
		$nd->setNotifyState($state);
		return $this->updateNoticeDefinition($nd);
	}
	
	public function getNotice($id)
	{
		if (! is_numeric($id)) {
			throw new InvalidParameterException(__METHOD__, 'id');
		}

		$notice_service = new LatencyNoticeService();
		return $notice_service->getLatencyNotice(intval($id));
	}
	
	public function getNotices($selector)
	{
		if (! (is_object($selector) && (get_class($selector) == 'LatencyNoticeSelector')))
		{
			throw new InvalidParameterException(__METHOD__, 'selector');
		}

		$notice_service = new LatencyNoticeService();
		///TODO validate selector?
		return $notice_service->getLatencyNotices($selector);
	}

	/*
	 * returns the start time for the incident associated
	 * with a Latency Notice
	 *
	 */
	public function getNoticeIncidentStartTime($notice_id)
	{
		$notice_service = new LatencyNoticeService();
		$notice = $notice_service->getLatencyNotice($notice_id);
		if ($notice == null)
		{
			throw new NotFoundException('LatencyNotice');
		}
		return $notice->getSentTime();
	}

	public function getLastNoticeForRS($rsid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastLatencyNoticeForUser($rsid);
	}
	
	public function getLastNoticeForCompany($companyid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastLatencyNotice($companyid);
	}

	public function inIncident($rsid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->isUserCurrentlyLatent($rsid);
	}
	
	public function isCompanyInIncident($companyid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->isCurrentlyLatent($companyid);
	}

	public function lastIncidentStart($rsid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastIncidentStartTimeForUser($rsid);
	}
	
	public function lastIncidentStartForCompany($companyid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastIncidentStartTime($companyid);
	}

	public function lastIncidentEnd($rsid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastIncidentEndTimeForUser($rsid);
	}
	
	public function lastIncidentEndForCompany($companyid)
	{
		$notice_service = new LatencyNoticeService();
		return $notice_service->getLastIncidentEndTime($companyid);
	}
	
	public function getLogins($selector)
	{
		throw new NotImplementedException('LatencyNoticeWebClient::getLogins');
	}
	
	public function getEmailFrequencyOptions()
	{
		$config = new ConfigService();
		return $config->getEmailFrequencyOptions();
	}
	
	public function getLatencyThresholdOptions()
	{
		$config = new ConfigService();
		return $config->getLatencyThresholdOptions();
	}
	
	public function getNoticeStateOptions()
	{
		$config = new ConfigService();
		return $config->getNotificationStateOptions();
	}

	public function unsubscribeLoginFromNotices($company_id, $login_id)
	{
		$lnds = new LatencyNoticeDefinitionService();
		$lnds->setLoginSubscription($company_id, $login_id, 0);
	}
}
	

