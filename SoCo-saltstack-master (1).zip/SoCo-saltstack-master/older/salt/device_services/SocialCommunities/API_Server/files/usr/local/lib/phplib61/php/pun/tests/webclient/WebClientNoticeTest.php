<?php

include 'application.inc';
require_once 'pun/webclient/LatencyNoticeWebClient.php';

class WebClientNoticeTest extends PHPUnit_Framework_TestCase
{
    private $webapi;

    public function __construct()
    {   
        $this->webapi = new LatencyNoticeWebClient();
    }   

	public function test_getNoticeBySelector()
	{
		$rsid = 'sistr2';
		$selector = new LatencyNoticeSelector();
		$selector->setRsid($rsid);
		$notices = $this->webapi->getNotices($selector);
		
		$this->assertType('array', $notices);
		$this->assertTrue((count($notices) > 0));
		$this->assertType('object', $notices[0]);
		$this->assertTrue(get_class($notices[0]) == 'LatencyNotice');
		//$this->assertTrue($notices[0]->getRsid() == $rsid);
	}

	public function test_getNoticeByID()
	{
		$rsid = 'sistr2';
		$selector = new LatencyNoticeSelector();
		$selector->setRsid($rsid);
		$selector->setLoginCompany('Bizco');
		$notices = $this->webapi->getNotices($selector);
		$this->assertTrue((count($notices) > 0), "this test is failing because the notice data has changed");
		$notice = $this->webapi->getNotice($notices[0]->getID());

		$this->assertType('object', $notice);
		$this->assertTrue(get_class($notice) == 'LatencyNotice');
	}

	public function test_getNoticeByLimitSelector()
	{
		$rsid = 'sistr2';
		$selector = new LatencyNoticeSelector();
		$selector->setRsid($rsid);
		$selector->limitResult(1);
		$notices = $this->webapi->getNotices($selector);
		
		$this->assertType('array', $notices);
		$this->assertTrue((count($notices) == 1), 'limit is not working');
		$this->assertType('object', $notices[0]);
		$this->assertTrue(get_class($notices[0]) == 'LatencyNotice');
		//$this->assertTrue($notices[0]->getRsid() == $rsid);
	}

}

