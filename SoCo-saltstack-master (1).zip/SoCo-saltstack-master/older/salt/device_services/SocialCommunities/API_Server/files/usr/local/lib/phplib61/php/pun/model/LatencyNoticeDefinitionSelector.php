<?php

class LatencyNoticeDefinitionSelector
{
	private $noticeDefId;
	private $rsid;
	private $userid;
	private $billingCustomerId;
	private $billingCustomerName;
	private $loginCompany;
	private $loginCompanyName;
	private $adobeEmail;
	private $haEmail;
	private $customerLogin;
	private $customerEmail;
	private $emailFrequency;
	private $latencyThreshold;
	private $noticeState;
	private $resultCountLimit;
	private $resultStartindex;
	
	public function getNoticeDefId()
	{
		return $this->noticeDefId;
	}
	
	public function setNoticeDefId($noticeDefId)
	{
		$this->noticeDefId = $noticeDefId;
	}
	
	public function getRsid() 
	{
		return $this->rsid;
	}
	
	public function getUserid()
	{
		return $this->userid;
	}
	
	public function setUserid($userid)
	{
		$this->userid = $userid;
	}

	public function getBillingCustomerId() 
	{
		return $this->billingCustomerId;
	}

	public function getBillingCustomerName()
	{
		return $this->billingCustomerName;
	}

	public function getLoginCompany() 
	{
		return $this->loginCompany;
	}

	public function getLoginCompanyName()
	{
		return $this->loginCompanyName;
	}

	public function getAdobeEmail() 
	{
		return $this->adobeEmail;
	}

	public function getHaEmail() 
	{
		return $this->haEmail;
	}

	public function getCustomerLogin() 
	{
		return $this->customerLogin;
	}

	public function getCustomerEmail() 
	{
		return $this->customerEmail;
	}

	public function getEmailFrequency() 
	{
		return $this->emailFrequency;
	}

	public function getLatencyThreshold() 
	{
		return $this->latencyThreshold;
	}

	public function getNoticeState() 
	{
		return $this->noticeState;
	}

	public function getResultCountLimit() 
	{
		return $this->resultCountLimit;
	}

	public function getResultStartindex() 
	{
		return $this->resultStartindex;
	}

	public function setRsid($rsid) 
	{
		$this->rsid = $rsid;
	}

	public function setBillingCustomerId($billingCustomerId) 
	{
		$this->billingCustomerId = $billingCustomerId;
	}

	public function setBillingCustomerName($billingCustomerName)
	{
		$this->billingCustomerName = $billingCustomerName;
	}

	public function setLoginCompany($loginCompany) 
	{
		$this->loginCompany = $loginCompany;
	}

	public function setLoginCompanyName($loginCompanyName)
	{
		$this->loginCompanyName = $loginCompanyName;
	}

	public function setAdobeEmail($adobeEmail) 
	{
		$this->adobeEmail = $adobeEmail;
	}

	public function setHaEmail($haEmail) 
	{
		$this->haEmail = $haEmail;
	}

	public function setCustomerLogin($customerLogin) 
	{
		$this->customerLogin = $customerLogin;
	}

	public function setCustomerEmail($customerEmail) 
	{
		$this->customerEmail = $customerEmail;
	}

	public function setEmailFrequency($emailFrequency) 
	{
		$this->emailFrequency = $emailFrequency;
	}

	public function setLatencyThreshold($latencyThreshold) 
	{
		$this->latencyThreshold = $latencyThreshold;
	}

	public function setNoticeState($noticeState) 
	{
		$this->noticeState = $noticeState;
	}

	public function limitResult($resultCountLimit, $resultStartIndex =  0)
	{
		$this->resultCountLimit = $resultCountLimit;
		$this->resultStartindex = $resultStartIndex;
	}
}

