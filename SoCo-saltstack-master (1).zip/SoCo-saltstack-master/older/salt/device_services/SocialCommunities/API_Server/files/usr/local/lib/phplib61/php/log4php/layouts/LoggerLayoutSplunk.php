<?php

class L4P_LoggerLayoutSplunk extends L4P_LoggerLayout {

	/**
	 * Constructor
	 */
	public function __construct() {
	}
  

    /**
     * Formats a {@link L4P_LoggerLoggingEvent} in conformance with the log4php.dtd.
     *
     * @param L4P_LoggerLoggingEvent $event
     * @return string
     */
    public function format(L4P_LoggerLoggingEvent $event) {
    
        $buf = "timestamp=".$timeStamp.",";
        $buf .= $event->getRenderedMessage(). PHP_EOL;
        
        return $buf;
    }   
}