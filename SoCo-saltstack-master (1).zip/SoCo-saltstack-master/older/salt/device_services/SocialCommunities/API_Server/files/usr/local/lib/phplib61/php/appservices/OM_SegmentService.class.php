<?
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2014 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property laws, 
* including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

require_once("appservices/OM_AppServiceBase.class.php");

class OM_SegmentService extends OM_AppServiceBase
{
	//Data Types
	const DATATYPE_ALL    = '';
	const DATATYPE_OBERON = 'oberon';
	const DATATYPE_DW     = 'dw';

	//Include Types
	const INCLUDETYPE_ALL = 'all';
	const INCLUDETYPE_SHARED = 'shared';

	public function getSimpleSegmentList($token,$datatype=OM_SegmentService::DATATYPE_ALL,$rsid=null,$expansion=array(),$includeType=null,$ownerId = 0,$includeBasicInfo=false, $selected=array())
	{
		$path = "/segments";
		//add the data type
		$path.='?dataType='.$datatype;
		//filter by rsid
		if (!is_null($rsid)) {
			$path .= "&rsid=".$rsid;
		}
		if (!is_null($includeType)) {
			$path .= "&includeType=".$includeType;
		}
		//Filter the list by a specific owner if necessary
		if($ownerId){
			$path .= "&ownerId=".$ownerId;
		}
		//add the expansion params
		if (is_array($expansion) && count($expansion) > 0) {
			$path .= "&expansion=".implode(',', $expansion);
		}
		if (is_array($selected) && count($selected) > 0) {
			$path .= "&segmentFilter=".implode(',', $selected);
		}
		$response_obj = $this->makeAnalyticsEndpointRequest($path,$token);
		if($response_obj && !$response_obj->hasErrors()){
			$response = $response_obj->getResponse();
			$response = json_decode($response);
			$result = array();
			foreach ($response as $item) {
				$seg = array();
				$seg['id'] = $item->id;
				$seg['name'] = $item->name;
				if ($includeBasicInfo) {
					$seg['rsid'] = $item->rsid;
					$seg['description'] = $item->description;
					$seg['owner'] = $item->owner;
				}
				if (is_array($expansion) && count($expansion) > 0) {
					foreach ($expansion as $expand) {
						$seg[$expand] = $item->$expand;
					}
				}
				$result[] = $seg;
			}
			usort($result,array("OM_SegmentService","sortSegmentsByName"));
			return $result;
		} else {
			return false;
		}
	}

	private static function sortSegmentsByName($segment_a, $segment_b){
		return strcasecmp($segment_a['name'],$segment_b['name']);
	}

	public function getSegmentName($segment_id,$token){
		if(!$segment_id) return self::getNoSegmentName();

		if($this->isOldDWSegmentId($segment_id)){
			if(stripos($segment_id,"dw:") !== 0){
				$segment_id = "dw:". $segment_id;
			}
		}

		$path = "/segments/$segment_id";

		$response_obj = $this->makeAnalyticsEndpointRequest($path,$token);
		if($response_obj && !$response_obj->hasErrors()){
			$response = $response_obj->getResponse();
			$response = json_decode($response);
			if($response && $response->name){
				return $response->name;
			}
		}
		return self::getUnknownSegmentName();
	}

	private function isOldDWSegmentId($segment_id){
		//The old segment ID stored in the account_segments table were numeric IDs with a max length of 10. The new IDs are longer and contain alpha characters
		if(strlen($segment_id) <= 10 && is_numeric($segment_id)){
			return true;
		}
		return false;
	}

	public function getSegmentId($legacy_segment_id,$token){

		$path = "/segments/$legacy_segment_id";

		$response_obj = $this->makeAnalyticsEndpointRequest($path,$token);
		if($response_obj && !$response_obj->hasErrors()){
			$response = $response_obj->getResponse();
			$response = json_decode($response);
			if($response && $response->id){
				return $response->id;
			}
		}
		return "";
	}

	public function changeOwner($segment_id,$new_owner_loginid,$token){
		if($segment_id && $new_owner_loginid){
			$path = "/segments/$segment_id";
			$request_body = json_encode(array("owner" => array("id" => $new_owner_loginid)));
			$this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::PUT_REQUEST,$request_body);
		}
	}

	public function deleteSegment($segment_id,$token){
		if($segment_id){
			$path = "/segments/$segment_id";
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::DELETE_REQUEST);
			if($response_obj && !$response_obj->hasErrors()){
				return $response_obj->getResponse();
			}
		}
		return false;
	}
	public function dwMigrate($dw_segment_id,$token) {
		if ($dw_segment_id) {
			$path = "/segments/migrate";
			$body = '{"legacyId":"dw:'.$dw_segment_id.'"}';
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::POST_REQUEST,$body);
			if($response_obj && !$response_obj->hasErrors()){
				return $response_obj->getResponse();
			}
		}
		return false;
	}

	/**
	 * Saves a segment and returns the response from the segment service which includes the segment id
	 */
	public function saveSegment($segment_name, $segment_definition, $report_suite_id, $token, $segment_description = ""){
		if($segment_name && $segment_definition && $report_suite_id){
			$path = "/segments";
			$body_array = array("name" => $segment_name, "rsid" => $report_suite_id, "definition" => $segment_definition, "description" => $segment_description);
			$body = json_encode($body_array);
			$response_obj = $this->makeAnalyticsEndpointRequest($path,$token,OM_AppServiceBase::POST_REQUEST,$body);
			if($response_obj && !$response_obj->hasErrors()){
				return $response_obj->getResponse();
			}
		}
		return false;
	}


	public static function getNoSegmentName()
	{
		return OM_L10n::getString('lib://all-visits-no-segment', 'All Visits (No Segment)');
	}

	public static function getUnknownSegmentName()
	{
		return OM_L10n::getString('lib://unknown-segment', 'Unknown Segment');
	}
}

