<?php

class InvalidParameterException extends Exception
{
    public function __construct($method, $parameter_name)
    {
        $msg = sprintf("method: %s, parameter: %s recieved an invalid value", $method, $parameter_name);
        parent::__construct($msg);
    }
}

class NotFoundException extends Exception
{
    public function __construct($object_type)
    {
        $msg = sprintf("object of type:%s not found", $object_type);
        parent::__construct($msg);
    }
}

class AlreadyExistsException extends Exception
{
    public function __construct($object_type, $id)
    {
        $msg = sprintf("object of type:%s, id:%s already exists", $object_type, $id);
        parent::__construct($msg);
    }
}

class NotImplementedException Extends Exception
{
    public function __construct($method)
    {
        $msg = sprintf("%s() : Not Implemented", $method);
        parent::__construct($msg);
    }
}

