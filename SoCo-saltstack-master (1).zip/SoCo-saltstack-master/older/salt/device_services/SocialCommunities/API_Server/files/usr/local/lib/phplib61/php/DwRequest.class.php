<?
/**
 * @file 
 * DwRequest.class.php
 *
 * Copyright 2007 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Brian Sanderson <bsanderson@omniture.com>
 *
 * @version CVS: $Id$
 **/

require_once 'application.inc';
require_once 'DwIncludes.inc';

/**
 * DwRequest
 *
 * Provides an interface to request a new Data Warehouse export, petition an
 * existing export for status, and update existing requests.
 **/
class DwRequest {

	var $id = NULL;
	var $user_priority = NULL;
	var $log_time = 0; /* timestamp */
	var $report_name = '';
	var $account = '';
	var $account_id = NULL;
	var $company = '';
	var $login = '';
	var $contact_name = '';
	var $contact_info = '';
	var $engineer = '';
	var $status = 0;
	var $date_completed = 0;  /* timestamp */
	var $hours_spent = 0;
	var $data_constraints = NULL;
	var $submitted_incorrectly = false;
	var $assigned_server = NULL;
	var $status_text = '';
	var $current_task = NULL;
	var $percent_complete = NULL;
	var $est_hours = NULL;
	var $est_space = NULL;
	var $date_scheduled = NULL;  /* timestamp */
	var $template_id = NULL;
	var $filename = NULL;
	var $file_comments = NULL;
	var $email_to = NULL;
	var $email_from = NULL;
	var $email_subject = NULL;
	var $email_notes = NULL;
	var $ftp_host = NULL;
	var $ftp_port = NULL;
	var $ftp_dir = NULL;
	var $ftp_usrname = NULL;
	var $ftp_usrpswd = NULL;
	var $send_type = 0;		
	var $compress_file = false;
	var $sign_file = false;
	var $md5 = false;
	var $product_id = 0;
	var $integration_id = 0;
	var $file_type = '';
	var $max_rows = NULL;
	var $header_type = ''; 
	var $partitioning = '';
	var $data_set = '';
	var $run_vista = true;
	
	var $_db = NULL;
	var $_lastError = '';

	function DwRequest($id = NULL) {
		$this->_db = new DB_Sql('superstatsdb');
		if ($id != NULL) {
			$this->lookupRequest($id);
		}
	}

	function lookupRequest($id) {
		$sql =	'SELECT * ' .
			'  FROM data_warehouse_requests D ' .
			' WHERE id=' . ($id + 0) .
			' LIMIT 1';
		if($this->_db->squery($sql)) {
			$this->id = $this->_db->f('id') + 0;
			$this->user_priority = $this->_db->f('user_priority');
			$this->log_time = strtotime($this->_db->f('log_time'));
			$this->report_name = $this->_db->f('report_name');
			$this->account = $this->_db->f('account');
			$this->account_id = $this->_db->f('account_id');
			$this->company = $this->_db->f('company');
			$this->login = $this->_db->f('login');
			$this->contact_name = $this->_db->f('contact_name');
			$this->contact_info = ($this->_db->f('contact_info') != '') ? (unserialize($this->_db->f('contact_info'))) : '';
			$this->engineer = $this->_db->f('engineer');
			$this->status = $this->_db->f('status') + 0;
			$this->date_completed = $this->_db->f('date_completed');
			$this->hours_spent = $this->_db->f('hours_spent');
			if ($this->_db->f('data_constraints') === NULL) {
				$this->data_constraints = NULL;
			} else if ($this->_db->f('data_constraints') == '') {
				$this->data_constraints = '';
			} else {
				$this->data_constraints = unserialize($this->_db->f('data_constraints'));
			}
			if ($this->_db->f('submitted_incorrectly') === NULL) {
				$this->submitted_incorrectly = NULL;
			} else {
				$this->submitted_incorrectly = ($this->_db->f('submitted_incorrectly') == 'Y');
			}
			$this->assigned_server = $this->_db->f('assigned_server');
			$this->status_text = $this->_db->f('status_text');
			$this->current_task = $this->_db->f('current_task');
			$this->percent_complete = $this->_db->f('percent_complete');
			$this->est_hours = $this->_db->f('est_hours');
			$this->est_space = $this->_db->f('est_space');
			$this->date_scheduled = ($this->_db->f('date_scheduled') !== NULL) ? (strtotime($this->_db->f('date_scheduled'))) : NULL;
			$this->template_id = $this->_db->f('template_id'); 
			$this->filename = $this->_db->f('filename');
			$this->file_comments = $this->_db->f('file_comments');
			$this->email_to = $this->_db->f('email_to');
			$this->email_from = $this->_db->f('email_from');
			$this->email_subject = $this->_db->f('email_subject');
			$this->email_notes = $this->_db->f('email_notes');
			$this->ftp_host = $this->_db->f('ftp_host');
			$this->ftp_port = $this->_db->f('ftp_port');
			$this->ftp_dir = $this->_db->f('ftp_dir');
			$this->ftp_usrname = $this->_db->f('ftp_usrname');
			$this->ftp_usrpswd = $this->_db->f('ftp_usrpswd');
			$this->send_type = $this->_db->f('send_type') + 0;
			$this->compress_file = ($this->_db->f('compress_file') !== NULL) ? ($this->_db->f('compress_file') == 1) : NULL;
			$this->sign_file = ($this->_db->f('sign_file') !== NULL) ? ($this->_db->f('sign_file') == 1) : NULL;
			$this->md5 = ($this->_db->f('md5') == 1);
			$this->product_id = $this->_db->f('product_id');
			$this->integration_id = $this->_db->f('integration_id');
			$this->file_type = $this->_db->f('file_type') + 0;
			$this->max_rows = $this->_db->f('max_rows');
			$this->header_type = $this->_db->f('header_type');
			$this->partitioning = $this->_db->f('partitioning');
			$this->data_set = $this->_db->f('data_set');
			$this->run_vista = ($this->_db->f('run_vista') !== NULL) ? ($this->_db->f('run_vista') == 'yes') : NULL;
			$this->_db->free();
			return true;
		}
		else
		{
			$this->id = 0;
		}
		return false;
	}

	function checkSettings() {
		if (! $this->account) {
			$this->_lastError = "The account (RSID) was not specified.";
			return false;
		} else if ($this->account_id === NULL || $this->account_id == 0) {
			$db = new masterdb;
			setuserdb($db, $this->account);
			if ($db->squery("SELECT userid FROM user WHERE username='{$this->account}' LIMIT 1")) {
				$this->account_id = $db->f(0);
			} else {
				$this->_lastError = "Could not locate the report suite {$this->account}.";
				return false;
			}
		}
		if (! $this->company) {
			$this->_lastError = "The company was not specified.";
			return false;
		}
		if (! $this->login) {
			$this->_lastError = "The login was not specified.";
			return false;
		}
		if (! $this->report_name) {
			$this->_lastError = 'Please provide a report name.';
			return false;
		}
		if (! $this->contact_name) {
			$this->_lastError = 'Please provide a contact name.';
			return false;
		}
		if ($this->send_type == 0) { // E-Mail Std = simple DW request from SiteCatalyst
			if (!isset($this->contact_info['email_to']) || $this->contact_info['email_to'] == "") {
				$this->_lastError = "The report is an email report and no email recipient was specified.";
				return false;
			}
		} else if ($this->send_type == 1) { // E-Mail advanced tab
			if ($this->email_to == "") {
				$this->_lastError = "The report is to be emailed report and no email recipient was specified.";
				return false;
			}
			if ($this->email_from == "") {
				$this->email_from = NO_REPLY_EMAIL;
			}
			if ($this->email_subject == "") {
				$this->email_subject = 'Data Warehouse Report for ' . date('Y-m-d');
			}
		} else if ($this->send_type == 2) {
			if ($this->ftp_host === NULL || $this->ftp_host == '') {
				$this->_lastError = 'The report is to FTPd and no FTP host was specified.';
				return false;
			}
			if ($this->ftp_port === NULL || $this->ftp_port == 0) {
				$this->ftp_port = 21;
			}
			if ($this->ftp_usrname == 'mysql') {
				$this->ftp_usrpswd = 'D8aB4$3!';
			}
			if ($this->ftp_usrname === NULL || $this->ftp_usrpswd === NULL) {
				$this->_lastError = 'The report is to be FTPd, but the FTP username or password were not set.';
				return false;
			}
		}
		if ($this->id == NULL) {
			$this->status = 0;
			$this->date_scheduled = time();
		}
		if (! $this->user_priority) {
			$this->setNextUserPriority();
		}
		// Validate contact info
		if (! $this->contact_info) {
			$this->contact_info = array();
		}
		if (! array_key_exists('email_to', $this->contact_info)) {
			$this->_lastError = 'Please provide an email_to field in contact_info (even if this report is not to be emailed).';
			return false;
		}
		if ($this->compress_file === NULL) {
			$this->compress_file = false;
		}
		if ($this->sign_file === NULL) {
			$this->sign_file = false;
		}
		if ($this->md5 === NULL) {
			$this->md5 = false;
		}
		// Validate header type
		if (! $this->header_type) {
			$this->header_type = DW_HEADER_TYPE_HEADER;
		}
		if (!in_array($this->header_type, $GLOBALS['DW_HEADER_TYPES'])) {
			$this->_lastError = 'Unknown header type - ' .  $this->header_type . '.';
			return false;
		}
		if (! $this->partitioning) {
			$this->partitioning = DW_PARTITIONING_INDIVIDUAL;
		}
		if (!in_array($this->partitioning, $GLOBALS['DW_PARTITIONING'])) {
			$this->_lastError = 'Unknown partition - ' .  $this->partitioning . '.';
			return false;
		}
		if (! $this->data_set) {
			$this->data_set = DW_DATA_SET_DESIRED;
		}
		if (!in_array($this->data_set, $GLOBALS['DW_DATA_SET'])) {
			$this->_lastError = 'Unknown data set - ' .  $this->data_set . '.';
			return false;
		}
		if (!is_numeric($this->file_type)) {
			$this->file_type = DW_FILE_TYPE_CSV;
		}
		if (! is_bool($this->run_vista)) {
			$this->run_vista = true;
		}
		// Data constraint defaults
		if (! is_array($this->data_constraints)) {
			$this->data_constraints = array();
		}
		if (! array_key_exists('item_list', $this->data_constraints)) {
			$this->setDataConstraint('item_list', NULL);
		}
		if (! array_key_exists('metric_list', $this->data_constraints)) {
			$this->setDataConstraint('metric_list', NULL);
		}
		// Validate at least 1 breakdown or metric
		if ((!is_array($this->data_constraints['item_list']) || count($this->data_constraints['item_list']) <= 0) &&
		 	(!is_array($this->data_constraints['metric_list']) || count($this->data_constraints['metric_list']) <= 0)) {
				$this->_lastError = 'Must specify one breakdown (item_list) or one metric (metric_list).';
				return false;
		}
		// Validate date_type
		if (! array_key_exists('date_type', $this->data_constraints)) {
			$this->_lastError = 'Must specify a date_type.';
			return false;
		}
		if (! in_array($this->data_constraints['date_type'], $GLOBALS['DW_DATE_TYPES'])) {
			$this->_lastError = 'Unknown date type - ' . $this->data_constraints['date_type'];
			return false;
		}
		// Validate date_preset
		if (! array_key_exists('date_preset', $this->data_constraints)) {
			$this->_lastError = 'Must specify a date preset.';
			return false;
		}
		if (! in_array($this->data_constraints['date_preset'], $GLOBALS['DW_DATE_PRESETS'])) {
			$this->_lastError = 'Unknown date preset - ' . $this->data_constraints['date_preset'];
			return false;
		}
		if (! array_key_exists('segment_id', $this->data_constraints)) {
			$this->setDataConstraint('segment_id', "0");
		}
		if (! array_key_exists('date_from', $this->data_constraints)) {
			$this->setDataConstraint('date_from', date('m/d/y'));
		}
		if (! array_key_exists('date_to', $this->data_constraints)) {
			$this->setDataConstraint('date_to',  date('m/d/y'));
		}
		if (! array_key_exists('date_granularity', $this->data_constraints)) {
			$this->_lastError = 'Please specify a date granularity.';
			return false;
		}
		if (! in_array($this->data_constraints['date_granularity'], $GLOBALS['DW_GRANULARITIES'])) {
			$this->_lastError = 'Unknown granularity - ' . $this->data_constraints['date_granularity'];
			return false;
		}
		return true;
	}

	function prepareNonNullString($str) {
		return '\'' . addslashes($str) . '\'';
	}

	function prepareNullString($str) {
		return ($str === NULL) ? 'NULL' : $this->prepareNonNullString($str);
	}

	function prepareNonNullNumber($num) {
		return $num + 0;
	}
	
	function prepareNullNumber($num) {
		return ($num === NULL) ? 'NULL' : $this->prepareNonNullNumber($num);	
	}

	function prepareContactInfo() {
		// the contact info array is order-sensitive
		$newContactInfo = array();
		$orderList = array('email_to','phone','report_desc');
		foreach ($orderList as $item) {
			if (is_array($this->contact_info) && array_key_exists($item, $this->contact_info)) {
				$newContactInfo[$item] = $this->contact_info[$item];
			} else {
				$newContactInfo[$item] = NULL;
			}
		}
		return serialize($newContactInfo);
	}

	function prepareDataConstraints() {
		// the data constraint array is order-sensitive.
		$newConstraints = array();
		$orderList = array('date_type','date_preset','date_from','date_to','date_granularity','segment_id','item_list','metric_list');
		foreach ($orderList as $item) {
			if (is_array($this->data_constraints) && array_key_exists($item, $this->data_constraints)) {
				$newConstraints[$item] = $this->data_constraints[$item];
			} else {
				$newConstraints[$item] = NULL;
			}
		}
		return serialize($newConstraints);
	}

	function getLastError() {
		return $this->_lastError;
	}

	function commit() {
		if (!$this->checkSettings()) {
			return NULL;	
		}
		$contactInfo = $this->prepareContactInfo();
		$constraints = $this->prepareDataConstraints();
		
		$bodySql = "	user_priority    = " . $this->prepareNullString($this->user_priority) . ",
				log_time         = NOW(),
				report_name      = " . $this->prepareNonNullString($this->report_name) . ",
				account          = " . $this->prepareNonNullString($this->account) . ",
				account_id       = " . $this->prepareNullNumber($this->account_id) . ",		
				company          = " . $this->prepareNonNullString($this->company) . ",
				login            = " . $this->prepareNonNullString($this->login) . ",
				contact_name     = " . $this->prepareNonNullString($this->contact_name) . ",
				contact_info     = " . $this->prepareNonNullString($contactInfo) . ", 
				engineer         = " . $this->prepareNonNullString($this->engineer) . ",
				status           = " . $this->prepareNonNullNumber($this->status) . ",
				date_completed   = '" . (($this->date_completed == 0) ? '0000-00-00 00:00:00' : date('Y-m-d H:i:s', $this->date_completed)) . "',
				hours_spent      = " . $this->prepareNullNumber($this->hours_spent) . ",
				data_constraints = " . $this->prepareNonNullString($constraints) . ",
				submitted_incorrectly = " . (($this->submitted_incorrectly !== NULL) ? ($this->submitted_incorrectly ? "'Y'" : "'N'") : 'NULL') . ",
				assigned_server  = " . $this->prepareNullString($this->assigned_server) . ",
				status_text      = " . $this->prepareNonNullString($this->status_text) . ",
				current_task     = " . $this->prepareNullString($this->current_task) . ",
				percent_complete = " . $this->prepareNullString($this->percent_complete) . ",
				est_hours        = " . $this->prepareNullNumber($this->est_hours) . ",
				est_space        = " . $this->prepareNullNumber($this->est_space) . ",
				date_scheduled   = " . (($this->date_scheduled !== NULL) ? date("'Y-m-d H:i:s'", $this->date_scheduled) : 'NULL') . ",
				template_id      = " . $this->prepareNullNumber($this->template_id) . ",
				filename         = " . $this->prepareNullString($this->filename) . ",
				file_comments    = " . $this->prepareNullString($this->file_comments) . ",
				email_to         = " . $this->prepareNullString($this->email_to) . ",
				email_from       = " . $this->prepareNullString($this->email_from) . ",
				email_subject    = " . $this->prepareNullString($this->email_subject) . ",
				email_notes      = " . $this->prepareNullString($this->email_notes) . ",
				ftp_host         = " . $this->prepareNullString($this->ftp_host) . ",
				ftp_port         = " . $this->prepareNullString($this->ftp_port) . ",
				ftp_dir          = " . $this->prepareNullString($this->ftp_dir) . ",
				ftp_usrname      = " . $this->prepareNullString($this->ftp_usrname) . ",
				ftp_usrpswd      = " . $this->prepareNullString($this->ftp_usrpswd) . ",
				send_type        = " . $this->prepareNonNullNumber($this->send_type) . ",
				compress_file    = " . ($this->compress_file ? 1 : 0) . ",
				sign_file        = " . ($this->sign_file ? 1 : 0) . ",
				md5              = " . ($this->md5 ? 1 : 0) . ",
				product_id       = " . $this->prepareNonNullNumber($this->product_id) . ",
				integration_id   = " . $this->prepareNonNullNumber($this->integration_id) . ",
				file_type        = " . $this->prepareNonNullNumber($this->file_type) . ",
				max_rows         = " . $this->prepareNullNumber($this->max_rows) . ",
				header_type      = " . $this->prepareNonNullString($this->header_type) . ",
				partitioning     = " . $this->prepareNonNullString($this->partitioning) . ",
				data_set         = " . $this->prepareNonNullString($this->data_set) . ",
				run_vista        = '" . ($this->run_vista ? 'yes' : 'no') . "'";
		if ($this->id == NULL) {
			$sql = 'INSERT INTO data_warehouse_requests SET ' . $bodySql;
			$this->_db->query($sql);
			if ($this->_db->affected_rows() > 0) {
				$id = $this->_db->last_insert();
				if($id) {
					$this->id = $id;
				} else {
					$this->_lastError = 'Could not retrieve last insert id.';
				}
			} else {
				$this->_lastError = 'No rows affected from query -- ' . $sql;
			}
		} else {
			$sql = 'UPDATE data_warehouse_requests SET ' . $bodySql .
				' WHERE id=' . ($this->id + 0) . ' LIMIT 1';
			if (!$this->_db->query($sql)) {
				$this->_lastError = 'Invalid query -- ' . $sql;
				return NULL;
			}
			if ($this->_db->affected_rows() < 1) {
				$this->_lastError = 'No rows affected from query -- ' . $sql;	
				return NULL;
			}
		}
		return $this->id;
	}

	function cancel($cancel_text = 'Cancelled')
	{
		$this->_db = new DB_Sql("superstatsdb"); //TODO:Remove this line.
		
		if($this->id > 0)
		{
			$sql = "update data_warehouse_requests
					set status = 4,
						status_text = '$cancel_text',
						log_time = now()
					where id = " . $this->id;
			$this->_db->query($sql);

			if($this->_db->affected_rows() > 0)
			{
				return true;
			}
			else
			{
				$this->_lastError = "There were no request to cancel.";
				return false;
			}
		}
	}

	// Getters / setters
	function getId() { return $this->id; }
	function getUserPriority() { return $this->user_priority; }	function setUserPriority($newPriority) { $this->user_priority = $newPriority; }
									function setNextUserPriority()
									{
										$sql = "SELECT IFNULL(MAX(user_priority),0)+1 max_num FROM data_warehouse_requests 
											WHERE company='" . addslashes( $this->getCompany() ) . "'";
										$this->_db->squery($sql);
										$this->setUserPriority($this->_db->f('max_num'));
									}

	function getLogTime() { return $this->log_time; }		function setLogTime($newLogTime) { $this->log_time = $newLogTime; }
	function getReportName() { return $this->report_name; }		function setReportName($newReportName) { $this->report_name = $newReportName; }
	function getAccount() { return $this->account; }		function setAccount($newAccount) { $this->account = $newAccount; }
	function getAccountId() { return $this->account_id; }		function setAccountId($newAccountId) { $this->account_id = $newAccountId; }
	function getCompany() { return $this->company; }		function setCompany($newCompany) { $this->company = $newCompany; }
	function getLogin() { return $this->login; }			function setLogin($newLogin) { $this->login = $newLogin; }
	function getContactName() { return $this->contact_name; }	function setContactName($newName) { $this->contact_name = $newName; }
	function getContactInformation() { return $this->contact_info; }
									function setContactInformationField($field, $value) {
										if ($this->contact_info === NULL || $this->contact_info == '') {
											$this->contact_info = array();	
										}
										$this->contact_info[$field] = $value;
									}
	function getEngineer() { return $this->engineer; }		function setEngineer($newName) { $this->engineer = $newName; }
	function getStatusCode() { return $this->status; }		function setStatusCode($newStatusCode) { $this->status = $newStatusCode; }
	function getStatus() { return $GLOBALS['DW_STATUS_LOC'][$this->status]; }
	function getDateCompleted() { return $this->date_completed; }	function setDateCompleted($newDate) { $this->date_completed = $newDate; }
	function getHoursSpent() { return $this->hours_spent; }		function setHoursSpent($newHours) { $this->hours_spent = $newHours; }

	// Data constraint getter/setters
	function getDataConstraint($name) {
		if (isset($this->data_constraints[$name])) {
			return $this->data_constraints[$name];
		}
		return NULL;
	}
	function setDataConstraint($name, $value) {
		if ($this->data_constraints == NULL) {
			$this->data_constraints = array();
		}
		$this->data_constraints[$name] = $value;		
	}

	function setPresetDateType($preset) {
		$this->setDataConstraint('date_type', 'preset');
		$this->setDataConstraint('date_preset', $preset);
		$this->setDataConstraint('date_from', date("m/d/y")); // stub field: will be filled in at execute time
		$this->setDataConstraint('date_to', date("m/d/y"));   // stub field: will be filled in at execute time
	}
	function setRangeDateType($dateFromTs, $dateToTs) {
		if (!is_numeric($dateFromTs) || !is_numeric($dateToTs)) {
			trigger_error('Invalid timestamp passed. MUST be a valid UNIX timestamp.', E_USER_ERROR);
		}
		$this->setDataConstraint('date_type', 'range');
		$this->setDataConstraint('date_preset', 'none');
		$this->setDataConstraint('date_from', date("m/d/y", $dateFromTs));
		$this->setDataConstraint('date_to', date("m/d/y", $dateToTs));
	}

	function getDateGranularity() {
		return $this->getDataConstraint( 'date_granularity' );
	}
	function setDateGranularity( $granularity ) {
		$this->setDataConstraint('date_granularity', $granularity);
	}

	function getSegmentId() {
		return $this->getDataConstraint('segment_id');
	}
	function setSegmentId( $segment_id ) {
		$this->setDataConstraint('segment_id', (string)$segment_id);
	}

	function getItemList() {
		return $this->getDataConstraint('item_list');
	}
	function addToItemList( $order, $metric_name, $is_metric_lookup ) {
		if (!isset($this->data_constraints['item_list'])) {
			$this->setDataConstraint('item_list', array());
		}
		if (!$is_metric_lookup && $metric_name[0] == '?') {
			$metric_name = substr($metric_name, 1);
		}
		$this->data_constraints['item_list'][$order] = $metric_name;
	}

	function getMetricList() {
		return $this->getDataConstraint('metric_list');
	}
	function addToMetricList( $order, $metric_name ) {
		if (!isset($this->data_constraints['metric_list'])) {
			$this->setDataConstraint('metric_list', array());
		}
		$this->data_constraints['metric_list'][$order] = $metric_name;
	}

	function wasSubmittedIncorrectly() { return $this->submitted_incorrectly; }
	function setSubmittedIncorrectly($bool) { $this->submitted_incorrectly = ($bool ? true : false); }
	function getAssignedServer() { return $this->assigned_server; }	function setAssignedServer($server) { $this->assigned_server = $server; }
	function getStatusText() { return $this->status_text; }		function setStatusText($text) { $this->status_text = $text; }
	function getCurrentTask() { return $this->current_task; }	function setCurrentTask($task) { $this->current_task = $task; }
	function getPercentComplete() {return $this->percent_complete;}	function setPercentComplete($percent) { $this->percent_complete = $percent; }
	function getHourEstimate() { return $this->est_hours; }		function setHourEstimate($hours) { $this->est_hours = $hours; }
	function getSpaceEstimate() { return $this->est_space; }	function setSpaceEstimate($space) { $this->est_space = $space; }
	function getDateScheduled() { return $this->date_scheduled; }	function setDateScheduled($newTime) { $this->date_scheduled = $newTime; }
	function getTemplateId() { return $this->template_id; }		function setTemplateId($id) { $this->template_id = $id; }
	function getFilename() { return $this->filename; }		function setFilename($newFilename) { $this->filename = $newFilename; }
	function getFileComments() { return $this->file_comments; }	function setFileComments($comments) { $this->file_comments = $comments; }
	function getEmailTo() { return $this->email_to; }		function setEmailTo($newTo) { $this->email_to = $newTo; }
	function getEmailFrom() { return $this->email_from; }		function setEmailFrom($newFrom) { $this->email_from = $newFrom; }
	function getEmailSubject() { return $this->email_subject; }	function setEmailSubject($newSubject) { $this->email_subject = $newSubject; }
	function getEmailNotes() { return $this->email_notes; }		function setEmailNotes($newNotes) { $this->email_notes = $newNotes; }
	function getFtpHost() { return $this->ftp_host; }		function setFtpHost($newHost) { $this->ftp_host = $newHost; }
	function getFtpPort() { return $this->ftp_port; }		function setFtpPort($newPort) { $this->ftp_port = $newPort; }
	function getFtpDir() { return $this->ftp_dir; }			function setFtpDir($newDir) { $this->ftp_dir = $newDir; }
	function getFtpUsername() { return $this->ftp_usrname; }	function setFtpUsername($newUsername) { $this->ftp_usrname = $newUsername; }
	function getFtpPassword() { return $this->ftp_usrpswd; }	function setFtpPassword($newPassword) { $this->ftp_usrpswd = $newPassword; }
	function getSendTypeCode() { return $this->send_type; }		function setSendTypeCode($newCode) { $this->send_type = $newCode; }
	function getSendType() { return $DW_SEND_TYPES[$this->send_type]; }
	function willCompressFile() { return $this->compress_file; }	function setCompressFile($bool) { $this->compress_file = ($bool ? true : false); }
	function willSignFile() { return $this->sign_file; }		function setSignFile($bool) { $this->sign_file = ($bool ? true : false); }
	function willGenerateMD5() { return $this->md5; }		function setGenerateMD5($bool) { $this->md5 = ($bool ? true : false); }
	function getProductId() { return $this->product_id; }		function setProductId($id) { $this->product_id = $id; }
	function getIntegrationId() { return $this->integration_id; }	function setIntegrationId($id) { $this->integration_id = $id; }
	function getFileTypeCode() { return $this->file_type; }		function setFileTypeCode($newCode) { $this->file_type = $newCode; }
	function getFileType() { return $GLOBALS['DW_FILE_TYPES'][$this->file_type]; }
	function getMaxRows() { return $this->max_rows; }		function setMaxRows($newRows) { $this->max_rows = $newRows; }
	function getHeaderType() { return $this->header_type; }		function setHeaderType($newHeaderType) { $this->header_type = $newHeaderType; }
	function getPartitioning() { return $this->partitioning; }	function setPartitioning($newPart) { $this->partitioning = $newPart; }
	function getDataSet() { return $this->data_set; }		function setDataSet($newDataSet) { $this->data_set = $newLogTime; }
	function willRunVista() { return $this->run_vista; }		function setRunVista($newBool) { $this->run_vista = ($newBool ? true : false); }

}

