<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2016 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

class CertifiedMetricsUtil
{
	const COMSCORE_INTEGRATION = "ComScore";

	//The integer key is what is stored in the DB, the value is the friendly name for the integration used in the Dr Teeth UI
	protected static $INTEGRATIONS = array(
		1 => self::COMSCORE_INTEGRATION
	);

	public static function getReportSuiteIntegrationsWithPostbackEnabled(array $rsids = array(), $get_all = false)
	{
		/*
		 * Cory Aitchison
		 * caitchis@adobe.com
		 * May 19, 2016
		 * This looks a little wierd but I did it this way so the method signature would remain uncahinged
		 */
		if (
			   !count($rsids)
			&& !$get_all
		) {
			return array();
		}

		$db = new DB_Sql("nielsendb");
		$sql = "SELECT username,integration_type FROM certified_metric_report_suites WHERE postback_enabled = 1";
		if (count($rsids) && !get_all) {
			$sql .= " and username IN (%a{rsids})";
		}

		$query = new DBQuery($db, $sql, array("rsids" => $rsids));
		$result = $query->execute();

		$return_value  = array();
		while ($result->hasNext()) {
			$data = $result->next();
			$return_value[$data['username']][] = self::dbFormatToIntegrationType($data['integration_type']);
		}

		return $return_value;
	}

	protected static function dbFormatToIntegrationType($dbformat_integration_type){
		$possible_mappings = self::$INTEGRATIONS;
		if(!isset($possible_mappings[$dbformat_integration_type])){
			throw new Exception("Failed to map $dbformat_integration_type to a valid certified metrics integration type");
		}
		return $possible_mappings[$dbformat_integration_type];
	}
}