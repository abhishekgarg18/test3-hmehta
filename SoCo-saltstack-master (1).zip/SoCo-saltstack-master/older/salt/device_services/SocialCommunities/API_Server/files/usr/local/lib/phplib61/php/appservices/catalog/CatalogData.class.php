<?php
  /*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2016 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/
  /**
   Written by drawal June,2016
   Represents Catalog RULE as an entity
  */

   class CatalogData implements JsonSerializable
   {

  
   private $catalogId;  
   private $fileDate;  
   private $name;  
   private $raid;
   private $monthNode;
   private $dataFormat;
   private $firstTimestamp;
   private $rows;
   private $fileSize;
   private $status;
   private $dateCataloged;
   private $actionId; 
  	public function jsonSerialize() 
  	{
        
        if(isset($this->catalogId))
          $arr['catalogId']=$this->catalogId;
        if(isset($this->fileDate))
          $arr['fileDate']=$this->fileDate;
        if(isset($this->name))
          $arr['name']=$this->name;
        if(isset($this->raid))
          $arr['raid']=base64_encode($this->raid);
        if($this->monthNode)
          $arr['monthNode']=$this->monthNode;
        if(isset($this->dataFormat))
          $arr['dataFormat']=$this->dataFormat;
        if(isset($this->firstTimestamp))
          $arr['firstTimestamp']=$this->firstTimestamp;
        if(isset($this->rows))
          $arr['rows']=$this->rows;
        if(isset($this->fileSize))
          $arr['fileSize']=$this->fileSize;
        if(isset($this->status))
            $arr['status']=$this->status;
        if(isset($this->dateCataloged))
            $arr['dateCataloged']=$this->dateCataloged;
        if(isset($this->actionId))
            $arr['actionId']=$this->actionId;
        return $arr;
    }

       public function getCatalogId()
       {
           return $this->catalogId;
       }

       public function setCatalogId($catalogId)
       {
           $this->catalogId = $catalogId;
       }

       public function getFileDate()
       {
           return $this->fileDate;
       }

       public function setFileDate($fileDate)
       {
           $this->fileDate = $fileDate;
       }

       public function getName()
       {
           return $this->name;
       }

       public function setName($name)
       {
           $this->name = $name;
       }

       public function getRaid()
       {
           return $this->raid;
       }

       public function setRaid($raid)
       {
           $this->raid = $raid;
       }

       public function getMonthNode()
       {
           return $this->monthNode;
       }


       public function setMonthNode($monthNode)
       {
           $this->monthNode = $monthNode;
       }


       public function getDataFormat()
       {
           return $this->dataFormat;
       }

       public function setDataFormat($dataFormat)
       {
           $this->dataFormat = $dataFormat;
       }
       
       public function getFirstTimestamp()
       {
           return $this->firstTimestamp;
       }
      
       public function setFirstTimestamp($firstTimestamp)
       {
           $this->firstTimestamp = $firstTimestamp;
       }
       
       public function getRows()
       {
           return $this->rows;
       }
       
       public function setRows($rows)
       {
           $this->rows = $rows;
       }
       
       public function getFileSize()
       {
           return $this->fileSize;
       }
       
       public function setFileSize($fileSize)
       {
           $this->fileSize = $fileSize;
       }
       
       public function getStatus()
       {
           return $this->status;
       }
       
       public function setStatus($status)
       {
           $this->status = $status;
       }
       
       public function getDateCataloged()
       {
           return $this->dateCataloged;
       }

       public function setDateCataloged($dateCataloged)
       {
           $this->dateCataloged = $dateCataloged;
       }
       
       public function getActionId()
       {
           return $this->actionId;
       }

       public function setActionId($actionId)
       {
           $this->actionId = $actionId;
       }

        public function setObjectFromJson($json)
       {
           $data = json_decode($json, true);
           $this->setObjectFromArray($data);
       }

        public function setObjectFromArray($data)
        {
           foreach ($data AS $key => $value) $this->{$key} = $value;
        }

}

/* Usage Examples 
$vr=new CatalogData(); //Initialization

*/

