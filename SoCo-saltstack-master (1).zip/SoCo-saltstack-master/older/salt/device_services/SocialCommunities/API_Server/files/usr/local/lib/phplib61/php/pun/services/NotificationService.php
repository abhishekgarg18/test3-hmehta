<?php
require_once "pun/model/LatencyNotice.php";
require_once "pun/model/LatencyEvent.php";
require_once "pun/services/ConfigService.php";
require_once "pun/services/LatencyNoticeDefinitionService.php";
require_once "pun/model/LatencyNoticeDefinition.php";

require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

class NotificationService
{
	private $log;
	private $configService;
	private $noticeDefService;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
		$this->configService = new ConfigService();
		$this->noticeDefService = new LatencyNoticeDefinitionService();	
	}
	
	/**
	 * Sends the given LatencyNotice to the email addresses and email text in the object.
	 * @param LatencyNotice $latencyNotice
	 */
	public function mailLatencyNotice(LatencyNotice $latencyNotice, $emailFrequency, $logins)
	{
		global $localConfig;
		$headers  = 'MIME-Version: 1.0' . "\r\n";
//		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
		$headers .= 'From: ' . $this->getEmailFromText()."\r\n";
		
		$body = $this->getFinishedEmailText($latencyNotice,$emailFrequency);
		
		if($latencyNotice->isPrelatencyNotice())
		{
			$ex = array();
			foreach($logins as $login)
			{
				$ex[] = $login->getEmail();
			}
			$to = implode(",",$ex);
			
			$headers .=	'Cc: '.$latencyNotice->getCc()."\r\n"; 
			$headers .=	'Bcc: '.$latencyNotice->getBcc()."\r\n";
			mail($to,$this->getEmailSubjectText($latencyNotice),$body,$headers);
		}
		else
		{
			$externalEmails = array();
			$companyId = $latencyNotice->getLoginCompanyId();
			foreach($logins as $login)
			{
				if($this->noticeDefService->getLoginSubscription($companyId,$login->getLoginId()))
				{
					$to = $login->getEmail();
					$externalEmails[] = $to;
					if($this->configService->useExtenalEmails())
					{
						$loginId = $login->getLoginId();
						
						$currentDataCenter = $localConfig['data_center'];
						$unsubScribeLink = CURR_SUITE_URL . "index.html?a=Company.Unsubscribe&c=$companyId&l=$loginId";
						$text = $body . " $unsubScribeLink";					
						mail($to,$this->getEmailSubjectText($latencyNotice),$text,$headers);
						$this->log->debug("Sent email to external customer $to");
					}
				}
				else
				{
					$this->log->debug("Login ".$login->getEmail()." has opted out of email notifications.");
				}		
			}
			$to =	$latencyNotice->getCc(); 
			$headers .=	'Cc: '.$latencyNotice->getBcc()."\r\n";  // Now that we are sending emails to indivudual users, the internal mailing lists can be bumped up 
																 // to the To: and Cc: fields instead of Cc: and Bcc:
			$externals = implode(",",$externalEmails); 
			if(strlen(trim($externals)) > 0)
			{
				$body .= "\r\n\r\n\r\nExternal email addresses for this notice: $externals";
			}
			else 
			{
				$body .= "\r\n\r\n\r\nThere are no external emails configured for ".$latencyNotice->getLoginCompany();
			}
			mail($to,$this->getEmailSubjectText($latencyNotice),$body,$headers);
			$this->log->debug("Sent internal email To: $to Cc: ".$latencyNotice->getBcc());		
		}
	}
	
	public function getFinishedEmailText(LatencyNotice $notice, $emailFrequency)
	{
		$body = $this->generateEmailbody($notice, $emailFrequency);
		return $body;
	}
	
	private function generateEmailBody(LatencyNotice $notice, $emailFrequency)
	{
		$template = "";
		if($notice->isPrelatencyNotice())
		{
			$template = $this->configService->getInternalPreLatencyEmailTemplate($notice->getEmailversion());
		}
		else
		{
			$template = $this->configService->getExternalLatencyEmailTemplate($notice->getEmailversion());
		}
		$template = str_replace("<#COMPANY_NAME#>",$notice->getLoginCompany(),$template);
		$this->log->debug("generating email body for ".sizeof($notice->getLatencyEvents())." latency events.");
		$body = " ";
		$newlyLatent = $notice->getEventsByType(1);
		$stillLatent = $notice->getEventsByType(2);
		$noLongerLatent = $notice->getEventsByType(3);
		$preLatent = $notice->getEventsByType(4);
		
		if(sizeof($newlyLatent) > 0)
		{
			$body .= "New data latency has been detected for the following report suite(s):\r\n\r\n";
			foreach($newlyLatent as $event)
			{
				$body .= "\t".$event->getUsername()." is ".$this->minutesToDaysHoursMinutes($event->getLatency())." latent.\r\n";
			}
			$body .= "\r\nEngineering resources have already been notified and are currently engaged in resolving this latency.\r\n";
		}
		
		if(sizeof($stillLatent) > 0)
		{
			$body .= "\r\nOur Engineering team is continuing to work on the data latency for the following report suite(s):\r\n\r\n";
			foreach($stillLatent as $event)
			{
				$body .= "\t".$event->getUsername()." is ".$this->minutesToDaysHoursMinutes($event->getLatency())." latent.\r\n";
			}
			$body .= "\r\n\r\nYou will continue to receive notifications every $emailFrequency hour(s) until the open latency issue(s) have been resolved. Once the latency has been restored to normal levels, a final notification will be sent to indicate the latency resolved status. Please note that latency could continue to rise as our engineers work to resolve the issue.\r\n";
		}
		
		if(sizeof($noLongerLatent) > 0)
		{
			$body .= "\r\nThe data latency for the following report suite(s) have been resolved:\r\n\r\n";
			foreach($noLongerLatent as $event)
			{
				$body .= "\t".$event->getUsername()." is no longer latent.\r\n";
			}
		}
		
		if(sizeof($preLatent) > 0)
		{
			$body .= "\r\nReport Suites That Will Soon Be Latent\r\n\r\n";
			foreach($preLatent as $event)
			{
				
				$body .= "\t".$event->getUsername()." is ".$this->minutesToDaysHoursMinutes($event->getLatency())." latent.  SiteCatalyst Version: ".$event->getSiteCatalystVersion()."\r\n";
			}
		}
		$text = str_replace( "<#DATA#>",$body,$template);
		 
		$this->log->debug("Generated email body: $text");
		return $text;
	}
	
	
	public function minutesToDaysHoursMinutes($totalMinutes)
	{
		$totalSeconds = $totalMinutes*60;
		$days = intval($totalSeconds/24/60/60); 
		$remain=$totalSeconds%86400; 
		$hours=intval($remain/3600); 
		$remain=$remain%3600; 
		$mins=intval($remain/60);
		
		$retVal = array();
		if($days >=1)
		{
			$retVal[] = "$days Day(s) ";
		}
		if($hours >= 1)
		{
			$retVal[] = "$hours Hour(s) ";
		}
		if($mins >= 1)
		{
			$retVal[] = "$mins Minutes";
		}
		$this->log->debug("Converting $totalMinutes minutes of latency to Days $days Hours $hours Minutes $mins to get ".implode(" ",$retVal));
		
		return implode(" ",$retVal);
	}
	
	public function getEmailSubjectText(LatencyNotice $notice)
	{
		$subject = "";
		if(sizeof($notice->getEventsByType(4)) > 0)
		{
			$subject = $this->configService->getInternalPreLatencyEmailSubject($notice->getEmailversion());
		}
		else if(sizeof($notice->getEventsByType(1)) == sizeof($notice->getLatencyEvents())) // If all we have are new latency events
		{
			$subject = $this->configService->getExternalNewLatencyEmailSubject($notice->getEmailversion());
		}
		else if(sizeof($notice->getEventsByType(2)) > 0)  // If there are any continuing latency events
		{
			$subject = $this->configService->getExternalContinuingLatencyEmailSubject($notice->getEmailversion());
		}
		else if(sizeof($notice->getEventsByType(3)) == sizeof($notice->getLatencyEvents())) // If all we have are end of latency events
		{
			$subject = $this->configService->getExternalEndLatencyEmailSubject($notice->getEmailversion());
		}
		
		$text = str_replace("<#DATA#>",$notice->getLoginCompany(),$subject);
		return $text;
	}
	
	public function getEmailFromText()
	{
		return $this->configService->getEmailReturnAddressText();
	}
	
}
