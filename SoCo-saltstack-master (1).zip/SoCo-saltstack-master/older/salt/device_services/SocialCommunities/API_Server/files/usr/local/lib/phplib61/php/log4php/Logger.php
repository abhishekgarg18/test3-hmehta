<?php
/**
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * 
 *		http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * MODIFICATION: all class names in the project have been prefixed with 'L4P_'
 * to avoid namespace collisions in PHP 5.2.4.   --David Cardon (dcardon@adobe.com)
 * 
 * @package log4php
 */

/**
 * LOG4PHP_DIR points to the log4php root directory.
 *
 * If not defined it will be set automatically when the first package classfile 
 * is included
 * 
 * @var string 
 */
if (!defined('LOG4PHP_DIR')) define('LOG4PHP_DIR', dirname(__FILE__));

spl_autoload_register(array('L4P_Logger', 'autoload'));

/**
 * This is the central class in the log4j package. Most logging operations, 
 * except configuration, are done through this class. 
 *
 * In log4j this class replaces the Category class. There is no need to 
 * port deprecated classes; log4php L4P_Logger class doesn't extend Category.
 *
 * @category   log4php
 * @package log4php
 * @license	   http://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2.0
 * @version	   SVN: $Id$
 * @link	   http://logging.apache.org/log4php
 */
 /*
  * TODO:
  * Localization: setResourceBundle($bundle) : not supported
  * Localization: getResourceBundle: not supported
  * Localization: getResourceBundleString($key): not supported
  * Localization: l7dlog($priority, $key, $params, $t) : not supported
  */
class L4P_Logger {
	private static $_classes = array(
		'L4P_LoggerException' => '/LoggerException.php',
		'L4P_LoggerHierarchy' => '/LoggerHierarchy.php',
		'L4P_LoggerLayout' => '/LoggerLayout.php',
		'L4P_LoggerLevel' => '/LoggerLevel.php',
		'L4P_LoggerMDC' => '/LoggerMDC.php',
		'L4P_LoggerNDC' => '/LoggerNDC.php',
		'L4P_LoggerReflectionUtils' => '/LoggerReflectionUtils.php',
		'L4P_LoggerConfigurator' => '/LoggerConfigurator.php',
		'L4P_LoggerConfiguratorBasic' => '/configurators/LoggerConfiguratorBasic.php',
		'L4P_LoggerConfiguratorIni' => '/configurators/LoggerConfiguratorIni.php',
		'L4P_LoggerConfiguratorPhp' => '/configurators/LoggerConfiguratorPhp.php',
		'L4P_LoggerConfiguratorXml' => '/configurators/LoggerConfiguratorXml.php',
		'L4P_LoggerRoot' => '/LoggerRoot.php',
		'L4P_LoggerAppender' => '/LoggerAppender.php',
		'L4P_LoggerAppenderPool' => '/LoggerAppenderPool.php',
		'L4P_LoggerAppenderAdodb' => '/appenders/LoggerAppenderAdodb.php',
		'L4P_LoggerAppenderPDO' => '/appenders/LoggerAppenderPDO.php',
		'L4P_LoggerAppenderConsole' => '/appenders/LoggerAppenderConsole.php',
		'L4P_LoggerAppenderDailyFile' => '/appenders/LoggerAppenderDailyFile.php',
		'L4P_LoggerAppenderEcho' => '/appenders/LoggerAppenderEcho.php',
		'L4P_LoggerAppenderFile' => '/appenders/LoggerAppenderFile.php',
		'L4P_LoggerAppenderMail' => '/appenders/LoggerAppenderMail.php',
		'L4P_LoggerAppenderMailEvent' => '/appenders/LoggerAppenderMailEvent.php',
		'L4P_LoggerAppenderNull' => '/appenders/LoggerAppenderNull.php',
		'L4P_LoggerAppenderPhp' => '/appenders/LoggerAppenderPhp.php',
		'L4P_LoggerAppenderRollingFile' => '/appenders/LoggerAppenderRollingFile.php',
		'L4P_LoggerAppenderSocket' => '/appenders/LoggerAppenderSocket.php',
		'L4P_LoggerAppenderSyslog' => '/appenders/LoggerAppenderSyslog.php',
		'L4P_LoggerFormattingInfo' => '/helpers/LoggerFormattingInfo.php',
		'L4P_LoggerOptionConverter' => '/helpers/LoggerOptionConverter.php',
		'L4P_LoggerPatternConverter' => '/helpers/LoggerPatternConverter.php',
		'L4P_LoggerBasicPatternConverter' => '/helpers/LoggerBasicPatternConverter.php',
		'L4P_LoggerCategoryPatternConverter' => '/helpers/LoggerCategoryPatternConverter.php',
		'L4P_LoggerClassNamePatternConverter' => '/helpers/LoggerClassNamePatternConverter.php',
		'L4P_LoggerDatePatternConverter' => '/helpers/LoggerDatePatternConverter.php',
		'L4P_LoggerLiteralPatternConverter' => '/helpers/LoggerLiteralPatternConverter.php',
		'L4P_LoggerLocationPatternConverter' => '/helpers/LoggerLocationPatternConverter.php',
		'L4P_LoggerMDCPatternConverter' => '/helpers/LoggerMDCPatternConverter.php',
		'L4P_LoggerNamedPatternConverter' => '/helpers/LoggerNamedPatternConverter.php',
		'L4P_LoggerBasicPatternConverter' => '/helpers/LoggerBasicPatternConverter.php',
		'L4P_LoggerLiteralPatternConverter' => '/helpers/LoggerLiteralPatternConverter.php',
		'L4P_LoggerDatePatternConverter' => '/helpers/LoggerDatePatternConverter.php',
		'L4P_LoggerMDCPatternConverter' => '/helpers/LoggerMDCPatternConverter.php',
		'L4P_LoggerLocationPatternConverter' => '/helpers/LoggerLocationPatternConverter.php',
		'L4P_LoggerNamedPatternConverter' => '/helpers/LoggerNamedPatternConverter.php',
		'L4P_LoggerClassNamePatternConverter' => '/helpers/LoggerClassNamePatternConverter.php',
		'L4P_LoggerCategoryPatternConverter' => '/helpers/LoggerCategoryPatternConverter.php',
		'L4P_LoggerPatternParser' => '/helpers/LoggerPatternParser.php',
		'L4P_LoggerLayoutHtml' => '/layouts/LoggerLayoutHtml.php',
		'L4P_LoggerLayoutSimple' => '/layouts/LoggerLayoutSimple.php',
		'L4P_LoggerLayoutTTCC' => '/layouts/LoggerLayoutTTCC.php',
	    'L4P_LoggerLayoutSplunk' => '/layouts/LoggerLayoutSplunk.php',
		'L4P_LoggerLayoutPattern' => '/layouts/LoggerLayoutPattern.php',
		'L4P_LoggerLayoutXml' => '/layouts/LoggerLayoutXml.php',
		'L4P_LoggerRendererDefault' => '/renderers/LoggerRendererDefault.php',
		'L4P_LoggerRendererObject' => '/renderers/LoggerRendererObject.php',
		'L4P_LoggerRendererMap' => '/renderers/LoggerRendererMap.php',
		'L4P_LoggerLocationInfo' => '/LoggerLocationInfo.php',
		'L4P_LoggerLoggingEvent' => '/LoggerLoggingEvent.php',
		'L4P_LoggerFilter' => '/LoggerFilter.php',
		'L4P_LoggerFilterDenyAll' => '/filters/LoggerFilterDenyAll.php',
		'L4P_LoggerFilterLevelMatch' => '/filters/LoggerFilterLevelMatch.php',
		'L4P_LoggerFilterLevelRange' => '/filters/LoggerFilterLevelRange.php',
		'L4P_LoggerFilterStringMatch' => '/filters/LoggerFilterStringMatch.php',
	);

	/**
	 * Class autoloader
	 * This method is provided to be invoked within an __autoload() magic method.
	 * @param string class name
	 */
	public static function autoload($className) {
		if(isset(self::$_classes[$className])) {
			include LOG4PHP_DIR.self::$_classes[$className];
		}
	}

	/**
	 * Additivity is set to true by default, that is children inherit the 
	 * appenders of their ancestors by default.
	 * @var boolean
	 */
	private $additive = true;
	
	/** @var string fully qualified class name */
	private $fqcn = 'L4P_Logger';

	/** @var L4P_LoggerLevel The assigned level of this category. */
	private $level = null;
	
	/** @var string name of this category. */
	private $name = '';
	
	/** @var L4P_Logger The parent of this category. Null if this is the root logger*/
	private $parent = null;
	
	/**
	 * @var array collection of appenders
	 * @see L4P_LoggerAppender
	 */
	private $aai = array();

	/** the hierarchy used by log4php */
	private static $hierarchy;
	
	/** the configurator class name */
	private static $configurationClass = 'L4P_LoggerConfiguratorBasic';
	
	/** the path to the configuration file */
	private static $configurationFile = null;
	
	/** inidicates if log4php has already been initialized */
	private static $initialized = false;
	
	/**
	 * Constructor.
	 * @param  string  $name  Category name	  
	 */
	public function __construct($name) {
		$this->name = $name;
	}
	
	/**
	 * Return the category name.
	 * @return string
	 */
	public function getName() {
		return $this->name;
	} 

	/**
	 * Returns the parent of this category.
	 * @return L4P_Logger
	 */
	public function getParent() {
		return $this->parent;
	}	  
	
	/**
	 * Returns the hierarchy used by this L4P_Logger.
	 * Caution: do not use this hierarchy unless you have called initialize().
	 * To get L4P_Loggers, use the L4P_Logger::getLogger and L4P_Logger::getRootLogger methods
	 * instead of operating on on the hierarchy directly.
	 * 
	 * @deprecated - will be moved to private
	 * @return L4P_LoggerHierarchy
	 */
	public static function getHierarchy() {
		if(!isset(self::$hierarchy)) {
			self::$hierarchy = new L4P_LoggerHierarchy(new L4P_LoggerRoot());
		}
		return self::$hierarchy;
	}
	
	/* Logging methods */
	/**
	 * Log a message object with the DEBUG level including the caller.
	 *
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function debug($message, $caller = null) {
		$this->logLevel($message, L4P_LoggerLevel::getLevelDebug(), $caller);
	} 


	/**
	 * Log a message object with the INFO Level.
	 *
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function info($message, $caller = null) {
		$this->logLevel($message, L4P_LoggerLevel::getLevelInfo(), $caller);
	}

	/**
	 * Log a message with the WARN level.
	 *
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function warn($message, $caller = null) {
		$this->logLevel($message, L4P_LoggerLevel::getLevelWarn(), $caller);
	}
	
	/**
	 * Log a message object with the ERROR level including the caller.
	 *
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function error($message, $caller = null) {
		$this->logLevel($message, L4P_LoggerLevel::getLevelError(), $caller);
	}
	
	/**
	 * Log a message object with the FATAL level including the caller.
	 *
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function fatal($message, $caller = null) {
		$this->logLevel($message, L4P_LoggerLevel::getLevelFatal(), $caller);
	}
	
	/**
	 * This method creates a new logging event and logs the event without further checks.
	 *
	 * It should not be called directly. Use {@link info()}, {@link debug()}, {@link warn()},
	 * {@link error()} and {@link fatal()} wrappers.
	 *
	 * @param string $fqcn Fully Qualified Class Name of the L4P_Logger
	 * @param mixed $caller caller object or caller string id
	 * @param L4P_LoggerLevel $level log level	   
	 * @param mixed $message message
	 * @see L4P_LoggerLoggingEvent			
	 */
	public function forcedLog($fqcn, $caller, $level, $message) {
		$this->callAppenders(new L4P_LoggerLoggingEvent($fqcn, $this, $level, $message));
	} 
	
	
		/**
	 * Check whether this category is enabled for the DEBUG Level.
	 * @return boolean
	 */
	public function isDebugEnabled() {
		return $this->isEnabledFor(L4P_LoggerLevel::getLevelDebug());
	}		

	/**
	 * Check whether this category is enabled for a given Level passed as parameter.
	 *
	 * @param L4P_LoggerLevel level
	 * @return boolean
	 */
	public function isEnabledFor($level) {
		return (bool)($level->isGreaterOrEqual($this->getEffectiveLevel()));
	} 

	/**
	 * Check whether this category is enabled for the info Level.
	 * @return boolean
	 * @see L4P_LoggerLevel
	 */
	public function isInfoEnabled() {
		return $this->isEnabledFor(L4P_LoggerLevel::getLevelInfo());
	} 

	/**
	 * This generic form is intended to be used by wrappers.
	 *
	 * @param L4P_LoggerLevel $priority a valid level
	 * @param mixed $message message
	 * @param mixed $caller caller object or caller string id
	 */
	public function log($priority, $message, $caller = null) {
		if($this->isEnabledFor($priority)) {
			$this->forcedLog($this->fqcn, $caller, $priority, $message);
		}
	}
	
	/**
	 * If assertion parameter is false, then logs msg as an error statement.
	 *
	 * @param bool $assertion
	 * @param string $msg message to log
	 */
	public function assertLog($assertion = true, $msg = '') {
		if($assertion == false) {
			$this->error($msg);
		}
	}
	 
	private function logLevel($message, $level, $caller = null) {
		if($level->isGreaterOrEqual($this->getEffectiveLevel())) {
			$this->forcedLog($this->fqcn, $caller, $level, $message);
		}
	} 
	
	/* Factory methods */ 
	
	/**
	 * Get a L4P_Logger by name (Delegate to {@link L4P_Logger})
	 * 
	 * @param string $name logger name
	 * @param L4P_LoggerFactory $factory a {@link L4P_LoggerFactory} instance or null
	 * @return L4P_Logger
	 * @static 
	 */
	public static function getLogger($name) {
		if(!self::isInitialized()) {
			self::initialize();
		}
		return self::getHierarchy()->getLogger($name);
	}
	
	/**
	 * get the Root L4P_Logger (Delegate to {@link L4P_Logger})
	 * @return L4P_LoggerRoot
	 * @static 
	 */	   
	public static function getRootLogger() {
		if(!self::isInitialized()) {
			self::initialize();
		}
		return self::getHierarchy()->getRootLogger();	  
	}
	
	/* Configuration methods */
	
	/**
	 * Add a new Appender to the list of appenders of this Category instance.
	 *
	 * @param L4P_LoggerAppender $newAppender
	 */
	public function addAppender($newAppender) {
		$appenderName = $newAppender->getName();
		$this->aai[$appenderName] = $newAppender;
	}
	
	/**
	 * Remove all previously added appenders from this Category instance.
	 */
	public function removeAllAppenders() {
		$appenderNames = array_keys($this->aai);
		$enumAppenders = count($appenderNames);
		for($i = 0; $i < $enumAppenders; $i++) {
			$this->removeAppender($appenderNames[$i]); 
		}
	} 
			
	/**
	 * Remove the appender passed as parameter form the list of appenders.
	 *
	 * @param mixed $appender can be an appender name or a {@link L4P_LoggerAppender} object
	 */
	public function removeAppender($appender) {
		if($appender instanceof L4P_LoggerAppender) {
			$appender->close();
			unset($this->aai[$appender->getName()]);
		} else if (is_string($appender) and isset($this->aai[$appender])) {
			$this->aai[$appender]->close();
			unset($this->aai[$appender]);
		}
	} 
			
	/**
	 * Call the appenders in the hierarchy starting at this.
	 *
	 * @param L4P_LoggerLoggingEvent $event 
	 */
	public function callAppenders($event) {
		if(count($this->aai) > 0) {
			foreach(array_keys($this->aai) as $appenderName) {
				$this->aai[$appenderName]->doAppend($event);
			}
		}
		if($this->parent != null and $this->getAdditivity()) {
			$this->parent->callAppenders($event);
		}
	}
	
	/**
	 * Get the appenders contained in this category as an array.
	 * @return array collection of appenders
	 */
	public function getAllAppenders() {
		return array_values($this->aai);
	}
	
	/**
	 * Look for the appender named as name.
	 * @return L4P_LoggerAppender
	 */
	public function getAppender($name) {
		return $this->aai[$name];
	}
	
	/**
	 * Get the additivity flag for this Category instance.
	 * @return boolean
	 */
	public function getAdditivity() {
		return $this->additive;
	}
 
	/**
	 * Starting from this category, search the category hierarchy for a non-null level and return it.
	 * @see L4P_LoggerLevel
	 * @return L4P_LoggerLevel or null
	 */
	public function getEffectiveLevel() {
		for($c = $this; $c != null; $c = $c->parent) {
			if($c->getLevel() !== null) {
				return $c->getLevel();
			}
		}
		return null;
	}
  
	/**
	 * Returns the assigned Level, if any, for this Category.
	 * @return L4P_LoggerLevel or null 
	 */
	public function getLevel() {
		return $this->level;
	}
	
	/**
	 * Set the level of this Category.
	 *
	 * @param L4P_LoggerLevel $level a level string or a level constant 
	 */
	public function setLevel($level) {
		$this->level = $level;
	}
	
	/**
	 * Clears all logger definitions
	 * 
	 * @static
	 * @return boolean 
	 */
	public static function clear() {
		return self::getHierarchy()->clear();	 
	}
	
	/**
	 * Destroy configurations for logger definitions
	 * 
	 * @static
	 * @return boolean 
	 */
	public static function resetConfiguration() {
		$result = self::getHierarchy()->resetConfiguration();
		self::$initialized = false;
		self::$configurationClass = 'L4P_LoggerConfiguratorBasic';
		self::$configurationFile = null;
		return $result;	 
	}

	/**
	 * Safely close all appenders.
	 * This is not longer necessary due the appenders shutdown via
	 * destructors. 
	 * @deprecated
	 * @static
	 */
	public static function shutdown() {
		return self::getHierarchy()->shutdown();	   
	}
	
	/**
	 * check if a given logger exists.
	 * 
	 * @param string $name logger name 
	 * @static
	 * @return boolean
	 */
	public static function exists($name) {
		return self::getHierarchy()->exists($name);
	}
	
	/**
	 * Returns an array this whole L4P_Logger instances.
	 * 
	 * @static
	 * @see L4P_Logger
	 * @return array
	 */
	public static function getCurrentLoggers() {
		return self::getHierarchy()->getCurrentLoggers();
	}
	
	/**
	 * Is the appender passed as parameter attached to this category?
	 *
	 * @param L4P_LoggerAppender $appender
	 */
	public function isAttached($appender) {
		return isset($this->aai[$appender->getName()]);
	} 
		   
	/**
	 * Set the additivity flag for this Category instance.
	 *
	 * @param boolean $additive
	 */
	public function setAdditivity($additive) {
		$this->additive = (bool)$additive;
	}

	/**
	 * Sets the parent logger of this logger
	 */
	public function setParent(L4P_Logger $logger) {
		$this->parent = $logger;
	} 
	
	/**
	 * Configures Log4PHP.
	 * This method needs to be called before the first logging event
	 * has occured. If this methode is never called, the standard configuration
	 * takes place (@see L4P_LoggerConfiguratorBasic).
	 * If only the configuration file is given, the configurator class will
	 * be the XML Configurator or the INI Configurator, if no .xml ending
	 * could be determined.
	 * 
	 * If a custom configurator should be used, the configuration file
	 * is either null or the path to file the custom configurator uses.
	 * Make sure the configurator is already or can be loaded by PHP when necessary.
	 * 
	 * @param String $configurationFile the configuration file
	 * @param String $configurationClass the configurator class
	 */
	public static function configure($configurationFile = null, 
									 $configurationClass = null ) {
		if($configurationClass === null && $configurationFile === null) {
			self::$configurationClass = 'L4P_LoggerConfiguratorBasic';
			return;
		}
									 	
		if($configurationClass !== null) {
			self::$configurationFile = $configurationFile;
			self::$configurationClass = $configurationClass;
			return;
		}
		
		if (strtolower(substr( $configurationFile, -4 )) == '.xml') {
			self::$configurationFile = $configurationFile;
			self::$configurationClass = 'L4P_LoggerConfiguratorXml';
		} else {
			self::$configurationFile = $configurationFile;
			self::$configurationClass = 'L4P_LoggerConfiguratorIni';
		}
	}
	
	/**
	 * Returns the current configurator
	 * @return the configurator
	 */
	public static function getConfigurationClass() {
		return self::$configurationClass;
	}
	
	/**
	 * Returns the current configuration file
	 * @return the configuration file
	 */
	public static function getConfigurationFile() {
		return self::$configurationFile;
	}
	
	/**
	 * Returns, true, if the log4php framework is already initialized
	 */
	private static function isInitialized() {
		return self::$initialized;
	}
	
	/**
	 * Initializes the log4php framework.
	 * @return boolean
	 */
	public static function initialize() {
		self::$initialized = true;
		$instance = L4P_LoggerReflectionUtils::createObject(self::$configurationClass);
		$result = $instance->configure(self::getHierarchy(), self::$configurationFile);
		return $result;
	}
}
