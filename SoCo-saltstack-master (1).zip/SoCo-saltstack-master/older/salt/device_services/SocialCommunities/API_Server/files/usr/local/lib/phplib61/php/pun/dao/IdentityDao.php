<?php

require_once "pun/model/Login.php";

include "reverse_userid_lookup.inc";

require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

class IdentityDao
{
	private $qc = '/*PowerUp Notices: IdentityDao*/';
	
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	public function getPrimaryLoginForCompany($companyName,$companyId)
	{
		//now get the login info
		$company_frag_db = new companyFragDB($companyName);

		$sql = "SELECT $this->qc loginid, login, first_name, last_name, email
				FROM login 
				WHERE companyid = $companyId 
				ORDER BY admin DESC, last_login DESC
				LIMIT 1";
		$login = new Login();
		$this->log->debug("Executing SQL: $sql");
		if($company_frag_db->squery($sql))
		{
			$login->setEmail($company_frag_db->f('email'));
			$login->setFirstName($company_frag_db->f('first_name'));
			$login->setLastName($company_frag_db->f('last_name'));
			$login->setLoginName($company_frag_db->f('login'));
			$login->setLoginId($company_frag_db->f('loginid'));
		}
		return $login;
	}

	public function getLoginsForRsid($rsid)
	{
		$results = array();

		//first get company id
		$userdb = new masterdb;
		setuserdb($userdb, $rsid);
		$userdb->halt_on_error = false;

		$sql = "SELECT $this->qc companyid FROM user WHERE username='" . addslashes($rsid) . "'";
		$this->log->debug("Executing SQL: $sql");
		$userdb->query($sql);

		if ($userdb->next_record())
		{
			$company_id = $userdb->f('companyid');
		}

		//next need company name
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc company.company FROM company WHERE company.companyid = $company_id";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$company_name = $companydb->f('company');
		}

		//now get the login info
		$company_frag_db = new companyFragDB($company_name);

		$sql = "SELECT $this->qc loginid, login, first_name, last_name, email " .
			"FROM login WHERE companyid = $company_id";
		$this->log->debug("Executing SQL: $sql");
		$company_frag_db->query($sql);

		while ($company_frag_db->next_record())
		{
			$login = new Login();
			$login->setEmail($company_frag_db->f('email'));
			$login->setFirstName($company_frag_db->f('first_name'));
			$login->setLastName($company_frag_db->f('last_name'));
			$login->setLoginName($company_frag_db->f('login'));
			$login->setLoginId($company_frag_db->f('loginid'));
			$results[] = $login;
		}

		return $results;
	}

	public function isLoginInCompany($login_id, $company_id, $company_name)
	{
		$company_frag_db = new companyFragDB($company_name);

		$sql = "SELECT $this->qc loginid, login, first_name, last_name, email " .
			"FROM login WHERE companyid = $company_id AND loginid = $login_id";
		$this->log->debug("Executing SQL: $sql");
		$company_frag_db->query($sql);

		if ($company_frag_db->next_record())
		{
			return true;
		}

		return false;
	}

	public function getLoginIdFromLoginName($login_name, $company_id, $company_name)
	{
		$login_id = -1;
		$company_frag_db = new companyFragDB($company_name);

		$sql = "SELECT $this->qc loginid " .
			"FROM login WHERE companyid = $company_id AND login = '" . addslashes($login_name) . "'";
		$this->log->debug("Executing SQL: $sql");
		$company_frag_db->query($sql);

		if ($company_frag_db->next_record())
		{
			$login_id = intval($company_frag_db->f('loginid'));
		}

		return $login_id;
	}

	public function getLoginsFromIDs($ids, $company_id, $company_name)
	{
		$results = array();

		if (is_array($ids) && (count($ids) > 0))
		{
			$company_frag_db = new companyFragDB($company_name);

			$sql = "SELECT $this->qc loginid, login, first_name, last_name, email " .
				"FROM login WHERE companyid = $company_id AND loginid in (" . implode(', ', $ids) . ")";
			$this->log->debug("Executing SQL: $sql");
			$company_frag_db->query($sql);

			while ($company_frag_db->next_record())
			{
				$login = new Login();
				$login->setEmail($company_frag_db->f('email'));
				$login->setFirstName($company_frag_db->f('first_name'));
				$login->setLastName($company_frag_db->f('last_name'));
				$login->setLoginName($company_frag_db->f('login'));
				$login->setLoginId($company_frag_db->f('loginid'));
				$results[] = $login;
			}
		}
		
		return $results;
	}

	public function getLoginNamesFromIDs($ids, $company_id, $company_name)
	{
		$results = array();

		if (is_array($ids) && (count($ids) > 0))
		{
			$company_frag_db = new companyFragDB($company_name);
			$company_frag_db->halt_on_error = false;

			$sql = "SELECT $this->qc login " .
				"FROM login WHERE companyid = $company_id AND loginid in (" . implode(', ', $ids) . ")";
			$this->log->debug("Executing SQL: $sql");
			$company_frag_db->query($sql);

			while ($company_frag_db->next_record())
			{
				$results[] = $company_frag_db->f('login');
			}
		}
		
		return $results;
	}

	public function getSuiteIDFromSuiteName($rsid)
	{
		$suiteID = null;
		$userdb = new masterdb;
		setuserdb($userdb, $rsid);
		$userdb->halt_on_error = false;

		$sql = "SELECT $this->qc userid FROM user WHERE username = '". addslashes($rsid) . "'";
		$this->log->debug("Executing SQL: $sql");
		$userdb->query($sql);

		if ($userdb->next_record())
		{
			$suiteID = $userdb->f('userid');
		}

		$userdb->free();

		return $suiteID;
	}

	public function getSuiteNameFromSuiteID($suiteID)
	{
		return reverse_userid_lookup($suiteID, 'nohalt');
	}

	public function getCompanyForRsid($rsid)
	{
		$cid = 0;
		$company = '';

		$db = new DB_Sql('masterdb');
		setuserdb($db, $rsid);
		$db->halt_on_error = false;

		$sql = "SELECT $this->qc companyid FROM user WHERE username = '" . addslashes($rsid) . "'";
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);

		if ($db->next_record())
	  	{
			$cid = $db->f('companyid');
		}

		$db->free();

		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc company FROM company WHERE companyid = $cid";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$company = $companydb->f('company');
		}

		$companydb->free();

		return array($cid, $company);
	}

	public function getCompanyName($company_id)
	{
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc company FROM company WHERE companyid = $company_id";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$company = $companydb->f('company');
		}

		$companydb->free();

		return $company;
	}
	
	public function getCompanyId($company_name)
	{
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc companyid FROM company WHERE company = '$company_name'";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$companyId = $companydb->f('companyid');
		}

		$companydb->free();

		return $companyId;
	}
	
	public function getBillingCustomerForCompanyID($companyID)
	{
		$billing_customer_id = -1;
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc billing_customer_id FROM company WHERE companyid = $companyID";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$billing_customer_id = $companydb->f('billing_customer_id');
		}

		$companydb->free();

		return $billing_customer_id;
	}

	public function getBillingCustomerForRsid($rsid)
	{
		$bcid = 0;
		$bc_name = '';

		$db = new DB_Sql('masterdb');
		setuserdb($db, $rsid);
		$db->halt_on_error = false;

		$sql = "SELECT $this->qc billing_customer_id FROM user WHERE username = '" . addslashes($rsid) . "'";
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);

		if ($db->next_record())
	  	{
			$bcid = $db->f('billing_customer_id');
		}

		$db->free();

		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc cus_name FROM billing_customer WHERE id = $bcid";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$bc_name = $companydb->f('cus_name');
		}

		$companydb->free();

		return array($bcid, $bc_name);
	}

	public function getBillingCustomerName($bcid)
	{
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc cus_name FROM billing_customer WHERE id = $bcid";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$bc_name = $companydb->f('cus_name');
		}

		$companydb->free();

		return $bc_name;
	}
	
	public function getBillingCustomerId($bcname)
	{
		$companydb = new DB_Sql('companydb');
		$companydb->halt_on_error = false;

		$sql = "SELECT $this->qc cus_id FROM billing_customer WHERE cus_name = '$bcname'";
		$this->log->debug("Executing SQL: $sql");
		$companydb->query($sql);

		if ($companydb->next_record())
		{
			$bc_id = $companydb->f('cus_id');
		}

		$companydb->free();

		return $bc_id;
	}
	

	public function rsIsV15($rsid)
	{
		$suite_id = $this->getSuiteIDFromSuiteName($rsid);

		$db = new DB_Sql('masterdb');
		setuserdb($db, $rsid);
		$db->halt_on_error = false;

		$sql = "SELECT $this->qc axle_data FROM user_services WHERE userid = $suite_id";
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);

		$enabled = 0;
		if ($db->next_record())
		{
			$enabled = $db->f('axle_data');
		}

		$db->close();

		return $enabled == 1;
	}
}

