<?
/**
 * Adds coordinated access to related rows in the file_distribution and
 * rpt_schedule tables. 
 *
 * Copyright 2012 Adobe, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt
 *
 * @author      James Aldous
 *
 * @version     CVS: $Id: //depot/phplib/trunk/php/rptsched_file_distribution.class.php#1 $
 */

require_once('rptsched.class');
require_once('database/DBQuery.class.php');

class Report_Schedule_File_Distribution extends Report_Schedule
{
	var $schedule_id;
	var $companyid;
	var $loginid;
	var $source_url;
	var $metadata_file_name;
	var $fd_locked_by;
	var $failure_count;
	var $last_state;

	// State from file_distribution table

	/**
	* Constructor
	* Initializes data using data from database if applicable.
	*/
	function Report_Schedule_File_Distribution($pId = -999)
	{
		$schedule_id = 0;
		$companyid = 0;
		$loginid = 0;
		$source_url = '';
		$metadata_file_name = '';
		$fd_locked_by = '';
		$failure_count = 0;
		$last_state = 'ready';

		$parent_result = parent::Report_Schedule($pId);
		if (!$parent_result) {
			return(FALSE);
		}

		return(TRUE);
	}

	/**
	* Overrides Report_Schedule's Get_Schedule to add setting of data specific to
	* this class.
	*/
	function Get_Schedule($pRS_Id)
	{
		$parent_result = parent::Get_Schedule($pRS_Id);
		if (!$parent_result) {
			return(FALSE);
		}

		// Get a database connection.
		$db = new DB_Sql(DWDBNAME);

		$sql = '
			SELECT COUNT(*) cnt FROM file_distribution
			WHERE schedule_id = %i{schedule_id}
		';

		$query = new DBQuery($db, $sql, array(
			'schedule_id' =>  $pRS_Id
		));

		$result = $query->execute();

		if ($query->hasError())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-select-count-from-file-distribution',
				'Cannot select count from file_distribution for schedule %s because: %s'),
				$pRS_Id, $query->getErrorMessage());
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$cnt = 0;
		if ($result->hasNext())
		{
			$record = $result->next();
			$cnt = $record['cnt'];
		}

		$query->free();

		if ($cnt == 0)
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://given-report-id-s-does-not',
				'Given report id %s does not exist.'), $pRS_Id);
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$query->free();
		$this->Get_File_Distribution_Data();
	}

	/**
	* Gets of data specific to this class from the database
	*/
	function Get_File_Distribution_Data()
	{
		// Get a database connection.
		$db = new DB_Sql(DWDBNAME);

		$sql = '
			SELECT companyid, loginid, source_url,
			metadata_file_name, locked_by,  
			failure_count, last_state
			FROM file_distribution 
			WHERE schedule_id = %i{schedule_id}
		';

		$query = new DBQuery($db, $sql, array(
			'schedule_id' =>  $this->id
		));

		$result = $query->execute();

		if ($query->hasError())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-select-data-from-file-distribution',
				'Cannot select data from file_distribution for schedule %s because: %s'),
				$this->id, $query->getErrorMessage());
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		if (!$result->hasNext())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-get-next-record-from-file-distribution',
				'Cannot get next record from file_distribution for schedule %s'),
				$this->id);
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$record = $result->next();
		$this->schedule_id        = $this->id;
		$this->companyid       = $record['companyid'];
		$this->loginid         = $record['loginid'];
		$this->source_url         = $record['source_url'];
		$this->metadata_file_name = $record['metadata_file_name'];
		$this->fd_locked_by       = $record['locked_by'];
		$this->failure_count      = $record['failure_count'];
		$this->last_state         = $record['last_state'];

		$query->free();

		$this->errmsg = "";
		return(TRUE);
	}

	/**
	* Overrides Report_Schedule's Create_Schedule to add creation of data specific to
	* this class.
	*/
	function Create_Schedule($pRptType, $account = '')
	{
		$parent_result = parent::Create_Schedule($pRptType, $account);
		if (!$parent_result) {
			return(FALSE);
		}

		// Get a database connection.
		$db = new DB_Sql(DWDBNAME);

		$sql = '
			INSERT INTO file_distribution
			(schedule_id)
			VALUES (%i{schedule_id})
		';

		$query = new DBQuery($db, $sql, array(
			'schedule_id' =>  $this->id
		));

		$query->execute();

		if ($query->hasError())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-insert-into-file-distribution',
				'Cannot insert record into file_distribution for schedule %s because: %s'),
				$this->id, $query->getErrorMessage());
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$query->free();
		$this->Get_File_Distribution_Data();

		$this->errmsg = "";
		return(TRUE);
    }


	/**
	* Convenience method that builds the source URL field from individual components of
	* an FTP server, user and password.
	*/
	function Set_FTP_Source($ftpServer, $directory, $user, $password)
	{
		$path = $directory;
		if ($directory && $directory[0] == '/') {
			$path = substr($directory, 1);
		}
		$this->source_url = "ftp://".$user.":".$password."@".$ftpServer."/".$path;
	}

	/**
	* Sets the database row corresponding to this object with the current state.
	* The individual data members can be set directly prior to the calling of
	* this method.
	*/
	function Update_File_Distribution()
	{
		// Get a database connection.
		$db = new DB_Sql(DWDBNAME);

		$sql = '
			UPDATE file_distribution SET
			companyid = %i{companyid},
			loginid = %i{loginid},
			source_url = %s{source_url},
			metadata_file_name = %s{metadata_file_name},
			locked_by = %s{locked_by},
			failure_count = %i{failure_count},
			last_state = %s{last_state}
			WHERE schedule_id = %i{schedule_id}
		';

		$query = new DBQuery($db, $sql, array(
			'companyid' =>  $this->companyid,
			'loginid' =>  $this->loginid,
			'source_url' =>  $this->source_url,
			'metadata_file_name' =>  $this->metadata_file_name,
			'locked_by' =>  $this->fd_locked_by,
			'failure_count' =>  $this->failure_count,
			'last_state' =>  $this->last_state,
			'schedule_id' =>  $this->id
		));
		
		$query->execute();

		if ($query->hasError())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-update-file-distribution',
				'Cannot update record in file_distribution for schedule %s because: %s'),
				$this->id, $query->getErrorMessage());
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$query->free();
		
		return(TRUE);
	}

	/**
	 * Removes a file distribution schedule report
	 *
	 * Overrides parent Delete function.
	 *
	 * @return (boolean) true on success false otherwise
	 */
	function Delete()
	{
		// Get a database connection.
		$db = new DB_Sql(DWDBNAME);

		$sql = '
			DELETE FROM file_distribution
			WHERE schedule_id = %i{schedule_id}
		';

		$query = new DBQuery($db, $sql, array(
			'schedule_id' =>  $this->id
		));

		$query->execute();

		if ($query->hasError())
		{
			$this->errmsg = sprintf(OM_L10n::getString('lib://cannot-delete-file-distribution',
				'Cannot delete record from file_distribution for schedule %s because: %s'),
				$this->id, $query->getErrorMessage());
			$this->DoMsg( "\nERROR: " . $this->errmsg . "\n\n" );
			$query->free();
			return(FALSE);
		}

		$query->free();

		if ($db->affected_rows() != 1) return(FALSE);

		return parent::Delete();
	}

}