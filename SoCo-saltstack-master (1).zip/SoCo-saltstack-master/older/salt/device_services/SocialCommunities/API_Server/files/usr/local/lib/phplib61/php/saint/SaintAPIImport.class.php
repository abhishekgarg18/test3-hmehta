<?php
require_once "saint/SaintAPI.class.php";
require_once "saint/SaintAPIFileFunctions.class.php";

class SaintAPIImport{
	private $sfh;
	private $report_suites;
	private $relation_id;
	private $overwrite_conflicts;
	private $email_address;
	private $errors_array;
	private $SaintAPI;
	private $check_divisions;
	private $export_results;
	private $api_login;
	private $company;
	private $description;
	private $email;
	private $company_id;
	private $job_id;
	private $headers;
	private $import_path;
	private $integration_id = 0; // Genesis integration_id (if applicable)

	function __construct($company, $company_id, $api_login, $report_suites, $relation_id, $email, $headers, $import_path, $overwrite_conflicts = 0, $check_divisions = 1, $export_results = 0, $description = '')
	{
		$this->company = $company;
		$this->company_id = $company_id;
		$this->email = $email;
		$this->report_suites = $report_suites;
		$this->relation_id = $relation_id;
		$this->api_login = $api_login;
		$this->overwrite_conflicts = $overwrite_conflicts;
		$this->check_divisions = $check_divisions;
		$this->export_results = $export_results;
		$this->description = $description;
		$this->headers = $headers;
		$this->import_path = $import_path;

		$this->SaintAPI = new SaintAPI($company);
		$this->validation();
	}

	private function validation()
	{
		if(isset($this->company))
		{
			//Nothing to do.
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://company-name-must-be-set', 'A company name must be set.'));
		}


		//e-mail validation
		if(isset($this->email))
		{
			$emails=explode(",",$this->email);
			foreach ($emails as $email){
				if(!eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email))
				{
					$this->add_error(sprintf(OM_L10n::getString('lib://email-addr-not-valid', 'e-Mail address is not valid: %s'), $email));
				}
			}
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://email-addr-must-be-set', 'e-Mail address must be set.'));
		}

		if(isset($this->report_suites))
		{
			if(!is_array($this->report_suites))
			{
				$this->add_error(OM_L10n::getString('lib://reportsuites-submitted-as-array', 'Report Suites must be submitted as a valid array.'));
			}

			if($this->check_divisions)//checks to see if we should check if divisions match
			{
				if(!$this->SaintAPI->reportSuiteDivisionsMatch($this->report_suites, $this->relation_id))
				{
					$this->add_error($this->SaintAPI->get_last_error_string());
				}
			}
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-one-reportsuite', 'Must specify at least one Report Suite.'));
		}


		if(isset($this->relation_id))
		{
			//TODO:is numberic?
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-relation-id', 'Must specify a relation id.'));
		}

		if(isset($this->api_login))
		{
			//nothing to do here.
		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-login-name', 'Must Specify a login name'));
		}

		if(isset($this->overwrite_conflicts))
		{

		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-boolean-for-overwrite', 'Must specify a true/false for overwrite conflicts.'));
		}
		if(isset($this->check_divisions))
		{

		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-boolean-for-check-divisions', 'Must specify a true/false for check divisions.'));
		}

		if(isset($this->export_results))
		{

		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://must-specify-boolean-export-results', 'Must specify a true/false for export results.'));
		}
		
		if(is_array($this->headers))
		{

		}
		else
		{
			$this->add_error(OM_L10n::getString('lib://headers-must-be-valid-array', 'headers must be a valid array.'));
		}

		if(count($this->get_errors) > 0)
		{
			return false;
		}
		else
		{
			return true;
		}

		if (!isset($this->integration_id)) {
			$this->integration_id = 0;
		}
	}

	function execute()
	{	
		$this->job_id = $this->SaintAPI->createJob($this->api_login, 'import', 0, 0, $this->integration_id);

		if($this->job_id)
		{
			if(!$this->SaintAPI->createImportConfig($this->description, $this->relation_id, implode('*', $this->report_suites), $this->overwrite_conflicts, $this->email, $this->export_results, $this->job_id, $this->company, $this->company_id))
			{
				$this->add_error($this->SaintAPI->last_error());
			}
			else
			{
				$this->sfh = new SaintAPIFileFunctions();
				$filename = $this->job_id . "_SaintImport.tab";
				//Add Record
				$this->sfh->addFileRecord($this->job_id, $filename, $this->import_path, 'upload', 0);
				//Write Master File Chunk.
				$this->sfh->saveFileHeader($this->job_id, 0, $this->headers, $this->import_path, $this->report_suites);
				
			}
		}
		else
		{
			$this->add_error($this->SaintAPI->last_error());
		}

	}

	//Corny Error tracker.
	function add_error($error_string)
	{
		//Adds an error to the errors array.
		$this->error_array[count($this->errors_array)] = $error_string;
	}

	function getJobId()
	{
		return $this->job_id;
	}

	function get_errors()
	{
		return $this->error_array;
	}

	function get_last_error_string()
	{
		return $this->error_array[(count($this->error_array)-1)];
	}

	function getGenesisIntegrationId() 
	{
		return $this->integration_id;
	}

	function setGenesisIntegrationId($integration_id)
	{
		$this->integration_id = $integration_id;
	}
}
?>
