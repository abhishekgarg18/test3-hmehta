<?php

$PHP_SELF = '/sc15';
include 'local.inc';
require_once PLATFORM_DIR . '/util/cache/OM_Cache.class.php';
$GLOBALS['PRODUCT_ID'] = PRODUCT_ID_SEARCHCENTER;

$account_id = $argv[1];

if (empty($account_id)) {
	echo "An account_id is required\n";
	exit();
}

echo "Clearing Cache for Account: $account_id\n";

if (!class_exists('memcache')) {
	echo "Uh, Houston, We have a problem.  Memcache is not enabled\n";
	echo "Check the php.ini settings and see if memcache.so is being loaded\n";
	exit();
}

OM_Cache::enableCache();
OM_Cache::clearAccountNameSpace($account_id);
