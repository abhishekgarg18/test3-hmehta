<?php

require_once 'application.inc';
require_once 'class-ha-queue-item.php';

// got help from http://stackoverflow.com/questions/45953/php-execute-a-background-process#45966

define(HA_RE_NAME,          'run-everywhere');
define(HA_RE_TEMP_DIR,      'run-everywhere');
define(HA_RE_PROCESS_LIMIT, 50);

class HA_Run_Everywhere extends HA_Utilities 
{
	var $name;
	var $process_limit;
	var $temp_dir;
	var $results_dir;
	var $queue = array();
	var $clean_up_flag = true;
	var $dirs_ready = false;
    var $active_servers = array();
    var $active_data_centers = array();
    var $sleep_time = 5;
	
	// anything you put in $args will override the default value
	function __construct( $args = array() ) {
		if( !isset( $args['name'] ) ) {
			$args['name'] = HA_RE_NAME;
		}
		$this->name( $args['name'] );
		
		if( !isset( $args['log_level'] ) ) {
			$args['log_level'] = HA_LOG_LEVEL_DEBUG;
		}
		$this->log_level( $args['log_level'] );
		
		if( !isset( $args['temp_dir'] ) ) {
			$args['temp_dir'] = '/tmp/' . HA_RE_TEMP_DIR . '-' . time() . '-' . rand(10, 99); // a good unique temp dir name includes a timestamp!
		}
		$this->temp_dir( $args['temp_dir'] );
		
		if( !isset( $args['process_limit'] ) ) {
			$args['process_limit'] = HA_RE_PROCESS_LIMIT;
		}
		$this->process_limit( $args['process_limit'] );
		
		if( isset( $args['queue'] ) ) {
			$this->queue( $args['queue'] );
		}
		
		if( isset( $args['sleep_time'] ) ) {
			$this->sleep_time( $args['sleep_time'] );
		}
		
		if( !isset( $args['clean_up_flag'] ) ) {
			$args['clean_up_flag'] = true;
		}
		$this->clean_up_flag( $args['clean_up_flag'] );
		
		if( !isset( $args['active_servers'] ) ) {
			$args['active_servers'] = array();
		}
		$this->active_servers( $args['active_servers'] );
		
		parent::__construct($args);
	}
	
	function __destruct() {
		if ( $this->dirs_ready() ) {
			$this->clean_up_dirs();
		}
	}
	
	function add_to_queue( $args = array() ) {
		if ( !isset($args['queue_index']) ) {
			$args['queue_index'] = count($this->queue);
		}
		if ( !isset($args['log_level']) ) {
			$args['log_level'] = $this->log_level();
		}
		if ( !isset($args['results_dir']) ) {
			$args['results_dir'] = $this->results_dir();
		}
		if ( !isset($args['pid_dir']) ) {
			$args['pid_dir'] = $this->pid_dir();
		}
        if ( isset($args['data_center']) && is_array($args['active_data_centers']) && (!in_array($args['data_center'], $args['active_data_centers'] ) ) ) {
            $args['active_data_centers'][] = $args['data_center'];
        }
		
		array_push($this->queue, new HA_Queue_Item( $args ));
	}

	function all_dirs() {
		return array(
			'temp_dir'    => $this->temp_dir(),
			'pid_dir'     => $this->pid_dir(),
			'results_dir' => $this->results_dir(),
		);
	}
    
	// remove all of those temp files & folders
	// can be turned off with a setting
	function clean_up_dirs() {
		if ( $this->clean_up_flag() == true) {
			//$this->debug('cleaning up temp dirs');

			// invert the processing order of directories, because we'll want to 
			// delete inner directories before deleting outer directories.
			$all_dirs = array_reverse( $this->all_dirs() );

			foreach ( $all_dirs as $name => $dir ) {
				// delete child files and then the directory
				if ($handle = opendir($dir)) {
					while (false !== ($entry = readdir($handle))) {
						$del_file = $dir . '/' . $entry;
						
						if ( ($entry == ".") || ($entry == "..")) {
							// skip this one!
						}
						else if (is_file($del_file) ) {
							$success = unlink( $del_file );
							if ( !$success ) {
								$this->warn('Error removing temp file ' . $del_file);
							}
						}
						else if (is_dir($del_file) ) {
							// do we want to delete recursively? not yet. maybe later...
						}
					}
					closedir($handle);
				}
				
				$success = rmdir($dir);
				if ( !$success ) {
					$this->warn('Error removing temp dir ' . $dir);
				}
			}

			$this->dirs_ready(false);
		}
	}
	
	function active_data_centers( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->active_data_centers = $new_value;
		}
		return $this->active_data_centers;
	}
	
	function active_servers( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->active_servers = $new_value;
		}
		return $this->active_servers;
	}
	
	function clean_up_flag( $new_value = null ) {
		if ( (!empty( $new_value )) || is_bool( $new_value ) ) {
			$this->clean_up_flag = $new_value;
		}
		return $this->clean_up_flag;
	}
	
	function dirs_ready( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->dirs_ready = $new_value;
		}
		return $this->dirs_ready;
	}
	
	function log_level( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->log_level = $new_value;
		}
		return $this->log_level;
	}
	
	function name( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->name = $new_value;
		}
		return $this->name;
	}
	
	// get the final output after running all of the processes
	function output() {
		$final_output = array();
		$queue = $this->queue();
		
		if (is_array($queue)) {
			foreach( $queue as $queue_item ) {
				$final_output[ $queue_item->queue_index() ] = $queue_item->output();
			}
		}
		
		return $final_output;
	}

	// get the final output after running all of the processes
	function output_as_arrays() {
		$final_output = array();
		$queue = $this->queue();
		
		if (is_array($queue)) {
			foreach( $queue as $queue_item ) {
				$final_output[ $queue_item->queue_index() ] = $queue_item->output_as_array();
			}
		}
		
		return $final_output;
	}

	// get the final output after running all of the processes (still in the files)
	function output_filenames() {
		$final_output = array();
		$queue = $this->queue();
		
		if (is_array($queue)) {
			foreach( $queue as $queue_item ) {
				$final_output[ $queue_item->queue_index() ] = $queue_item->output_filename();
			}
		}
		
		return $final_output;
	}

	function pid_dir( $new_value = array() ) {
		if ( !empty( $new_value ) ) {
			$this->pid_dir = $new_value;
		}
		if ( empty( $this->pid_dir ) ) {
			$this->pid_dir = $this->temp_dir . '/pid';
		}
		return $this->pid_dir;
	}

	function process_limit( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->process_limit = $new_value;
		}
		return $this->process_limit;
	}
	
	function queue( $new_value = array() ) {
		if ( !empty( $new_value ) ) {
			$this->queue = $new_value;
		}
		return $this->queue;
	}
	
	function sleep_time( $new_value = array() ) {
		if ( !empty( $new_value ) ) {
			$this->sleep_time = $new_value;
		}
		return $this->sleep_time;
	}
	
	function results_dir( $new_value = array() ) {
		if ( !empty( $new_value ) ) {
			$this->results_dir = $new_value;
		}
		if ( empty( $this->results_dir ) ) {
			$this->results_dir = $this->temp_dir . '/results';
		}
		return $this->results_dir;
	}
	
	// initialize temp folders
	function set_up_dirs() {
		//$this->debug('setting up temp dirs');

		foreach( $this->all_dirs() as $name => $dir ) {
			if ( !file_exists( $dir ) ) {
				$success = mkdir( $dir );
				if ( !$success ) {
					$this->error( 'Error making directory ' . $dir );
				}
			}
			else {
				$this->warn( 'Tried to create a directory that already exists - ' . $dir );
			}
		}
		$this->dirs_ready(true);
	}
	
	function start( ) {
		// have the temp files been set up? if not, do it!
		if ($this->dirs_ready() == false) {
			$this->set_up_dirs();
		}
		
		$process_limit = $this->process_limit();
		$queue_size = count($this->queue);
		$this->unfinished_queue_keys = array_keys($this->queue);
		$this->finished_keys = array();
		$i = 0;
		foreach($this->queue as $queue_item) {
			$queue_item->begin();
			$i++;
			
			if (($i >= $process_limit) && ($process_limit > 0) && ($process_limit < $queue_size)) {
				//$this->debug("Hit process limit of " . $process_limit . ".  $i/$queue_size - Unfinished queue size: " . count($this->unfinished_queue_keys) . ".");
				
				$this->wait_for_finished_items($i, 1);
			}
		}
		
		$this->wait_for_finished_items();
	}
	
	// params "index" and "limit" will default to everything left in the queue if left empty
	function wait_for_finished_items($index = null, $limit = null) {
		if ($limit == null) {
			$limit = count($this->unfinished_queue_keys);
		}
		if ($index == null) {
			$index = count($this->unfinished_queue_keys);
		}
       

		$num_orig_unfinished = count($this->unfinished_queue_keys);
        $this->debug("Wait for finished items - limit " . $limit . "; index " . $index . "; # unfinished " . $num_orig_unfinished . ";\n");
		$num_finished_here = 0;
        $k = 0;
		
		// usually we just need to free up one item, for the next on the list.
        // EXCEPT when we want to wait until EVERYTHING is finished, at the very end
		while ( //(count($this->unfinished_queue_keys) > 0) && 
			    //(count($this->unfinished_queue_keys) >= $num_orig_unfinished) &&
			    //($num_orig_unfinished >= $limit) &&
				($num_finished_here < $limit) ) {
			$j = 0;
            $k++;
            
            $server_list = '';

			foreach($this->unfinished_queue_keys as $key) {
				$item = $this->queue[$key];
				
				if ($item->is_complete()) {
					unset($this->unfinished_queue_keys[$key]);
					$this->finished_keys[$key] = $key;
					$num_finished_here++;
					
					// stop if we're just freeing up one item.
					if ($num_finished_here >= $limit) {
						return;
					}
				}
                
                $server_list .= ' ' . $item->remote_server();

				// no need to check into items past the queue item we're looking at now.
				$j++;
				if ($j > $index) {
					break;
				}
			}

            if ($k > 1) {
                $this->debug("going to sleep; with " . count($this->unfinished_queue_keys) . " unfinished keys. " . $server_list);
       			sleep($this->sleep_time());
            }

		}
	}

	function temp_dir( $new_value = null ) {
		if ( !empty( $new_value ) ) {
			$this->temp_dir = $new_value;
		}
		if ( empty( $this->temp_dir ) ) {
			$this->temp_dir = HA_RE_TEMP_DIR . '-' . time(); // a good unique temp dir name includes a timestamp!
		}
		return $this->temp_dir;
	}
}


?>