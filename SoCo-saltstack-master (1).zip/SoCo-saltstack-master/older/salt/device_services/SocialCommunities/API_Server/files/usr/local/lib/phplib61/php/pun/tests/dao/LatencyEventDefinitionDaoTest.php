<?php
require_once("application.inc");
require_once("pun/dao/LatencyEventDefinitionDao.php");
require_once("pun/model/LatencyEventDefinition.php");

class LatencyEventDefinitionDaoTest extends PHPUnit_Framework_TestCase
{
	private $defDao;
	
	public function __construct()
	{
		$this->defDao = new LatencyEventDefinitionDao();	
	}
	
	public function testSaveLatencyEventDefinition()
	{
		$def = new LatencyEventDefinition();
		$def->setUsername("sistr2");
		$def->setUserid(4);
		$def->setLatencyThreshold(5);
		$def->setNoticeDefId(12);
		
		$newDef = $this->defDao->saveLatencyEventDefinition($def);
		
		$this->assertNotNull($newDef);
		$this->assertNotNull($newDef->getEventDefId());
		$this->assertTrue($newDef->getEventDefId() > 0);
		
		$this->defDao->deleteLatencyEventDefinition($newDef->getEventDefId());
	}
	
	public function testGetLatencyEventDefinition()
	{
		$def = new LatencyEventDefinition();
		$def->setUsername("sistr2");
		$def->setUserid(4);
		$def->setLatencyThreshold(6);
		$def->setNoticeDefId(12);
		
		$def = $this->defDao->saveLatencyEventDefinition($def);
		
		$newDef = $this->defDao->getLatencyEventDefinition($def->getEventDefId());
		$this->assertNotNull($newDef);
		$this->assertNotNull($newDef->getEventDefId());
		$this->assertTrue($newDef->getEventDefId() > 0);
		$this->assertEquals($def->getEventDefId(),$newDef->getEventDefId());
		
		$this->defDao->deleteLatencyEventDefinition($newDef->getEventDefId());
		
	}
	
	public function testGetLatencyEventDefinitions()
	{
		$def = new LatencyEventDefinition();
		$def->setUsername("sistr2");
		$def->setUserid(4);
		$def->setLatencyThreshold(6);
		$def->setNoticeDefId(12);
		
		$def = $this->defDao->saveLatencyEventDefinition($def);
		
		$newDef = $this->defDao->getLatencyEventDefinition($def->getEventDefId());
		$this->assertNotNull($newDef);
		$this->assertNotNull($newDef->getEventDefId());
		$this->assertTrue($newDef->getEventDefId() > 0);
		$this->assertEquals($def->getEventDefId(),$newDef->getEventDefId(0));
		
		$this->defDao->deleteLatencyEventDefinition($newDef->getEventDefId());
		
	}
}
