<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2014 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com
// The point here is to get direct queries out of the Scout code.

require_once 'application.inc';
require_once 'class-ha-utilities.php';

class SLA_Accounts extends HA_Utilities
{
    const DB_NAME = 'latencydb';
    const SQL_COMMENT = " /* MODULE: bertlib FILE: class-sla-accounts.php */ ";        
    private $days;
    private $db;

    function __construct($args = array()) {
        $this->db = new DB_SQL(self::DB_NAME);
   		$this->load_args($args);

        $this->days = array(
            0 => 'Sun',
            1 => 'Mon',
            2 => 'Tue',
            3 => 'Wed',
            4 => 'Thu',
            5 => 'Fri',
            6 => 'Sat',
        );
        
	    parent::__construct($args);
    }

    function load_args($args) {
    }
    
    function db() {
        return $this->db;
    }

    function pretty_time($time){
        return date("M d, h:i",strtotime($time));
    }
    //Fri, Aug 18, at 12:35am
    function format_time($time){
        return date("D, M j",strtotime($time)).', at '.date("g:ia",strtotime($time)) ;
    }
    
    function list_current_sla_alerts() {
        $sql = 'SELECT ' . self::SQL_COMMENT . '
            alert.*, 
            account.rsid 
        FROM 
            sla_alerts alert 
            LEFT JOIN sla_accounts account 
                ON alert.sla_id = account.id 
        WHERE 
            severity IN ("critical","warning") 
        ORDER BY 
            severity
        ';
        $db = $this->db();
        $db->query($sql);
        $alerts = array();
        while ($db->next_record()) {
            $alert = array();
            $alert['id'] = $db->f('id');
            $alert['rsid'] = $db->f('rsid');
            $alert['sla_id'] = $db->f('sla_id');
            $alert['severity'] = $db->f('severity');
            $alert['alert_time'] = $db->f('alert_time');
            $alert['alert_time-formatted'] = $this->format_time( $db->f('alert_time') );
            $alert['acknowledged'] = ($db->f('acknowledged') == 0) ? 'no' : 'yes';
            $alert['acknowledged_by'] = $db->f('acknowledged_by');
            $alert['acknowledged_reset_time'] = $db->f('acknowledged_reset_time');
            $alert['acknowledged_reset_time-formatted'] = $this->format_time( $db->f('acknowledged_reset_time') );
            $alert['comments'] = $db->f('comments');
            $alert['server_type'] = $db->f('server_type');
            $alert['minutes_latent'] = $db->f('minutes_latent');
            
            $alerts[$db->f('rsid')] = $alert;
        }
        return $alerts;
    }
    
    function delete_sla_account($id) {
        $clean_value = intval($id);
        
        if ($id > 0) {
            
            // first, make sure id exists.
            $sql = 
                'SELECT ' . self::SQL_COMMENT . ' id
                 FROM
                    sla_accounts
                 WHERE id=' . $clean_value;
            $db = $this->db();
            $db->query($sql);
             
            if ($db->next_record()) {
                $sql = 
                    'DELETE ' . self::SQL_COMMENT . ' 
                     FROM
                        sla_accounts
                     WHERE id=' . $clean_value;
                $db = $this->db();
                $db->query($sql);
                
                return true;
            }
        }
        
        return false;
    }
    
    function list_all_sla_accounts() {    
        $sql = 'SELECT ' . self::SQL_COMMENT . '
            id,
            rsid, 
            lobby_critical_latency, 
            elevator_critical_latency, 
            lobby_warning_latency,
            elevator_warning_latency,
            lobby_alert_email, 
            elevator_alert_email,
            enabled,
            begin_date,
            end_date,
            daily_begin_time,
            daily_end_time,
            day_of_week,
        	comments
        FROM
            sla_accounts
        ORDER BY 
            RSID, 
            begin_date
        ';
        $db = $this->db();
        $db->query($sql);
        $all = array();
        
        while ($db->next_record()){
            $list['id'] = $db->f('id');
            $list['rsid'] = $db->f('rsid');
            $list['lobby_latency'] = $db->f('lobby_critical_latency');
            $list['elevator_latency'] = $db->f('elevator_critical_latency');
            $list['lobby_warning'] = $db->f('lobby_warning_latency');
            $list['elevator_warning'] = $db->f('elevator_warning_latency');
            $list['lobby_email'] = $db->f('lobby_alert_email');
            $list['elevator_email'] = $db->f('elevator_alert_email');
            $list['enabled'] = $db->f('enabled');
            $list['begin_date'] = $db->f('begin_date');
            $list['end_date'] = $db->f('end_date');
            $list['daily_begin_time'] = $db->f('daily_begin_time');
            $list['daily_end_time'] = $db->f('daily_end_time');
            $list['day_of_week'] = $db->f('day_of_week');
            $list['comments'] = $db->f('comments');
            
            $list['enabled-formatted'] = (($list['enabled']) ? 'yes' : 'no');
            
            if ((intval($list['begin_date']) > 0) && (strlen($list['begin_date']) > 0)) {
                $list['begin_date-formatted'] = date('Y-m-d', strtotime($list['begin_date']));
            }
            if ((intval( $list['end_date']) > 0) && (strlen( $list['end_date']) > 0)) {
                $list['end_date-formatted'] = date('Y-m-d', strtotime( $list['end_date']));
            }
            if (strlen($list['daily_begin_time']) > 0) {
                $list['daily_begin_time-formatted'] = date('H:m:s', strtotime($list['daily_begin_time']));
            }
            if (strlen($list['daily_end_time']) > 0) {
                $list['daily_end_time-formatted'] = date('H:m:s', strtotime($list['daily_end_time']));
            }
            
            $these_days = split(',', $list['day_of_week']);
            $nice_days = array();
            foreach($these_days as $day_index) {
                $nice_days[] = $this->days[$day_index];
            }
            $list['day_of_week-formatted'] = join(', ', $nice_days);
            
            $lobby_emails = split('[, ]+', $list['lobby_email']);
            $formatted_lobby_emails = array();
            foreach($lobby_emails as $indiv_lobby_email) {
                if (strstr($indiv_lobby_email, '@')) {
                    $formatted_lobby_emails[] = '<a href="mailto:' . htmlspecialchars($indiv_lobby_email) . '" title="Email ' . htmlspecialchars($indiv_lobby_email) . '">' . $indiv_lobby_email . '</a>';
                }
                else {
                    $formatted_lobby_emails[] = $indiv_lobby_email;
                }
            }
            sort($formatted_lobby_emails);
            $list['lobby_email-formatted'] = join(', ', $formatted_lobby_emails);
            
            $elevator_emails = split('[, ]+', $list['elevator_email']);
            $formatted_elevator_emails = array();
            foreach($elevator_emails as $indiv_elevator_email) {
                if (strstr($indiv_elevator_email, '@')) {
                    $formatted_elevator_emails[] = '<a href="mailto:' . htmlspecialchars($indiv_elevator_email) . '"title="Email ' . htmlspecialchars($indiv_lobby_email) . '">' . $indiv_elevator_email . '</a>';
                }
                else {
                    $formatted_elevator_emails[] = $indiv_elevator_email;
                }
            }
            sort($formatted_elevator_emails);
            $list['elevator_email-formatted'] = join(', ', $formatted_elevator_emails);
            
            $all[ $list['id'] ] = $list;
	    	$list = array();
        }
        
        return $all;
    }
    
    function setValue($row_id, $field, $new_value) {
        $clean_row_id = intval($row_id);
        
        if ($clean_row_id > 0) {
            
            $retval = $this->setSQL($field, $new_value);
            
            if ( strlen( $retval['error'] ) > 0 ) {
                return $retval['error'];
            }
            
            if ( $retval['found'] === false ) {
                return false;
            }
            
            $sql = 'UPDATE sla_accounts ' . self::SQL_COMMENT . ' SET ' . $retval['set_sql'] . ' WHERE id=' . $clean_row_id . ';';
            $db = $this->db();
            $db->query($sql);
            return true;
        }
        
        return false;
    }
    
    function createNewRow($args = array()) {
        $set_clauses = array();
        $final_return = array();
        $final_return['found'] = false;
        $final_return['error'] = '';
        $final_return['id'] = -1;
        $final_return['response'] = false;
        
        foreach($args as $field => $new_value) {
            $retval = $this->setSQL($field, $new_value);

            if ( strlen( $retval['error'] ) > 0 ) {
                $final_return['error'] = $retval['error'];
                $final_return['response'] = $retval['error'];
                return $final_return;
            }
            
            if ( $retval['found'] === false ) {
                $final_return['found'] = false;
                return $final_return;
            }

            if (strlen($retval['set_sql']) > 0) {
                $set_clauses[] = $retval['set_sql'];
            }
        }
        
        $sql = 'INSERT INTO sla_accounts ' . self::SQL_COMMENT . 
            ' SET ' . join(', ', $set_clauses);
        $db = $this->db();
        $db->query($sql);

        $final_return['found'] = true;
        $final_return['id'] = $this->db->last_insert();
        $final_return['response'] = true;
        
        return $final_return;
    }
    
    function updateRow($args = array()) {
        $set_clauses = array();
        $final_return = array();
        $final_return['found'] = false;
        $final_return['error'] = '';
        $final_return['id'] = (isset($args['id']) ? $args['id'] : $args['report-suite']);
        $final_return['response'] = false;
        
        foreach($args as $field => $new_value) {
            $retval = $this->setSQL($field, $new_value);

            if ( strlen( $retval['error'] ) > 0 ) {
                $final_return['error'] = $retval['error'];
                $final_return['response'] = $retval['error'];
                return $final_return;
            }
            
            if ( $retval['found'] === false ) {
                $final_return['found'] = false;
                return $final_return;
            }

            if (strlen($retval['set_sql']) > 0) {
                $set_clauses[] = $retval['set_sql'];
            }
        }
        
        $update_id = $args['id'];
        $sql = 'UPDATE sla_accounts ' . self::SQL_COMMENT . 
            ' SET ' . join(', ', $set_clauses) . ' WHERE id=' . $update_id;
        $db = $this->db();
        $db->query($sql);

        $final_return['found'] = true;
        $final_return['id'] = $update_id;
        $final_return['response'] = true;
        
        return $final_return;
    }
    
    function setSQL($field, $new_value) {
        $set = '';
        $found = false;
        $error = '';
        
        switch($field) {
            
            // verify new_value is a valid report suite.
            case 'report-suite':
                $userid = userid_lookup($new_value);
                if ($userid > 0) {
                    $found = true;
                    $set = 'rsid="' . addslashes($new_value) . '" ';
                }
                else {
                    $error = "Error: $new_value is not a valid report suite";
                }
                break;
                
            case 'lobby-warning':
                $clean_value = intval($new_value);
                if ($new_value == '') {
                    // treat an empty string like a null here
                    $clean_value = 'NULL';
                }
                else if (($clean_value != $new_value) || ($clean_value <= 0) || ($clean_value > 360)) {
                    $error = "Error: Not a valid lobby warning time.  Time should be given in minutes between 0 and 360.";
                    break;
                }
                $found = true;
                $set = 'lobby_warning_latency=' . $clean_value . ' ';
                break;
                
            case 'lobby-alert':
                $clean_value = intval($new_value);
                if ($new_value == '') {
                    // treat an empty string like a null here
                    $clean_value = 'NULL';
                }
                else if (($clean_value != $new_value) || ($clean_value <= 0) || ($clean_value > 360)) {
                    $error = "Error: Not a valid lobby alert time.  Time should be given in minutes between 0 and 360.";
                    break;
                }
                $found = true;
                $set = 'lobby_critical_latency=' . $clean_value . ' ';
                break;

            case 'elevator-warning':
                $clean_value = intval($new_value);
                if ($new_value == '') {
                    // treat an empty string like a null here
                    $clean_value = 'NULL';
                }
                else if (($clean_value != $new_value) || ($clean_value <= 0) || ($clean_value > 360)) {
                    $error = "Error: Not a valid elevator warning time.  Time should be given in minutes between 0 and 360.";
                    break;
                }
                $found = true;
                $set = 'elevator_warning_latency=' . $clean_value . ' ';
                break;
                
            case 'elevator-alert':
                $clean_value = intval($new_value);
                if ($new_value == '') {
                    // treat an empty string like a null here
                    $clean_value = 'NULL';
                }
                else if (($clean_value != $new_value) || ($clean_value <= 0) || ($clean_value > 360)) {
                    $error = "Error: Not a valid elevator alert time.  Time should be given in minutes between 0 and 360.";
                    break;
                }
                $found = true;
                $set = 'elevator_critical_latency=' . $clean_value . ' ';
                break;

            case 'lobby-email':
                $clean_value = addslashes($new_value);
                $found = true;
                $set = 'lobby_alert_email="' . $clean_value . '" ';
                break;

            case 'elevator-email':
                $clean_value = addslashes($new_value);
                $found = true;
                $set = 'elevator_alert_email="' . $clean_value . '" ';
                break;
            case 'comments':
                	
                	$found = true;
                	$set = 'comments="' . $new_value . '" ';
                	break;

            case 'enabled':
                if ( ($new_value == 'yes') || ($new_value == 'true') ) {
                    $new_value = 1;
                }
                else if ( ($new_value == 'no') || ($new_value == 'false') ) {
                    $new_value = 0;
                }
                else {
                    // default to "yes" if not given
                    $new_value = 1;
                }
                $clean_value = intval($new_value);
                if ( ($clean_value != 0) && ($clean_value != 1) ) {
                    $error = "Error: Not a valid value for 'enabled'";
                    break;
                }
                $found = true;
                $set = 'enabled="' . $clean_value . '" ';
                break;

            case 'begin-date':
                if ($new_value == '') {
                    // an empty date should be set to null here
                    $found = true;
                    $set = 'begin_date=NULL ';
                }
                else {
                    $clean_value = date('Y-m-d', strtotime($new_value));
                    if ($clean_value != $new_value) {
                        $error = "Error: Not a valid begin date.  Use the format YYYY-mm-dd.";
                        break;
                    }
                    $found = true;
                    $set = 'begin_date="' . $clean_value . '" ';
                }
                break;

            case 'end-date':
                if ($new_value == '') {
                    // an empty date should be set to null here
                    $found = true;
                    $set = 'end_date=NULL ';
                }
                else {
                    $clean_value = date('Y-m-d', strtotime($new_value));
                    if ($clean_value != $new_value) {
                        $error = "Error: Not a valid end date.  Use the format YYYY-mm-dd.";
                        break;
                    }
                    $found = true;
                    $set = 'end_date="' . $clean_value . '" ';
                }
                break;

            case 'daily-begin-time':
                if ($new_value == '') {
                    // an empty time should be set to null here
                    $found = true;
                    $set = 'daily_begin_time=NULL ';
                }
                else {
                    $clean_value = date('H:i:s', strtotime($new_value));
                    if ($clean_value != $new_value) {
                        $error = "Error: Not a valid begin time.  Use the format HH:MM:SS.";
                        break;
                    }
                    $found = true;
                    $set = 'daily_begin_time="' . $clean_value . '" ';
                }
                break;

            case 'daily-end-time':
                if ($new_value == '') {
                    // an empty time should be set to null here
                    $found = true;
                    $set = 'daily_end_time=NULL ';
                }
                else {
                    $clean_value = date('H:i:s', strtotime($new_value));
                    if ($clean_value != $new_value) {
                        $error = "Error: Not a valid end time.  Use the format HH:MM:SS.";
                        break;
                    }
                    $found = true;
                    $set = 'daily_end_time="' . $clean_value . '" ';
                }
                break;

            // allow user to enter a number between 0-6 or day abbreviations as displayed, case insensitive
            case 'days-of-week':
                if ($new_value == '') {
                    // an empty value should be set to null here
                    $found = true;
                    $set = 'day_of_week=NULL ';
                }
                else {
                    $days_of_week = preg_split("/\s*,\s*/", $new_value);
                    $numeric_days = array();
                    $all_string_days = array_flip($this->days);
                    foreach($days_of_week as $day) {
                        if ( is_numeric($day) && ($day < 7) ) {
                            $numeric_days[] = $day;
                        }
                        else {
                            $check_day = ucfirst(strtolower($day));
                            if (array_search($check_day, $this->days) === false) {
                                $error = "Error: There is an invalid day '" . $day . "' in the list: " . $new_value . 
                                    ".\nUse the values Sun, Mon, Tue, Wed, Thu, and Fri.";
                                break;
                            }
                            else {
                                $numeric_days[] = $all_string_days[$day];
                            }
                        }
                    }
                    $clean_value = join(',', $numeric_days);
                    $found = true;
                    $set = 'day_of_week="' . $clean_value . '" ';
                }
                break;

            // don't do anything with id, but don't throw an error, either
            case 'id':
                $found = true;
                $set = '';
                break;

            default:
                $error = 'Error: field ' . $field . ' not found.';
        }
        
        $retval = array();
        $retval['set_sql'] = $set;
        $retval['found'] = $found;
        $retval['error'] = $error;
        
        return $retval;
    }
}