<?php

$PHP_SELF = '/sc15';
include 'local.inc';
require_once PLATFORM_DIR . '/util/cache/OM_Cache.class.php';
$GLOBALS['PRODUCT_ID'] = PRODUCT_ID_SEARCHCENTER;

echo "Clearing Cache\n";

if (!class_exists('memcache')) {
	echo "Uh, Houston, We have a problem.  Memcache is not enabled\n";
	echo "Check the php.ini settings and see if memcache.so is being loaded\n";
	exit();
}

OM_Cache::enableCache();
OM_Cache::flush();
