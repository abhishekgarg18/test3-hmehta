<?

/**********************************************************************
master DB tables:
-----------------
CREATE TABLE rprop_entities (
	entity_key  char(32)         NOT NULL,
	description char(255)        NOT NULL,
	required    tinyint unsigned NOT NULL,
	PRIMARY KEY (entity_key)
);
INSERT INTO rprop_entities VALUES ("media.name","Video reporting - Video name for pathing",1);
INSERT INTO rprop_entities VALUES ("media.ad.name","Video reporting - Video ad name for pathing",1);

CREATE TABLE revar_entities (
	entity_key  char(32)         NOT NULL,
	description char(255)        NOT NULL,
	required    tinyint unsigned NOT NULL,
	PRIMARY KEY (entity_key)
);
INSERT INTO revar_entities VALUES ("media.name","Video reporting - Video name",1);
INSERT INTO revar_entities VALUES ("media.segment","Video reporting - Video segment",1);
INSERT INTO revar_entities VALUES ("media.ad.name","Video reporting - Video ad name",1);
INSERT INTO revar_entities VALUES ("media.ad.segment","Video reporting - Video ad segment",1);
INSERT INTO revar_entities VALUES ("partner.dfa.ad1","Genesis - DFA - Ad tracking code for Impressions and Click-Thrus",0);
INSERT INTO revar_entities VALUES ("partner.dfa.ad2","Genesis - DFA - Ad tracking code for View-Thrus",0);
INSERT INTO revar_entities VALUES ("partner.dfa.viewThruBucket","Genesis - DFA - Ad time buckets for View-Thrus",0);

CREATE TABLE revent_entities (
	entity_key  char(32)         NOT NULL,
	description char(255)        NOT NULL,
	required    tinyint unsigned NOT NULL,
	PRIMARY KEY (entity_key)
);
INSERT INTO revent_entities VALUES ("media.timePlayed","Video reporting - Video time played",1);
INSERT INTO revent_entities VALUES ("media.ad.timePlayed","Video reporting - Video ad time played",1);
INSERT INTO revent_entities VALUES ("partner.dfa.impressions","Genesis - DFA - Ad Impressions",0);
INSERT INTO revent_entities VALUES ("partner.dfa.clickThrus","Genesis - DFA - Ad Click-Thrus",0);
INSERT INTO revent_entities VALUES ("partner.dfa.viewThrus","Genesis - DFA - Ad View-Thrus",0);

user DB tables:
---------------
CREATE TABLE user_rprops (
	userid         int unsigned     NOT NULL,
	entity_key     char(32)         NOT NULL,
	rprop_num      tinyint unsigned NOT NULL,
	reserved_state enum("reserved","released") NOT NULL DEFAULT "reserved",
	PRIMARY KEY (userid,rprop_num),
	UNIQUE (userid,entity_key)
);

CREATE TABLE user_revars (
	userid int     unsigned         NOT NULL,
	entity_key     char(32)         NOT NULL,
	revar_num      tinyint unsigned NOT NULL,
	reserved_state enum("free","reserved","released") NOT NULL DEFAULT "free",
	PRIMARY KEY (userid,revar_num),
	UNIQUE (userid,entity_key)
);

CREATE TABLE user_revents (
	userid int     unsigned         NOT NULL,
	entity_key     char(32)         NOT NULL,
	revent_num     tinyint unsigned NOT NULL,
	reserved_state enum("free","reserved","released") NOT NULL DEFAULT "free",
	PRIMARY KEY (userid,revent_num),
	UNIQUE (userid,entity_key)
);
**********************************************************************/

/***
 * This class is used to manage reserved variables (rProps, rEVar, and rEvents)
 ***/
class ReservedVariables {
	/**********************************************************************
	 * Basic needs
	 **********************************************************************/
	var $_username;
	var $_userid;
	var $_db;

	/**********************************************************************
	 * Constructor
	 **********************************************************************/
	function ReservedVariables($username,$userid = 0) {
		$this->_username = $username;

		$this->_db = new masterdb;
		setuserdb($this->_db,$this->_username);

		if (!$userid) {
			$sql = 'SELECT userid FROM user WHERE username = "' . addslashes($username) . '"';
			if ($this->_db->squery($sql)) {
				$userid = $this->_db->f('userid');
			}
			$this->_db->free();
		}

		$this->_userid = $userid;
	}

	/**********************************************************************
	 * Reserved Properties
	 **********************************************************************/
	function getRPropEntities() {
		return $this->_getEntities("rProp");
	}

	function getRProp($entityKey) {
		return $this->_get($entityKey,"rProp");
	}

	function getAndReserveRProp($entityKey) {
		return $this->_getAndReserve($entityKey,"rProp");
	}

	function getAllReservedRProps() {
		return $this->_getAllReserved("rProp");
	}

	function releaseRProp($entityKey) {
		$this->_release($entityKey,"rProp");
	}

	/**********************************************************************
	 * Reserved eVars
	 **********************************************************************/
	function getREVarEntities() {
		return $this->_getEntities("rEVar");
	}

	function getREVar($entityKey) {
		return $this->_get($entityKey,"rEVar");
	}

	function getAndReserveREVar($entityKey) {
		return $this->_getAndReserve($entityKey,"rEVar");
	}

	function getAllReservedREVars() {
		return $this->_getAllReserved("rEVar");
	}

	function releaseREVar($entityKey) {
		$this->_release($entityKey,"rEVar");
	}

	/**********************************************************************
	 * Reserved conversion events
	 **********************************************************************/
	function getREventEntities() {
		return $this->_getEntities("rEvent");
	}

	function getREvent($entityKey) {
		return $this->_get($entityKey,"rEvent");
	}

	function getAndReserveREvent($entityKey) {
		return $this->_getAndReserve($entityKey,"rEvent");
	}

	function getAllReservedREvents() {
		return $this->_getAllReserved("rEvent");
	}

	function releaseREvent($entityKey) {
		$this->_release($entityKey,"rEvent");
	}

	/**********************************************************************
	 * Private and used for all variable types
	 **********************************************************************/
	/***
	 * Variables are reserved by entities and all entities are
	 * predefined in tables in masterdb
	 ***/
	var $RPROP_ENTITIES = null;
	var $REVAR_ENTITIES = null;
	var $REVENT_ENTITIES = null;
	function _getEntities($type) {
		$entitiesVar = '';
		$table = '';
		switch ($type) {
			case 'rProp' : {
				$entitiesVar = 'RPROP_ENTITIES';
				$table       = 'rprop_entities';
			} break;
			case 'rEVar' : {
				$entitiesVar = 'REVAR_ENTITIES';
				$table       = 'revar_entities';
			} break;
			case 'rEvent' : {
				$entitiesVar = 'REVENT_ENTITIES';
				$table       = 'revent_entities';
			} break;
		}

		if ((!is_array($this->$entitiesVar)) || (count($this->$entitiesVar) == 0)) {
			if ($table) {
				$this->$entitiesVar = array();
				$mdb = new masterdb;
				$sql = 'SELECT entity_key,description,required FROM ' . $table;
				$mdb->query($sql);
				while ($mdb->next_record()) {
					$this->$entitiesVar[$mdb->f('entity_key')] = array(
						'description' => $mdb->f('entity_desc'),
						'required'    => $mdb->f('required'),
					);
				}
				$mdb->free();
			}
		}

		return $this->$entitiesVar;
	}

	function _getTable($type) {
		switch ($type) {
			case 'rProp'  : return 'user_rprops';
			case 'rEVar'  : return 'user_revars';
			case 'rEvent' : return 'user_revents';
		}

		return "";
	}

	function _getNumField($type) {
		switch ($type) {
			case 'rProp'  : return 'rprop_num';
			case 'rEVar'  : return 'revar_num';
			case 'rEvent' : return 'revent_num';
		}

		return "";
	}

	function _getMaxNum($type) {
		switch ($type) {
			case 'rProp'  : return 100;
			case 'rEVar'  : return 100;
			case 'rEvent' : return 100;
		}

		return 0;
	}

	/***
	 * This will return the variable number by type reserved for
	 * the passed in entity-key.  For example if you passed in
	 * "media.name" and "rEVar" and "rEVar50" is assigned to
	 * "media.name" this will return 50
	 ***/
	function _get($entityKey,$type) {
		$table    = $this->_getTable($type);
		$numField = $this->_getNumField($type);

		$num = 0;
		$sql = 'SELECT ' . $numField . ' FROM ' . $table . ' WHERE userid = ' . $this->_userid . ' AND entity_key = "' . addslashes($entityKey) . '"';
		if ($this->_db->squery($sql)) {
			$num = $this->_db->f($numField);
		}
		$this->_db->free();

		return $num;
	}

	/***
	 * We make 3 attempts to reserve a variable for the entity to try
	 * and take care of races.
	 *
	 * The first thing we do is make sure reserving is even possible
	 * based on if this entiry is required or based on the number of
	 * unised slots vs the number of required entities that are not
	 * reserved yet.
	 *
	 * If we have not reached the max number for the variable we will
	 * try top use a new variable rather than reuse one that has been
	 * released and may still have old data sitting around for it.
	 *
	 * If we reach the max we will go back and try to find a released
	 * variable to reuse.
	 ***/
	function _getAndReserve($entityKey,$type) {
		$table    = $this->_getTable($type);
		$numField = $this->_getNumField($type);

		$num = 0;
		if (($num = $this->get($entityKey,$type)) == 0) {
			$entities = $this->_getEntities($type);
			if (isset($entities[$entityKey])) {
				$maxNum = $this->_getMaxNum($type);
				$attemptNum = 0;
				while ($attemptNum < 3) {
					// Get all variables currently reserved
					$allReserved = $this->_getAllReserved($type);

					// Determine if reserving is even possible based on required
					// open slots by variables that have not been reserved yet
					$possible = false;
					// If this is a required entity reserving is always possible
					if ($entities[$entityKey]['required']) {
						$possible = true;
					} else {
						$numLeft     = ($maxNum - count($allReserved));
						$numRequired = 0;
						// For each entity that is required and is not reserved yet..
						foreach ($entities as $subEntityKey => $subEntity) {
							if (($subEntity['required']) &&
							    (!isset($allReserved[$subEntityKey]))) {
								$numRequired++;
							}
						}
						// If after reserved this variable we will still have enough
						// open slots for all required variables reserving is possible
						if (($numLeft - $numRequired) > 0) {
							$possible = true;
						}
					}

					// If we decided reserving is possible...
					if ($possible) {
						// Get number of highest reserved variable
						$highestNum = 0;
						if ((is_array($allReserved)) && (count($allReserved) > 0)) {
							$allNums = array_keys($allReserved);
							$highestNum = array_pop($allNums);
						}

						// Find a variable number to use
						$num = 0;
						// If we have not reached the max just use the next highest
						if ($highestNum < $maxNum) {
							$num = ($highestNum + 1);
						// If we have reached the max try to reuse a released variable
						} else {
							$nextNum = 1;
							while (($num == 0) && ($nextNum <= $maxNum)) {
								if (!isset($allReserved,$nextNum)) {
									$num = $nextNum;
								}
								$nextNum++;
							}
						}

						// If we found a free variable try to reserve it
						if ($num > 0) {
							// Try to insert a new row first
							$sql = 'INSERT INTO ' . $table . ' SET '
							     . 'userid = ' . $this->_userid . ','
							     . 'entity_key = "' . addslashes($entityKey) . '",'
							     . $numField . ' = ' . $num . ','
							     . 'reserved_state = "reserved"'
							;
							if ($this->_db->query($sql,1062)) {
								return $num;
							} else {
								// If we run into a duplicate key try to treat the row as a released variable
								$sql = 'UPDATE ' . $table . ' SET '
								     . 'entity_key = "' . addslashes($entityKey) . '",'
								     . 'reserved_state = "reserved" '
								     . 'WHERE '
								     . 'userid = ' . $this->_userid . ' AND '
								     . $numField . ' = ' . $num . ' AND '
								     . 'reserved_state = "released"';
								if ($this->_db->query($sql)) {
									return $num;
								}
							}
						}
					}

					$attemptNum++;
				}
			}
		}

		return $num;
	}

	/***
	 * This returns an array of all variables reserved by type
	 * indexed by the variable number with the value containing
	 * the entity-key the variable is reserved for
	 ***/
	function _getAllReserved($type) {
		$table    = $this->_getTable($type);
		$numField = $this->_getNumField($type);

		$allReservedNums = array();
		$sql = 'SELECT entity_key,' . $numField . ' FROM ' . $table . ' WHERE userid = ' . $this->_userid . ' AND reserved_state = "reserved" ORDER BY ' . $numField . ' ASC';
		$this->_db->query($sql);
		while ($this->_db->next_record()) {
			$allReservedNums[$this->_db->f($numField)] = $this->_db->f('entity_key');
		}
		$this->_db->free();

		return $allReservedNums;
	}

	/***
	 * When a variable is released we change the reserved_state
	 * instead of deleting so we have some record of what variables
	 * have ever been used so we have some explanation for "orphan"
	 * frag tables or other historical storage of a variable
	 ***/
	function _release($entityKey,$type) {
		$table = $this->_getTable($type);

		$sql = 'UPDATE ' . $table . ' SET reserved_state = "released" WHERE userid = ' . $this->_userid . ' AND entity_key = "' . addslashes($entityKey) . '"';
		$this->_db->query($sql);
	}
}
