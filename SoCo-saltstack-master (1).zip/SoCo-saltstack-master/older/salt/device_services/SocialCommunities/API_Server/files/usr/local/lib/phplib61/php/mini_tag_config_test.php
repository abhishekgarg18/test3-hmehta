<?

$SERVER_NAME = 'omniture';
$PHP_SELF = '/sc15';
require 'application.inc';

include_once('mini_tag_config.inc');

echo "starting...\n";

$mini_tag_config = new MiniTagConfig('bugzilla.www14');

echo "add\n";
$mini_tag_id = $mini_tag_config->add_mini_tag('testConfig', 'testdescript', array(20, 101), array(101) , 1, 0);
echo "$mini_tag_id\n";

echo "get all\n";
$mini_tags = $mini_tag_config->get_all_mini_tag();
print_r($mini_tags);

echo "get one\n";
$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
print_r($mini_tag);

echo "comparing results (should be empty)\n";
print_r(array_diff(end($mini_tags), $mini_tag));

echo "disable and enable\n";
$mini_tag_config->deactivate_mini_tag($mini_tag_id);
$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
print_r($mini_tag);
$mini_tag_config->activate_mini_tag($mini_tag_id);
$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
print_r($mini_tag);

echo "update\n";
$error = $mini_tag_config->update_mini_tag($mini_tag_id, 'testConFig', 'test description', array(20, 102), array(102) , 0, 1);
if ($error > 0) {
	$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
	print_r($mini_tag);
} else {
	echo "update failed: $error\n";
}

echo "delete\n";
$mini_tag_config->delete_mini_tag($mini_tag_id);
$mini_tags = $mini_tag_config->get_all_mini_tag();
print_r($mini_tags);

echo "add using texual evar and event names\n";
$mini_tag_id = $mini_tag_config->add_mini_tag('testConfig', 'testdescript', array(MiniTagConfig::evar_string_to_relation_id('campaign'), MiniTagConfig::evar_string_to_relation_id('evar 1')), array(MiniTagConfig::event_string_to_event_num('event 1')) , 1, 0);
$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
print_r($mini_tag);
$mini_tag_config->delete_mini_tag($mini_tag_id);

echo "add using oid evar and event names\n";
$mini_tag_id = $mini_tag_config->add_mini_tag('testConfig', 'testdescript', array(MiniTagConfig::oid_to_relation_id(848), MiniTagConfig::oid_to_relation_id(771)), array(MiniTagConfig::oid_to_event_num(872)) , 1, 0);
$mini_tag = $mini_tag_config->get_mini_tag($mini_tag_id);
print_r($mini_tag);
$mini_tag_config->delete_mini_tag($mini_tag_id);

echo "...complete.\n";

?>
