<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-utilities.php';

class Server_Configurations extends HA_Utilities
{
    const DB_NAME = 'cache_maintenance';
    private $db;
    
    function __construct($args = array()) {
        $this->db = new DB_SQL(self::DB_NAME);
        $this->create_tables();
        
	    parent::__construct($args);
    }

    function db() {
        return $this->db;
    }
    
    function get_server_classes() {
        $sql = 'SELECT 
            server_class_id, 
            name 
        FROM
            server_classes
        ';
        $this->db()->query($sql);
        if ($this->db()->Errno != 0) {
            $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
        }
        
        $classes = array();
        while ($this->db()->next_record()) {
            $classes[ $this->db()->f('server_class_id') ] = array(
                'server_class_id' => $this->db()->f('server_class_id'),
                'name' => $this->db()->f('name'),
            );
        }
        return $classes;
    }
    
    function remove_server_class( $remove_id ) {
        
        if (($remove_id > 0) && (intval($remove_id) == $remove_id)) {
            $sql = 'DELETE FROM server_classes WHERE server_class_id=' . $remove_id;
            $this->db()->query($sql);
            if ($this->db()->Errno != 0) {
                $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
                return false;
            }
            return true;
        }
        return false;
    }
    
    function save_server_classes( $classes = array() ) {
        
        // if arg is not already in an array, make one, to fake out the loop
        if (!is_array($classes)) {
            $classes = array( $classes );
        }
        
        foreach ($classes as $class) {
            
            if ( isset( $class['server_class_id'] ) ) {
                $insert_update = 'UPDATE';
                $set_id = 'server_class_id = ' . intval($class['server_class_id']) . ',';
            }
            else {
                $insert_update = 'INSERT INTO';
                $set_id = ''; 
            }

            $sql = $insert_update . " server_classes SET \n" . 
                $set_id . '
                name = "' . addslashes($class['name']) . '"';
            //echo "SQL is $sql.\n";
            $sql = preg_replace('/\s+/', ' ', $sql);
            $this->db()->squery($sql);
            
            if ($this->db()->Errno != 0) {
                $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
            }
        }
    }
    
    function get_server_types() {
        $classes = $this->get_server_classes();
        $sql = 'SELECT 
            server_type_id, 
            server_class_id, 
            type_code, 
            name, 
            characteristics, 
            general_usage, 
            sort_order 
        FROM
            server_types 
        ORDER BY 
            sort_order
        ';
        $this->db()->query($sql);
        if ($this->db()->Errno != 0) {
            $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
        }
        
        $types = array();
        while ($this->db()->next_record()) {
            $types[ $this->db()->f('server_class_id') . '_' . $this->db()->f('type_code') ] = array(
                'server_type_id' => $this->db()->f('server_type_id'),
                'server_class_id' => $this->db()->f('server_class_id'),
                'server_class' => $classes[ $this->db()->f('server_class_id') ],
                'type_code' => $this->db()->f('type_code'),
                'name' => $this->db()->f('name'),
                'characteristics' => $this->db()->f('characteristics'),
                'general_usage' => $this->db()->f('general_usage'),
                'sort_order' => $this->db()->f('sort_order'),
            );
        }
        return $types;
    }
    
    
    function remove_server_type( $remove_id ) {
        
        if (($remove_id > 0) && (intval($remove_id) == $remove_id)) {
            $sql = 'DELETE FROM server_types WHERE server_type_id=' . $remove_id;
            $this->db()->query($sql);
            if ($this->db()->Errno != 0) {
                $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
                return false;
            }
            return true;
        }
        return false;
    }
    
    function save_server_types($types = array()) {
        
        // if it's not already in an array, make one, to fake out the loop
        if (!is_array($types)) {
            $types = array( $types );
        }
        
        foreach ($types as $type) {

            if ( isset( $type['server_type'] ) ) {
                $this->save_server_types( array( $type['server_type'] ) );
            }
            
            if ( isset( $type['server_type_id'] ) ) {
                $insert_update = 'UPDATE';
                $set_id = 'server_type_id = ' . intval($type['server_type_id']) . ',';
            }
            else {
                $insert_update = 'INSERT INTO';
                $set_id = ''; 
            }

            $sql = $insert_update . " server_types SET \n" . 
                $set_id . '
                server_class_id = ' . intval($type['server_class_id']) . ',
                type_code = "' . addslashes($type['type_code']) . '", 
                name = "' . addslashes($type['name']) . '", 
                characteristics = "' . addslashes($type['characteristics']) . '", 
                general_usage = "' . addslashes($type['general_usage']) . '", 
                sort_order = ' . intval($type['sort_order']);
            //echo "SQL is $sql.\n";
            $sql = preg_replace('/\s+/', ' ', $sql);
            $this->db()->squery($sql);
            
            if ($this->db()->Errno != 0) {
                $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
            }
        }
    }
    
    function get_server_configurations() {
        $types = $this->get_server_types();
        $sql = 'SELECT
            server_configuration_id,
            server_type_id,
            model_code,
            model_name,
            ram,
            disk_space,
            processors,
            has_write_cache_controller,
            sort_order,
            is_certified,
            manufacturer
        FROM
            server_configurations
        ORDER BY
            sort_order
        ';
        $this->db()->query($sql);
        if ($this->db()->Errno != 0) {
            $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
        }
        
        $configs = array();
        while ($this->db()->next_record()) {
            $configs[ $this->db()->f('server_configuration_id') ] = array(
                'server_configuration_id' => $this->db()->f('server_configuration_id'),
                'server_type_id' => $this->db()->f('server_type_id'),
                'server_type' => $types[ $this->db()->f('server_type_id') ],
                'model_code' => $this->db()->f('model_code'),
                'model_name' => $this->db()->f('model_name'),
                'ram' => $this->db()->f('ram'),
                'disk_space' => $this->db()->f('disk_space'),
                'processors' => $this->db()->f('processors'),
                'has_write_cache_controller' => $this->db()->f('has_write_cache_controller'),
                'sort_order' => $this->db()->f('sort_order'),
                'is_certified' => $this->db()->f('is_certified'),
                'manufacturer' => $this->db()->f('manufacturer'),
            );
        }
        return $configs;
    }

    function remove_server_configuration( $remove_id ) {
        
        if (($remove_id > 0) && (intval($remove_id) == $remove_id)) {
            $sql = 'DELETE FROM server_configurations WHERE server_configuration_id=' . $remove_id;
            $this->db()->query($sql);
            if ($this->db()->Errno != 0) {
                $this->error('Error removing server configurations: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
                return false;
            }
            return true;
        }
        return false;
    }
    
    
    function save_server_configurations($configs = array()) {
        
        // if it's not already in an array, make one, to fake out the loop
        if (!is_array($configs)) {
            $configs = array( $configs );
        }
        
        foreach($configs as $config) {

            if ( isset( $config['server_type'] ) ) {
                $this->save_server_types( $config['server_type'] );
            }
            
            if ( isset( $config['server_configuration_id'] ) ) {
                $insert_update = 'UPDATE';
                $set_id = 'server_configuration_id = ' . intval($config['server_configuration_id']) . ',';
            }
            else {
                $insert_update = 'INSERT INTO';
                $set_id = '';
            }
            
            $sql = $insert_update . " server_configurations SET \n" . 
                    $set_id . '
                    server_type_id = ' . intval($config['server_type_id']) . ',
                    model_code = "' . addslashes($config['model_code']) . '",
                    model_name = "' . addslashes($config['model_name']) . '",
                    ram = ' . intval($config['ram']) . ',
                    disk_space = ' . intval($config['disk_space']) . ',
                    processors = ' . intval($config['processors']) . ',
                    has_write_cache_controller = ' . intval($config['has_write_cache_controller']) . ',
                    sort_order = ' . intval($config['sort_order']) . ',
                    is_certified = ' . intval($config['is_certified']) . ',
                    manufacturer = "' . addslashes($config['manufacturer']) . '";';
            //echo "SQL is $sql.\n";
            $sql = preg_replace('/\s+/', ' ', $sql);
            $this->db()->squery($sql);
            
            if ($this->db()->Errno != 0) {
                $this->error('Error listing server classes: ' . $this->db()->Errno . '; DB_Error=' . $this->db()->Error . '; SQL= ' . $sql . "\n");
            }
        }
        
    }
    
    function create_tables() {
        $create_server_classes = 'CREATE TABLE IF NOT EXISTS server_classes ( 
            server_class_id int not null primary key auto_increment,
            name varchar(40)
        );';
        $sql = preg_replace('/\s+/', ' ', $create_server_classes);
        $this->db()->squery($sql);
        
        $create_server_types = 'CREATE TABLE IF NOT EXISTS server_types ( 
            server_type_id int not null primary key auto_increment,
            server_class_id int not null,
            type_code char(1) not null,
            name varchar(40),
            characteristics varchar(255),
            general_usage varchar(255),
            sort_order int not null
        );';
        $sql = preg_replace('/\s+/', ' ', $create_server_types);
        $this->db()->squery($sql);
        
        $create_server_configurations = 'CREATE TABLE IF NOT EXISTS server_configurations ( 
            server_configuration_id int not null primary key auto_increment,
            server_type_id int not null,
            model_code varchar(10),
            model_name varchar(255),
            ram int not null,
            disk_space int not null,
            processors int not null,
            has_write_cache_controller tinyint not null,
            sort_order int not null,
            is_certified tinyint not null,
            manufacturer varchar(255)
        );';
        $sql = preg_replace('/\s+/', ' ', $create_server_configurations);
        $this->db()->squery($sql);
    }
}