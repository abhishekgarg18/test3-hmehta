<?php
include ("application.inc");
require_once("pun/services/LatencyEventDefinitionService.php");
require_once("pun/model/LatencyEventDefinition.php");
require_once("pun/model/LatencyEventDefinitionSelector.php");

class LatencyEventDefinitionServiceTest  extends PHPUnit_Framework_TestCase
{
	private $service;
	
	public function __construct()
	{
		$this->service = new LatencyEventDefinitionService();
	}
	
	public function testCRUD()
	{
		$eventDef = new LatencyEventDefinition();
		$eventDef->setNoticeDefId(11);
		$eventDef->setUserid(111);
		$eventDef->setUsername("test1");
		$eventDef->setLatencyThreshold(2);
		
		$newDef = $this->service->saveLatencyEventDefinition($eventDef);
		$this->assertNotNull($newDef);
		$this->assertTrue($newDef->getEventDefId() > 0);
		
		$rDef = $this->service->getLatencyEventDefinition($newDef->getEventDefId());
		$this->assertNotNull($rDef);
		$this->assertType('LatencyEventDefinition',$rDef);
		$this->assertEquals($rDef->getNoticeDefId(),11);
		
		try 
		{
			$this->service->getLatencyEventDefinition(-1);
			$this->assertTrue(false);
		}
		catch(Exception $ex)
		{
			
		}
		
		$rDef->setLatencyThreshold(3);
		$rDef = $this->service->saveLatencyEventDefinition($rDef);
		$rrDef = $this->service->getLatencyEventDefinition($rDef->getEventDefId());
		$this->assertNotNull($rrDef);
		$this->assertType('LatencyEventDefinition',$rrDef);
		$this->assertEquals($rrDef->getNoticeDefId(),11);
		
		$this->service->deleteLatencyEventDefiniton($rrDef->getEventDefId());
		
		try 
		{
			$this->service->getLatencyEventDefinition($rrDef->getEventDefid());
			$this->assertTrue(false);
		}
		catch(Exception $ex)
		{
			
		}
		
		$eventDef = new LatencyEventDefinition();
		$eventDef->setNoticeDefId(11);
		$eventDef->setUserid(111);
		$eventDef->setUsername("test1");
		
		$newDef = $this->service->saveLatencyEventDefinition($eventDef);
		
		$this->service->deleteAllLatencyEventDefinitions($newDef->getNoticeDefId());
		
		try 
		{
			$this->service->getLatencyEventDefinition($rrDef->getEventDefid());
			$this->assertTrue(false);
		}
		catch(Exception $ex)
		{
			
		}
		
		
	}
	
	public function testSelector()
	{
		$eventDef = new LatencyEventDefinition();
		$eventDef->setNoticeDefId(11);
		$eventDef->setUserid(111);
		$eventDef->setUsername("test1");
		$eventDef->setLatencyThreshold(2);
		
		$newDef = $this->service->saveLatencyEventDefinition($eventDef);
		$this->assertNotNull($newDef);
		$this->assertTrue($newDef->getEventDefId() > 0);
		
		$selector = new LatencyEventDefinitionSelector();

		$defs = $this->service->getLatencyEventDefinitions($selector);
		$this->assertNotNull($defs);
		$this->assertType('array',$defs);
		$this->assertTrue((count($defs) == 1));
		$def1 = $defs[0];
		$this->assertEquals($def1->getEventDefId(),$newDef->getEventDefId());
		
		$selector->setDefid($newDef->getEventDefId());
		$defs = $this->service->getLatencyEventDefinitions($selector);
		$this->assertNotNull($defs);
		$this->assertType('array',$defs);
		$this->assertTrue((count($defs) == 1));
		$def1 = $defs[0];
		$this->assertEquals($def1->getEventDefId(),$newDef->getEventDefId());

		$selector = new LatencyEventDefinitionSelector();
		$selector->setDefid(98786543);
		$defs = $this->service->getLatencyEventDefinitions($selector);
		$this->assertNotNull($defs);
		$this->assertType('array',$defs);
		$this->assertTrue((count($defs) == 0));

		$selector = new LatencyEventDefinitionSelector();
		$selector->setUsername("test1");
		$defs = $this->service->getLatencyEventDefinitions($selector);
		$this->assertNotNull($defs);
		$this->assertType('array',$defs);
		$this->assertTrue((count($defs) == 1));
		
		$this->service->deleteLatencyEventDefiniton($newDef->getEventDefId());
		
		$selector->setDefid($newDef->getEventDefId());
		$defs = $this->service->getLatencyEventDefinitions($selector);
		$this->assertNotNull($defs);
		$this->assertType('array',$defs);
		$this->assertTrue((count($defs) == 0));
		
	}
	

}