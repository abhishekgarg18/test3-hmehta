<?php

/**
 * OM_L10n_Mock.class.php
 *
 * @author Joel Sahleen
 * @version $Id: //depot/l10n/branches/automation/classes/core/OM_L10n.class.php#1 $
 * @copyright Adobe Systems, Inc., 11 February, 2010
 * @package OM_L10n
 **/

/**
 * OM_L10n MOCK class
 *
 * This class is a mock for the OM_L10n class. To be used when localization is not enabled or files are missing.
 * @package OM_L10n
 * @author Joel Sahleen
 **/
class OM_L10n
{
	
	private function __construct(){}
	
	/**
	 * __clone
	 *
	 * @return void
	 * @author Joel Sahleen
	 **/
	private function __clone(){}
	
	
	/*************************************
	**** STRING TRANSLATION FUNCTIONS ****
	**************************************/
	
	/**
	 * getString function
	 *
	 * @param string $token -id used to look up localized version of string
	 * @param string $string -English string associated with token, used for scraping and as default
	 * @param string $locale -optional parameter to force a particular locale
	 * @return string original english string
	 * @author Joel Sahleen
	 */
	public static function getString($token, $string, $locale = NULL)
	{				
		return $string;
	}
	
	/**
	 * getStringEscape Chars
	 *
	 * @static
	 * @param string $token 
	 * @param string $string -English string associated with token, used for scraping and default
	 * @param mixed $characters - string or array with characters to be escaped
	 * @param string $locale - optional locale for the string to be returned in
	 * @return string original string with characters escaped
	 * @author Joel Sahleen
	 */
	public static function getStringEscapeChars($token, $string, $characters, $locale = NULL)
	{		
		$string = self::getString($token, $string, $locale);
		$characters = (array) $characters;
		$patterns = array();
		$replacements = array();

		foreach($characters as $character){	
			if($character == '\\'){ // escape backslash first so it doesn't mess up other escapes
				$string = preg_replace("/" . preg_quote($character) . "/", "\\\\\\\\", $string);
			}	else {
				$patterns[] = "/" . preg_quote($character) . "/"; // build array of patterns
				$replacements[] = "\\" . $character; // build array of replacements
			}
		}

		$output = preg_replace($patterns, $replacements, $string);
				
		return $output;
	}
	
	/**
	 * getStringHtmlSafe
	 *
	 * @static
	 * @param string $token -token for the localized string to be retrieved
	 * @param string $string -English string associated with token, used for scraping
	 * @param string $multibyte -Multibyte
	 * @param string $locale -locale for which the string should be retrieved (optional)
	 * @return string the original string
	 * @author Joel Sahleen
	 */
	public static function getStringHtmlSafe($token, $string, $multibyte = FALSE, $locale = NULL)
	{		
		$string = self::getString($token, $string, $locale);
		
		$encoding = 'ISO-8859-1';
		if ($GLOBALS['sess_ssGlobalsArray']['localization'] || $multibyte) {
			$encoding = 'UTF-8';
		}
		$output = htmlentities($string, ENT_QUOTES, $encoding);
				
		return $output;
	}
	
	/****************************
	**** DB STRING FUNCTIONS ****
	*****************************/
	
	public static function getDbString($string, $locale = NULL)
	{		
		return $string;
	}
	
	
	
	
	/************************************
	**** NUMBER FORMATTING FUNCTIONS ****
	************************************/
	
	public static function getNumberPattern($token, $pattern, $locale = NULL)
	{
		return $pattern;
	}
		
	public static function getNumberFormatter($style = OM_L10n_NumberFormatter::DEFAULT_STYLE, $pattern = NULL, $locale = NULL)
	{
		return null;
	}
	
	/**********************************
	**** DATE FORMATTING FUNCTIONS ****
	**********************************/

	public static function getDatePattern($token, $pattern, $locale = NULL)
	{
		return $pattern;
	}
	
	public static function getIntlDateFormatter($dateType = OM_L10n_IntlDateFormatter::FULL, 
																					$timeType = OM_L10n_IntlDateFormatter::FULL, 
																					$timezone = "America/Los_Angeles", 
																					$calendar = OM_L10n_IntlDateFormatter::GREGORIAN, 
																					$pattern = NULL,
																					$locale = NULL)
	{
		return null;
	}
	
	/****************************
	**** COLLATION FUNCTIONS ****
	****************************/

	public static function getCollator($locale = NULL)
	{
		return null;
	}
	

	/*************************************
	**** MESSAGE FORMATTING FUNCTIONS ****
	*************************************/
	
	public static function getMessageFormatter($pattern, $locale = NULL)
	{
		return null;
	}

	/*********************************
	**** URL FORMATTING FUNCTIONS ****
	*********************************/
	
	public static function getLocalizedUrl($url, $locale = NULL)
	{
		$patterns = array(
			'/\{LOCALE\}/',
			'/\{LANGUAGE\}/',
			'/\{REGION\}/'
			);

		$replacements = array(
			'en_US',
			'en',
			'US'
			);

		$locUrl = preg_replace($patterns, $replacements, $url);

		return $locUrl;
	}
	
	/***************************
	**** ENCODING FUNCTIONS ****
	***************************/

	public static function isValidUtf8($string) {

	    // From http://w3.org/International/questions/qa-forms-utf-8.html
	    return preg_match('%^(?:
	          [\x09\x0A\x0D\x20-\x7E]            # ASCII
	        | [\xC2-\xDF][\x80-\xBF]             # non-overlong 2-byte
	        |  \xE0[\xA0-\xBF][\x80-\xBF]        # excluding overlongs
	        | [\xE1-\xEC\xEE\xEF][\x80-\xBF]{2}  # straight 3-byte
	        |  \xED[\x80-\x9F][\x80-\xBF]        # excluding surrogates
	        |  \xF0[\x90-\xBF][\x80-\xBF]{2}     # planes 1-3
	        | [\xF1-\xF3][\x80-\xBF]{3}          # planes 4-15
	        |  \xF4[\x80-\x8F][\x80-\xBF]{2}     # plane 16
	    )*$%xs', $string);
	}
	
} // END class 