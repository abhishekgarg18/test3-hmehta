<?php
require_once "pun/model/LatencyEvent.php";
require_once "pun/model/LatencyEventSelector.php";
require_once "log4php/Logger.php";

class LatencyEventDao
{
	private $qc = '/*PowerUp Notices: LatencyEventDao*/';
	private $tableName = 'latency_event';
	private $defTableName = 'latency_event_definition';
	private $dbName = 'compassdb';
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	public function getLatencyEvent($eventId)
	{
		$this->log->debug("Retrieving LatencyEvent with id $eventId");
		$latencyEvent = null;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_type,event_time,sitecatalyst_version 
			    FROM $this->tableName    
			    WHERE event_id = $eventId";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('event_def_id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserid($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setEventType($db->f('event_type'));
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
		}
		$db->close();

		return $latencyEvent;
		
	}
	
	public function getLatencyEventsByUserId($userid)
	{
		$this->log->debug("Retrieving LatencyEvents for userid $userid");
		$latencyEvents = array();
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_type,event_time,sitecatalyst_version 
			    FROM $this->tableName  
			    WHERE userid = $userid";

		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('le.event_def-id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserid($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setEventType($db->f('event_type'));
			$latencyEvents[] = $latencyEvent;
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
		}
		$db->close();

		return $latencyEvents;
	}
	
	public function getLatencyEventsByNoticeId($noticeId)
	{
		$this->log->debug("Retrieving LatencyEvents for NoticeDefid $noticeId");
		$latencyEvents = array();
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_type,event_time,sitecatalyst_version 
			    FROM $this->tableName  
			    WHERE notice_id = $noticeId";

		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('event_def_id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserid($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setEventType($db->f('event_type'));
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
			$latencyEvents[] = $latencyEvent;
		}
		$db->close();

		return $latencyEvents;
	}
	
	public function saveLatencyEvent(LatencyEvent $latencyEvent)
	{
		$this->log->debug("Saving LatencyEvent for user ".$latencyEvent->getUsername());
		$db =  new DB_Sql($this->dbName);
		$sql = "INSERT INTO $this->qc $this->tableName (event_def_id,notice_id,userid,latency,event_type,sitecatalyst_version)
				VALUES (".$latencyEvent->getDefId().",".$latencyEvent->getNoticeId().",".$latencyEvent->getUserId().",".$latencyEvent->getLatency().",".$latencyEvent->getEventType().",".$latencyEvent->getSiteCatalystVersion().")
				ON DUPLICATE KEY UPDATE event_id=LAST_INSERT_ID(event_id)";

		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		
		if($db->squery("SELECT LAST_INSERT_ID()"))
		{
			$latencyEvent->setId($db->f('LAST_INSERT_ID()'));
		}
		
		$db->close();
		
		return $latencyEvent;
	}
	
	/**
	 * Deletes the latency event with the given id
	 * @param int $id
	 */
	public function deleteLatencyEvent($id)
	{
		$this->log->debug("Deleting LatencyEvent with id of $id");
		$db =  new DB_Sql($this->dbName);
		$sql = "DELETE from $this->tableName where event_id = $id";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}
	
	/**
	 * Delete ALL latency events associated with the given notice id
	 * 
	 * @param int $noticeId
	 */
	public function deleteLatencyEvents($noticeId)
	{
		$this->log->debug("Deleting LatencyEvents associated with the notice id $noticeId");
		$db =  new DB_Sql($this->dbName);
		$sql = "DELETE from $this->tableName where notice_id = $noticeId";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		$db->close();
	}

		
	public function getLatencyEvents(LatencyEventSelector $selector)
	{
		$this->log->debug("Retrieving LatencyEvents using selector");
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_time,event_type,sitecatalyst_version
			    FROM $this->tableName";  
						
		$fieldValues = $this->getPopulatedFieldsFromSelector($selector);
		if(sizeof($fieldValues) > 0)
		{
			$sql .= "\n\t\t\tWHERE ".implode(" AND ",$fieldValues);
		}
		
		$sql .= " ORDER BY event_time DESC";
		
		
		if ($selector->getResultCountLimit()) 
		{
			$count = $selector->getResultCountLimit();
			$start = $selector->getResultStartindex();
			$sql .= "\n\t\t\tLIMIT $start, $count";
		}
		
		$latencyEvents = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('le.event_def_id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserId($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
			
			$latencyEvents[] = $latencyEvent;
		}
		$db->close();
		
		return $latencyEvents;
		
	}

	/**
	 * Retrieves the most recent latency event for the given user and given event type
	 * Only latency events will be returned. Prelatent event will not be returned, even if asked for. See getMostRecentEvent() to get any event
	 * 
	 * @param int $userid
	 * @param int $eventType
	 */
	public function getMostRecentLatencyEvent($userid,$eventType = NULL)
	{
		$this->log->debug("Retrieving most recent LatencyEvent for user id $userid");
		$latencyEvent = NULL;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_type,event_time,sitecatalyst_version 
			    FROM $this->tableName   
			    WHERE userid = $userid AND event_type != 4 ";
		if(isset($eventType))
		{
			$sql .= " AND event_type = $eventType";
		}
		$sql .= " ORDER BY event_time DESC LIMIT 1";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('event_def_id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserid($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setEventType($db->f('event_type'));
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
		}
		$db->close();

		return $latencyEvent;
	}

	/**
	 * Retreives the most recent latency event, including prelatent events, for the given userid
	 * @param int $userid
	 */
	public function getMostrecentEvent($userid)
	{
		$this->log->debug("Retrieving most recent Event for user id $userid");
		$latencyEvent = NULL;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc event_id,event_def_id,notice_id,userid,latency,event_type,event_time,sitecatalyst_version 
			    FROM $this->tableName   
			    WHERE userid = $userid 
			    ORDER BY event_time DESC LIMIT 1";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyEvent = new LatencyEvent();
			$latencyEvent->setId($db->f('event_id'));
			$latencyEvent->setDefId($db->f('event_def_id'));
			$latencyEvent->setNoticeId($db->f('notice_id'));
			$latencyEvent->setUserid($db->f('userid'));
			$latencyEvent->setLatency($db->f('latency'));
			$latencyEvent->setEventTime($db->f('event_time'));
			$latencyEvent->setEventType($db->f('event_type'));
			$latencyEvent->setSiteCatalystVersion($db->f('sitecatalyst_version'));
		}
		$db->close();

		return $latencyEvent;
	}
	
	/*
	 * Builds an array of database field names and associated values. eg, (userid => 'sistr2')
	 * This is used in building where clauses dynamically.
	 * 
	 * @param LatencyEventSelector  $selector  
	 */
	private function getPopulatedFieldsFromSelector(LatencyEventSelector $selector)
	{
		$values = array();
		if($selector == NULL)
		{
			return $values;
		}
		
		if($selector->getLatencyNoticeDefinitionId() != null && $selector->getLatencyNoticeDefinitionId() > 0)
		{
			$values[] = "def_id = ".$selector->getLatencyNoticeDefinitionId(); 
		}

		// The sevice should have switched the username with the userid. This will make queries much more efficient.
//		if($selector->getUsername() != null && strlen($selector->getUsername()) > 0)
//		{
//			$values[] = "username = '".addslashes($selector->getUsername())."'"; 
//		}
			
		if($selector->getUserid() != null && $selector->getUserid() > 0)
		{
			$values[] = "userid = ".$selector->getUserid(); 
		}
		
		if($selector->getEventType() != null && $selector->getEventType() > 0)
		{
			$values[] = "event_type = ".$selector->getEventType(); 
			
		}
		
		if($selector->getStartDate() != NULL && $selector->getEndDate() != NULL)
		{
			$values[] = "event_time >= '".date('Y-m-d 00:00:00', strtotime(str_replace('-', '/', $selector->getStartDate())))."'";
			$values[] = "event_time <= '".date('Y-m-d 23:59:59', strtotime(str_replace('-', '/', $selector->getEndDate())))."'";
		}
		
		$this->log->debug("Selector field values: ".implode($values));
					
		return $values;
	}
	
}