<?

$SERVER_NAME = 'omniture';
$PHP_SELF = '/sc15';
require 'application.inc';

include_once('user_services_config.inc');

$user = 'bugzilla.www14';
echo "testing $user...\n";
$usc = new UserServicesConfig($user);

$vis_status = $usc->getVisitorStitchingStatus();
echo "vis_stitching_status $vis_status\n";

$return_status = $usc->enableVisitorStitching();
$vis_status = $usc->getVisitorStitchingStatus();
echo "vis_stitching_status $return_status $vis_status\n";

$return_status = $usc->disableVisitorStitching();
$vis_status = $usc->getVisitorStitchingStatus();
echo "vis_stitching_status $return_status $vis_status\n";

?>
