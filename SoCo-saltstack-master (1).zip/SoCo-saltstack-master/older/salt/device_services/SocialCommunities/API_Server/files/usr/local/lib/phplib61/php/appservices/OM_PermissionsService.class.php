<?php
/* ***************************************************************************
 *                                                                           *
 * ADOBE CONFIDENTIAL                                                        *
 * ___________________                                                       *
 *                                                                           *
 * Copyright 2014 Adobe Systems Incorporated                                 *
 * All Rights Reserved.                                                      *
 *                                                                           *
 * NOTICE:  All information contained herein is, and remains the property of *
 * Adobe Systems Incorporated and its suppliers, if any.  The intellectual   *
 * and technical concepts contained herein are proprietary to Adobe Systems  *
 * Incorporated and its suppliers and are protected by trade secret or       *
 * copyright law. Dissemination of this information or reproduction of this  *
 * material is strictly forbidden unless prior written permission is         *
 * obtained from Adobe Systems Incorporated.                                 *
 *                                                                           *
 *****************************************************************************/

require_once("appservices/OM_AnalyticsServicesAccessTokenGenerator.class.php");
require_once("appservices/OM_AppServiceBase.class.php");

class OM_PermissionsService extends OM_AppServiceBase {

	private static $_instance = null;

	private static $_permissionableMetrics = null;
	private static $_permissionableDimensions = null;

	public static function getInstance(){
		if(self::$_instance == null){
			self::$_instance = new OM_PermissionsService();
		}
		return self::$_instance;
	}

	public function getPermissionsForUser($user){
        $path = "/permissions/users/" . $user->getLoginId() . "?unionAll=true";
        $token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
        $token = $token_generator->getTokenForUser($user);
        if (!$token) {
                $token = $token_generator->getIMSServiceToken();
                $response = $this->makeAnalyticsEndpointRequest($path, $token, self::GET_REQUEST,"", true, "","", $user->getCompanyId(),$user->getLoginId());
        } else {
                $response = $this->makeAnalyticsEndpointRequest($path, $token);
        }
        if ($response->hasErrors()) {
			throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
        }
        return json_decode($response->getResponse(), true);
	}

	public function getPermissions($companyid, $loginid) {
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$path = "/permissions/users/" . $loginid . "?unionAll=true";
		$response = $this->makeAnalyticsEndpointRequest($path, $token, self::GET_REQUEST,"", true, "","", $companyid,$loginid);
		if ($response->hasErrors()) {
			throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}

	public function getPermissionsForUserWithRsids($user, $rsids){
        $path = "/permissions/users/" . $user->getLoginId() . "/search";
        $body = urlencode(is_array($rsids) ? implode(",", $rsids) : $rsids);
        $token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
        $token = $token_generator->getTokenForUser($user);
        if (!$token) {
                $token = $token_generator->getIMSServiceToken();
                $response = $this->makeAnalyticsEndpointRequest($path, $token, self::POST_REQUEST, $body, true, "","", $user->getCompanyId(),$user->getLoginId());
        } else {
                $response = $this->makeAnalyticsEndpointRequest($path, $token, self::POST_REQUEST, $body);
        }
        if ($response->hasErrors()) {
			throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
        }
        return json_decode($response->getResponse(), true);
	}

	public function getPermissionsWithRsids($companyid, $loginid, $rsids) {
		$token_generator = new OM_AnalyticsServicesAccessTokenGenerator();
		$token = $token_generator->getIMSServiceToken();
		$path = "/permissions/users/" . $loginid . "/search";
		$body = urlencode(is_array($rsids) ? implode(",", $rsids) : $rsids);
		$response = $this->makeAnalyticsEndpointRequest($path, $token, self::POST_REQUEST, $body, true, "","", $companyid,$loginid);
		if ($response->hasErrors()) {
			throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
		}
		return json_decode($response->getResponse(), true);
	}

	public function getPermissionableMetrics() {
		if( self::$_permissionableMetrics == null ) {
			$token = OM_AnalyticsServicesAccessTokenGenerator::getIMSServiceToken();
			$query_string = "?locale=" . $GLOBALS['locale'];
			$path = "/identity/permission/metrics" .$query_string;
			$response = $this->makePlatformEndpointRequest($path,$token,self::GET_REQUEST);

			if($response->hasErrors()){
				throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
			}

			self::$_permissionableMetrics = json_decode($response->getResponse());
		}

		return self::$_permissionableMetrics;
	}

	public function getPermissionableDimensions() {
		if( self::$_permissionableDimensions == null ) {
			$token = OM_AnalyticsServicesAccessTokenGenerator::getIMSServiceToken();
			$query_string = "?locale=" . $GLOBALS['locale'];
			$path = "/identity/permission/dimensions" .$query_string;
			$response = $this->makePlatformEndpointRequest($path,$token,self::GET_REQUEST);

			if($response->hasErrors()){
				throw new Exception("Permissions service error: " . $response->getErrorMessage()." errorId=".$response->getErrorId());
			}

			self::$_permissionableDimensions = json_decode($response->getResponse());
		}

		return self::$_permissionableDimensions;
	}
}
