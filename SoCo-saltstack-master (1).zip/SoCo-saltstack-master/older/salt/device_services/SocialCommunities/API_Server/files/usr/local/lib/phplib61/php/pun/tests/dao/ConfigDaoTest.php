<?php
require_once("application.inc");
require_once("pun/dao/ConfigDao.php");

class ConfigDaoTest extends PHPUnit_Framework_TestCase
{
	private	$dao;

	public function __construct()
	{
		$this->dao = new ConfigDao();	
	}
	
	public function testGetLatencyEmailTemplate()
	{
		$template = $this->dao->getLatencyEmailTemplate(1,1);
		$this->assertType('string',$template);
		$template = $this->dao->getLatencyEmailTemplate(2,1);	
		$this->assertType('string',$template);
		$template = $this->dao->getLatencyEmailTemplate(11,1);	
		$this->assertType('string',$template);
		$template = $this->dao->getLatencyEmailTemplate(22,1);	
		$this->assertType('string',$template);
	}
	
	public function testGetCurrentEmailTemplateVersion()
	{
		$template = $this->dao->getCurrentTemplateVersion(1);		
		$this->assertType('string',$template);
		$template = $this->dao->getCurrentTemplateVersion(11);		
		$this->assertType('string',$template);
		$template = $this->dao->getCurrentTemplateVersion(12);		
		$this->assertType('string',$template);
		$template = $this->dao->getCurrentTemplateVersion(13);		
		$this->assertType('string',$template);
		$template = $this->dao->getCurrentTemplateVersion(2);		
		$this->assertType('string',$template);
		$template = $this->dao->getCurrentTemplateVersion(22);		
		$this->assertType('string',$template);
	}
	
	public function testGetEmailFrequencyOptionList()
	{
		$options = $this->dao->getEmailFrequencyOptionList();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 7), 'returning wrong number of email frequency options');
		$this->assertContains('2', $options);
		$this->assertContains('3', $options);
		$this->assertContains('4', $options);
		$this->assertContains('5', $options);
		$this->assertContains('6', $options);
		$this->assertContains('7', $options);
		$this->assertContains('8', $options);
	}
	
	public function testGetLatencyThresholdOptionList()
	{
		$options = $this->dao->getLatencyThresholdOptionList();
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 3), 'returning wrong number of options');
		$this->assertContains('4', $options);
		$this->assertContains('6', $options);
		$this->assertContains('8', $options);
		
	}
	
	public function testGetNotificationStateOptionList()
	{
		$options = $this->dao->getNotificationStateOptionList();		
		$this->assertType('array', $options);
		$this->assertTrue((count($options) == 2), 'returning wrong number of state options');
		$this->assertContains('Active', $options);
		$this->assertContains('Hold', $options);
	}
}
