-run all tests with "phpunit --configuration allTests.xml"
-run single test file with "phpunit WebClientTest.php"

-can disable single tests by prefacing their function with "_"
