<?php
/*************************************************************************
* ADOBE CONFIDENTIAL
* ___________________
*
*  Copyright 2013 Adobe Systems Incorporated
*  All Rights Reserved.
*
* NOTICE:  All information contained herein is, and remains
* the property of Adobe Systems Incorporated and its suppliers,
* if any.  The intellectual and technical concepts contained
* herein are proprietary to Adobe Systems Incorporated and its
* suppliers and are protected by all applicable intellectual property 
* laws, including trade secret and copyright laws.
* Dissemination of this information or reproduction of this material
* is strictly forbidden unless prior written permission is obtained
* from Adobe Systems Incorporated.
**************************************************************************/

// By Mary Shaw maryshaw@adobe.com

require_once 'application.inc';
require_once 'class-ha-utilities.php';
require_once 'pun/webclient/LatencyNoticeWebClient.php';
require_once 'elevator_dist.inc';

//require_once 'class-compass-list.php';
//require_once 'class-compass-list-item.php';
//require_once 'class-compass-lists-history.php';

class Compass_Lists extends HA_Utilities
{
    const DB_NAME          = 'compassdb';
    const TABLE_NAME       = 'compass_list';
    const ITEM_TABLE_NAME  = 'compass_list_item';
    const AUDIT_DB_NAME    = 'compassdb';
    const AUDIT_TABLE_NAME = 'compass_list_log';
    
    private $lists = array();
    private $compass_db;
    
    function __construct($args = array()) {
        $this->compass_db = new DB_SQL(self::DB_NAME);
   		//$this->load_args($args);
        
	    parent::__construct($args);
    }

/* commenting out functions not needed in the first revision. I'll add it later after unit tests have been built.

    function load_args($args) {
    }
    
    function compass_db() {
        return $this->compass_db;
    }
    
    // e.g. from account dashboard, find lists that have RSID in it.
    // todo: pagination
    function search_lists($args = array()) {
        $db = $this->compass_db();

        // return array of lists
        $sql = '
            SELECT /* ' . __FILE__ . ': ' . __FUNCTION__ . '() line ' . __LINE__ . ' * /
                name,
                description,
                type,
                owner,
                monitor_start_date,
                monitor_end_date,
                is_frozen,
                is_active,
                create_timestamp,
                help_url
            FROM
                ' . Compass_Lists::TABLE_NAME . ';';
        $sql = preg_replace('/\s+/', ' ', $sql);
        $db->query($sql);
        
        $db->halt_on_error = false;
        $sql = preg_replace('/\s+/', ' ', $sql);
        //$this->debug('SQL: ' . $sql . "\n");
        $db->query($sql);

        if ($db->Errno != 0) {
            $this->error('Error listing compass lists: ' . $db->Errno . '; DB_Error=' . $db->Error . '; SQL= ' . $sql . "\n");
        }

        $lists = array();
        while ($db->next_record()) {
            $list = new Compass_List();
            $list->init_from_table_row($db);
            
            $lists[ $list->id() ] = $list;
        }
        return $lists;
    }
    
    // report_suite_search() function??  which list(s) is this report suite a part of?
    
    function all_lists($args = array()) {
        return $this->search_lists($args);
    }
    
    function create_list($args = array()) {
    }
    
    function copy_list($args = array()) {
    }
    
    function log_change($args = array()) {
        
        // todo: parameter validation
        
        $logger = new Compass_Lists_History();
        $logger->log_change($args);
    }
    
    // todo: add keys to the tables
    function create_tables_if_needed() {
        $db = $this->compass_db();
        
        $table = self::TABLE_NAME;
        $sql = '
            CREATE TABLE IF NOT EXISTS ' . $table . ' /* ' . __FILE__ . ': ' . __FUNCTION__ . '() line ' . __LINE__ . ' * /(
                ' . $table . '_id int not null primary key auto_increment,
                name varchar(60),
                description varchar(255),
                type int not null,
                owner varchar(60),
                create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                monitor_start_date DATETIME,
                monitor_end_date DATETIME,
                help_url varchar(255),
                is_frozen tinyint not null default 0,
                is_active tinyint not null default 0
            )';
        $sql = preg_replace('/\s+/', ' ', $sql);
        //echo 'SQL: ' . $sql . "\n";
        $db->squery($sql);

        $table = self::ITEM_TABLE_NAME;
        $sql = '
            CREATE TABLE IF NOT EXISTS ' . $table . ' /* ' . __FILE__ . ': ' . __FUNCTION__ . '() line ' . __LINE__ . ' * /(
                ' . $table . '_id int not null primary key auto_increment,
                username varchar(40),
                userid int not null,
                sort_order int not null,
                description varchar(255), 
                ' . self::TABLE_NAME . '_id int not null,
                data_center varchar(4),
                create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_active tinyint not null default 0
            )';
        $sql = preg_replace('/\s+/', ' ', $sql);
        //echo 'SQL: ' . $sql . "\n";
        $db->squery($sql);

        $table = self::AUDIT_TABLE_NAME;
        $sql = '
            CREATE TABLE IF NOT EXISTS ' . $table . ' /* ' . __FILE__ . ': ' . __FUNCTION__ . '() line ' . __LINE__ . ' * /(
                ' . $table . '_id int not null primary key auto_increment,
                description varchar(255),
                type int not null,
                changer varchar(60),
                create_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )';
        $sql = preg_replace('/\s+/', ' ', $sql);
        //echo 'SQL: ' . $sql . "\n";
        $db->squery($sql);
    }
 */   
    function is_priority_report_suite($rsid) {
        try {
            $web_client = new LatencyNoticeWebClient();
            return $web_client->noticeEligible($rsid);
        }
        catch(InvalidParameterException $e) {
            return false;
        }
    }
    
    function has_priority_report_suite($base) {
        if (strlen($base) <= 0) {
            return false;
        }
        
        // first, split up base names to handle combined bases
        $bases = array();
		if (strstr($base, ',') !== false) {
			$bases = split( ',', $base );
		} 
        else {
            $bases[] = $base;
        }
        
        // go through those base names to find users; base children can be bases and/or users
        $ed = new elevator_distribution();
        foreach ($bases as $base){
			$userid = userid_lookup($base);

            // it's an account
			if ($userid > 0) { 
                $rsid = $base;
			    $is_priority = $this->is_priority_report_suite($rsid);
                if ($is_priority) {
                    return true;
                }
			} 
            
            // it's a base
            else { 
				$users = $ed->get_users_for_base($base);
                
                foreach( $users as $user) {
                    $is_priority = $this->has_priority_report_suite($user);
                    if ($is_priority) {
                        return true;
                    }
                }
			}
        }
        return false;
    }
}