<?
/**
 * @file 
 * DwTemplate.class.php
 *
 * Copyright 2007 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Brian Sanderson <bsanderson@omniture.com>
 *
 * @version CVS: $Id$
 **/

require_once 'application.inc';
require_once 'DwIncludes.inc';

/**
 * DwTemplate
 *
 * Provides an interface to create and modify a scheduled data warehouse export.
 *
 **/
class DwTemplate {

	var $id = NULL;
	var $user_priority = NULL;
	var $log_time = 0; /* timestamp */
	var $report_name = '';
	var $account = '';
	var $account_id = NULL;
	var $company = '';
	var $login = '';
	var $contact_name = '';
	var $contact_info = '';
	var $engineer = '';
	var $status = 0;
	var $date_completed = 0;  /* timestamp */
	var $hours_spent = 0;
	var $data_constraints = NULL;
	var $status_text = '';
	var $est_hours = NULL;
	var $est_space = NULL;
	var $date_scheduled = NULL;  /* timestamp */
	var $file_type = '';
	var $max_rows = NULL;
	var $header_type = ''; 
	var $partitioning = '';
	var $data_set = '';
	var $run_vista = true;
	var $schedule_id = NULL;
	var $segment_guid = NULL;
	var $beta = 0;
	var $metrics_sort = 0;
	var $send_empty_reports = "default";

	var $_db = NULL;
	var $_lastError = '';
	var $requested_by = DW_REQUESTED_BY_UNKNOWN;

	function DwTemplate($id = NULL) {
		$this->_db = new DB_Sql('superstatsdb');
		if ($id != NULL) {
			$this->readTemplate($id);
		}
	}

	function readTemplate($id) {
		$sql =	'SELECT * ' .
			'  FROM dw_templates D ' .
			' WHERE id=' . ($id + 0) .
			' LIMIT 1';
		if($this->_db->squery($sql)) {
			$this->id = $this->_db->f('id') + 0;
			$this->user_priority = $this->_db->f('user_priority');
			$this->log_time = strtotime($this->_db->f('log_time'));
			$this->report_name = $this->_db->f('report_name');
			$this->account = $this->_db->f('account');
			$this->account_id = $this->_db->f('account_id');
			$this->company = $this->_db->f('company');
			$this->login = $this->_db->f('login');
			$this->contact_name = $this->_db->f('contact_name');
			$this->contact_info = ($this->_db->f('contact_info') != '') ? (unserialize($this->_db->f('contact_info'))) : '';
			$this->engineer = $this->_db->f('engineer');
			$this->status = $this->_db->f('status') + 0;
			$this->date_completed = $this->_db->f('date_completed');
			$this->hours_spent = $this->_db->f('hours_spent');
			if ($this->_db->f('data_constraints') === NULL) {
				$this->data_constraints = NULL;
			} else if ($this->_db->f('data_constraints') == '') {
				$this->data_constraints = '';
			} else {
				$this->data_constraints = unserialize($this->_db->f('data_constraints'));
			}
			$this->status_text = $this->_db->f('status_text');
			$this->est_hours = $this->_db->f('est_hours');
			$this->est_space = $this->_db->f('est_space');
			$this->date_scheduled = ($this->_db->f('date_scheduled') !== NULL) ? (strtotime($this->_db->f('date_scheduled'))) : NULL;
			$this->file_type = $this->_db->f('file_type') + 0;
			$this->max_rows = $this->_db->f('max_rows');
			$this->header_type = $this->_db->f('header_type');
			$this->partitioning = $this->_db->f('partitioning');
			$this->data_set = $this->_db->f('data_set');
			$this->run_vista = ($this->_db->f('run_vista') !== NULL) ? ($this->_db->f('run_vista') == 'yes') : NULL;
			$this->schedule_id = $this->_db->f('schedule_id');
			$this->metrics_sort = $this->_db->f('metrics_sort');
			$this->send_empty_reports = $this->_db->f('send_empty_reports');
			$this->_db->free();
			return true;
		}
		else
		{
			$this->id = 0;
		}
		return false;
	}

	function checkSettings() {
		if (! $this->account) {
			$this->_lastError = "The account (RSID) was not specified.";
			return false;
		} else if ($this->account_id === NULL || $this->account_id == 0) {
			$db = new masterdb;
			setuserdb($db, $this->account);
			if ($db->squery("SELECT userid FROM user WHERE username='{$this->account}' LIMIT 1")) {
				$this->account_id = $db->f(0);
			} else {
				$this->_lastError = "Could not locate the report suite {$this->account}.";
				return false;
			}
		}
		if (! $this->company) {
			$this->_lastError = "The company was not specified.";
			return false;
		}
		if (! $this->login) {
			$this->_lastError = "The login was not specified.";
			return false;
		}
		if (! $this->report_name) {
			$this->_lastError = 'Please provide a report name.';
			return false;
		}
		if (! $this->contact_name) {
			$this->_lastError = 'Please provide a contact name.';
			return false;
		}
		if ($this->id == NULL) {
			$this->status = 0;
			$this->date_scheduled = time();
		}
		if (! $this->user_priority) {
			$this->setNextUserPriority();
		}
		// Validate contact info
		if (! $this->contact_info) {
			$this->contact_info = array();
		}
		if (! array_key_exists('email_to', $this->contact_info)) {
			$this->_lastError = 'Please provide an email_to field in contact_info (even if this report is not to be emailed).';
			return false;
		}
		// Validate header type
		if (! $this->header_type) {
			$this->header_type = DW_HEADER_TYPE_HEADER;
		}
		if (!in_array($this->header_type, $GLOBALS['DW_HEADER_TYPES'])) {
			$this->_lastError = 'Unknown header type - ' .  $this->header_type . '.';
			return false;
		}
		if (! $this->partitioning) {
			$this->partitioning = DW_PARTITIONING_INDIVIDUAL;
		}
		if (!in_array($this->partitioning, $GLOBALS['DW_PARTITIONING'])) {
			$this->_lastError = 'Unknown partition - ' .  $this->partitioning . '.';
			return false;
		}
		if (! $this->data_set) {
			$this->data_set = DW_DATA_SET_DESIRED;
		}
		if (!in_array($this->data_set, $GLOBALS['DW_DATA_SET'])) {
			$this->_lastError = 'Unknown data set - ' .  $this->data_set . '.';
			return false;
		}
		if (!is_numeric($this->file_type)) {
			$this->file_type = DW_FILE_TYPE_CSV;
		}
		if (! is_bool($this->run_vista)) {
			$this->run_vista = true;
		}
		// Data constraint defaults
		if (! is_array($this->data_constraints)) {
			$this->data_constraints = array();
		}
		if (! array_key_exists('item_list', $this->data_constraints)) {
			$this->setDataConstraint('item_list', NULL);
		}
		if (! array_key_exists('metric_list', $this->data_constraints)) {
			$this->setDataConstraint('metric_list', NULL);
		}
		// Validate at least 1 breakdown or metric
		if ((!is_array($this->data_constraints['item_list']) || count($this->data_constraints['item_list']) <= 0) &&
		 	(!is_array($this->data_constraints['metric_list']) || count($this->data_constraints['metric_list']) <= 0)) {
				$this->_lastError = 'Must specify one breakdown (item_list) or one metric (metric_list).';
				return false;
		}
		// Validate date_type
		if (! array_key_exists('date_type', $this->data_constraints)) {
			$this->_lastError = 'Must specify a date_type.';
			return false;
		}
		if (! in_array($this->data_constraints['date_type'], $GLOBALS['DW_DATE_TYPES'])) {
			$this->_lastError = 'Unknown date type - ' . $this->data_constraints['date_type'];
			return false;
		}
		// Validate date_preset
		if (! array_key_exists('date_preset', $this->data_constraints)) {
			$this->_lastError = 'Must specify a date preset.';
			return false;
		}
		if (! in_array($this->data_constraints['date_preset'], $GLOBALS['DW_DATE_PRESETS'])) {
			$this->_lastError = 'Unknown date preset - ' . $this->data_constraints['date_preset'];
			return false;
		}
		if (! array_key_exists('segment_id', $this->data_constraints)) {
			$this->setDataConstraint('segment_id', "0");
		}
		if (! array_key_exists('date_from', $this->data_constraints)) {
			$this->setDataConstraint('date_from', date('m/d/y'));
		}
		if (! array_key_exists('date_to', $this->data_constraints)) {
			$this->setDataConstraint('date_to',  date('m/d/y'));
		}
		if (! array_key_exists('date_granularity', $this->data_constraints)) {
			$this->_lastError = 'Please specify a date granularity.';
			return false;
		}
		if (! in_array($this->data_constraints['date_granularity'], $GLOBALS['DW_GRANULARITIES'])) {
			$this->_lastError = 'Unknown granularity - ' . $this->data_constraints['date_granularity'];
			return false;
		}
		return true;
	}

	function prepareNonNullString($str) {
		return '\'' . addslashes($str) . '\'';
	}

	function prepareNullString($str) {
		return ($str === NULL) ? 'NULL' : $this->prepareNonNullString($str);
	}

	function prepareNonNullNumber($num) {
		return $num + 0;
	}
	
	function prepareNullNumber($num) {
		return ($num === NULL) ? 'NULL' : $this->prepareNonNullNumber($num);	
	}

	function prepareContactInfo() {
		// the contact info array is order-sensitive
		$newContactInfo = array();
		$orderList = array('email_to','phone','report_desc');
		foreach ($orderList as $item) {
			if (is_array($this->contact_info) && array_key_exists($item, $this->contact_info)) {
				$newContactInfo[$item] = $this->contact_info[$item];
			} else {
				$newContactInfo[$item] = NULL;
			}
		}
		return serialize($newContactInfo);
	}

	function prepareDataConstraints() {
		// the data constraint array is order-sensitive.
		$newConstraints = array();
		$orderList = array('date_type','date_preset','date_from','date_to','date_granularity','segment_id','item_list','metric_list');
		foreach ($orderList as $item) {
			if (is_array($this->data_constraints) && array_key_exists($item, $this->data_constraints)) {
				$newConstraints[$item] = $this->data_constraints[$item];
			} else {
				$newConstraints[$item] = NULL;
			}
		}
		return serialize($newConstraints);
	}

	function getLastError() {
		return $this->_lastError;
	}

	function commit() {
		if (!$this->checkSettings()) {
			return NULL;	
		}
		$contactInfo = $this->prepareContactInfo();
		$constraints = $this->prepareDataConstraints();
		
		$bodySql = "	user_priority    = " . $this->prepareNullString($this->user_priority) . ",
				log_time         = NOW(),
				report_name      = " . $this->prepareNonNullString($this->report_name) . ",
				account          = " . $this->prepareNonNullString($this->account) . ",
				account_id       = " . $this->prepareNullNumber($this->account_id) . ",		
				company          = " . $this->prepareNonNullString($this->company) . ",
				login            = " . $this->prepareNonNullString($this->login) . ",
				contact_name     = " . $this->prepareNonNullString($this->contact_name) . ",
				contact_info     = " . $this->prepareNonNullString($contactInfo) . ", 
				engineer         = " . $this->prepareNonNullString($this->engineer) . ",
				status           = " . $this->prepareNonNullNumber($this->status) . ",
				date_completed   = '" . (($this->date_completed == 0) ? '0000-00-00 00:00:00' : date('Y-m-d H:i:s', $this->date_completed)) . "',
				hours_spent      = " . $this->prepareNullNumber($this->hours_spent) . ",
				data_constraints = " . $this->prepareNonNullString($constraints) . ",
				status_text      = " . $this->prepareNonNullString($this->status_text) . ",
				est_hours        = " . $this->prepareNullNumber($this->est_hours) . ",
				est_space        = " . $this->prepareNullNumber($this->est_space) . ",
				date_scheduled   = " . (($this->date_scheduled !== NULL) ? date("'Y-m-d H:i:s'", $this->date_scheduled) : 'NULL') . ",
				file_type        = " . $this->prepareNonNullNumber($this->file_type) . ",
				max_rows         = " . $this->prepareNullNumber($this->max_rows) . ",
				metrics_sort     = " . $this->prepareNonNullNumber($this->metrics_sort) . ",
				header_type      = " . $this->prepareNonNullString($this->header_type) . ",
				partitioning     = " . $this->prepareNonNullString($this->partitioning) . ",
				data_set         = " . $this->prepareNonNullString($this->data_set) . ",
				run_vista        = '" . ($this->run_vista ? 'yes' : 'no') . "',
				schedule_id      = " . $this->prepareNullNumber($this->schedule_id) . ",
				segment_id       = " . $this->prepareNonNullNumber($this->getSegmentId()) . ",
				segment_guid     = " . $this->prepareNonNullString($this->segment_guid) . ",
				beta             = " . $this->prepareNonNullNumber($this->beta) . ",
				send_empty_reports = " . $this->prepareNonNullString($this->send_empty_reports) . ",
				requested_by     = " . "'" . $this->requested_by . "'";
		
		if($is_api_request)
		{
			$bodySql .= "requested_by = $requested_by";
		}

		if ($this->id == NULL) {
			$sql = "INSERT INTO dw_templates SET\n" . $bodySql;
			$this->_db->query($sql);
			if ($this->_db->affected_rows() > 0) {
				$id = $this->_db->last_insert();
				if($id) {
					$this->id = $id;
				} else {
					$this->_lastError = 'Could not retrieve last insert id.';
				}
			} else {
				$this->_lastError = 'No rows affected from query -- ' . $sql;
			}
		} else {
			$sql = "UPDATE dw_templates SET\n" . $bodySql .
				' WHERE id=' . ($this->id + 0) . ' LIMIT 1';
			if (!$this->_db->query($sql)) {
				$this->_lastError = 'Invalid query -- ' . $sql;
				return NULL;
			}
			if ($this->_db->affected_rows() < 1) {
				$this->_lastError = 'No rows affected from query -- ' . $sql;	
				return NULL;
			}
		}
		return $this->id;
	}

	function cancel($cancel_text = 'Cancelled')
	{		
		if($this->id > 0)
		{
			$sql = "update dw_templates
					set status = 4,
						status_text = '$cancel_text',
						log_time = now()
					where id = " . $this->id;
			$this->_db->query($sql);
			
			if($this->_db->affected_rows() > 0)
			{
				return true;
			}
			else
			{
				$this->_lastError = "There were no templates to cancel.";
				return false;
			}
		}
	}

	// Getters / setters
	function getId() { return $this->id; }
	function getUserPriority() { return $this->user_priority; }	function setUserPriority($newPriority) { $this->user_priority = $newPriority; }
									function setNextUserPriority()
									{
										$sql = "SELECT IFNULL(MAX(user_priority),0)+1 max_num FROM dw_templates 
											WHERE company='" . addslashes( $this->getCompany() ) . "'";
										$this->_db->squery($sql);
										$this->setUserPriority($this->_db->f('max_num'));
									}

	function getLogTime() { return $this->log_time; }		function setLogTime($newLogTime) { $this->log_time = $newLogTime; }
	function getReportName() { return $this->report_name; }		function setReportName($newReportName) { $this->report_name = $newReportName; }
	function getAccount() { return $this->account; }		function setAccount($newAccount) { $this->account = $newAccount; }
	function getAccountId() { return $this->account_id; }		function setAccountId($newAccountId) { $this->account_id = $newAccountId; }
	function getCompany() { return $this->company; }		function setCompany($newCompany) { $this->company = $newCompany; }
	function getLogin() { return $this->login; }			function setLogin($newLogin) { $this->login = $newLogin; }
	function getContactName() { return $this->contact_name; }	function setContactName($newName) { $this->contact_name = $newName; }
	function getContactInformation() { return $this->contact_info; }
									function setContactInformationField($field, $value) {
										if ($this->contact_info === NULL || $this->contact_info == '') {
											$this->contact_info = array();	
										}
										$this->contact_info[$field] = $value;
									}
	function getEngineer() { return $this->engineer; }		function setEngineer($newName) { $this->engineer = $newName; }
	function getStatusCode() { return $this->status; }		function setStatusCode($newStatusCode) { $this->status = $newStatusCode; }
	function getStatus() { return $GLOBALS['DW_STATUS_CODES'][$this->status]; }
	function getDateCompleted() { return $this->date_completed; }	function setDateCompleted($newDate) { $this->date_completed = $newDate; }
	function getHoursSpent() { return $this->hours_spent; }		function setHoursSpent($newHours) { $this->hours_spent = $newHours; }

	// Data constraint getter/setters
	function getDataConstraint($name) {
		if (isset($this->data_constraints[$name])) {
			return $this->data_constraints[$name];
		}
		return NULL;
	}
	function setDataConstraint($name, $value) {
		if ($this->data_constraints == NULL) {
			$this->data_constraints = array();
		}
		$this->data_constraints[$name] = $value;		
	}

	function setPresetDateType($preset) {
		$this->setDataConstraint('date_type', 'preset');
		$this->setDataConstraint('date_preset', $preset);
		$this->setDataConstraint('date_from', date("m/d/y")); // stub field: will be filled in at execute time
		$this->setDataConstraint('date_to', date("m/d/y"));   // stub field: will be filled in at execute time
	}
	function setRangeDateType($dateFromTs, $dateToTs) {
		if (!is_numeric($dateFromTs) || !is_numeric($dateToTs)) {
			trigger_error('Invalid timestamp passed. MUST be a valid UNIX timestamp.', E_USER_ERROR);
		}
		$this->setDataConstraint('date_type', 'range');
		$this->setDataConstraint('date_preset', 'none');
		$this->setDataConstraint('date_from', date("m/d/y", $dateFromTs));
		$this->setDataConstraint('date_to', date("m/d/y", $dateToTs));
	}

	function getDateGranularity() {
		return $this->getDataConstraint( 'date_granularity' );
	}
	function setDateGranularity( $granularity ) {
		$this->setDataConstraint('date_granularity', $granularity);
	}

	function getSegmentId() {
		return $this->getDataConstraint('segment_id');
	}
	function setSegmentId( $segment_id ) {
		$this->setDataConstraint('segment_id', (string)$segment_id);
	}

	function getItemList() {
		return $this->getDataConstraint('item_list');
	}
	function addToItemList( $order, $metric_name, $is_metric_lookup ) {
		if (!isset($this->data_constraints['item_list'])) {
			$this->setDataConstraint('item_list', array());
		}
		if (!$is_metric_lookup && $metric_name[0] == '?') {
			$metric_name = substr($metric_name, 1);
		}
		$this->data_constraints['item_list'][$order] = $metric_name;
	}

	function getMetricList() {
		return $this->getDataConstraint('metric_list');
	}
	function addToMetricList( $order, $metric_name ) {
		if (!isset($this->data_constraints['metric_list'])) {
			$this->setDataConstraint('metric_list', array());
		}
		$this->data_constraints['metric_list'][$order] = $metric_name;
	}

	function getStatusText() { return $this->status_text; }		function setStatusText($text) { $this->status_text = $text; }
	function getHourEstimate() { return $this->est_hours; }		function setHourEstimate($hours) { $this->est_hours = $hours; }
	function getSpaceEstimate() { return $this->est_space; }	function setSpaceEstimate($space) { $this->est_space = $space; }
	function getDateScheduled() { return $this->date_scheduled; }	function setDateScheduled($newTime) { $this->date_scheduled = $newTime; }
	function getFileTypeCode() { return $this->file_type; }		function setFileTypeCode($newCode) { $this->file_type = $newCode; }
	function getFileType() { return $GLOBALS['DW_FILE_TYPES'][$this->file_type]; }
	function getMaxRows() { return $this->max_rows; }		function setMaxRows($newRows) { $this->max_rows = $newRows; }
	function getHeaderType() { return $this->header_type; }		function setHeaderType($newHeaderType) { $this->header_type = $newHeaderType; }
	function getPartitioning() { return $this->partitioning; }	function setPartitioning($newPart) { $this->partitioning = $newPart; }
	function getDataSet() { return $this->data_set; }		function setDataSet($newDataSet) { $this->data_set = $newLogTime; }
	function willRunVista() { return $this->run_vista; }		function setRunVista($newBool) { $this->run_vista = ($newBool ? true : false); }
	function getScheduleId() { return $this->schedule_id; }		function setScheduleId($newId) { $this->schedule_id = $newId; }
	function getSegmentGUID() { return $this->segment_guid; }		function setSegmentGUID($newId) { $this->segment_guid = $newId; }
	function getRequestedBy() { return $this->$is_api_request; } function setRequestedBy($newRequestedBy) { $this->requested_by = $newRequestedBy; }
	function getSendEmptyReports() { return $this->send_empty_reports; }	function setSendEmptyReports($newSendEmptyReports) { $this->send_empty_reports = $newSendEmptyReports;}
	function getBeta() { return $this->beta; }	function setBeta($val) { $this->beta = $val; }
	function getMetricsSort() { return $this->metrics_sort; }		function setMetricsSort($sort) { $this->metrics_sort = $sort; }

}

