<?php
/**
 * @file X509CertGen
 *
 * Generates a self-signed certificate
 *
 * Copyright 2006 Omniture, Inc. All Rights Reserved.
 * License at http://www.omniture.com/license/1_0.txt 
 *
 * @author Kole Winters <kwinters@omniture.com>
 * @copyright 2006 Omniture, Inc. All Rights Reserved
 * @version CVS: $Id$
 **/


/**
 * This class will generate an x509 certificate and return
 * back the private and public keys in PEM format.  It will
 * also return the CSR
 *
 * Note: Please read the documentation on the following site:
 * 		 http://us2.php.net/manual/en/function.openssl-csr-new.php
 */

class X509CertGen {
		
		/**
		 * The resulting PEM formatted private key after generate()
		 */
		var $private_key;

		/**
		 * The resulting PEM formatted public key after generate()
		 */
		var $public_key;


		function X509CertGen(){
			// no functionality
		}


		/**
		 * Generates the key based on the parameters passed in
		 *
		 * @param	$numberofdays	(int)		The number of days the cert is valid.  Default
		 * 										is one year (365)
		 * @param	$dn				(array)		The information for the distinguished name see
		 * 										the website in the class description for more 
		 * 										details
		 * @param	$config_options	(array)		Contains configuration options such as the digest
		 * 										algorithm.  Again, see the website on php.net
		 * @param	$password		(string)	If a password is to be added to the private key
		 *
		 * @return	(bool)						Returns true if the cert was generated successfully
		 */
		function generate($numberofdays=365,$dn=array(),$config_options=array(),$password=''){
			
			$privkey = openssl_pkey_new();
			$csr = openssl_csr_new($dn, $privkey, $config_options);
			$sscert = openssl_csr_sign($csr, null, $privkey, $numberofdays);
			openssl_x509_export($sscert, $this->public_key);
			if ($password) {
				openssl_pkey_export($privkey, $this->private_key, $password);
			} else {
				openssl_pkey_export($privkey, $this->private_key);
			}
			openssl_csr_export($csr, $this->csr_str);
	
	
			if ($this->private_key && $this->public_key && $this->csr_str) {
				return true;
			} else {
				return false;
			}	
			
		}

		/**
		 * Returns the private key from generate()
		 *
		 * @return (string) The PEM formatted private key
		 */
		function getPrivateKey() {
			return $this->private_key;
		}

		/**
		 * Returns the public key from generate()
		 *
		 * @return (string) The PEM formatted public key
		 */
		function getPublicKey() {
			return $this->public_key;
		}

		/**
		 * Returns the exported certificate from generate()
		 *
		 * @return (string) The PEM formatted certificate
		 */
		function getCSR() {
			return $this->csr_str;
		}

		/**
		 * Returns all three keys in one string
		 *
		 * @return (string) all three keys in one string
		 */
		function getFullCert() {
			return $this->private_key.$this->public_key.$this->csr_str;
		}

		/**
		 * Returns any errors
		 *
		 * @return (array) an array of any errors
		 */
		function getErrors() {
			$rtn = array();
			while (($e = openssl_error_string()) !== false) {
		   		array_push($rtn,$e);
			}
			return $rtn;
		}
}
