<?php
/*************************************************************************
 * ADOBE CONFIDENTIAL
 * __________________
 *
 *  Copyright (c) 2014 Adobe Systems Incorporated
 *  All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and are protected by all applicable intellectual property
 * laws, including trade secret and copyright laws.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 **************************************************************************/

/**
 * @file
 * @see SetupString::HELP()
 *
 * @author  Jack Thomasson <thomasso@adobe.com>
 *
 * @version $Id: $
 */
require_once 'AdjustString.class.php';
require_once 'CacheAllocationTypes.class';
require_once 'FragAllocationTypes.class';
require_once 'user_account.class';

class SetupStringException extends AdjustStringException {};
class SetupStringMissingBRSException extends SetupStringException {};
class SetupStringDropException extends SetupStringException {};

/**
 * @class SetupString - concise representation of base or report suite (BRS) setup
 */
class SetupString extends AdjustString {
	const MATCH_COMBINE = 'COMBINE';
	const MATCH_BRS = 'BRS';
	const MATCH_DROP = 'DROP';
	private static $preg; ///< regular expression used by Iterator
	private $dropping = [self::CACHE => 0, self::FRAG => 0]; ///< tristates: <0 dropping, >0 not dropping, =0 unknown

	public static function __init() {
		$usages = self::ABBREVS();
		$atypes = self::ATYPES();
		global $localConfig;
		$MODE = self::MATCH_MODE;
		$USAGE = self::MATCH_USAGE;
		$ALLOCATION = self::MATCH_ALLOCATION;
		$DC = self::MATCH_DC;
		$COUNT = self::MATCH_COUNT;
		$ATYPE = self::MATCH_ATYPE;
		$DOMAIN = self::DOMAIN;
		$COUNTONLY = self::COUNTONLY;
		$COMBINE = self::MATCH_COMBINE;
		$BRS = self::MATCH_BRS;
		$DROP = self::MATCH_DROP;
		self::$preg = "/^(?:(?:(?<$COMBINE>[[:alnum:]][^+:]*?)\+)|(?:,?(?<$BRS>[[:alnum:]].*?|\^):)?(?:[,+]?(?<$USAGE>[".join('', $usages)."]:))?(?:\+?(?<$ALLOCATION>(?<$DC>".join('|',array_merge(array_flatten($localConfig['data_center_hostname_suffix_list']),['\?']))."):(?<$COUNT>\d+):(?<$ATYPE>[".join('', array_unique($atypes))."])|[[:alpha:]][-[:alnum:].]*\.(?<$DOMAIN>".join('|',array_flatten($localConfig['data_center_hostname_suffix_list']))."))|(?<$COUNTONLY>\d+[^,+]*))|!(?<$DROP>[[:alnum:]][^,]*))/i";
	}

	/**
	 * dropping the cache base or dedicated frag?
	 */
	public function dropping($service = self::CACHE) {
		if (0 == $this->dropping[$service])
			foreach ($this as $match)
				/**/;
		return $this->dropping[$service] < 0;
	}

	/**
	 * combining a base onto another?
	 * @return array [0 => moving, 1 => onto]
	 */
	public function combining() {
		$ret = [];
		$this->rewind();
		if (!$this->valid() or !($ret[0] = $this->matches[self::MATCH_COMBINE]))
			return [];
		$this->next();
		if (!$this->valid() or !($ret[1] = $this->matches[self::MATCH_BRS]))
			return [];
		return $ret;
	}

	/**
	 * retrieve the current base from the SetupString
	 * @warning rewinds SetupString, avoid inside foreach loop
	 */
	public function base() {
		if (!$this->matches[self::MATCH_BRS]) {
			$this->rewind();
			if (!$this->valid())
				return FALSE;
		}
		return $this->matches[self::MATCH_BRS];
	}

	/**
	 * the regular expression used for parsing
	 */
	protected function preg() {
		return self::$preg;
	}

	/**
	 * extra validation for valid()
	 */
	protected function extra_validation(array $last) {
		if ($this->matches[self::MATCH_DROP]) {
			$this->matches[self::MATCH_BRS] = $this->matches[self::MATCH_DROP];
			$this->dropping[self::CACHE] = -1;
			return TRUE;
		}
		if ($this->matches[self::MATCH_COMBINE]) {
			$this->matches[self::MATCH_BRS] = $this->matches[self::MATCH_COMBINE];
			$this->dropping[self::CACHE] = 1;
			return TRUE;
		}
		if ($this->matches[self::MATCH_BRS] and !$this->matches[self::MATCH_USAGE]) {
			$this->matches[self::MATCH_USAGE] = $this->matches[self::MATCH_BRS].':';
			$this->matches[self::MATCH_BRS] = NULL;
		}
		if (!$this->matches[self::MATCH_BRS] and !($this->matches[self::MATCH_BRS] = $last[self::MATCH_BRS]))
			throw new SetupStringMissingBRSException('missing base or report_suite');
		if ('0' === $this->matches[self::COUNTONLY]) {
			switch (self::$mapper[$this->matches[self::MATCH_USAGE]]) {
			case CacheServerUsage::HOTEL:
				$service = self::CACHE;
				break;
			case FragServerUsage::COMBO:
				$service = self::FRAG;
				break;
			default:
				throw new SetupStringDropException('drop must use '.CacheServerUsage::HOTEL.' or '.FragServerUsage::COMBO);
			}
			if ($this->dropping[$service] > 0)
				throw new SetupStringDropException('drop must stand alone');
			$this->dropping[$service] = -1;
			$this->matches[self::MATCH_DROP] = $this->matches[self::MATCH_BRS];
		} else if ($this->matches[self::MATCH_COUNT] or $this->matches[self::COUNTONLY]) {
			foreach (self::$tracker as $service => $usage)
				foreach ($usage['usage'] as $abbrev => $usage)
					if (strtoupper($this->matches[self::MATCH_USAGE]) == $abbrev) {
						if ($this->dropping[$service] < 0)
							throw new SetupStringDropException('drop must stand alone');
						$this->dropping[$service] = 1;
						break 2;
					}
		}
		return FALSE;
	}

/*
 * provide descriptive help and samples
 * @return array [0] => help, [1+] => samples
 */
	public static function HELP() {
		/// @warning Proposal::HELP uses these values directly
		static $HELP;
		if (!$HELP) {
			$HELP = [<<<TEXT
a concise representation of base or report suite (BRS) setup.  some parts are optional, mainly to avoid repetition.  ? may used as a placeholder for dc or atype or both may be omitted together leaving just count.  a server name may be specified instead of the dc:count:atype tuple.  specifying only 0 hotels indicates dropping a cache base.  specifying only 0 combos indicates dropping dedicated frag.  an older syntax using a leading exclamation mark to drop a cache base is deprecated.
canonical forms are:
[combine+]BRS:usage:dc:count:atype[+dc:count:atype]...[,usage:dc:count:atype]...[,usage:count]
TEXT
			         ,
			         'applecnip:H:oak1:1:v',
			         'applestoreapacaui:H:oak1:1:g',
			         'applestoreapacaui:H:0,C:oak1:1:b',
			         'applecnip:C:0',
				];
			$HELP[] = 'applecnip+'.$HELP[2];
		}
		return $HELP;
	}
}
SetupString::__init();

/**
 * SELFTEST
 * Usage: php  SetupString.class.php
 */
if (!(version_compare(PHP_VERSION, '5.3.6', '<') ? debug_backtrace(FALSE) :
      (version_compare(PHP_VERSION, '5.4.0', '<') ? debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) :
       debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 1)))) {
	if (function_exists('xdebug_break')) xdebug_break();
	define('DEBUG_MESSAGES', 1);

	if (1 < count($argv))
		array_splice($argv, 0, 1);
	else
		$argv = split("\n", <<<SAMPLE
applecnip:L:ut1:5:g,E:ut1:5:g
applecnip:L:ut1:4:g,E:ut1:4:g,H:ut1:1:g
applestoreapacaui:H:ut1:1:g
applecnip+applestoreapacaui:H:ut1:1:g
!applestoreapacaui
applestoreapachkconsum:L:ut1:6:g,E:ut1:6:e
^:L:ut1:5:g,E:ut1:5:e,H:ut1:1:e
geo1metrixx:L:ut1:2:E+ut1:3:H,E:ut1:15:E
backwards-compatible:L:ut1:2:E+ut1:3:H+E:ut1:6:E
ha-testing-mg:H:?:2:e
ha-testing-mg:H:ut1:1:?
ha-testing-mg:H:1
ha-testing-jkt:H:ut1:1:g,ha-testing-mg:H:ut1:1:e
ha-testing-jkt+ha-testing-mg:H:ut1:1:e
ha-testing-jkt:F:ut1:1:b,ha-testing-mg:C:ut1:1:e
one-each:L:ut1:1:s+ut1:1:l,E:ut1:1:h+ut1:1:g,H:ut1:1:e+ut1:1:v,F:ut1:1:l+ut1:1:c,C:ut1:1:b+ut1:1:d,U:ut1:1:e
two-named-servers:F:db122.ut1,E:scvm102.dev.ut1+ut1:1:?
!drop-and-reduce,C:ut1:1:c
random-frag:C:ut1:1:?
drop-cache:H:0
drop-frag:C:0
SAMPLE
		             );
	foreach ($argv as $s) {
		echo "\nprocess $s\n";
		$a = SetupString::withString($s);
		$dropping = ($a->dropping() or $a->dropping(SetupString::FRAG)) ? 'TRUE' : 'FALSE';
		if (($b = $a->combining()))
			echo "Combining $b[0] onto $b[1]\n";
		foreach ($a as $matches)
			echo<<<EOF
COMBI={$matches[SetupString::MATCH_COMBINE]}
BRS  ={$matches[SetupString::MATCH_BRS]}
USAGE={$matches[SetupString::MATCH_USAGE]}
ALLOC={$matches[SetupString::MATCH_ALLOCATION]}
DC   ={$matches[SetupString::MATCH_DC]}
COUNT={$matches[SetupString::MATCH_COUNT]}
ATYPE={$matches[SetupString::MATCH_ATYPE]}
DROP =$dropping


EOF;
	}
	$exit = 0;
	foreach (['invalid-atype:L:ut1:1:b' => 'invalid atype=b for group=Cache',
	          'ut1:1:b' => 'missing base or report_suite',
	          '^extended:H:1' => 'could not parse',
	          'F:+ut1:1:b' => 'missing base or report_suite',
	          'wrong-datacenter:F:+sbx1:1:b' => 'wrong datacenter',
	          'L:ut1:1:b' => 'missing base or report_suite',
	          'drop-embellish-pre:L:1,H:0' => 'drop must stand alone',
	          'drop-embellish-post:C:0,F:1' => 'drop must stand alone',
	          'drop-using-lobby:L:0' => 'drop must use '.CacheServerUsage::HOTEL.' or '.FragServerUsage::COMBO,
	          'missing-datacenter:L:2:v' => 'missing datacenter',
	         ] as $s => $m) {
		echo "\nprocess $s\n";
		try {
			$a = SetupString::withString($s);
			foreach ($a as $matches)
				var_export($matches);
			fwrite(STDERR, "Missed Exception for '$m'!\n");
			$exit = 1;
		}
		catch (Exception $e) {
			$e = $e->getMessage();
			if ($m == $e)
				echo "Good! caught '$e'\n";
			else {
				fwrite(STDERR, "Bad! expected '$m', caught '$e'\n");
				$exit = 1;
			}
		}
	}
	exit($exit);
}
