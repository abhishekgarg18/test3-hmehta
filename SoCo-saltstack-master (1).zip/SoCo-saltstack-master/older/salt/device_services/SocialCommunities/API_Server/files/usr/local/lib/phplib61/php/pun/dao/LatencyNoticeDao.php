<?php
require_once "pun/model/LatencyNotice.php";
require_once "log4php/Logger.php";
L4P_Logger::configure('pun/LogConfig.xml');

/**
 * Implements methods for creating, storing, retrieving and modifying Notifications
 * @author gpaulsen
 *
 */
class LatencyNoticeDao
{
	private $qc = '/*PowerUp Notices: LatencyNoticeDao*/';
	private $tableName = 'latency_notice';
	private $definitionTableName = 'latency_notice_definition';
	private $dbName = 'compassdb';
	private $emailTemplateTableName = 'email_templates';
	private $log;
	
	public function __construct()
	{
		$this->log = L4P_Logger::getLogger(__CLASS__);
	}
	
	/**
	 * Retrieves a single LatencyNotice record from the database based on the given id
	 * 
	 * @param int $id database id for the desired db record.
	 */
	public function getLatencyNotice($id)
	{
		$this->log->debug('Retrieving LatencyNotice with id $id');
		$latencyNotice = null;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc notice_id,notice_def_id,sent_time,to_email,cc_email,bcc_email,text_version 
			    FROM $this->tableName   
			    WHERE notice_id = $id";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyNotice = new LatencyNotice();
			$latencyNotice->setID($db->f('notice_id'));
			$latencyNotice->setDefId($db->f('notice_def_id'));
			$latencyNotice->setSentTime($db->f('sent_time'));
			$latencyNotice->setTo($db->f('to_email'));
			$latencyNotice->setCc($db->f('cc_email'));
			$latencyNotice->setBcc($db->f('bcc_email'));
			$latencyNotice->setEmailVersion($db->f('text_version'));
		}
		$db->close();

		return $latencyNotice;
	}
	
	/**
	 * Saves a single LatencyNotice to the database as a new record
	 * @param LatencyNotice $latencyNotice
	 */
	public function saveLatencyNotice($notice)
	{
		$this->log->debug("Saving LatencyNotice for definition $notice->getDefId()");
		$db =  new DB_Sql($this->dbName);
		$sql = "INSERT INTO $this->qc $this->tableName (notice_def_id,to_email,cc_email,bcc_email,text_version)
				VALUES (".$notice->getDefId().",'".$notice->getTo()."','".$notice->getCc()."','".$notice->getBcc()."',".$notice->getEmailVersion().")
				ON DUPLICATE KEY UPDATE notice_id=LAST_INSERT_ID(notice_id)";

		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		
		if($db->squery("SELECT LAST_INSERT_ID()"))
		{
			$notice->setID($db->f('LAST_INSERT_ID()'));
		}
		
		$db->close();
		
		return $notice;
	}
	
	/**
	 * Deletes the latency notice with the given id
	 * @param int $id
	 */
	public function deleteLatencyNotice($id)
	{
		$this->log->debug("Deleting LatencyNotice with id of $id");
		$db =  new DB_Sql($this->dbName);
		$sql = "DELETE from $this->tableName where notice_id = $id";
		$this->log->debug("Executing SQL: $sql");
		$db->squery($sql);
		
		$db->close();
	}

	/**
	 * retrieves all LatencyNotice rows from the database that match the given rsid
	 * @param string $rsid
	 */
	public function getLatencyNotices($latencyNoticeSelector)
	{
		$this->log->debug("Retrieving LatencyNotices using selector");
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc notice_id,n.notice_def_id,sent_time,to_email,cc_email,bcc_email,text_version,company,companyid,billing_customer_id,billing_customer_name
				FROM $this->tableName n JOIN $this->definitionTableName nd on n.notice_def_id = nd.notice_def_id";
				
		$fieldValues = $this->getPopulatedFieldsFromSelector($latencyNoticeSelector);
		if(sizeof($fieldValues) > 0)
		{
			$sql .= "\n\t\t\tWHERE ".implode(" AND ",$fieldValues);
		}
		
		$sql .= " ORDER BY sent_time DESC";
		
		
		if ($latencyNoticeSelector->getResultCountLimit()) 
		{
			$count = $latencyNoticeSelector->getResultCountLimit();
			$start = $latencyNoticeSelector->getResultStartindex();
			$sql .= "\n\t\t\tLIMIT $start, $count";
		}
		
		$latencyEventDao = new LatencyEventDao();
		$latencyNoticeRows = array();
		$this->log->debug("Executing SQL: $sql");
		$db->query($sql);
		while($db->next_record()) 
		{
			$latencyNotice = new LatencyNotice();
			$latencyNotice->setId($db->f('notice_id'));
			$latencyNotice->setDefId($db->f('notice_def_id'));
			$latencyNotice->setSentTime($db->f('sent_time'));
			$latencyNotice->setTo($db->f('to_email'));
			$latencyNotice->setCc($db->f('cc_email'));
			$latencyNotice->setBcc($db->f('bcc_email'));
			$latencyNotice->setEmailVersion($db->f('text_version'));
			
			$latencyNoticeRows[] = $latencyNotice;
		}
		$db->close();
		
		return $latencyNoticeRows;
	}
	
	public function getLastLatencyNotice($companyid)
	{
		$this->log->debug("Retrieving most recent LatencyNotice for company id $companyid");
		$latencyNotice = null;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc notice_id,n.notice_def_id,sent_time,to_email,cc_email,bcc_email,text_version,companyid 
			    FROM $this->tableName n JOIN $this->definitionTableName nd on n.notice_def_id = nd.notice_def_id   
			    WHERE companyid = $companyid ORDER BY sent_time DESC limit 1";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$latencyNotice = new LatencyNotice();
			$latencyNotice->setID($db->f('notice_id'));
			$latencyNotice->setDefId($db->f('notice_def_id'));
			$latencyNotice->setSentTime($db->f('sent_time'));
			$latencyNotice->setTo($db->f('to_email'));
			$latencyNotice->setCc($db->f('cc_email'));
			$latencyNotice->setBcc($db->f('bcc_email'));
			$latencyNotice->setEmailVersion($db->f('text_version'));
		}
		$db->close();

		return $latencyNotice;
	}
	
	public function getLastLatencyNoticeForUser($userid)
	{
		$this->log->debug("Retrieving most recent LatencyNotice for user id $userid");
		$notice = null;
		$db =  new DB_Sql($this->dbName);
		$sql = "SELECT $this->qc notice_id 
			    FROM $this->tableName  
			    WHERE notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE userid = $userid)
			    ORDER BY sent_time DESC limit 1";

		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$noticeId = $db->f('notice_id');
			$notice = $this->getlatencyNotice($noticeId);
		}
		$db->close();

		return $notice;
		
	}
	
	public function getLastIncidentStartNotice($companyid)
	{
		$notice = NULL;
		$this->log->debug('Retrieving most recent Latency Start LatencyNotice for user $userid');
		$sql = "SELECT $this->qc e.notice_id,
       			MAX(CASE WHEN e.event_type = 1 THEN 1 ELSE 0 END) as event_type_1,
       			MAX(CASE WHEN e.event_type = 2 THEN 1 ELSE 0 END) as event_type_2,
       			MAX(CASE WHEN e.event_type = 3 THEN 1 ELSE 0 END) as event_type_3
       			FROM latency_notice n
				INNER JOIN latency_event e
    			ON n.notice_id = e.notice_id
				GROUP BY e.notice_id
				HAVING event_type_1 = 1
   				AND event_type_2 = 0
   				AND event_type_3 = 0
				ORDER BY sent_time DESC LIMIT 1";
		
		$db =  new DB_Sql($this->dbName);
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$noticeId = $db->f('e.notice_id');
			if(!is_null($noticeId) && $noticeId > 0)
			{
				$notice = $this->getlatencyNotice($noticeId);
			}
		}
		$db->close();

		return $notice;
	}
	
	public function getLastIncidentEndNotice($companyid)
	{
		$notice = NULL;
		$this->log->debug('Retrieving most recent Latency Start LatencyNotice for user $userid');
		$sql = "SELECT $this->qc e.notice_id,
       			MAX(CASE WHEN e.event_type = 1 THEN 1 ELSE 0 END) as event_type_1,
       			MAX(CASE WHEN e.event_type = 2 THEN 1 ELSE 0 END) as event_type_2,
       			MAX(CASE WHEN e.event_type = 3 THEN 1 ELSE 0 END) as event_type_3
       			FROM latency_notice n
				INNER JOIN latency_event e
    			ON n.notice_id = e.notice_id
				GROUP BY e.notice_id
				HAVING event_type_1 = 0
   				AND event_type_2 = 0
   				AND event_type_3 = 1
				ORDER BY sent_time DESC LIMIT 1";
		
		$db =  new DB_Sql($this->dbName);
		$this->log->debug("Executing SQL: $sql");
		if($db->squery($sql))
		{
			$noticeId = $db->f('e.notice_id');
			if(!is_null($noticeId) && $noticeId > 0)
			{
				$notice = $this->getlatencyNotice($noticeId);
			}
		}
		$db->close();

		return $notice;
	}
	
	/*
	 * Builds an array of database field names and associated values. eg, (userid => 'sistr2')
	 * This is used in building where clauses dynamically.
	 * 
	 * @param LatencyNoticeSelector  $selector  
	 */
	private function getPopulatedFieldsFromSelector(LatencyNoticeSelector $selector)
	{
		$values = array();
		if($selector == NULL)
		{
			return $values;
		}
		
		if($selector->getLatencyNoticeDefinitionId() != null && $selector->getLatencyNoticeDefinitionId() > 0)
		{
			$values[] = "n.notice_def_id = ".$selector->getLatencyNoticeDefinitionId(); 
		}

		if($selector->getRsid() != null && strlen($selector->getRsid()) > 0)
		{
			$values[] = "n.notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE username = '" . $selector->getRsid() . "')";
		}
			
		if($selector->getUserId() != null && $selector->getUserId() > 0)
		{
			$values[] = "n.notice_def_id = (SELECT notice_def_id FROM latency_event_definition WHERE userid = " . $selector->getUserId() . ")";
		}
		
		if($selector->getLoginCompany() != null && strlen($selector->getLoginCompany()) > 0)
		{
			$values[] = "company = '".addslashes($selector->getLoginCompany())."'"; 
		}	
		
		if($selector->getBillingCustomerName() != null && strlen($selector->getBillingCustomerName()) > 0)
		{
			$values[] = "billing_customer_name = '".addslashes($selector->getBillingCustomerName())."'"; 
		}

		if($selector->getStartDate() != NULL && $selector->getEndDate() != NULL)
		{
			$values[] = "sent_time >= '".date('Y-m-d 00:00:00', strtotime(str_replace('-', '/', $selector->getStartDate())))."'";
			$values[] = "sent_time <= '".date('Y-m-d 23:59:59', strtotime(str_replace('-', '/', $selector->getEndDate())))."'";
		}
		
		$this->log->debug("Selector field values: ".implode($values));
					
		return $values;
	}
	
}
