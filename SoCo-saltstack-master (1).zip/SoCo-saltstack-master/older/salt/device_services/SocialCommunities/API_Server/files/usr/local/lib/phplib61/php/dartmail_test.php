#! /usr/local/bin/php

<?php

require('dartmail_controller.inc');

$test = new dartmail_controller();
$test->debugging = true;


$test->execute();

/*
$connection_parameters = array();
//$connection_parameters['server_url'] = 'https://login.rd.dartmail.net/dmconnect45/dmconnect.exe';
//$connection_parameters['server_url'] = 'https://login.rd.dartmail.net/dmconnect45/';
//$connection_parameters['server_url'] = 'https://www.daemonmaker.net/';
$connection_parameters['server_name'] = 'qacore1dm1';
$connection_parameters['username'] = 'omnituredev';
$connection_parameters['password'] = 'Password1';
$connection_parameters['client_name'] = 'QA_Jrm_Huron';
$connection_parameters['site_name'] = 'QA_Jrm_Huron1';
$connection_parameters['email_addresses'] = array('dwebb@omniture.com', 'awinters@omniture.com', 'dwalbeck@omniture.com'); // To be pulled from Data Sources
$connection_parameters['email_addresses'] = array('someinvalidemail');

// These could probably be custom fields.
//$connection_parameters['version'] = '4.5';
//$connection_parameters['option'] = 0;

//print_r($test->test_connection($connection_parameters));
*/
?>
