# Salt

cis/ contains remediation states for individual CentOS 6.x CIS policy settings.  



'
